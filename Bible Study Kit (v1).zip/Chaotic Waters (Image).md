links: [[Biblical Themes and Images MOC]]
# Chaotic Waters (Image)
This is the first image that is given in the Bible ([[Gen-01#v2]]) . It’s meant to convey a state of un-creation, a state that is uninhabitable and unwelcoming of life.

## Chaotic Waters are often become personified as evil
In the story of the Exodus, Pharaoh and his army are compared to chaotic waters in [[Exod-15]]. This is similar to the portrayal in [[Ps-18]].y

## Chaotic Waters and New Creation prophecies
The defeat of chaotic, unpredictable evil is anticipated in many prophecies:

* [[Isa-02#v1]]
* [[Zech-14#v8]]

Jesus asserts his authority over danger and death when he walked on water. That's why it is described in three Gospels:
* [[Matt-14#v22]]
* [[John-06#v15]]
* [[Mark-06#v45]]