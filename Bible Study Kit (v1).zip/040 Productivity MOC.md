---
aliases: [Productivity MOC]
---
links: [[000 Home|Home]]
# Productivity MOC
![[Eccles-09#v10]]


## Work: Non-optional
First off, [[Work is a blessing]]. Not contributing we go against the grain of our calling.


## Advancing the creation project: How?
### Working like God works
With [[Excellence]], hard work and with focused attention. 

Working in our specific calling with limitations and passions as signposts. In *koinonia* partnership with God.

## Work, a temptation
### The tragic cliche: Working for your own glory
[[Work is broken]]. It is so easy to look to work for identity, status and fulfillment. Sabbath is one of the ways we can resist our plunge into the consumption and celebretyism machine.

### The antidote: True greatness
In God's upside-down Kingdom the mundane, lowly and unimportant is what true greatness looks like.