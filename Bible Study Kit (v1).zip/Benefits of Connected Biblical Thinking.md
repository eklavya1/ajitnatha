# Benefits of Connected Biblical Thinking
There are plenty of benefits in using Obsidian for Bible Study (and your personal notes). Using [[Connected Biblical Thinking]] in Obsidian helps you to *retrieve*, *remember* and *engage* with Scripture.

Dive into the benefits here:
* Retrieve: [[Connecting simplifies retrieving]]
* Remember: [[Connecting strengthens remembering]]
* Engage: [[Connecting makes you engage Scripture]]