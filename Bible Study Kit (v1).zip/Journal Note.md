links: [[Examples of deductive note-taking]]
# Journal Note
## Sun, Jan 31
I am working on a project currently that I feel like God has called me into. It's not moving forward quickly though, a bit tough and a test of patience. 

An opportunity for a shortcut came up and I was praying about whether to take it. While thinking about this decision for some days, a person approached me and shared that they felt like taking the shortcut would be like Abraham's and Sarah's temptation with Hagar ([[Gen-16#v2]]).

After praying about it some more, I continued going forward with it and it was a big success.

***
# Commentary
In journal notes we can easily link to specific Bible passages that spoke (or have been spoken) to us. Whenever I open the [[Gen-16]] chapter, I see how it was relevant in my own life.