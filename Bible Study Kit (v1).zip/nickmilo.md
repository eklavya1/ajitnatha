# nickmilo
Nick was very influential in providing an approach to note-*making* that is fun, focused on creating and future-proof.

His [LYT Kit](https://forum.obsidian.md/t/lyt-kit-now-downloadable/390) is a great place to get started. He also provides a [Beginner's Guide to Obsidian](https://www.youtube.com/watch?v=QgbLb6QCK88&list=PL3NaIVgSlAVLHty1-NuvPa9V0b0UwbzBd) on YouTube.