links: [[Examples of deductive note-taking]]
# Design
## God values beauty
[[Gen-02#v9]]. He created them "pleasing to the eye". The first person filled with the Holy Spirit was a designer ([[Exod-31#v2]]).

## Design points toward the beauty behind the beauty
[[1 Cor-10#v31]] explains how even something as mundane as drinking or eating can be done for the glory of God. In designing work we can show people the *beauty behind the beauty*.

We are called to do this with [[Excellence]].
