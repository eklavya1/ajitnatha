# Glossary
* **LYT**: "Linking your Thinking", a framework by [[nickmilo]] for note-making (See the [website](https://linkingyourthinking.com))
* **MOC**: "Maps of content", overview notes that consolidate notes to group ideas and allow simple navigation
* **Emergence**: When things come together and form more than the sum of their part.