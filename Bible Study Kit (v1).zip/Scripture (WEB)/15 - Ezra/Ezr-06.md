# Ezra 6

[[Ezr-05|← Ezra 05]] | [[Ezra]] | [[Ezr-07|Ezra 07 →]]
***



###### v1 
Then Darius the king made a decree, and the house of the archives, where the treasures were laid up in Babylon, was searched. 

###### v2 
A scroll was found at Achmetha, in the palace that is in the province of Media, and in it this was written for a record: 

###### v3 
In the first year of Cyrus the king, Cyrus the king made a decree: Concerning God's house at Jerusalem, let the house be built, the place where they offer sacrifices, and let its foundations be strongly laid; with its height sixty cubits, and its width sixty cubits; 

###### v4 
with three courses of great stones and a course of new timber. Let the expenses be given out of the king's house. 

###### v5 
Also let the gold and silver vessels of God's house, which Nebuchadnezzar took out of the temple which is at Jerusalem, and brought to Babylon, be restored and brought again to the temple which is at Jerusalem, everything to its place. You shall put them in God's house. 

###### v6 
Now therefore, Tattenai, governor beyond the River, Shetharbozenai, and your companions the Apharsachites, who are beyond the River, you must stay far from there. 

###### v7 
Leave the work of this house of God alone; let the governor of the Jews and the elders of the Jews build this house of God in its place. 

###### v8 
Moreover I make a decree what you shall do for these elders of the Jews for the building of this house of God: that of the king's goods, even of the tribute beyond the River, expenses must be given with all diligence to these men, that they not be hindered. 

###### v9 
That which they have need of, including young bulls, rams, and lambs, for burnt offerings to the God of heaven; also wheat, salt, wine, and oil, according to the word of the priests who are at Jerusalem, let it be given them day by day without fail; 

###### v10 
that they may offer sacrifices of pleasant aroma to the God of heaven, and pray for the life of the king, and of his sons. 

###### v11 
I have also made a decree that whoever alters this message, let a beam be pulled out from his house, and let him be lifted up and fastened on it; and let his house be made a dunghill for this. 

###### v12 
May the God who has caused his name to dwell there overthrow all kings and peoples who stretch out their hand to alter this, to destroy this house of God which is at Jerusalem. I Darius have made a decree. Let it be done with all diligence. 

###### v13 
Then Tattenai, the governor beyond the River, Shetharbozenai, and their companions did accordingly with all diligence, because Darius the king had sent a decree. 

###### v14 
The elders of the Jews built and prospered, through the prophesying of Haggai the prophet and Zechariah the son of Iddo. They built and finished it, according to the commandment of the God of Israel, and according to the decree of Cyrus, Darius, and Artaxerxes king of Persia. 

###### v15 
This house was finished on the third day of the month Adar, which was in the sixth year of the reign of Darius the king. 

###### v16 
The children of Israel, the priests, the Levites, and the rest of the children of the captivity, kept the dedication of this house of God with joy. 

###### v17 
They offered at the dedication of this house of God one hundred bulls, two hundred rams, four hundred lambs; and for a sin offering for all Israel, twelve male goats, according to the number of the tribes of Israel. 

###### v18 
They set the priests in their divisions, and the Levites in their courses, for the service of God, which is at Jerusalem, as it is written in the book of Moses. 

###### v19 
The children of the captivity kept the Passover on the fourteenth day of the first month. 

###### v20 
Because the priests and the Levites had purified themselves together, all of them were pure. They killed the Passover for all the children of the captivity, for their brothers the priests, and for themselves. 

###### v21 
The children of Israel who had returned out of the captivity, and all who had separated themselves to them from the filthiness of the nations of the land, to seek Yahweh, the God of Israel, ate, 

###### v22 
and kept the feast of unleavened bread seven days with joy; because Yahweh had made them joyful, and had turned the heart of the king of Assyria to them, to strengthen their hands in the work of God, the God of Israel's house.

***
[[Ezr-05|← Ezra 05]] | [[Ezra]] | [[Ezr-07|Ezra 07 →]]
