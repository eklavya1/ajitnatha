# Ezra 8

[[Ezr-07|← Ezra 07]] | [[Ezra]] | [[Ezr-09|Ezra 09 →]]
***



###### v1 
Now these are the heads of their fathers' households, and this is the genealogy of those who went up with me from Babylon, in the reign of Artaxerxes the king: 

###### v2 
Of the sons of Phinehas, Gershom. Of the sons of Ithamar, Daniel. Of the sons of David, Hattush. 

###### v3 
Of the sons of Shecaniah, of the sons of Parosh, Zechariah; and with him were listed by genealogy of the males one hundred fifty. 

###### v4 
Of the sons of Pahathmoab, Eliehoenai the son of Zerahiah; and with him two hundred males. 

###### v5 
Of the sons of Shecaniah, the son of Jahaziel; and with him three hundred males. 

###### v6 
Of the sons of Adin, Ebed the son of Jonathan; and with him fifty males. 

###### v7 
Of the sons of Elam, Jeshaiah the son of Athaliah; and with him seventy males. 

###### v8 
Of the sons of Shephatiah, Zebadiah the son of Michael; and with him eighty males. 

###### v9 
Of the sons of Joab, Obadiah the son of Jehiel; and with him two hundred eighteen males. 

###### v10 
Of the sons of Shelomith, the son of Josiphiah; and with him one hundred sixty males. 

###### v11 
Of the sons of Bebai, Zechariah the son of Bebai; and with him twenty-eight males. 

###### v12 
Of the sons of Azgad, Johanan the son of Hakkatan; and with him one hundred ten males. 

###### v13 
Of the sons of Adonikam, who were the last; and these are their names: Eliphelet, Jeuel, and Shemaiah; and with them sixty males. 

###### v14 
Of the sons of Bigvai, Uthai and Zabbud; and with them seventy males. 

###### v15 
I gathered them together to the river that runs to Ahava; and there we encamped three days: and I looked around at the people and the priests, and found there were none of the sons of Levi. 

###### v16 
Then I sent for Eliezer, for Ariel, for Shemaiah, for Elnathan, for Jarib, for Elnathan, for Nathan, for Zechariah, and for Meshullam, chief men; also for Joiarib and for Elnathan, who were teachers. 

###### v17 
I sent them out to Iddo the chief at the place Casiphia; and I told them what they should tell Iddo, and his brothers the temple servants, at the place Casiphia, that they should bring to us ministers for the house of our God. 

###### v18 
According to the good hand of our God on us they brought us a man of discretion, of the sons of Mahli, the son of Levi, the son of Israel; and Sherebiah, with his sons and his brothers, eighteen; 

###### v19 
and Hashabiah, and with him Jeshaiah of the sons of Merari, his brothers and their sons, twenty; 

###### v20 
and of the temple servants, whom David and the princes had given for the service of the Levites, two hundred twenty temple servants. All of them were mentioned by name. 

###### v21 
Then I proclaimed a fast there, at the river Ahava, that we might humble ourselves before our God, to seek from him a straight way for us, and for our little ones, and for all our possessions. 

###### v22 
For I was ashamed to ask of the king a band of soldiers and horsemen to help us against the enemy on the way, because we had spoken to the king, saying, "The hand of our God is on all those who seek him, for good; but his power and his wrath is against all those who forsake him." 

###### v23 
So we fasted and begged our God for this: and he granted our request. 

###### v24 
Then I set apart twelve of the chiefs of the priests, even Sherebiah, Hashabiah, and ten of their brothers with them, 

###### v25 
and weighed to them the silver, the gold, and the vessels, even the offering for the house of our God, which the king, his counselors, his princes, and all Israel there present, had offered. 

###### v26 
I weighed into their hand six hundred fifty talents of silver, one hundred talents of silver vessels; one hundred talents of gold, 

###### v27 
twenty bowls of gold weighing one thousand darics; and two vessels of fine bright bronze, precious as gold. 

###### v28 
I said to them, "You are holy to Yahweh, and the vessels are holy. The silver and the gold are a free will offering to Yahweh, the God of your fathers. 

###### v29 
Watch and keep them, until you weigh them before the chiefs of the priests and the Levites, and the princes of the fathers' households of Israel, at Jerusalem, in the rooms of Yahweh's house." 

###### v30 
So the priests and the Levites received the weight of the silver and the gold, and the vessels, to bring them to Jerusalem to the house of our God. 

###### v31 
Then we departed from the river Ahava on the twelfth day of the first month, to go to Jerusalem. The hand of our God was on us, and he delivered us from the hand of the enemy and the bandit by the way. 

###### v32 
We came to Jerusalem, and stayed there three days. 

###### v33 
On the fourth day the silver and the gold and the vessels were weighed in the house of our God into the hand of Meremoth the son of Uriah the priest; and with him was Eleazar the son of Phinehas; and with them was Jozabad the son of Jeshua, and Noadiah the son of Binnui, the Levite; 

###### v34 
everything by number and by weight; and all the weight was written at that time. 

###### v35 
The children of the captivity, who had come out of exile, offered burnt offerings to the God of Israel, twelve bulls for all Israel, ninety-six rams, seventy-seven lambs, and twelve male goats for a sin offering. All this was a burnt offering to Yahweh. 

###### v36 
They delivered the king's commissions to the king's local governors, and to the governors beyond the River. So they supported the people and God's house.

***
[[Ezr-07|← Ezra 07]] | [[Ezra]] | [[Ezr-09|Ezra 09 →]]
