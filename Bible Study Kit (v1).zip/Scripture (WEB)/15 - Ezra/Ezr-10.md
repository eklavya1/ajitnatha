# Ezra 10

[[Ezr-09|← Ezra 09]] | [[Ezra]]
***



###### v1 
Now while Ezra prayed and made confession, weeping and casting himself down before God's house, there was gathered together to him out of Israel a very great assembly of men and women and children; for the people wept very bitterly. 

###### v2 
Shecaniah the son of Jehiel, one of the sons of Elam, answered Ezra, "We have trespassed against our God, and have married foreign women of the peoples of the land. Yet now there is hope for Israel concerning this thing. 

###### v3 
Now therefore let's make a covenant with our God to put away all the wives, and those who are born of them, according to the counsel of my lord, and of those who tremble at the commandment of our God. Let it be done according to the law. 

###### v4 
Arise; for the matter belongs to you, and we are with you. Be courageous, and do it." 

###### v5 
Then Ezra arose, and made the chiefs of the priests, the Levites, and all Israel, to swear that they would do according to this word. So they swore. 

###### v6 
Then Ezra rose up from before God's house, and went into the room of Jehohanan the son of Eliashib. When he came there, he ate no bread, nor drank water; for he mourned because of the trespass of those of the captivity. 

###### v7 
They made a proclamation throughout Judah and Jerusalem to all the children of the captivity, that they should gather themselves together to Jerusalem; 

###### v8 
and that whoever didn't come within three days, according to the counsel of the princes and the elders, all his possessions should be forfeited, and himself separated from the assembly of the captivity. 

###### v9 
Then all the men of Judah and Benjamin gathered themselves together to Jerusalem within the three days. It was the ninth month, on the twentieth day of the month; and all the people sat in the wide place in front of God's house, trembling because of this matter, and because of the great rain. 

###### v10 
Ezra the priest stood up and said to them, "You have trespassed, and have married foreign women, to increase the guilt of Israel. 

###### v11 
Now therefore make confession to Yahweh, the God of your fathers, and do his pleasure; and separate yourselves from the peoples of the land, and from the foreign women." 

###### v12 
Then all the assembly answered with a loud voice, "We must do as you have said concerning us. 

###### v13 
But the people are many, and it is a time of much rain, and we are not able to stand outside. This is not a work of one day or two, for we have greatly transgressed in this matter. 

###### v14 
Now let our princes be appointed for all the assembly, and let all those who are in our cities who have married foreign women come at appointed times, and with them the elders of every city, and its judges, until the fierce wrath of our God is turned from us, until this matter is resolved." 

###### v15 
Only Jonathan the son of Asahel and Jahzeiah the son of Tikvah stood up against this; and Meshullam and Shabbethai the Levite helped them. 

###### v16 
The children of the captivity did so. Ezra the priest, with certain heads of fathers' households, after their fathers' houses, and all of them by their names, were set apart; and they sat down in the first day of the tenth month to examine the matter. 

###### v17 
They finished with all the men who had married foreign women by the first day of the first month. 

###### v18 
Among the sons of the priests there were found who had married foreign women: of the sons of Jeshua, the son of Jozadak, and his brothers, Maaseiah, and Eliezer, and Jarib, and Gedaliah. 

###### v19 
They gave their hand that they would put away their wives; and being guilty, they offered a ram of the flock for their guilt. 

###### v20 
Of the sons of Immer: Hanani and Zebadiah. 

###### v21 
Of the sons of Harim: Maaseiah, and Elijah, and Shemaiah, and Jehiel, and Uzziah. 

###### v22 
Of the sons of Pashhur: Elioenai, Maaseiah, Ishmael, Nethanel, Jozabad, and Elasah. 

###### v23 
Of the Levites: Jozabad, and Shimei, and Kelaiah (also called Kelita), Pethahiah, Judah, and Eliezer. 

###### v24 
Of the singers: Eliashib. Of the gatekeepers: Shallum, and Telem, and Uri. 

###### v25 
Of Israel: Of the sons of Parosh: Ramiah, and Izziah, and Malchijah, and Mijamin, and Eleazar, and Malchijah, and Benaiah. 

###### v26 
Of the sons of Elam: Mattaniah, Zechariah, and Jehiel, and Abdi, and Jeremoth, and Elijah. 

###### v27 
Of the sons of Zattu: Elioenai, Eliashib, Mattaniah, and Jeremoth, and Zabad, and Aziza. 

###### v28 
Of the sons of Bebai: Jehohanan, Hananiah, Zabbai, Athlai. 

###### v29 
Of the sons of Bani: Meshullam, Malluch, and Adaiah, Jashub, and Sheal, Jeremoth. 

###### v30 
Of the sons of Pahathmoab: Adna, and Chelal, Benaiah, Maaseiah, Mattaniah, Bezalel, and Binnui, and Manasseh. 

###### v31 
Of the sons of Harim: Eliezer, Isshijah, Malchijah, Shemaiah, Shimeon, 

###### v32 
Benjamin, Malluch, Shemariah. 

###### v33 
Of the sons of Hashum: Mattenai, Mattattah, Zabad, Eliphelet, Jeremai, Manasseh, Shimei. 

###### v34 
Of the sons of Bani: Maadai, Amram, and Uel, 

###### v35 
Benaiah, Bedeiah, Cheluhi, 

###### v36 
Vaniah, Meremoth, Eliashib, 

###### v37 
Mattaniah, Mattenai, and Jaasu, 

###### v38 
and Bani, and Binnui, Shimei, 

###### v39 
and Shelemiah, and Nathan, and Adaiah, 

###### v40 
Machnadebai, Shashai, Sharai, 

###### v41 
Azarel, and Shelemiah, Shemariah, 

###### v42 
Shallum, Amariah, Joseph. 

###### v43 
Of the sons of Nebo: Jeiel, Mattithiah, Zabad, Zebina, Iddo, and Joel, Benaiah. 

###### v44 
All these had taken foreign wives; and some of them had wives by whom they had children.

***
[[Ezr-09|← Ezra 09]] | [[Ezra]]
