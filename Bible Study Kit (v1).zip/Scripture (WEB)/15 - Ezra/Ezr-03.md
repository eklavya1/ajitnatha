# Ezra 3

[[Ezr-02|← Ezra 02]] | [[Ezra]] | [[Ezr-04|Ezra 04 →]]
***



###### v1 
When the seventh month had come, and the children of Israel were in the cities, the people gathered themselves together as one man to Jerusalem. 

###### v2 
Then Jeshua the son of Jozadak stood up with his brothers the priests, and Zerubbabel the son of Shealtiel and his brothers, and built the altar of the God of Israel, to offer burnt offerings on it, as it is written in the law of Moses the man of God. 

###### v3 
In spite of their fear because of the peoples of the surrounding lands, they set the altar on its base; and they offered burnt offerings on it to Yahweh, even burnt offerings morning and evening. 

###### v4 
They kept the feast of booths, as it is written, and offered the daily burnt offerings by number, according to the ordinance, as the duty of every day required; 

###### v5 
and afterward the continual burnt offering, the offerings of the new moons, of all the set feasts of Yahweh that were consecrated, and of everyone who willingly offered a free will offering to Yahweh. 

###### v6 
From the first day of the seventh month, they began to offer burnt offerings to Yahweh; but the foundation of Yahweh's temple was not yet laid. 

###### v7 
They also gave money to the masons, and to the carpenters. They also gave food, drink, and oil to the people of Sidon and Tyre, to bring cedar trees from Lebanon to the sea, to Joppa, according to the grant that they had from Cyrus King of Persia. 

###### v8 
Now in the second year of their coming to God's house at Jerusalem, in the second month, Zerubbabel the son of Shealtiel, and Jeshua the son of Jozadak, and the rest of their brothers the priests and the Levites, and all those who had come out of the captivity to Jerusalem, began the work and appointed the Levites, from twenty years old and upward, to have the oversight of the work of Yahweh's house. 

###### v9 
Then Jeshua stood with his sons and his brothers, Kadmiel and his sons, the sons of Judah, together, to have the oversight of the workmen in God's house: the sons of Henadad, with their sons and their brothers the Levites. 

###### v10 
When the builders laid the foundation of Yahweh's temple, they set the priests in their clothing with trumpets, with the Levites the sons of Asaph with cymbals, to praise Yahweh, according to the directions of David king of Israel. 

###### v11 
They sang to one another in praising and giving thanks to Yahweh, "For he is good, for his loving kindness endures forever toward Israel." All the people shouted with a great shout, when they praised Yahweh, because the foundation of Yahweh's house had been laid. 

###### v12 
But many of the priests and Levites and heads of fathers' households, the old men who had seen the first house, when the foundation of this house was laid before their eyes, wept with a loud voice. Many also shouted aloud for joy, 

###### v13 
so that the people could not discern the noise of the shout of joy from the noise of the weeping of the people; for the people shouted with a loud shout, and the noise was heard far away.

***
[[Ezr-02|← Ezra 02]] | [[Ezra]] | [[Ezr-04|Ezra 04 →]]
