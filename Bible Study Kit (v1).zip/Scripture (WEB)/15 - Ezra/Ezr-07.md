# Ezra 7

[[Ezr-06|← Ezra 06]] | [[Ezra]] | [[Ezr-08|Ezra 08 →]]
***



###### v1 
Now after these things, in the reign of Artaxerxes king of Persia, Ezra the son of Seraiah, the son of Azariah, the son of Hilkiah, 

###### v2 
the son of Shallum, the son of Zadok, the son of Ahitub, 

###### v3 
the son of Amariah, the son of Azariah, the son of Meraioth, 

###### v4 
the son of Zerahiah, the son of Uzzi, the son of Bukki, 

###### v5 
the son of Abishua, the son of Phinehas, the son of Eleazar, the son of Aaron the chief priest-- 

###### v6 
this Ezra went up from Babylon. He was a skilled scribe in the law of Moses, which Yahweh, the God of Israel, had given; and the king granted him all his request, according to Yahweh his God's hand on him. 

###### v7 
Some of the children of Israel, including some of the priests, the Levites, the singers, the gatekeepers, and the temple servants went up to Jerusalem in the seventh year of Artaxerxes the king. 

###### v8 
He came to Jerusalem in the fifth month, which was in the seventh year of the king. 

###### v9 
For on the first day of the first month he began to go up from Babylon; and on the first day of the fifth month he came to Jerusalem, according to the good hand of his God on him. 

###### v10 
For Ezra had set his heart to seek Yahweh's law, and to do it, and to teach statutes and ordinances in Israel. 

###### v11 
Now this is the copy of the letter that King Artaxerxes gave to Ezra the priest, the scribe, even the scribe of the words of Yahweh's commandments, and of his statutes to Israel: 

###### v12 
Artaxerxes, king of kings, To Ezra the priest, the scribe of the law of the perfect God of heaven. Now 

###### v13 
I make a decree, that all those of the people of Israel, and their priests and the Levites, in my realm, who intend of their own free will to go to Jerusalem, go with you. 

###### v14 
Because you are sent by the king and his seven counselors, to inquire concerning Judah and Jerusalem, according to the law of your God which is in your hand, 

###### v15 
and to carry the silver and gold, which the king and his counselors have freely offered to the God of Israel, whose habitation is in Jerusalem, 

###### v16 
and all the silver and gold that you will find in all the province of Babylon, with the free will offering of the people, and of the priests, offering willingly for the house of their God which is in Jerusalem; 

###### v17 
therefore you shall with all diligence buy with this money bulls, rams, lambs, with their meal offerings and their drink offerings, and shall offer them on the altar of the house of your God which is in Jerusalem. 

###### v18 
Whatever seems good to you and to your brothers to do with the rest of the silver and the gold, do that according to the will of your God. 

###### v19 
The vessels that are given to you for the service of the house of your God, deliver before the God of Jerusalem. 

###### v20 
Whatever more will be needed for the house of your God, which you may have occasion to give, give it out of the king's treasure house. 

###### v21 
I, even I Artaxerxes the king, make a decree to all the treasurers who are beyond the River, that whatever Ezra the priest, the scribe of the law of the God of heaven, requires of you, it shall be done with all diligence, 

###### v22 
up to one hundred talents of silver, and to one hundred cors of wheat, and to one hundred baths of wine, and to one hundred baths of oil, and salt without prescribing how much. 

###### v23 
Whatever is commanded by the God of heaven, let it be done exactly for the house of the God of heaven; for why should there be wrath against the realm of the king and his sons? 

###### v24 
Also we inform you that it shall not be lawful to impose tribute, custom, or toll on any of the priests, Levites, singers, gatekeepers, temple servants, or laborers of this house of God. 

###### v25 
You, Ezra, according to the wisdom of your God that is in your hand, appoint magistrates and judges, who may judge all the people who are beyond the River, who all know the laws of your God; and teach him who doesn't know them. 

###### v26 
Whoever will not do the law of your God and the law of the king, let judgment be executed on him with all diligence, whether it is to death, or to banishment, or to confiscation of goods, or to imprisonment. 

###### v27 
Blessed be Yahweh, the God of our fathers, who has put such a thing as this in the king's heart, to beautify Yahweh's house which is in Jerusalem; 

###### v28 
and has extended loving kindness to me before the king and his counselors, and before all the king's mighty princes. I was strengthened according to Yahweh my God's hand on me, and I gathered together chief men out of Israel to go up with me.

***
[[Ezr-06|← Ezra 06]] | [[Ezra]] | [[Ezr-08|Ezra 08 →]]
