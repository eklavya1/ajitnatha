# Ezra 2

[[Ezr-01|← Ezra 01]] | [[Ezra]] | [[Ezr-03|Ezra 03 →]]
***



###### v1 
Now these are the children of the province, who went up out of the captivity of those who had been carried away, whom Nebuchadnezzar the king of Babylon had carried away to Babylon, and who returned to Jerusalem and Judah, everyone to his city; 

###### v2 
who came with Zerubbabel, Jeshua, Nehemiah, Seraiah, Reelaiah, Mordecai, Bilshan, Mispar, Bigvai, Rehum, and Baanah. The number of the men of the people of Israel: 

###### v3 
The children of Parosh, two thousand one hundred seventy-two. 

###### v4 
The children of Shephatiah, three hundred seventy-two. 

###### v5 
The children of Arah, seven hundred seventy-five. 

###### v6 
The children of Pahathmoab, of the children of Jeshua and Joab, two thousand eight hundred twelve. 

###### v7 
The children of Elam, one thousand two hundred fifty-four. 

###### v8 
The children of Zattu, nine hundred forty-five. 

###### v9 
The children of Zaccai, seven hundred sixty. 

###### v10 
The children of Bani, six hundred forty-two. 

###### v11 
The children of Bebai, six hundred twenty-three. 

###### v12 
The children of Azgad, one thousand two hundred twenty-two. 

###### v13 
The children of Adonikam, six hundred sixty-six. 

###### v14 
The children of Bigvai, two thousand fifty-six. 

###### v15 
The children of Adin, four hundred fifty-four. 

###### v16 
The children of Ater, of Hezekiah, ninety-eight. 

###### v17 
The children of Bezai, three hundred twenty-three. 

###### v18 
The children of Jorah, one hundred twelve. 

###### v19 
The children of Hashum, two hundred twenty-three. 

###### v20 
The children of Gibbar, ninety-five. 

###### v21 
The children of Bethlehem, one hundred twenty-three. 

###### v22 
The men of Netophah, fifty-six. 

###### v23 
The men of Anathoth, one hundred twenty-eight. 

###### v24 
The children of Azmaveth, forty-two. 

###### v25 
The children of Kiriath Arim, Chephirah, and Beeroth, seven hundred forty-three. 

###### v26 
The children of Ramah and Geba, six hundred twenty-one. 

###### v27 
The men of Michmas, one hundred twenty-two. 

###### v28 
The men of Bethel and Ai, two hundred twenty-three. 

###### v29 
The children of Nebo, fifty-two. 

###### v30 
The children of Magbish, one hundred fifty-six. 

###### v31 
The children of the other Elam, one thousand two hundred fifty-four. 

###### v32 
The children of Harim, three hundred twenty. 

###### v33 
The children of Lod, Hadid, and Ono, seven hundred twenty-five. 

###### v34 
The children of Jericho, three hundred forty-five. 

###### v35 
The children of Senaah, three thousand six hundred thirty. 

###### v36 
The priests: the children of Jedaiah, of the house of Jeshua, nine hundred seventy-three. 

###### v37 
The children of Immer, one thousand fifty-two. 

###### v38 
The children of Pashhur, one thousand two hundred forty-seven. 

###### v39 
The children of Harim, one thousand seventeen. 

###### v40 
The Levites: the children of Jeshua and Kadmiel, of the children of Hodaviah, seventy-four. 

###### v41 
The singers: the children of Asaph, one hundred twenty-eight. 

###### v42 
The children of the gatekeepers: the children of Shallum, the children of Ater, the children of Talmon, the children of Akkub, the children of Hatita, the children of Shobai, in all one hundred thirty-nine. 

###### v43 
The temple servants: the children of Ziha, the children of Hasupha, the children of Tabbaoth, 

###### v44 
the children of Keros, the children of Siaha, the children of Padon, 

###### v45 
the children of Lebanah, the children of Hagabah, the children of Akkub, 

###### v46 
the children of Hagab, the children of Shamlai, the children of Hanan, 

###### v47 
the children of Giddel, the children of Gahar, the children of Reaiah, 

###### v48 
the children of Rezin, the children of Nekoda, the children of Gazzam, 

###### v49 
the children of Uzza, the children of Paseah, the children of Besai, 

###### v50 
the children of Asnah, the children of Meunim, the children of Nephisim, 

###### v51 
the children of Bakbuk, the children of Hakupha, the children of Harhur, 

###### v52 
the children of Bazluth, the children of Mehida, the children of Harsha, 

###### v53 
the children of Barkos, the children of Sisera, the children of Temah, 

###### v54 
the children of Neziah, the children of Hatipha. 

###### v55 
The children of Solomon's servants: the children of Sotai, the children of Hassophereth, the children of Peruda, 

###### v56 
the children of Jaalah, the children of Darkon, the children of Giddel, 

###### v57 
the children of Shephatiah, the children of Hattil, the children of Pochereth Hazzebaim, the children of Ami. 

###### v58 
All the temple servants, and the children of Solomon's servants, were three hundred ninety-two. 

###### v59 
These were those who went up from Tel Melah, Tel Harsha, Cherub, Addan, and Immer; but they could not show their fathers' houses, and their offspring, whether they were of Israel: 

###### v60 
the children of Delaiah, the children of Tobiah, the children of Nekoda, six hundred fifty-two. 

###### v61 
Of the children of the priests: the children of Habaiah, the children of Hakkoz, and the children of Barzillai, who took a wife of the daughters of Barzillai the Gileadite, and was called after their name. 

###### v62 
These sought their place among those who were registered by genealogy, but they were not found: therefore they were deemed disqualified and removed from the priesthood. 

###### v63 
The governor told them that they should not eat of the most holy things until a priest stood up to serve with Urim and with Thummim. 

###### v64 
The whole assembly together was forty-two thousand three hundred sixty, 

###### v65 
in addition to their male servants and their female servants, of whom there were seven thousand three hundred thirty-seven; and they had two hundred singing men and singing women. 

###### v66 
Their horses were seven hundred thirty-six; their mules, two hundred forty-five; 

###### v67 
their camels, four hundred thirty-five; their donkeys, six thousand seven hundred twenty. 

###### v68 
Some of the heads of fathers' households, when they came to Yahweh's house which is in Jerusalem, offered willingly for God's house to set it up in its place. 

###### v69 
They gave according to their ability into the treasury of the work sixty-one thousand darics of gold, and five thousand minas of silver, and one hundred priests' garments. 

###### v70 
So the priests and the Levites, with some of the people, the singers, the gatekeepers, and the temple servants, lived in their cities, and all Israel in their cities.

***
[[Ezr-01|← Ezra 01]] | [[Ezra]] | [[Ezr-03|Ezra 03 →]]
