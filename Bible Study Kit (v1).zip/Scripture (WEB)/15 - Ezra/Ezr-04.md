# Ezra 4

[[Ezr-03|← Ezra 03]] | [[Ezra]] | [[Ezr-05|Ezra 05 →]]
***



###### v1 
Now when the adversaries of Judah and Benjamin heard that the children of the captivity were building a temple to Yahweh, the God of Israel; 

###### v2 
they came near to Zerubbabel, and to the heads of fathers' households, and said to them, "Let us build with you; for we seek your God, as you do; and we have been sacrificing to him since the days of Esar Haddon king of Assyria, who brought us up here." 

###### v3 
But Zerubbabel, and Jeshua, and the rest of the heads of fathers' households of Israel, said to them, "You have nothing to do with us in building a house to our God; but we ourselves together will build to Yahweh, the God of Israel, as king Cyrus the king of Persia has commanded us." 

###### v4 
Then the people of the land weakened the hands of the people of Judah, and troubled them in building. 

###### v5 
They hired counselors against them, to frustrate their purpose, all the days of Cyrus king of Persia, even until the reign of Darius king of Persia. 

###### v6 
In the reign of Ahasuerus, in the beginning of his reign, they wrote an accusation against the inhabitants of Judah and Jerusalem. 

###### v7 
In the days of Artaxerxes, Bishlam, Mithredath, Tabeel, and the rest of his companions, wrote to Artaxerxes king of Persia; and the writing of the letter was written in Syrian, and delivered in the Syrian language. 

###### v8 
Rehum the chancellor and Shimshai the scribe wrote a letter against Jerusalem to Artaxerxes the king as follows; 

###### v9 
then Rehum the chancellor, Shimshai the scribe, and the rest of their companions, the Dinaites, and the Apharsathchites, the Tarpelites, the Apharsites, the Archevites, the Babylonians, the Shushanchites, the Dehaites, the Elamites, 

###### v10 
and the rest of the nations whom the great and noble Osnappar brought over, and set in the city of Samaria, and in the rest of the country beyond the River, and so forth, wrote. 

###### v11 
This is the copy of the letter that they sent: To King Artaxerxes, From your servants the men beyond the River. 

###### v12 
Be it known to the king that the Jews who came up from you have come to us to Jerusalem. They are building the rebellious and bad city, and have finished the walls, and repaired the foundations. 

###### v13 
Be it known now to the king that if this city is built and the walls finished, they will not pay tribute, custom, or toll, and in the end it will be hurtful to the kings. 

###### v14 
Now because we eat the salt of the palace, and it is not appropriate for us to see the king's dishonor, therefore we have sent and informed the king, 

###### v15 
that search may be made in the book of the records of your fathers. You will see in the book of the records, and know that this city is a rebellious city, and hurtful to kings and provinces, and that they have started rebellions within it in the past. That is why this city was destroyed. 

###### v16 
We inform the king that if this city is built and the walls finished, then you will have no possession beyond the River. 

###### v17 
Then the king sent an answer to Rehum the chancellor, and to Shimshai the scribe, and to the rest of their companions who live in Samaria, and in the rest of the country beyond the River: Peace. 

###### v18 
The letter which you sent to us has been plainly read before me. 

###### v19 
I decreed, and search has been made, and it was found that this city has made insurrection against kings in the past, and that rebellion and revolts have been made in it. 

###### v20 
There have also been mighty kings over Jerusalem, who have ruled over all the country beyond the River; and tribute, custom, and toll, was paid to them. 

###### v21 
Make a decree now to cause these men to cease, and that this city not be built, until a decree is made by me. 

###### v22 
Be careful that you not be slack doing so. Why should damage grow to the hurt of the kings? 

###### v23 
Then when the copy of king Artaxerxes' letter was read before Rehum, Shimshai the scribe, and their companions, they went in haste to Jerusalem to the Jews, and made them to cease by force of arms. 

###### v24 
Then work stopped on God's house which is at Jerusalem. It stopped until the second year of the reign of Darius king of Persia.

***
[[Ezr-03|← Ezra 03]] | [[Ezra]] | [[Ezr-05|Ezra 05 →]]
