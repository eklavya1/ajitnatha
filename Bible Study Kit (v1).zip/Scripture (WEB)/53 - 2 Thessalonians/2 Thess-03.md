# 2 Thessalonians 3

[[2 Thess-02|← 2 Thessalonians 02]] | [[2 Thessalonians]]
***



###### v1 
Finally, brothers, pray for us, that the word of the Lord may spread rapidly and be glorified, even as also with you, 

###### v2 
and that we may be delivered from unreasonable and evil men; for not all have faith. 

###### v3 
But the Lord is faithful, who will establish you and guard you from the evil one. 

###### v4 
We have confidence in the Lord concerning you, that you both do and will do the things we command. 

###### v5 
May the Lord direct your hearts into God's love, and into the perseverance of Christ. 

###### v6 
Now we command you, brothers, in the name of our Lord Jesus Christ, that you withdraw yourselves from every brother who walks in rebellion, and not after the tradition which they received from us. 

###### v7 
For you know how you ought to imitate us. For we didn't behave ourselves rebelliously among you, 

###### v8 
neither did we eat bread from anyone's hand without paying for it, but in labor and travail worked night and day, that we might not burden any of you, 

###### v9 
not because we don't have the right, but to make ourselves an example to you, that you should imitate us. 

###### v10 
For even when we were with you, we commanded you this: "If anyone is not willing to work, don't let him eat." 

###### v11 
For we hear of some who walk among you in rebellion, who don't work at all, but are busybodies. 

###### v12 
Now those who are that way, we command and exhort in the Lord Jesus Christ, that they work with quietness and eat their own bread. 

###### v13 
But you, brothers, don't be weary in doing what is right. 

###### v14 
If any man doesn't obey our word in this letter, note that man, that you have no company with him, to the end that he may be ashamed. 

###### v15 
Don't count him as an enemy, but admonish him as a brother. 

###### v16 
Now may the Lord of peace himself give you peace at all times in all ways. The Lord be with you all. 

###### v17 
The greeting of me, Paul, with my own hand, which is the sign in every letter: this is how I write. 

###### v18 
The grace of our Lord Jesus Christ be with you all. Amen.

***
[[2 Thess-02|← 2 Thessalonians 02]] | [[2 Thessalonians]]
