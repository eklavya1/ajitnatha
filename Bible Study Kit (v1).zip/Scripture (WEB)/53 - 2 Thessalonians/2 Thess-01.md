# 2 Thessalonians 1

[[2 Thessalonians]] | [[2 Thess-02|2 Thessalonians 02 →]]
***



###### v1 
Paul, Silvanus, and Timothy, to the assembly of the Thessalonians in God our Father, and the Lord Jesus Christ: 

###### v2 
Grace to you and peace from God our Father and the Lord Jesus Christ. 

###### v3 
We are bound to always give thanks to God for you, brothers, even as it is appropriate, because your faith grows exceedingly, and the love of each and every one of you toward one another abounds, 

###### v4 
so that we ourselves boast about you in the assemblies of God for your perseverance and faith in all your persecutions and in the afflictions which you endure. 

###### v5 
This is an obvious sign of the righteous judgment of God, to the end that you may be counted worthy of God's Kingdom, for which you also suffer. 

###### v6 
Since it is a righteous thing with God to repay affliction to those who afflict you, 

###### v7 
and to give relief to you who are afflicted with us, when the Lord Jesus is revealed from heaven with his mighty angels in flaming fire, 

###### v8 
punishing those who don't know God, and to those who don't obey the Good News of our Lord Jesus, 

###### v9 
who will pay the penalty: eternal destruction from the face of the Lord and from the glory of his might, 

###### v10 
when he comes in that day to be glorified in his saints and to be admired among all those who have believed, because our testimony to you was believed. 

###### v11 
To this end we also pray always for you, that our God may count you worthy of your calling, and fulfill every desire of goodness and work of faith with power, 

###### v12 
that the name of our Lord Jesus may be glorified in you, and you in him, according to the grace of our God and the Lord Jesus Christ.

***
[[2 Thessalonians]] | [[2 Thess-02|2 Thessalonians 02 →]]
