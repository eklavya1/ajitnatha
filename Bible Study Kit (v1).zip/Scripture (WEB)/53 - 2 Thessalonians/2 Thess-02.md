# 2 Thessalonians 2

[[2 Thess-01|← 2 Thessalonians 01]] | [[2 Thessalonians]] | [[2 Thess-03|2 Thessalonians 03 →]]
***



###### v1 
Now, brothers, concerning the coming of our Lord Jesus Christ and our gathering together to him, we ask you 

###### v2 
not to be quickly shaken in your mind, and not be troubled, either by spirit, or by word, or by letter as if from us, saying that the day of Christ has already come. 

###### v3 
Let no one deceive you in any way. For it will not be, unless the rebellion comes first, and the man of sin is revealed, the son of destruction, 

###### v4 
he who opposes and exalts himself against all that is called God or that is worshiped, so that he sits as God in the temple of God, setting himself up as God. 

###### v5 
Don't you remember that, when I was still with you, I told you these things? 

###### v6 
Now you know what is restraining him, to the end that he may be revealed in his own season. 

###### v7 
For the mystery of lawlessness already works. Only there is one who restrains now, until he is taken out of the way. 

###### v8 
Then the lawless one will be revealed, whom the Lord will kill with the breath of his mouth, and destroy by the manifestation of his coming; 

###### v9 
even he whose coming is according to the working of Satan with all power and signs and lying wonders, 

###### v10 
and with all deception of wickedness for those who are being lost, because they didn't receive the love of the truth, that they might be saved. 

###### v11 
Because of this, God sends them a working of error, that they should believe a lie; 

###### v12 
that they all might be judged who didn't believe the truth, but had pleasure in unrighteousness. 

###### v13 
But we are bound to always give thanks to God for you, brothers loved by the Lord, because God chose you from the beginning for salvation through sanctification of the Spirit and belief in the truth, 

###### v14 
to which he called you through our Good News, for the obtaining of the glory of our Lord Jesus Christ. 

###### v15 
So then, brothers, stand firm and hold the traditions which you were taught by us, whether by word or by letter. 

###### v16 
Now our Lord Jesus Christ himself, and God our Father, who loved us and gave us eternal comfort and good hope through grace, 

###### v17 
comfort your hearts and establish you in every good work and word.

***
[[2 Thess-01|← 2 Thessalonians 01]] | [[2 Thessalonians]] | [[2 Thess-03|2 Thessalonians 03 →]]
