# Nehemiah 13

[[Neh-12|← Nehemiah 12]] | [[Nehemiah]]
***



###### v1 
On that day they read in the book of Moses in the hearing of the people; and it was found written in it that an Ammonite and a Moabite should not enter into the assembly of God forever, 

###### v2 
because they didn't meet the children of Israel with bread and with water, but hired Balaam against them, to curse them; however our God turned the curse into a blessing. 

###### v3 
It came to pass, when they had heard the law, that they separated all the mixed multitude from Israel. 

###### v4 
Now before this, Eliashib the priest, who was appointed over the rooms of the house of our God, being allied to Tobiah, 

###### v5 
had prepared for him a great room, where before they laid the meal offerings, the frankincense, the vessels, and the tithes of the grain, the new wine, and the oil, which were given by commandment to the Levites, the singers, and the gatekeepers; and the wave offerings for the priests. 

###### v6 
But in all this, I was not at Jerusalem; for in the thirty-second year of Artaxerxes king of Babylon I went to the king; and after some days I asked leave of the king, 

###### v7 
and I came to Jerusalem, and understood the evil that Eliashib had done for Tobiah, in preparing him a room in the courts of God's house. 

###### v8 
It grieved me severely. Therefore I threw all Tobiah's household stuff out of the room. 

###### v9 
Then I commanded, and they cleansed the rooms. I brought into them the vessels of God's house, with the meal offerings and the frankincense again. 

###### v10 
I perceived that the portions of the Levites had not been given them; so that the Levites and the singers, who did the work, had each fled to his field. 

###### v11 
Then I contended with the rulers, and said, "Why is God's house forsaken?" I gathered them together, and set them in their place. 

###### v12 
Then all Judah brought the tithe of the grain, the new wine, and the oil to the treasuries. 

###### v13 
I made treasurers over the treasuries, Shelemiah the priest, and Zadok the scribe, and of the Levites, Pedaiah: and next to them was Hanan the son of Zaccur, the son of Mattaniah; for they were counted faithful, and their business was to distribute to their brothers. 

###### v14 
Remember me, my God, concerning this, and don't wipe out my good deeds that I have done for the house of my God, and for its observances. 

###### v15 
In those days I saw some men treading wine presses on the Sabbath in Judah, bringing in sheaves, and loading donkeys; also with wine, grapes, figs, and all kinds of burdens, which they brought into Jerusalem on the Sabbath day; and I testified against them in the day in which they sold food. 

###### v16 
Some men of Tyre also lived there, who brought in fish and all kinds of wares, and sold on the Sabbath to the children of Judah, and in Jerusalem. 

###### v17 
Then I contended with the nobles of Judah, and said to them, "What evil thing is this that you do, and profane the Sabbath day? 

###### v18 
Didn't your fathers do this, and didn't our God bring all this evil on us, and on this city? Yet you bring more wrath on Israel by profaning the Sabbath." 

###### v19 
It came to pass that when the gates of Jerusalem began to be dark before the Sabbath, I commanded that the doors should be shut, and commanded that they should not be opened until after the Sabbath. I set some of my servants over the gates, so that no burden should be brought in on the Sabbath day. 

###### v20 
So the merchants and sellers of all kinds of wares camped outside of Jerusalem once or twice. 

###### v21 
Then I testified against them, and said to them, "Why do you stay around the wall? If you do so again, I will lay hands on you." From that time on, they didn't come on the Sabbath. 

###### v22 
I commanded the Levites that they should purify themselves, and that they should come and keep the gates, to sanctify the Sabbath day. Remember me for this also, my God, and spare me according to the greatness of your loving kindness. 

###### v23 
In those days I also saw the Jews who had married women of Ashdod, of Ammon, and of Moab; 

###### v24 
and their children spoke half in the speech of Ashdod, and could not speak in the Jews' language, but according to the language of each people. 

###### v25 
I contended with them, and cursed them, and struck certain of them, and plucked off their hair, and made them swear by God, "You shall not give your daughters to their sons, nor take their daughters for your sons, or for yourselves. 

###### v26 
Didn't Solomon king of Israel sin by these things? Yet among many nations there was no king like him, and he was loved by his God, and God made him king over all Israel. Nevertheless foreign women caused even him to sin. 

###### v27 
Shall we then listen to you to do all this great evil, to trespass against our God in marrying foreign women?" 

###### v28 
One of the sons of Joiada, the son of Eliashib the high priest, was son-in-law to Sanballat the Horonite; therefore I chased him from me. 

###### v29 
Remember them, my God, because they have defiled the priesthood, and the covenant of the priesthood and of the Levites. 

###### v30 
Thus I cleansed them from all foreigners, and appointed duties for the priests and for the Levites, everyone in his work; 

###### v31 
and for the wood offering, at times appointed, and for the first fruits. Remember me, my God, for good.

***
[[Neh-12|← Nehemiah 12]] | [[Nehemiah]]
