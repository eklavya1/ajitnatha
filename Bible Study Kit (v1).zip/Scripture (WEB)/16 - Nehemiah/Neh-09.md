# Nehemiah 9

[[Neh-08|← Nehemiah 08]] | [[Nehemiah]] | [[Neh-10|Nehemiah 10 →]]
***



###### v1 
Now in the twenty-fourth day of this month the children of Israel were assembled with fasting, with sackcloth, and dirt on them. 

###### v2 
The offspring of Israel separated themselves from all foreigners and stood and confessed their sins and the iniquities of their fathers. 

###### v3 
They stood up in their place, and read in the book of the law of Yahweh their God a fourth part of the day; and a fourth part they confessed, and worshiped Yahweh their God. 

###### v4 
Then Jeshua, Bani, Kadmiel, Shebaniah, Bunni, Sherebiah, Bani, and Chenani of the Levites stood up on the stairs, and cried with a loud voice to Yahweh their God. 

###### v5 
Then the Levites, Jeshua, and Kadmiel, Bani, Hashabneiah, Sherebiah, Hodiah, Shebaniah, and Pethahiah, said, "Stand up and bless Yahweh your God from everlasting to everlasting! Blessed be your glorious name, which is exalted above all blessing and praise! 

###### v6 
You are Yahweh, even you alone. You have made heaven, the heaven of heavens, with all their army, the earth and all things that are on it, the seas and all that is in them, and you preserve them all. The army of heaven worships you. 

###### v7 
You are Yahweh, the God who chose Abram, brought him out of Ur of the Chaldees, gave him the name of Abraham, 

###### v8 
found his heart faithful before you, and made a covenant with him to give the land of the Canaanite, the Hittite, the Amorite, the Perizzite, the Jebusite, and the Girgashite, to give it to his offspring, and have performed your words; for you are righteous. 

###### v9 
"You saw the affliction of our fathers in Egypt, and heard their cry by the Red Sea, 

###### v10 
and showed signs and wonders against Pharaoh, and against all his servants, and against all the people of his land; for you knew that they dealt proudly against them, and made a name for yourself, as it is today. 

###### v11 
You divided the sea before them, so that they went through the middle of the sea on the dry land; and you cast their pursuers into the depths, as a stone into the mighty waters. 

###### v12 
Moreover, in a pillar of cloud you led them by day; and in a pillar of fire by night, to give them light in the way in which they should go. 

###### v13 
"You also came down on Mount Sinai, and spoke with them from heaven, and gave them right ordinances and true laws, good statutes and commandments, 

###### v14 
and made known to them your holy Sabbath, and commanded them commandments, statutes, and a law, by Moses your servant, 

###### v15 
and gave them bread from the sky for their hunger, and brought water out of the rock for them for their thirst, and commanded them that they should go in to possess the land which you had sworn to give them. 

###### v16 
"But they and our fathers behaved proudly, hardened their neck, didn't listen to your commandments, 

###### v17 
and refused to obey. They weren't mindful of your wonders that you did among them, but hardened their neck, and in their rebellion appointed a captain to return to their bondage. But you are a God ready to pardon, gracious and merciful, slow to anger, and abundant in loving kindness, and didn't forsake them. 

###### v18 
Yes, when they had made themselves a molded calf, and said, 'This is your God who brought you up out of Egypt,' and had committed awful blasphemies; 

###### v19 
yet you in your manifold mercies didn't forsake them in the wilderness. The pillar of cloud didn't depart from over them by day, to lead them in the way; neither did the pillar of fire by night, to show them light, and the way in which they should go. 

###### v20 
You gave also your good Spirit to instruct them, and didn't withhold your manna from their mouth, and gave them water for their thirst. 

###### v21 
"Yes, forty years you sustained them in the wilderness. They lacked nothing. Their clothes didn't grow old, and their feet didn't swell. 

###### v22 
Moreover you gave them kingdoms and peoples, which you allotted according to their portions. So they possessed the land of Sihon, even the land of the king of Heshbon, and the land of Og king of Bashan. 

###### v23 
You also multiplied their children as the stars of the sky, and brought them into the land concerning which you said to their fathers, that they should go in to possess it. 

###### v24 
"So the children went in and possessed the land, and you subdued before them the inhabitants of the land, the Canaanites, and gave them into their hands, with their kings and the peoples of the land, that they might do with them as they pleased. 

###### v25 
They took fortified cities and a rich land, and possessed houses full of all good things, cisterns dug out, vineyards, olive groves, and fruit trees in abundance. So they ate, were filled, became fat, and delighted themselves in your great goodness. 

###### v26 
"Nevertheless they were disobedient, and rebelled against you, cast your law behind their back, killed your prophets that testified against them to turn them again to you, and they committed awful blasphemies. 

###### v27 
Therefore you delivered them into the hand of their adversaries, who distressed them. In the time of their trouble, when they cried to you, you heard from heaven; and according to your manifold mercies you gave them saviors who saved them out of the hands of their adversaries. 

###### v28 
But after they had rest, they did evil again before you; therefore you left them in the hands of their enemies, so that they had the dominion over them; yet when they returned, and cried to you, you heard from heaven; and many times you delivered them according to your mercies, 

###### v29 
and testified against them, that you might bring them again to your law. Yet they were arrogant, and didn't listen to your commandments, but sinned against your ordinances (which if a man does, he shall live in them), turned their backs, stiffened their neck, and would not hear. 

###### v30 
Yet many years you put up with them, and testified against them by your Spirit through your prophets. Yet they would not listen. Therefore you gave them into the hand of the peoples of the lands. 

###### v31 
"Nevertheless in your manifold mercies you didn't make a full end of them, nor forsake them; for you are a gracious and merciful God. 

###### v32 
Now therefore, our God, the great, the mighty, and the awesome God, who keeps covenant and loving kindness, don't let all the travail seem little before you, that has come on us, on our kings, on our princes, on our priests, on our prophets, on our fathers, and on all your people, since the time of the kings of Assyria to this day. 

###### v33 
However you are just in all that has come on us; for you have dealt truly, but we have done wickedly. 

###### v34 
Also our kings, our princes, our priests, and our fathers have not kept your law, nor listened to your commandments and your testimonies with which you testified against them. 

###### v35 
For they have not served you in their kingdom, and in your great goodness that you gave them, and in the large and rich land which you gave before them. They didn't turn from their wicked works. 

###### v36 
"Behold, we are servants today, and as for the land that you gave to our fathers to eat its fruit and its good, behold, we are servants in it. 

###### v37 
It yields much increase to the kings whom you have set over us because of our sins. Also they have power over our bodies and over our livestock, at their pleasure, and we are in great distress. 

###### v38 
Yet for all this, we make a sure covenant, and write it; and our princes, our Levites, and our priests, seal it."

***
[[Neh-08|← Nehemiah 08]] | [[Nehemiah]] | [[Neh-10|Nehemiah 10 →]]
