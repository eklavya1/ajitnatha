# Nehemiah 1

[[Nehemiah]] | [[Neh-02|Nehemiah 02 →]]
***



###### v1 
The words of Nehemiah the son of Hacaliah. Now in the month Chislev, in the twentieth year, as I was in Susa the palace, 

###### v2 
Hanani, one of my brothers, came, he and certain men out of Judah; and I asked them about the Jews who had escaped, who were left of the captivity, and concerning Jerusalem. 

###### v3 
They said to me, "The remnant who are left of the captivity there in the province are in great affliction and reproach. The wall of Jerusalem is also broken down, and its gates are burned with fire." 

###### v4 
When I heard these words, I sat down and wept, and mourned several days; and I fasted and prayed before the God of heaven, 

###### v5 
and said, "I beg you, Yahweh, the God of heaven, the great and awesome God, who keeps covenant and loving kindness with those who love him and keep his commandments: 

###### v6 
Let your ear now be attentive, and your eyes open, that you may listen to the prayer of your servant, which I pray before you at this time, day and night, for the children of Israel your servants, while I confess the sins of the children of Israel, which we have sinned against you. Yes, I and my father's house have sinned. 

###### v7 
We have dealt very corruptly against you, and have not kept the commandments, nor the statutes, nor the ordinances, which you commanded your servant Moses. 

###### v8 
"Remember, I beg you, the word that you commanded your servant Moses, saying, 'If you trespass, I will scatter you among the peoples; 

###### v9 
but if you return to me, and keep my commandments and do them, though your outcasts were in the uttermost part of the heavens, yet I will gather them from there, and will bring them to the place that I have chosen, to cause my name to dwell there.' 

###### v10 
"Now these are your servants and your people, whom you have redeemed by your great power, and by your strong hand. 

###### v11 
Lord, I beg you, let your ear be attentive now to the prayer of your servant, and to the prayer of your servants, who delight to fear your name; and please prosper your servant today, and grant him mercy in the sight of this man." Now I was cup bearer to the king.

***
[[Nehemiah]] | [[Neh-02|Nehemiah 02 →]]
