# Nehemiah 10

[[Neh-09|← Nehemiah 09]] | [[Nehemiah]] | [[Neh-11|Nehemiah 11 →]]
***



###### v1 
Now those who sealed were: Nehemiah the governor, the son of Hacaliah, and Zedekiah, 

###### v2 
Seraiah, Azariah, Jeremiah, 

###### v3 
Pashhur, Amariah, Malchijah, 

###### v4 
Hattush, Shebaniah, Malluch, 

###### v5 
Harim, Meremoth, Obadiah, 

###### v6 
Daniel, Ginnethon, Baruch, 

###### v7 
Meshullam, Abijah, Mijamin, 

###### v8 
Maaziah, Bilgai, and Shemaiah. These were the priests. 

###### v9 
The Levites: namely, Jeshua the son of Azaniah, Binnui of the sons of Henadad, Kadmiel; 

###### v10 
and their brothers, Shebaniah, Hodiah, Kelita, Pelaiah, Hanan, 

###### v11 
Mica, Rehob, Hashabiah, 

###### v12 
Zaccur, Sherebiah, Shebaniah, 

###### v13 
Hodiah, Bani, and Beninu. 

###### v14 
The chiefs of the people: Parosh, Pahathmoab, Elam, Zattu, Bani, 

###### v15 
Bunni, Azgad, Bebai, 

###### v16 
Adonijah, Bigvai, Adin, 

###### v17 
Ater, Hezekiah, Azzur, 

###### v18 
Hodiah, Hashum, Bezai, 

###### v19 
Hariph, Anathoth, Nobai, 

###### v20 
Magpiash, Meshullam, Hezir, 

###### v21 
Meshezabel, Zadok, Jaddua, 

###### v22 
Pelatiah, Hanan, Anaiah, 

###### v23 
Hoshea, Hananiah, Hasshub, 

###### v24 
Hallohesh, Pilha, Shobek, 

###### v25 
Rehum, Hashabnah, Maaseiah, 

###### v26 
Ahiah, Hanan, Anan, 

###### v27 
Malluch, Harim, and Baanah. 

###### v28 
The rest of the people, the priests, the Levites, the gatekeepers, the singers, the temple servants, and all those who had separated themselves from the peoples of the lands to the law of God, their wives, their sons, and their daughters--everyone who had knowledge, and understanding-- 

###### v29 
joined with their brothers, their nobles, and entered into a curse, and into an oath, to walk in God's law, which was given by Moses the servant of God, and to observe and do all the commandments of Yahweh our Lord, and his ordinances and his statutes; 

###### v30 
and that we would not give our daughters to the peoples of the land, nor take their daughters for our sons; 

###### v31 
and if the peoples of the land bring wares or any grain on the Sabbath day to sell, that we would not buy from them on the Sabbath, or on a holy day; and that we would forego the seventh year, and the exaction of every debt. 

###### v32 
Also we made ordinances for ourselves, to charge ourselves yearly with the third part of a shekel for the service of the house of our God; 

###### v33 
for the show bread, for the continual meal offering, for the continual burnt offering, for the Sabbaths, for the new moons, for the set feasts, and for the holy things, and for the sin offerings to make atonement for Israel, and for all the work of the house of our God. 

###### v34 
We, the priests, the Levites, and the people, cast lots for the wood offering, to bring it into the house of our God, according to our fathers' houses, at times appointed, year by year, to burn on Yahweh our God's altar, as it is written in the law; 

###### v35 
and to bring the first fruits of our ground, and the first fruits of all fruit of all kinds of trees, year by year, to Yahweh's house; 

###### v36 
also the firstborn of our sons, and of our livestock, as it is written in the law, and the firstborn of our herds and of our flocks, to bring to the house of our God, to the priests who minister in the house of our God; 

###### v37 
and that we should bring the first fruits of our dough, our wave offerings, the fruit of all kinds of trees, and the new wine and the oil, to the priests, to the rooms of the house of our God; and the tithes of our ground to the Levites; for they, the Levites, take the tithes in all the cities of our tillage. 

###### v38 
The priest the son of Aaron shall be with the Levites, when the Levites take tithes. The Levites shall bring up the tithe of the tithes to the house of our God, to the rooms, into the treasure house. 

###### v39 
For the children of Israel and the children of Levi shall bring the wave offering of the grain, of the new wine, and of the oil, to the rooms, where the vessels of the sanctuary are, and the priests who minister, with the gatekeepers and the singers. We will not forsake the house of our God.

***
[[Neh-09|← Nehemiah 09]] | [[Nehemiah]] | [[Neh-11|Nehemiah 11 →]]
