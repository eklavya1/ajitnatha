# Nehemiah 5

[[Neh-04|← Nehemiah 04]] | [[Nehemiah]] | [[Neh-06|Nehemiah 06 →]]
***



###### v1 
Then there arose a great cry of the people and of their wives against their brothers the Jews. 

###### v2 
For there were some who said, "We, our sons and our daughters, are many. Let us get grain, that we may eat and live." 

###### v3 
There were also some who said, "We are mortgaging our fields, our vineyards, and our houses. Let us get grain, because of the famine." 

###### v4 
There were also some who said, "We have borrowed money for the king's tribute using our fields and our vineyards as collateral. 

###### v5 
Yet now our flesh is as the flesh of our brothers, our children as their children. Behold, we bring our sons and our daughters into bondage to be servants, and some of our daughters have been brought into bondage. It is also not in our power to help it, because other men have our fields and our vineyards." 

###### v6 
I was very angry when I heard their cry and these words. 

###### v7 
Then I consulted with myself, and contended with the nobles and the rulers, and said to them, "You exact usury, everyone of his brother." I held a great assembly against them. 

###### v8 
I said to them, "We, after our ability, have redeemed our brothers the Jews that were sold to the nations; and would you even sell your brothers, and should they be sold to us?" Then they held their peace, and found not a word to say. 

###### v9 
Also I said, "The thing that you do is not good. Shouldn't you walk in the fear of our God, because of the reproach of the nations our enemies? 

###### v10 
I likewise, my brothers and my servants, lend them money and grain. Please let us stop this usury. 

###### v11 
Please restore to them, even today, their fields, their vineyards, their olive groves, and their houses, also the hundredth part of the money, and of the grain, the new wine, and the oil, that you are charging them." 

###### v12 
Then they said, "We will restore them, and will require nothing of them. We will do so, even as you say." Then I called the priests, and took an oath of them, that they would do according to this promise. 

###### v13 
Also I shook out my lap, and said, "So may God shake out every man from his house, and from his labor, that doesn't perform this promise; even may he be shaken out and emptied like this." All the assembly said, "Amen," and praised Yahweh. The people did according to this promise. 

###### v14 
Moreover from the time that I was appointed to be their governor in the land of Judah, from the twentieth year even to the thirty-second year of Artaxerxes the king, that is, twelve years, I and my brothers have not eaten the bread of the governor. 

###### v15 
But the former governors who were before me were supported by the people, and took bread and wine from them, plus forty shekels of silver; yes, even their servants ruled over the people; but I didn't do so, because of the fear of God. 

###### v16 
Yes, I also continued in the work of this wall. We didn't buy any land. All my servants were gathered there to the work. 

###### v17 
Moreover there were at my table, of the Jews and the rulers, one hundred fifty men, in addition to those who came to us from among the nations that were around us. 

###### v18 
Now that which was prepared for one day was one ox and six choice sheep. Also fowls were prepared for me, and once in ten days a store of all sorts of wine. Yet for all this, I didn't demand the governor's pay, because the bondage was heavy on this people. 

###### v19 
Remember me, my God, for good, all that I have done for this people.

***
[[Neh-04|← Nehemiah 04]] | [[Nehemiah]] | [[Neh-06|Nehemiah 06 →]]
