# Nehemiah 2

[[Neh-01|← Nehemiah 01]] | [[Nehemiah]] | [[Neh-03|Nehemiah 03 →]]
***



###### v1 
In the month Nisan, in the twentieth year of Artaxerxes the king, when wine was before him, I picked up the wine, and gave it to the king. Now I had not been sad before in his presence. 

###### v2 
The king said to me, "Why is your face sad, since you are not sick? This is nothing else but sorrow of heart." Then I was very much afraid. 

###### v3 
I said to the king, "Let the king live forever! Why shouldn't my face be sad, when the city, the place of my fathers' tombs, lies waste, and its gates have been consumed with fire?" 

###### v4 
Then the king said to me, "What is your request?" So I prayed to the God of heaven. 

###### v5 
I said to the king, "If it pleases the king, and if your servant has found favor in your sight, that you would send me to Judah, to the city of my fathers' tombs, that I may build it." 

###### v6 
The king said to me (the queen was also sitting by him), "How long will your journey be? When will you return?" So it pleased the king to send me, and I set a time for him. 

###### v7 
Moreover I said to the king, "If it pleases the king, let letters be given me to the governors beyond the River, that they may let me pass through until I come to Judah; 

###### v8 
and a letter to Asaph the keeper of the king's forest, that he may give me timber to make beams for the gates of the citadel by the temple, for the wall of the city, and for the house that I will occupy." The king granted my requests, because of the good hand of my God on me. 

###### v9 
Then I came to the governors beyond the River, and gave them the king's letters. Now the king had sent captains of the army and horsemen with me. 

###### v10 
When Sanballat the Horonite, and Tobiah the servant, the Ammonite, heard of it, it grieved them exceedingly, because a man had come to seek the welfare of the children of Israel. 

###### v11 
So I came to Jerusalem, and was there three days. 

###### v12 
I arose in the night, I and a few men with me. I didn't tell anyone what my God put into my heart to do for Jerusalem. There wasn't any animal with me, except the animal that I rode on. 

###### v13 
I went out by night by the valley gate, even toward the jackal's well, then to the dung gate, and inspected the walls of Jerusalem, which were broken down, and its gates were consumed with fire. 

###### v14 
Then I went on to the spring gate and to the king's pool, but there was no place for the animal that was under me to pass. 

###### v15 
Then I went up in the night by the brook, and inspected the wall; and I turned back, and entered by the valley gate, and so returned. 

###### v16 
The rulers didn't know where I went, or what I did. I had not as yet told it to the Jews, nor to the priests, nor to the nobles, nor to the rulers, nor to the rest who did the work. 

###### v17 
Then I said to them, "You see the bad situation that we are in, how Jerusalem lies waste, and its gates are burned with fire. Come, let's build up the wall of Jerusalem, that we won't be disgraced." 

###### v18 
I told them about the hand of my God which was good on me, and also about the king's words that he had spoken to me. They said, "Let's rise up and build." So they strengthened their hands for the good work. 

###### v19 
But when Sanballat the Horonite, Tobiah the Ammonite servant, and Geshem the Arabian, heard it, they ridiculed us, and despised us, and said, "What is this thing that you are doing? Will you rebel against the king?" 

###### v20 
Then I answered them, and said to them, "The God of heaven will prosper us. Therefore we, his servants, will arise and build; but you have no portion, nor right, nor memorial, in Jerusalem."

***
[[Neh-01|← Nehemiah 01]] | [[Nehemiah]] | [[Neh-03|Nehemiah 03 →]]
