# Nehemiah 12

[[Neh-11|← Nehemiah 11]] | [[Nehemiah]] | [[Neh-13|Nehemiah 13 →]]
***



###### v1 
Now these are the priests and the Levites who went up with Zerubbabel the son of Shealtiel, and Jeshua: Seraiah, Jeremiah, Ezra, 

###### v2 
Amariah, Malluch, Hattush, 

###### v3 
Shecaniah, Rehum, Meremoth, 

###### v4 
Iddo, Ginnethoi, Abijah, 

###### v5 
Mijamin, Maadiah, Bilgah, 

###### v6 
Shemaiah, and Joiarib, Jedaiah, 

###### v7 
Sallu, Amok, Hilkiah, and Jedaiah. These were the chiefs of the priests and of their brothers in the days of Jeshua. 

###### v8 
Moreover the Levites: Jeshua, Binnui, Kadmiel, Sherebiah, Judah, and Mattaniah, who was over the thanksgiving, he and his brothers. 

###### v9 
Also Bakbukiah and Unno, their brothers, were close to them according to their offices. 

###### v10 
Jeshua became the father of Joiakim, and Joiakim became the father of Eliashib, and Eliashib became the father of Joiada, 

###### v11 
and Joiada became the father of Jonathan, and Jonathan became the father of Jaddua. 

###### v12 
In the days of Joiakim were priests, heads of fathers' households: of Seraiah, Meraiah; of Jeremiah, Hananiah; 

###### v13 
of Ezra, Meshullam; of Amariah, Jehohanan; 

###### v14 
of Malluchi, Jonathan; of Shebaniah, Joseph; 

###### v15 
of Harim, Adna; of Meraioth, Helkai; 

###### v16 
of Iddo, Zechariah; of Ginnethon, Meshullam; 

###### v17 
of Abijah, Zichri; of Miniamin, of Moadiah, Piltai; 

###### v18 
of Bilgah, Shammua; of Shemaiah, Jehonathan; 

###### v19 
and of Joiarib, Mattenai; of Jedaiah, Uzzi; 

###### v20 
of Sallai, Kallai; of Amok, Eber; 

###### v21 
of Hilkiah, Hashabiah; of Jedaiah, Nethanel. 

###### v22 
As for the Levites, in the days of Eliashib, Joiada, and Johanan, and Jaddua, there were recorded the heads of fathers' households; also the priests, in the reign of Darius the Persian. 

###### v23 
The sons of Levi, heads of fathers' households, were written in the book of the chronicles, even until the days of Johanan the son of Eliashib. 

###### v24 
The chiefs of the Levites: Hashabiah, Sherebiah, and Jeshua the son of Kadmiel, with their brothers close to them, to praise and give thanks, according to the commandment of David the man of God, watch next to watch. 

###### v25 
Mattaniah, and Bakbukiah, Obadiah, Meshullam, Talmon, Akkub, were gatekeepers keeping the watch at the storehouses of the gates. 

###### v26 
These were in the days of Joiakim the son of Jeshua, the son of Jozadak, and in the days of Nehemiah the governor, and of Ezra the priest and scribe. 

###### v27 
At the dedication of the wall of Jerusalem, they sought the Levites out of all their places, to bring them to Jerusalem, to keep the dedication with gladness, both with giving thanks, and with singing, with cymbals, stringed instruments, and with harps. 

###### v28 
The sons of the singers gathered themselves together, both out of the plain around Jerusalem and from the villages of the Netophathites; 

###### v29 
also from Beth Gilgal, and out of the fields of Geba and Azmaveth: for the singers had built themselves villages around Jerusalem. 

###### v30 
The priests and the Levites purified themselves; and they purified the people, and the gates, and the wall. 

###### v31 
Then I brought up the princes of Judah on the wall, and appointed two great companies who gave thanks and went in procession. One went on the right hand on the wall toward the dung gate; 

###### v32 
and after them went Hoshaiah, with half of the princes of Judah, 

###### v33 
and Azariah, Ezra, and Meshullam, 

###### v34 
Judah, Benjamin, Shemaiah, Jeremiah, 

###### v35 
and some of the priests' sons with trumpets: Zechariah the son of Jonathan, the son of Shemaiah, the son of Mattaniah, the son of Micaiah, the son of Zaccur, the son of Asaph; 

###### v36 
and his brothers, Shemaiah, Azarel, Milalai, Gilalai, Maai, Nethanel, Judah, and Hanani, with the musical instruments of David the man of God; and Ezra the scribe was before them. 

###### v37 
By the spring gate, and straight before them, they went up by the stairs of David's city, at the ascent of the wall, above David's house, even to the water gate eastward. 

###### v38 
The other company of those who gave thanks went to meet them, and I after them, with the half of the people, on the wall, above the tower of the furnaces, even to the wide wall, 

###### v39 
and above the gate of Ephraim, and by the old gate, and by the fish gate, and the tower of Hananel, and the tower of Hammeah, even to the sheep gate: and they stood still in the gate of the guard. 

###### v40 
So the two companies of those who gave thanks in God's house stood, and I, and the half of the rulers with me; 

###### v41 
and the priests, Eliakim, Maaseiah, Miniamin, Micaiah, Elioenai, Zechariah, and Hananiah, with trumpets; 

###### v42 
and Maaseiah, Shemaiah, Eleazar, Uzzi, Jehohanan, Malchijah, Elam, and Ezer. The singers sang loud, with Jezrahiah their overseer. 

###### v43 
They offered great sacrifices that day, and rejoiced; for God had made them rejoice with great joy; and the women and the children also rejoiced; so that the joy of Jerusalem was heard even far away. 

###### v44 
On that day, men were appointed over the rooms for the treasures, for the wave offerings, for the first fruits, and for the tithes, to gather into them, according to the fields of the cities, the portions appointed by the law for the priests and Levites; for Judah rejoiced for the priests and for the Levites who served. 

###### v45 
They performed the duty of their God, and the duty of the purification, and so did the singers and the gatekeepers, according to the commandment of David, and of Solomon his son. 

###### v46 
For in the days of David and Asaph of old there was a chief of the singers, and songs of praise and thanksgiving to God. 

###### v47 
All Israel in the days of Zerubbabel, and in the days of Nehemiah, gave the portions of the singers and the gatekeepers, as every day required; and they set apart that which was for the Levites; and the Levites set apart that which was for the sons of Aaron.

***
[[Neh-11|← Nehemiah 11]] | [[Nehemiah]] | [[Neh-13|Nehemiah 13 →]]
