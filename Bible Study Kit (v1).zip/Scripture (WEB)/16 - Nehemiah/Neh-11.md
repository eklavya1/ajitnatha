# Nehemiah 11

[[Neh-10|← Nehemiah 10]] | [[Nehemiah]] | [[Neh-12|Nehemiah 12 →]]
***



###### v1 
The princes of the people lived in Jerusalem. The rest of the people also cast lots, to bring one of ten to dwell in Jerusalem the holy city, and nine parts in the other cities. 

###### v2 
The people blessed all the men who willingly offered themselves to dwell in Jerusalem. 

###### v3 
Now these are the chiefs of the province who lived in Jerusalem; but in the cities of Judah everyone lived in his possession in their cities: Israel, the priests, the Levites, the temple servants, and the children of Solomon's servants. 

###### v4 
Some of the children of Judah and of the children of Benjamin lived in Jerusalem. Of the children of Judah: Athaiah the son of Uzziah, the son of Zechariah, the son of Amariah, the son of Shephatiah, the son of Mahalalel, of the children of Perez; 

###### v5 
and Maaseiah the son of Baruch, the son of Colhozeh, the son of Hazaiah, the son of Adaiah, the son of Joiarib, the son of Zechariah, the son of the Shilonite. 

###### v6 
All the sons of Perez who lived in Jerusalem were four hundred sixty-eight valiant men. 

###### v7 
These are the sons of Benjamin: Sallu the son of Meshullam, the son of Joed, the son of Pedaiah, the son of Kolaiah, the son of Maaseiah, the son of Ithiel, the son of Jeshaiah. 

###### v8 
After him Gabbai, Sallai, nine hundred twenty-eight. 

###### v9 
Joel the son of Zichri was their overseer; and Judah the son of Hassenuah was second over the city. 

###### v10 
Of the priests: Jedaiah the son of Joiarib, Jachin, 

###### v11 
Seraiah the son of Hilkiah, the son of Meshullam, the son of Zadok, the son of Meraioth, the son of Ahitub, the ruler of God's house, 

###### v12 
and their brothers who did the work of the house, eight hundred twenty-two; and Adaiah the son of Jeroham, the son of Pelaliah, the son of Amzi, the son of Zechariah, the son of Pashhur, the son of Malchijah, 

###### v13 
and his brothers, chiefs of fathers' households, two hundred forty-two; and Amashsai the son of Azarel, the son of Ahzai, the son of Meshillemoth, the son of Immer, 

###### v14 
and their brothers, mighty men of valor, one hundred twenty-eight; and their overseer was Zabdiel, the son of Haggedolim. 

###### v15 
Of the Levites: Shemaiah the son of Hasshub, the son of Azrikam, the son of Hashabiah, the son of Bunni; 

###### v16 
and Shabbethai and Jozabad, of the chiefs of the Levites, who had the oversight of the outward business of God's house; 

###### v17 
and Mattaniah the son of Mica, the son of Zabdi, the son of Asaph, who was the chief to begin the thanksgiving in prayer, and Bakbukiah, the second among his brothers; and Abda the son of Shammua, the son of Galal, the son of Jeduthun. 

###### v18 
All the Levites in the holy city were two hundred eighty-four. 

###### v19 
Moreover the gatekeepers, Akkub, Talmon, and their brothers, who kept watch at the gates, were one hundred seventy-two. 

###### v20 
The residue of Israel, of the priests, the Levites, were in all the cities of Judah, everyone in his inheritance. 

###### v21 
But the temple servants lived in Ophel: and Ziha and Gishpa were over the temple servants. 

###### v22 
The overseer also of the Levites at Jerusalem was Uzzi the son of Bani, the son of Hashabiah, the son of Mattaniah, the son of Mica, of the sons of Asaph, the singers, over the business of God's house. 

###### v23 
For there was a commandment from the king concerning them, and a settled provision for the singers, as every day required. 

###### v24 
Pethahiah the son of Meshezabel, of the children of Zerah the son of Judah, was at the king's hand in all matters concerning the people. 

###### v25 
As for the villages, with their fields, some of the children of Judah lived in Kiriath Arba and its towns, in Dibon and its towns, in Jekabzeel and its villages, 

###### v26 
in Jeshua, in Moladah, Beth Pelet, 

###### v27 
in Hazar Shual, in Beersheba and its towns, 

###### v28 
in Ziklag, in Meconah and in its towns, 

###### v29 
in En Rimmon, in Zorah, in Jarmuth, 

###### v30 
Zanoah, Adullam, and their villages, Lachish and its fields, and Azekah and its towns. So they encamped from Beersheba to the valley of Hinnom. 

###### v31 
The children of Benjamin also lived from Geba onward, at Michmash and Aija, and at Bethel and its towns, 

###### v32 
at Anathoth, Nob, Ananiah, 

###### v33 
Hazor, Ramah, Gittaim, 

###### v34 
Hadid, Zeboim, Neballat, 

###### v35 
Lod, and Ono, the valley of craftsmen. 

###### v36 
Of the Levites, certain divisions in Judah settled in Benjamin's territory.

***
[[Neh-10|← Nehemiah 10]] | [[Nehemiah]] | [[Neh-12|Nehemiah 12 →]]
