# Nehemiah 3

[[Neh-02|← Nehemiah 02]] | [[Nehemiah]] | [[Neh-04|Nehemiah 04 →]]
***



###### v1 
Then Eliashib the high priest rose up with his brothers the priests, and they built the sheep gate. They sanctified it, and set up its doors. They sanctified it even to the tower of Hammeah, to the tower of Hananel. 

###### v2 
Next to him the men of Jericho built. Next to them Zaccur the son of Imri built. 

###### v3 
The sons of Hassenaah built the fish gate. They laid its beams, and set up its doors, its bolts, and its bars. 

###### v4 
Next to them, Meremoth the son of Uriah, the son of Hakkoz made repairs. Next to them, Meshullam the son of Berechiah, the son of Meshezabel made repairs. Next to them, Zadok the son of Baana made repairs. 

###### v5 
Next to them, the Tekoites made repairs; but their nobles didn't put their necks to the Lord's work. 

###### v6 
Joiada the son of Paseah and Meshullam the son of Besodeiah repaired the old gate. They laid its beams, and set up its doors, and its bolts, and its bars. 

###### v7 
Next to them, Melatiah the Gibeonite, and Jadon the Meronothite, the men of Gibeon and of Mizpah, repaired the residence of the governor beyond the River. 

###### v8 
Next to him, Uzziel the son of Harhaiah, goldsmiths, made repairs. Next to him, Hananiah, one of the perfumers, made repairs, and they fortified Jerusalem even to the wide wall. 

###### v9 
Next to them, Rephaiah the son of Hur, the ruler of half the district of Jerusalem, made repairs. 

###### v10 
Next to them, Jedaiah the son of Harumaph made repairs across from his house. Next to him, Hattush the son of Hashabneiah made repairs. 

###### v11 
Malchijah the son of Harim, and Hasshub the son of Pahathmoab, repaired another portion, and the tower of the furnaces. 

###### v12 
Next to him, Shallum the son of Hallohesh, the ruler of half the district of Jerusalem, he and his daughters, made repairs. 

###### v13 
Hanun and the inhabitants of Zanoah repaired the valley gate. They built it, and set up its doors, its bolts, and its bars, and one thousand cubits of the wall to the dung gate. 

###### v14 
Malchijah the son of Rechab, the ruler of the district of Beth Haccherem repaired the dung gate. He built it, and set up its doors, its bolts, and its bars. 

###### v15 
Shallun the son of Colhozeh, the ruler of the district of Mizpah repaired the spring gate. He built it, and covered it, and set up its doors, its bolts, and its bars, and the wall of the pool of Shelah by the king's garden, even to the stairs that go down from David's city. 

###### v16 
After him, Nehemiah the son of Azbuk, the ruler of half the district of Beth Zur, made repairs to the place opposite the tombs of David, and to the pool that was made, and to the house of the mighty men. 

###### v17 
After him, the Levites, Rehum the son of Bani made repairs. Next to him, Hashabiah, the ruler of half the district of Keilah, made repairs for his district. 

###### v18 
After him, their brothers, Bavvai the son of Henadad, the ruler of half the district of Keilah made repairs. 

###### v19 
Next to him, Ezer the son of Jeshua, the ruler of Mizpah, repaired another portion, across from the ascent to the armory at the turning of the wall. 

###### v20 
After him, Baruch the son of Zabbai earnestly repaired another portion, from the turning of the wall to the door of the house of Eliashib the high priest. 

###### v21 
After him, Meremoth the son of Uriah the son of Hakkoz repaired another portion, from the door of the house of Eliashib even to the end of the house of Eliashib. 

###### v22 
After him, the priests, the men of the Plain made repairs. 

###### v23 
After them, Benjamin and Hasshub made repairs across from their house. After them, Azariah the son of Maaseiah the son of Ananiah made repairs beside his own house. 

###### v24 
After him, Binnui the son of Henadad repaired another portion, from the house of Azariah to the turning of the wall, and to the corner. 

###### v25 
Palal the son of Uzai made repairs opposite the turning of the wall, and the tower that stands out from the upper house of the king, which is by the court of the guard. After him Pedaiah the son of Parosh made repairs. 

###### v26 
(Now the temple servants lived in Ophel, to the place opposite the water gate toward the east, and the tower that stands out.) 

###### v27 
After him the Tekoites repaired another portion, opposite the great tower that stands out, and to the wall of Ophel. 

###### v28 
Above the horse gate, the priests made repairs, everyone across from his own house. 

###### v29 
After them, Zadok the son of Immer made repairs across from his own house. After him, Shemaiah the son of Shecaniah, the keeper of the east gate made repairs. 

###### v30 
After him, Hananiah the son of Shelemiah, and Hanun the sixth son of Zalaph, repaired another portion. After him, Meshullam the son of Berechiah made repairs across from his room. 

###### v31 
After him, Malchijah, one of the goldsmiths to the house of the temple servants, and of the merchants, made repairs opposite the gate of Hammiphkad, and to the ascent of the corner. 

###### v32 
Between the ascent of the corner and the sheep gate, the goldsmiths and the merchants made repairs.

***
[[Neh-02|← Nehemiah 02]] | [[Nehemiah]] | [[Neh-04|Nehemiah 04 →]]
