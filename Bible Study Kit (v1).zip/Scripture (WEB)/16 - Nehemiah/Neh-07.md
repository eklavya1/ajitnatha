# Nehemiah 7

[[Neh-06|← Nehemiah 06]] | [[Nehemiah]] | [[Neh-08|Nehemiah 08 →]]
***



###### v1 
Now when the wall was built, and I had set up the doors, and the gatekeepers and the singers and the Levites were appointed, 

###### v2 
I put my brother Hanani, and Hananiah the governor of the fortress, in charge of Jerusalem; for he was a faithful man, and feared God above many. 

###### v3 
I said to them, "Don't let the gates of Jerusalem be opened until the sun is hot; and while they stand guard, let them shut the doors, and you bar them: and appoint watches of the inhabitants of Jerusalem, everyone in his watch, with everyone near his house." 

###### v4 
Now the city was wide and large; but the people were few therein, and the houses were not built. 

###### v5 
My God put into my heart to gather together the nobles, and the rulers, and the people, that they might be listed by genealogy. I found the book of the genealogy of those who came up at the first, and I found this written in it: 

###### v6 
These are the children of the province who went up out of the captivity of those who had been carried away, whom Nebuchadnezzar the king of Babylon had carried away, and who returned to Jerusalem and to Judah, everyone to his city, 

###### v7 
who came with Zerubbabel, Jeshua, Nehemiah, Azariah, Raamiah, Nahamani, Mordecai, Bilshan, Mispereth, Bigvai, Nehum, Baanah. The number of the men of the people of Israel: 

###### v8 
The children of Parosh: two thousand one hundred seventy-two. 

###### v9 
The children of Shephatiah: three hundred seventy-two. 

###### v10 
The children of Arah: six hundred fifty-two. 

###### v11 
The children of Pahathmoab, of the children of Jeshua and Joab: two thousand eight hundred eighteen. 

###### v12 
The children of Elam: one thousand two hundred fifty-four. 

###### v13 
The children of Zattu: eight hundred forty-five. 

###### v14 
The children of Zaccai: seven hundred sixty. 

###### v15 
The children of Binnui: six hundred forty-eight. 

###### v16 
The children of Bebai: six hundred twenty-eight. 

###### v17 
The children of Azgad: two thousand three hundred twenty-two. 

###### v18 
The children of Adonikam: six hundred sixty-seven. 

###### v19 
The children of Bigvai: two thousand sixty-seven. 

###### v20 
The children of Adin: six hundred fifty-five. 

###### v21 
The children of Ater: of Hezekiah, ninety-eight. 

###### v22 
The children of Hashum: three hundred twenty-eight. 

###### v23 
The children of Bezai: three hundred twenty-four. 

###### v24 
The children of Hariph: one hundred twelve. 

###### v25 
The children of Gibeon: ninety-five. 

###### v26 
The men of Bethlehem and Netophah: one hundred eighty-eight. 

###### v27 
The men of Anathoth: one hundred twenty-eight. 

###### v28 
The men of Beth Azmaveth: forty-two. 

###### v29 
The men of Kiriath Jearim, Chephirah, and Beeroth: seven hundred forty-three. 

###### v30 
The men of Ramah and Geba: six hundred twenty-one. 

###### v31 
The men of Michmas: one hundred twenty-two. 

###### v32 
The men of Bethel and Ai: one hundred twenty-three. 

###### v33 
The men of the other Nebo: fifty-two. 

###### v34 
The children of the other Elam: one thousand two hundred fifty-four. 

###### v35 
The children of Harim: three hundred twenty. 

###### v36 
The children of Jericho: three hundred forty-five. 

###### v37 
The children of Lod, Hadid, and Ono: seven hundred twenty-one. 

###### v38 
The children of Senaah: three thousand nine hundred thirty. 

###### v39 
The priests: The children of Jedaiah, of the house of Jeshua: nine hundred seventy-three. 

###### v40 
The children of Immer: one thousand fifty-two. 

###### v41 
The children of Pashhur: one thousand two hundred forty-seven. 

###### v42 
The children of Harim: one thousand seventeen. 

###### v43 
The Levites: the children of Jeshua, of Kadmiel, of the children of Hodevah: seventy-four. 

###### v44 
The singers: the children of Asaph: one hundred forty-eight. 

###### v45 
The gatekeepers: the children of Shallum, the children of Ater, the children of Talmon, the children of Akkub, the children of Hatita, the children of Shobai: one hundred thirty-eight. 

###### v46 
The temple servants: the children of Ziha, the children of Hasupha, the children of Tabbaoth, 

###### v47 
the children of Keros, the children of Sia, the children of Padon, 

###### v48 
the children of Lebana, the children of Hagaba, the children of Salmai, 

###### v49 
the children of Hanan, the children of Giddel, the children of Gahar, 

###### v50 
the children of Reaiah, the children of Rezin, the children of Nekoda, 

###### v51 
the children of Gazzam, the children of Uzza, the children of Paseah, 

###### v52 
the children of Besai, the children of Meunim, the children of Nephushesim, 

###### v53 
the children of Bakbuk, the children of Hakupha, the children of Harhur, 

###### v54 
the children of Bazlith, the children of Mehida, the children of Harsha, 

###### v55 
the children of Barkos, the children of Sisera, the children of Temah, 

###### v56 
the children of Neziah, and the children of Hatipha. 

###### v57 
The children of Solomon's servants: the children of Sotai, the children of Sophereth, the children of Perida, 

###### v58 
the children of Jaala, the children of Darkon, the children of Giddel, 

###### v59 
the children of Shephatiah, the children of Hattil, the children of Pochereth Hazzebaim, and the children of Amon. 

###### v60 
All the temple servants and the children of Solomon's servants were three hundred ninety-two. 

###### v61 
These were those who went up from Tel Melah, Tel Harsha, Cherub, Addon, and Immer; but they could not show their fathers' houses, nor their offspring, whether they were of Israel: 

###### v62 
The children of Delaiah, the children of Tobiah, the children of Nekoda: six hundred forty-two. 

###### v63 
Of the priests: the children of Hobaiah, the children of Hakkoz, the children of Barzillai, who took a wife of the daughters of Barzillai the Gileadite, and was called after their name. 

###### v64 
These searched for their genealogical records, but couldn't find them. Therefore they were deemed disqualified and removed from the priesthood. 

###### v65 
The governor told them not to eat of the most holy things until a priest stood up to minister with Urim and Thummim. 

###### v66 
The whole assembly together was forty-two thousand three hundred sixty, 

###### v67 
in addition to their male servants and their female servants, of whom there were seven thousand three hundred thirty-seven. They had two hundred forty-five singing men and singing women. 

###### v68 
Their horses were seven hundred thirty-six; their mules, two hundred forty-five; 

###### v69 
their camels, four hundred thirty-five; their donkeys, six thousand seven hundred twenty. 

###### v70 
Some from among the heads of fathers' households gave to the work. The governor gave to the treasury one thousand darics of gold, fifty basins, and five hundred thirty priests' garments. 

###### v71 
Some of the heads of fathers' households gave into the treasury of the work twenty thousand darics of gold, and two thousand two hundred minas of silver. 

###### v72 
That which the rest of the people gave was twenty thousand darics of gold, plus two thousand minas of silver, and sixty-seven priests' garments. 

###### v73 
So the priests, the Levites, the gatekeepers, the singers, some of the people, the temple servants, and all Israel, lived in their cities. When the seventh month had come, the children of Israel were in their cities.

***
[[Neh-06|← Nehemiah 06]] | [[Nehemiah]] | [[Neh-08|Nehemiah 08 →]]
