# Esther 7

[[Esth-06|← Esther 06]] | [[Esther]] | [[Esth-08|Esther 08 →]]
***



###### v1 
So the king and Haman came to banquet with Esther the queen. 

###### v2 
The king said again to Esther on the second day at the banquet of wine, "What is your petition, queen Esther? It shall be granted you. What is your request? Even to the half of the kingdom it shall be performed." 

###### v3 
Then Esther the queen answered, "If I have found favor in your sight, O king, and if it pleases the king, let my life be given me at my petition, and my people at my request. 

###### v4 
For we are sold, I and my people, to be destroyed, to be slain, and to perish. But if we had been sold for male and female slaves, I would have held my peace, although the adversary could not have compensated for the king's loss." 

###### v5 
Then King Ahasuerus said to Esther the queen, "Who is he, and where is he who dared presume in his heart to do so?" 

###### v6 
Esther said, "An adversary and an enemy, even this wicked Haman!" Then Haman was afraid before the king and the queen. 

###### v7 
The king arose in his wrath from the banquet of wine and went into the palace garden. Haman stood up to make request for his life to Esther the queen; for he saw that there was evil determined against him by the king. 

###### v8 
Then the king returned out of the palace garden into the place of the banquet of wine; and Haman had fallen on the couch where Esther was. Then the king said, "Will he even assault the queen in front of me in the house?" As the word went out of the king's mouth, they covered Haman's face. 

###### v9 
Then Harbonah, one of the eunuchs who were with the king said, "Behold, the gallows fifty cubits high, which Haman has made for Mordecai, who spoke good for the king, is standing at Haman's house." The king said, "Hang him on it!" 

###### v10 
So they hanged Haman on the gallows that he had prepared for Mordecai. Then the king's wrath was pacified.

***
[[Esth-06|← Esther 06]] | [[Esther]] | [[Esth-08|Esther 08 →]]
