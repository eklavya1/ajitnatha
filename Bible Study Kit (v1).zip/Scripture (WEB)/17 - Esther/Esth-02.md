# Esther 2

[[Esth-01|← Esther 01]] | [[Esther]] | [[Esth-03|Esther 03 →]]
***



###### v1 
After these things, when the wrath of King Ahasuerus was pacified, he remembered Vashti, and what she had done, and what was decreed against her. 

###### v2 
Then the king's servants who served him said, "Let beautiful young virgins be sought for the king. 

###### v3 
Let the king appoint officers in all the provinces of his kingdom, that they may gather together all the beautiful young virgins to the citadel of Susa, to the women's house, to the custody of Hegai the king's eunuch, keeper of the women. Let cosmetics be given them; 

###### v4 
and let the maiden who pleases the king be queen instead of Vashti." The thing pleased the king, and he did so. 

###### v5 
There was a certain Jew in the citadel of Susa, whose name was Mordecai, the son of Jair, the son of Shimei, the son of Kish, a Benjamite, 

###### v6 
who had been carried away from Jerusalem with the captives who had been carried away with Jeconiah king of Judah, whom Nebuchadnezzar the king of Babylon had carried away. 

###### v7 
He brought up Hadassah, that is, Esther, his uncle's daughter; for she had neither father nor mother. The maiden was fair and beautiful; and when her father and mother were dead, Mordecai took her for his own daughter. 

###### v8 
So, when the king's commandment and his decree was heard, and when many maidens were gathered together to the citadel of Susa, to the custody of Hegai, Esther was taken into the king's house, to the custody of Hegai, keeper of the women. 

###### v9 
The maiden pleased him, and she obtained kindness from him. He quickly gave her cosmetics and her portions of food, and the seven choice maidens who were to be given her out of the king's house. He moved her and her maidens to the best place in the women's house. 

###### v10 
Esther had not made known her people nor her relatives, because Mordecai had instructed her that she should not make it known. 

###### v11 
Mordecai walked every day in front of the court of the women's house, to find out how Esther was doing, and what would become of her. 

###### v12 
Each young woman's turn came to go in to King Ahasuerus after her purification for twelve months (for so were the days of their purification accomplished, six months with oil of myrrh, and six months with sweet fragrances and with preparations for beautifying women). 

###### v13 
The young woman then came to the king like this: whatever she desired was given her to go with her out of the women's house to the king's house. 

###### v14 
In the evening she went, and on the next day she returned into the second women's house, to the custody of Shaashgaz, the king's eunuch, who kept the concubines. She came in to the king no more, unless the king delighted in her, and she was called by name. 

###### v15 
Now when the turn of Esther, the daughter of Abihail the uncle of Mordecai, who had taken her for his daughter, came to go in to the king, she required nothing but what Hegai the king's eunuch, the keeper of the women, advised. Esther obtained favor in the sight of all those who looked at her. 

###### v16 
So Esther was taken to King Ahasuerus into his royal house in the tenth month, which is the month Tebeth, in the seventh year of his reign. 

###### v17 
The king loved Esther more than all the women, and she obtained favor and kindness in his sight more than all the virgins; so that he set the royal crown on her head, and made her queen instead of Vashti. 

###### v18 
Then the king made a great feast for all his princes and his servants, even Esther's feast; and he proclaimed a holiday in the provinces, and gave gifts according to the king's bounty. 

###### v19 
When the virgins were gathered together the second time, Mordecai was sitting in the king's gate. 

###### v20 
Esther had not yet made known her relatives nor her people, as Mordecai had commanded her; for Esther obeyed Mordecai, like she did when she was brought up by him. 

###### v21 
In those days, while Mordecai was sitting in the king's gate, two of the king's eunuchs, Bigthan and Teresh, who were doorkeepers, were angry, and sought to lay hands on the King Ahasuerus. 

###### v22 
This thing became known to Mordecai, who informed Esther the queen; and Esther informed the king in Mordecai's name. 

###### v23 
When this matter was investigated, and it was found to be so, they were both hanged on a gallows; and it was written in the book of the chronicles in the king's presence.

***
[[Esth-01|← Esther 01]] | [[Esther]] | [[Esth-03|Esther 03 →]]
