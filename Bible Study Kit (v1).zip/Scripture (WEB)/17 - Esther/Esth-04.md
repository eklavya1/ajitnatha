# Esther 4

[[Esth-03|← Esther 03]] | [[Esther]] | [[Esth-05|Esther 05 →]]
***



###### v1 
Now when Mordecai found out all that was done, Mordecai tore his clothes, and put on sackcloth with ashes, and went out into the middle of the city, and wailed loudly and bitterly. 

###### v2 
He came even before the king's gate, for no one is allowed inside the king's gate clothed with sackcloth. 

###### v3 
In every province, wherever the king's commandment and his decree came, there was great mourning among the Jews, and fasting, and weeping, and wailing; and many lay in sackcloth and ashes. 

###### v4 
Esther's maidens and her eunuchs came and told her this, and the queen was exceedingly grieved. She sent clothing to Mordecai, to replace his sackcloth; but he didn't receive it. 

###### v5 
Then Esther called for Hathach, one of the king's eunuchs, whom he had appointed to attend her, and commanded him to go to Mordecai, to find out what this was, and why it was. 

###### v6 
So Hathach went out to Mordecai, to city square which was before the king's gate. 

###### v7 
Mordecai told him of all that had happened to him, and the exact sum of the money that Haman had promised to pay to the king's treasuries for the destruction of the Jews. 

###### v8 
He also gave him the copy of the writing of the decree that was given out in Susa to destroy them, to show it to Esther, and to declare it to her, and to urge her to go in to the king, to make supplication to him, and to make request before him, for her people. 

###### v9 
Hathach came and told Esther the words of Mordecai. 

###### v10 
Then Esther spoke to Hathach, and gave him a message to Mordecai: 

###### v11 
"All the king's servants and the people of the king's provinces know that whoever, whether man or woman, comes to the king into the inner court without being called, there is one law for him, that he be put to death, except those to whom the king might hold out the golden scepter, that he may live. I have not been called to come in to the king these thirty days." 

###### v12 
They told Esther's words to Mordecai. 

###### v13 
Then Mordecai asked them to return this answer to Esther: "Don't think to yourself that you will escape in the king's house any more than all the Jews. 

###### v14 
For if you remain silent now, then relief and deliverance will come to the Jews from another place, but you and your father's house will perish. Who knows if you haven't come to the kingdom for such a time as this?" 

###### v15 
Then Esther asked them to answer Mordecai, 

###### v16 
"Go, gather together all the Jews who are present in Susa, and fast for me, and neither eat nor drink three days, night or day. I and my maidens will also fast the same way. Then I will go in to the king, which is against the law; and if I perish, I perish." 

###### v17 
So Mordecai went his way, and did according to all that Esther had commanded him.

***
[[Esth-03|← Esther 03]] | [[Esther]] | [[Esth-05|Esther 05 →]]
