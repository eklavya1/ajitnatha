# Esther 3

[[Esth-02|← Esther 02]] | [[Esther]] | [[Esth-04|Esther 04 →]]
***



###### v1 
After these things King Ahasuerus promoted Haman the son of Hammedatha the Agagite, and advanced him, and set his seat above all the princes who were with him. 

###### v2 
All the king's servants who were in the king's gate bowed down, and paid homage to Haman; for the king had so commanded concerning him. But Mordecai didn't bow down or pay him homage. 

###### v3 
Then the king's servants, who were in the king's gate, said to Mordecai, "Why do you disobey the king's commandment?" 

###### v4 
Now it came to pass, when they spoke daily to him, and he didn't listen to them, that they told Haman, to see whether Mordecai's reason would stand; for he had told them that he was a Jew. 

###### v5 
When Haman saw that Mordecai didn't bow down, nor pay him homage, Haman was full of wrath. 

###### v6 
But he scorned the thought of laying hands on Mordecai alone, for they had made known to him Mordecai's people. Therefore Haman sought to destroy all the Jews who were throughout the whole kingdom of Ahasuerus, even Mordecai's people. 

###### v7 
In the first month, which is the month Nisan, in the twelfth year of King Ahasuerus, they cast Pur, that is, the lot, before Haman from day to day, and from month to month, and chose the twelfth month, which is the month Adar. 

###### v8 
Haman said to King Ahasuerus, "There is a certain people scattered abroad and dispersed among the peoples in all the provinces of your kingdom, and their laws are different from other people's. They don't keep the king's laws. Therefore it is not for the king's profit to allow them to remain. 

###### v9 
If it pleases the king, let it be written that they be destroyed; and I will pay ten thousand talents of silver into the hands of those who are in charge of the king's business, to bring it into the king's treasuries." 

###### v10 
The king took his ring from his hand, and gave it to Haman the son of Hammedatha the Agagite, the Jews' enemy. 

###### v11 
The king said to Haman, "The silver is given to you, the people also, to do with them as it seems good to you." 

###### v12 
Then the king's scribes were called in on the first month, on the thirteenth day of the month; and all that Haman commanded was written to the king's local governors, and to the governors who were over every province, and to the princes of every people, to every province according to its writing, and to every people in their language. It was written in the name of King Ahasuerus, and it was sealed with the king's ring. 

###### v13 
Letters were sent by couriers into all the king's provinces, to destroy, to kill, and to cause to perish, all Jews, both young and old, little children and women, in one day, even on the thirteenth day of the twelfth month, which is the month Adar, and to plunder their possessions. 

###### v14 
A copy of the letter, that the decree should be given out in every province, was published to all the peoples, that they should be ready against that day. 

###### v15 
The couriers went out in haste by the king's commandment, and the decree was given out in the citadel of Susa. The king and Haman sat down to drink; but the city of Susa was perplexed.

***
[[Esth-02|← Esther 02]] | [[Esther]] | [[Esth-04|Esther 04 →]]
