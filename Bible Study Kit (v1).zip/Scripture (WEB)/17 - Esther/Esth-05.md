# Esther 5

[[Esth-04|← Esther 04]] | [[Esther]] | [[Esth-06|Esther 06 →]]
***



###### v1 
Now on the third day, Esther put on her royal clothing, and stood in the inner court of the king's house, next to the king's house. The king sat on his royal throne in the royal house, next to the entrance of the house. 

###### v2 
When the king saw Esther the queen standing in the court, she obtained favor in his sight; and the king held out to Esther the golden scepter that was in his hand. So Esther came near, and touched the top of the scepter. 

###### v3 
Then the king asked her, "What would you like, queen Esther? What is your request? It shall be given you even to the half of the kingdom." 

###### v4 
Esther said, "If it seems good to the king, let the king and Haman come today to the banquet that I have prepared for him." 

###### v5 
Then the king said, "Bring Haman quickly, so that it may be done as Esther has said." So the king and Haman came to the banquet that Esther had prepared. 

###### v6 
The king said to Esther at the banquet of wine, "What is your petition? It shall be granted you. What is your request? Even to the half of the kingdom it shall be performed." 

###### v7 
Then Esther answered and said, "My petition and my request is this. 

###### v8 
If I have found favor in the sight of the king, and if it pleases the king to grant my petition and to perform my request, let the king and Haman come to the banquet that I will prepare for them, and I will do tomorrow as the king has said." 

###### v9 
Then Haman went out that day joyful and glad of heart, but when Haman saw Mordecai in the king's gate, that he didn't stand up nor move for him, he was filled with wrath against Mordecai. 

###### v10 
Nevertheless Haman restrained himself, and went home. There, he sent and called for his friends and Zeresh his wife. 

###### v11 
Haman recounted to them the glory of his riches, the multitude of his children, all the things in which the king had promoted him, and how he had advanced him above the princes and servants of the king. 

###### v12 
Haman also said, "Yes, Esther the queen let no man come in with the king to the banquet that she had prepared but myself; and tomorrow I am also invited by her together with the king. 

###### v13 
Yet all this avails me nothing, so long as I see Mordecai the Jew sitting at the king's gate." 

###### v14 
Then Zeresh his wife and all his friends said to him, "Let a gallows be made fifty cubits high, and in the morning speak to the king about hanging Mordecai on it. Then go in merrily with the king to the banquet." This pleased Haman, so he had the gallows made.

***
[[Esth-04|← Esther 04]] | [[Esther]] | [[Esth-06|Esther 06 →]]
