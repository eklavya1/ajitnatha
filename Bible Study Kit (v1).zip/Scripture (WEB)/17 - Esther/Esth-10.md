# Esther 10

[[Esth-09|← Esther 09]] | [[Esther]]
***



###### v1 
King Ahasuerus laid a tribute on the land, and on the islands of the sea. 

###### v2 
Aren't all the acts of his power and of his might, and the full account of the greatness of Mordecai, to which the king advanced him, written in the book of the chronicles of the kings of Media and Persia? 

###### v3 
For Mordecai the Jew was next to King Ahasuerus, and great among the Jews, and accepted by the multitude of his brothers, seeking the good of his people, and speaking peace to all his descendants.

***
[[Esth-09|← Esther 09]] | [[Esther]]
