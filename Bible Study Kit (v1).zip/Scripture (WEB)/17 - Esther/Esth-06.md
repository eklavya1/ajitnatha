# Esther 6

[[Esth-05|← Esther 05]] | [[Esther]] | [[Esth-07|Esther 07 →]]
***



###### v1 
On that night, the king couldn't sleep. He commanded the book of records of the chronicles to be brought, and they were read to the king. 

###### v2 
It was found written that Mordecai had told of Bigthana and Teresh, two of the king's eunuchs, who were doorkeepers, who had tried to lay hands on the King Ahasuerus. 

###### v3 
The king said, "What honor and dignity has been given to Mordecai for this?" Then the king's servants who attended him said, "Nothing has been done for him." 

###### v4 
The king said, "Who is in the court?" Now Haman had come into the outer court of the king's house, to speak to the king about hanging Mordecai on the gallows that he had prepared for him. 

###### v5 
The king's servants said to him, "Behold, Haman stands in the court." The king said, "Let him come in." 

###### v6 
So Haman came in. The king said to him, "What shall be done to the man whom the king delights to honor?" Now Haman said in his heart, "Who would the king delight to honor more than myself?" 

###### v7 
Haman said to the king, "For the man whom the king delights to honor, 

###### v8 
let royal clothing be brought which the king uses to wear, and the horse that the king rides on, and on the head of which a royal crown is set. 

###### v9 
Let the clothing and the horse be delivered to the hand of one of the king's most noble princes, that they may array the man whom the king delights to honor with them, and have him ride on horseback through the city square, and proclaim before him, 'Thus it shall be done to the man whom the king delights to honor!'" 

###### v10 
Then the king said to Haman, "Hurry and take the clothing and the horse, as you have said, and do this for Mordecai the Jew, who sits at the king's gate. Let nothing fail of all that you have spoken." 

###### v11 
Then Haman took the clothing and the horse, and arrayed Mordecai, and had him ride through the city square, and proclaimed before him, "Thus it shall be done to the man whom the king delights to honor!" 

###### v12 
Mordecai came back to the king's gate, but Haman hurried to his house, mourning and having his head covered. 

###### v13 
Haman recounted to Zeresh his wife and all his friends everything that had happened to him. Then his wise men and Zeresh his wife said to him, "If Mordecai, before whom you have begun to fall, is of Jewish descent, you will not prevail against him, but you will surely fall before him." 

###### v14 
While they were yet talking with him, the king's eunuchs came, and hurried to bring Haman to the banquet that Esther had prepared.

***
[[Esth-05|← Esther 05]] | [[Esther]] | [[Esth-07|Esther 07 →]]
