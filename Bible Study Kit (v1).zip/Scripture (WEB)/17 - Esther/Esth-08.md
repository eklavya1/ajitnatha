# Esther 8

[[Esth-07|← Esther 07]] | [[Esther]] | [[Esth-09|Esther 09 →]]
***



###### v1 
On that day, King Ahasuerus gave the house of Haman, the Jews' enemy, to Esther the queen. Mordecai came before the king; for Esther had told what he was to her. 

###### v2 
The king took off his ring, which he had taken from Haman, and gave it to Mordecai. Esther set Mordecai over the house of Haman. 

###### v3 
Esther spoke yet again before the king, and fell down at his feet, and begged him with tears to put away the mischief of Haman the Agagite, and his plan that he had planned against the Jews. 

###### v4 
Then the king held out to Esther the golden scepter. So Esther arose, and stood before the king. 

###### v5 
She said, "If it pleases the king, and if I have found favor in his sight, and the thing seems right to the king, and I am pleasing in his eyes, let it be written to reverse the letters devised by Haman, the son of Hammedatha the Agagite, which he wrote to destroy the Jews who are in all the king's provinces. 

###### v6 
For how can I endure to see the evil that would come to my people? How can I endure to see the destruction of my relatives?" 

###### v7 
Then King Ahasuerus said to Esther the queen and to Mordecai the Jew, "See, I have given Esther the house of Haman, and they have hanged him on the gallows, because he laid his hand on the Jews. 

###### v8 
Write also to the Jews, as it pleases you, in the king's name, and seal it with the king's ring; for the writing which is written in the king's name, and sealed with the king's ring, may not be reversed by any man." 

###### v9 
Then the king's scribes were called at that time, in the third month, which is the month Sivan, on the twenty-third day of the month; and it was written according to all that Mordecai commanded to the Jews, and to the local governors, and the governors and princes of the provinces which are from India to Ethiopia, one hundred twenty-seven provinces, to every province according to its writing, and to every people in their language, and to the Jews in their writing, and in their language. 

###### v10 
He wrote in the name of King Ahasuerus, and sealed it with the king's ring, and sent letters by courier on horseback, riding on royal horses that were bred from swift steeds. 

###### v11 
In those letters, the king granted the Jews who were in every city to gather themselves together, and to defend their life, to destroy, to kill, and to cause to perish, all the power of the people and province that would assault them, their little ones and women, and to plunder their possessions, 

###### v12 
on one day in all the provinces of King Ahasuerus, on the thirteenth day of the twelfth month, which is the month Adar. 

###### v13 
A copy of the letter, that the decree should be given out in every province, was published to all the peoples, that the Jews should be ready for that day to avenge themselves on their enemies. 

###### v14 
So the couriers who rode on royal horses went out, hastened and pressed on by the king's commandment. The decree was given out in the citadel of Susa. 

###### v15 
Mordecai went out of the presence of the king in royal clothing of blue and white, and with a great crown of gold, and with a robe of fine linen and purple; and the city of Susa shouted and was glad. 

###### v16 
The Jews had light, gladness, joy, and honor. 

###### v17 
In every province, and in every city, wherever the king's commandment and his decree came, the Jews had gladness, joy, a feast, and a good day. Many from among the peoples of the land became Jews; for the fear of the Jews had fallen on them.

***
[[Esth-07|← Esther 07]] | [[Esther]] | [[Esth-09|Esther 09 →]]
