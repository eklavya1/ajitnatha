# Esther 9

[[Esth-08|← Esther 08]] | [[Esther]] | [[Esth-10|Esther 10 →]]
***



###### v1 
Now in the twelfth month, which is the month Adar, on the thirteenth day of the month, when the king's commandment and his decree came near to be put in execution, on the day that the enemies of the Jews hoped to conquer them, (but it was turned out the opposite happened, that the Jews conquered those who hated them), 

###### v2 
the Jews gathered themselves together in their cities throughout all the provinces of the King Ahasuerus, to lay hands on those who wanted to harm them. No one could withstand them, because the fear of them had fallen on all the people. 

###### v3 
All the princes of the provinces, the local governors, the governors, and those who did the king's business helped the Jews, because the fear of Mordecai had fallen on them. 

###### v4 
For Mordecai was great in the king's house, and his fame went out throughout all the provinces; for the man Mordecai grew greater and greater. 

###### v5 
The Jews struck all their enemies with the stroke of the sword, and with slaughter and destruction, and did what they wanted to those who hated them. 

###### v6 
In the citadel of Susa, the Jews killed and destroyed five hundred men. 

###### v7 
They killed Parshandatha, Dalphon, Aspatha, 

###### v8 
Poratha, Adalia, Aridatha, 

###### v9 
Parmashta, Arisai, Aridai, and Vaizatha, 

###### v10 
the ten sons of Haman the son of Hammedatha, the Jews' enemy, but they didn't lay their hand on the plunder. 

###### v11 
On that day, the number of those who were slain in the citadel of Susa was brought before the king. 

###### v12 
The king said to Esther the queen, "The Jews have slain and destroyed five hundred men in the citadel of Susa, including the ten sons of Haman; what then have they done in the rest of the king's provinces! Now what is your petition? It shall be granted you. What is your further request? It shall be done." 

###### v13 
Then Esther said, "If it pleases the king, let it be granted to the Jews who are in Susa to do tomorrow also according to today's decree, and let Haman's ten sons be hanged on the gallows." 

###### v14 
The king commanded this to be done. A decree was given out in Susa; and they hanged Haman's ten sons. 

###### v15 
The Jews who were in Susa gathered themselves together on the fourteenth day also of the month Adar, and killed three hundred men in Susa; but they didn't lay their hand on the plunder. 

###### v16 
The other Jews who were in the king's provinces gathered themselves together, defended their lives, had rest from their enemies, and killed seventy-five thousand of those who hated them; but they didn't lay their hand on the plunder. 

###### v17 
This was done on the thirteenth day of the month Adar; and on the fourteenth day of that month they rested and made it a day of feasting and gladness. 

###### v18 
But the Jews who were in Susa assembled together on the thirteenth and on the fourteenth days of the month; and on the fifteenth day of that month, they rested, and made it a day of feasting and gladness. 

###### v19 
Therefore the Jews of the villages, who live in the unwalled towns, make the fourteenth day of the month Adar a day of gladness and feasting, a good day, and a day of sending presents of food to one another. 

###### v20 
Mordecai wrote these things, and sent letters to all the Jews who were in all the provinces of the king Ahasuerus, both near and far, 

###### v21 
to enjoin them that they should keep the fourteenth and fifteenth days of the month Adar yearly, 

###### v22 
as the days in which the Jews had rest from their enemies, and the month which was turned to them from sorrow to gladness, and from mourning into a good day; that they should make them days of feasting and gladness, and of sending presents of food to one another, and gifts to the needy. 

###### v23 
The Jews accepted the custom that they had begun, as Mordecai had written to them; 

###### v24 
because Haman the son of Hammedatha, the Agagite, the enemy of all the Jews, had plotted against the Jews to destroy them, and had cast "Pur", that is the lot, to consume them, and to destroy them; 

###### v25 
but when this became known to the king, he commanded by letters that his wicked plan, which he had planned against the Jews, should return on his own head, and that he and his sons should be hanged on the gallows. 

###### v26 
Therefore they called these days "Purim", from the word "Pur." Therefore because of all the words of this letter, and of that which they had seen concerning this matter, and that which had come to them, 

###### v27 
the Jews established and imposed on themselves, and on their descendants, and on all those who joined themselves to them, so that it should not fail that they would keep these two days according to what was written, and according to its appointed time, every year; 

###### v28 
and that these days should be remembered and kept throughout every generation, every family, every province, and every city; and that these days of Purim should not fail from among the Jews, nor their memory perish from their offspring. 

###### v29 
Then Esther the queen, the daughter of Abihail, and Mordecai the Jew, wrote with all authority to confirm this second letter of Purim. 

###### v30 
He sent letters to all the Jews, to the hundred twenty-seven provinces of the kingdom of Ahasuerus, with words of peace and truth, 

###### v31 
to confirm these days of Purim in their appointed times, as Mordecai the Jew and Esther the queen had decreed, and as they had imposed upon themselves and their descendants, in the matter of the fastings and their cry. 

###### v32 
The commandment of Esther confirmed these matters of Purim; and it was written in the book.

***
[[Esth-08|← Esther 08]] | [[Esther]] | [[Esth-10|Esther 10 →]]
