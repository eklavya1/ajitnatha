# Esther 1

[[Esther]] | [[Esth-02|Esther 02 →]]
***



###### v1 
Now in the days of Ahasuerus (this is Ahasuerus who reigned from India even to Ethiopia, over one hundred twenty-seven provinces), 

###### v2 
in those days, when the King Ahasuerus sat on the throne of his kingdom, which was in Susa the palace, 

###### v3 
in the third year of his reign, he made a feast for all his princes and his servants; the power of Persia and Media, the nobles and princes of the provinces, being before him. 

###### v4 
He displayed the riches of his glorious kingdom and the honor of his excellent majesty many days, even one hundred eighty days. 

###### v5 
When these days were fulfilled, the king made a seven day feast for all the people who were present in Susa the palace, both great and small, in the court of the garden of the king's palace. 

###### v6 
There were hangings of white and blue material, fastened with cords of fine linen and purple to silver rings and marble pillars. The couches were of gold and silver, on a pavement of red, white, yellow, and black marble. 

###### v7 
They gave them drinks in golden vessels of various kinds, including royal wine in abundance, according to the bounty of the king. 

###### v8 
In accordance with the law, the drinking was not compulsory; for so the king had instructed all the officials of his house, that they should do according to every man's pleasure. 

###### v9 
Also Vashti the queen made a feast for the women in the royal house which belonged to King Ahasuerus. 

###### v10 
On the seventh day, when the heart of the king was merry with wine, he commanded Mehuman, Biztha, Harbona, Bigtha, and Abagtha, Zethar, and Carcass, the seven eunuchs who served in the presence of Ahasuerus the king, 

###### v11 
to bring Vashti the queen before the king with the royal crown, to show the people and the princes her beauty; for she was beautiful. 

###### v12 
But the queen Vashti refused to come at the king's commandment by the eunuchs. Therefore the king was very angry, and his anger burned in him. 

###### v13 
Then the king said to the wise men, who knew the times (for it was the king's custom to consult those who knew law and judgment; 

###### v14 
and next to him were Carshena, Shethar, Admatha, Tarshish, Meres, Marsena, and Memucan, the seven princes of Persia and Media, who saw the king's face, and sat first in the kingdom), 

###### v15 
"What shall we do to Queen Vashti according to law, because she has not done the bidding of the King Ahasuerus by the eunuchs?" 

###### v16 
Memucan answered before the king and the princes, "Vashti the queen has not done wrong to just the king, but also to all the princes, and to all the people who are in all the provinces of the King Ahasuerus. 

###### v17 
For this deed of the queen will become known to all women, causing them to show contempt for their husbands, when it is reported, 'King Ahasuerus commanded Vashti the queen to be brought in before him, but she didn't come.' 

###### v18 
Today, the princesses of Persia and Media who have heard of the queen's deed will tell all the king's princes. This will cause much contempt and wrath. 

###### v19 
"If it pleases the king, let a royal commandment go from him, and let it be written among the laws of the Persians and the Medes, so that it cannot be altered, that Vashti may never again come before King Ahasuerus; and let the king give her royal estate to another who is better than she. 

###### v20 
When the king's decree which he shall make is published throughout all his kingdom (for it is great), all the wives will give their husbands honor, both great and small." 

###### v21 
This advice pleased the king and the princes, and the king did according to the word of Memucan: 

###### v22 
for he sent letters into all the king's provinces, into every province according to its writing, and to every people in their language, that every man should rule his own house, speaking in the language of his own people.

***
[[Esther]] | [[Esth-02|Esther 02 →]]
