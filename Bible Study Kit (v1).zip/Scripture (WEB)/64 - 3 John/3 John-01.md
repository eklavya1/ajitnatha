# 3 John 1

[[3 John]]
***



###### v1 
The elder to Gaius the beloved, whom I love in truth. 

###### v2 
Beloved, I pray that you may prosper in all things and be healthy, even as your soul prospers. 

###### v3 
For I rejoiced greatly when brothers came and testified about your truth, even as you walk in truth. 

###### v4 
I have no greater joy than this: to hear about my children walking in truth. 

###### v5 
Beloved, you do a faithful work in whatever you accomplish for those who are brothers and strangers. 

###### v6 
They have testified about your love before the assembly. You will do well to send them forward on their journey in a way worthy of God, 

###### v7 
because for the sake of the Name they went out, taking nothing from the Gentiles. 

###### v8 
We therefore ought to receive such, that we may be fellow workers for the truth. 

###### v9 
I wrote to the assembly, but Diotrephes, who loves to be first among them, doesn't accept what we say. 

###### v10 
Therefore if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the assembly. 

###### v11 
Beloved, don't imitate that which is evil, but that which is good. He who does good is of God. He who does evil hasn't seen God. 

###### v12 
Demetrius has the testimony of all, and of the truth itself; yes, we also testify, and you know that our testimony is true. 

###### v13 
I had many things to write to you, but I am unwilling to write to you with ink and pen; 

###### v14 
but I hope to see you soon. Then we will speak face to face. Peace be to you. The friends greet you. Greet the friends by name.

***
[[3 John]]
