# Zechariah 10

[[Zech-09|← Zechariah 09]] | [[Zechariah]] | [[Zech-11|Zechariah 11 →]]
***



###### v1 
Ask of Yahweh rain in the spring time, Yahweh who makes storm clouds, and he gives rain showers to everyone for the plants in the field. 

###### v2 
For the teraphim have spoken vanity, and the diviners have seen a lie; and they have told false dreams. They comfort in vain. Therefore they go their way like sheep. They are oppressed, because there is no shepherd. 

###### v3 
My anger is kindled against the shepherds, and I will punish the male goats; For Yahweh of Armies has visited his flock, the house of Judah, and will make them as his majestic horse in the battle. 

###### v4 
From him will come the cornerstone, from him the nail, from him the battle bow, from him every ruler together. 

###### v5 
They shall be as mighty men, treading down muddy streets in the battle; and they shall fight, because Yahweh is with them; and the riders on horses will be confounded. 

###### v6 
"I will strengthen the house of Judah, and I will save the house of Joseph, and I will bring them back; for I have mercy on them; and they will be as though I had not cast them off: for I am Yahweh their God, and I will hear them. 

###### v7 
Ephraim will be like a mighty man, and their heart will rejoice as through wine; yes, their children will see it, and rejoice. Their heart will be glad in Yahweh. 

###### v8 
I will signal for them, and gather them; for I have redeemed them; and they will increase as they have increased. 

###### v9 
I will sow them among the peoples; and they will remember me in far countries; and they will live with their children, and will return. 

###### v10 
I will bring them again also out of the land of Egypt, and gather them out of Assyria; and I will bring them into the land of Gilead and Lebanon; and there won't be room enough for them. 

###### v11 
He will pass through the sea of affliction, and will strike the waves in the sea, and all the depths of the Nile will dry up; and the pride of Assyria will be brought down, and the scepter of Egypt will depart. 

###### v12 
I will strengthen them in Yahweh; and they will walk up and down in his name," says Yahweh.

***
[[Zech-09|← Zechariah 09]] | [[Zechariah]] | [[Zech-11|Zechariah 11 →]]
