# Zechariah 9

[[Zech-08|← Zechariah 08]] | [[Zechariah]] | [[Zech-10|Zechariah 10 →]]
***



###### v1 
A revelation. Yahweh's word is against the land of Hadrach, and will rest upon Damascus; for the eye of man and of all the tribes of Israel is toward Yahweh; 

###### v2 
and Hamath, also, which borders on it; Tyre and Sidon, because they are very wise. 

###### v3 
Tyre built herself a stronghold, and heaped up silver like the dust, and fine gold like the mire of the streets. 

###### v4 
Behold, the Lord will dispossess her, and he will strike her power in the sea; and she will be devoured with fire. 

###### v5 
Ashkelon will see it, and fear; Gaza also, and will writhe in agony; as will Ekron, for her expectation will be disappointed; and the king will perish from Gaza, and Ashkelon will not be inhabited. 

###### v6 
Foreigners will dwell in Ashdod, and I will cut off the pride of the Philistines. 

###### v7 
I will take away his blood out of his mouth, and his abominations from between his teeth; and he also will be a remnant for our God; and he will be as a chieftain in Judah, and Ekron as a Jebusite. 

###### v8 
I will encamp around my house against the army, that no one pass through or return; and no oppressor will pass through them any more: for now I have seen with my eyes. 

###### v9 
Rejoice greatly, daughter of Zion! Shout, daughter of Jerusalem! Behold, your King comes to you! He is righteous, and having salvation; lowly, and riding on a donkey, even on a colt, the foal of a donkey. 

###### v10 
I will cut off the chariot from Ephraim, and the horse from Jerusalem; and the battle bow will be cut off; and he will speak peace to the nations: and his dominion will be from sea to sea, and from the River to the ends of the earth. 

###### v11 
As for you also, because of the blood of your covenant, I have set free your prisoners from the pit in which is no water. 

###### v12 
Turn to the stronghold, you prisoners of hope! Even today I declare that I will restore double to you. 

###### v13 
For indeed I bend Judah as a bow for me. I have filled the bow with Ephraim; and I will stir up your sons, Zion, against your sons, Greece, and will make you like the sword of a mighty man. 

###### v14 
Yahweh will be seen over them; and his arrow will flash like lightning; and the Lord Yahweh will blow the trumpet, and will go with whirlwinds of the south. 

###### v15 
Yahweh of Armies will defend them; and they will destroy and overcome with sling stones; and they will drink, and roar as through wine; and they will be filled like bowls, like the corners of the altar. 

###### v16 
Yahweh their God will save them in that day as the flock of his people; for they are like the jewels of a crown, lifted on high over his land. 

###### v17 
For how great is his goodness, and how great is his beauty! Grain will make the young men flourish, and new wine the virgins.

***
[[Zech-08|← Zechariah 08]] | [[Zechariah]] | [[Zech-10|Zechariah 10 →]]
