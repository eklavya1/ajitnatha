# Zechariah 12

[[Zech-11|← Zechariah 11]] | [[Zechariah]] | [[Zech-13|Zechariah 13 →]]
***



###### v1 
A revelation: Yahweh's word concerning Israel. Yahweh, who stretches out the heavens, and lays the foundation of the earth, and forms the spirit of man within him says: 

###### v2 
"Behold, I will make Jerusalem a cup of reeling to all the surrounding peoples, and it will also be on Judah in the siege against Jerusalem. 

###### v3 
It will happen in that day, that I will make Jerusalem a burdensome stone for all the peoples. All who burden themselves with it will be severely wounded, and all the nations of the earth will be gathered together against it. 

###### v4 
In that day," says Yahweh, "I will strike every horse with terror, and his rider with madness; and I will open my eyes on the house of Judah, and will strike every horse of the peoples with blindness. 

###### v5 
The chieftains of Judah will say in their heart, 'The inhabitants of Jerusalem are my strength in Yahweh of Armies their God.' 

###### v6 
In that day I will make the chieftains of Judah like a pan of fire among wood, and like a flaming torch among sheaves; and they will devour all the surrounding peoples, on the right hand and on the left; and Jerusalem will yet again dwell in their own place, even in Jerusalem. 

###### v7 
Yahweh also will save the tents of Judah first, that the glory of David's house and the glory of the inhabitants of Jerusalem not be magnified above Judah. 

###### v8 
In that day Yahweh will defend the inhabitants of Jerusalem. He who is feeble among them at that day will be like David, and David's house will be like God, like Yahweh's angel before them. 

###### v9 
It will happen in that day, that I will seek to destroy all the nations that come against Jerusalem. 

###### v10 
I will pour on David's house, and on the inhabitants of Jerusalem, the spirit of grace and of supplication; and they will look to me whom they have pierced; and they shall mourn for him, as one mourns for his only son, and will grieve bitterly for him, as one grieves for his firstborn. 

###### v11 
In that day there will be a great mourning in Jerusalem, like the mourning of Hadadrimmon in the valley of Megiddon. 

###### v12 
The land will mourn, every family apart; the family of David's house apart, and their wives apart; the family of the house of Nathan apart, and their wives apart; 

###### v13 
the family of the house of Levi apart, and their wives apart; the family of the Shimeites apart, and their wives apart; 

###### v14 
all the families who remain, every family apart, and their wives apart.

***
[[Zech-11|← Zechariah 11]] | [[Zechariah]] | [[Zech-13|Zechariah 13 →]]
