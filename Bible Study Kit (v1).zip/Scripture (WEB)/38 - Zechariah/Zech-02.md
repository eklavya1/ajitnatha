# Zechariah 2

[[Zech-01|← Zechariah 01]] | [[Zechariah]] | [[Zech-03|Zechariah 03 →]]
***



###### v1 
I lifted up my eyes, and saw, and behold, a man with a measuring line in his hand. 

###### v2 
Then I asked, "Where are you going?" He said to me, "To measure Jerusalem, to see what is its width and what is its length." 

###### v3 
Behold, the angel who talked with me went out, and another angel went out to meet him, 

###### v4 
and said to him, "Run, speak to this young man, saying, 'Jerusalem will be inhabited as villages without walls, because of the multitude of men and livestock in it. 

###### v5 
For I,' says Yahweh, 'will be to her a wall of fire around it, and I will be the glory in the middle of her. 

###### v6 
Come! Come! Flee from the land of the north,' says Yahweh; 'for I have spread you abroad as the four winds of the sky,' says Yahweh. 

###### v7 
'Come, Zion! Escape, you who dwell with the daughter of Babylon.' 

###### v8 
For Yahweh of Armies says: 'For honor he has sent me to the nations which plundered you; for he who touches you touches the apple of his eye. 

###### v9 
For, behold, I will shake my hand over them, and they will be a plunder to those who served them; and you will know that Yahweh of Armies has sent me. 

###### v10 
Sing and rejoice, daughter of Zion; for, behold, I come, and I will dwell within you,' says Yahweh. 

###### v11 
Many nations shall join themselves to Yahweh in that day, and shall be my people; and I will dwell among you, and you shall know that Yahweh of Armies has sent me to you. 

###### v12 
Yahweh will inherit Judah as his portion in the holy land, and will again choose Jerusalem. 

###### v13 
Be silent, all flesh, before Yahweh; for he has roused himself from his holy habitation!"

***
[[Zech-01|← Zechariah 01]] | [[Zechariah]] | [[Zech-03|Zechariah 03 →]]
