# Zechariah 5

[[Zech-04|← Zechariah 04]] | [[Zechariah]] | [[Zech-06|Zechariah 06 →]]
***



###### v1 
Then again I lifted up my eyes, and saw, and behold, a flying scroll. 

###### v2 
He said to me, "What do you see?" I answered, "I see a flying scroll; its length is twenty cubits, and its width ten cubits." 

###### v3 
Then he said to me, "This is the curse that goes out over the surface of the whole land; for everyone who steals shall be cut off according to it on the one side; and everyone who swears falsely shall be cut off according to it on the other side. 

###### v4 
I will cause it to go out," says Yahweh of Armies, "and it will enter into the house of the thief, and into the house of him who swears falsely by my name; and it will remain in the middle of his house, and will destroy it with its timber and its stones." 

###### v5 
Then the angel who talked with me came forward, and said to me, "Lift up now your eyes, and see what this is that is appearing." 

###### v6 
I said, "What is it?" He said, "This is the ephah basket that is appearing." He said moreover, "This is their appearance in all the land 

###### v7 
(and behold, a talent of lead was lifted up); and this is a woman sitting in the middle of the ephah basket." 

###### v8 
He said, "This is Wickedness;" and he threw her down into the middle of the ephah basket; and he threw the weight of lead on its mouth. 

###### v9 
Then I lifted up my eyes and saw, and behold, there were two women, and the wind was in their wings. Now they had wings like the wings of a stork, and they lifted up the ephah basket between earth and the sky. 

###### v10 
Then I said to the angel who talked with me, "Where are these carrying the ephah basket?" 

###### v11 
He said to me, "To build her a house in the land of Shinar. When it is prepared, she will be set there in her own place."

***
[[Zech-04|← Zechariah 04]] | [[Zechariah]] | [[Zech-06|Zechariah 06 →]]
