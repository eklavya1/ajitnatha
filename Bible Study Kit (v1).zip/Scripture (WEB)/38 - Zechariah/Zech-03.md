# Zechariah 3

[[Zech-02|← Zechariah 02]] | [[Zechariah]] | [[Zech-04|Zechariah 04 →]]
***



###### v1 
He showed me Joshua the high priest standing before Yahweh's angel, and Satan standing at his right hand to be his adversary. 

###### v2 
Yahweh said to Satan, "Yahweh rebuke you, Satan! Yes, Yahweh who has chosen Jerusalem rebuke you! Isn't this a burning stick plucked out of the fire?" 

###### v3 
Now Joshua was clothed with filthy garments, and was standing before the angel. 

###### v4 
He answered and spoke to those who stood before him, saying, "Take the filthy garments off him." To him he said, "Behold, I have caused your iniquity to pass from you, and I will clothe you with rich clothing." 

###### v5 
I said, "Let them set a clean turban on his head." So they set a clean turban on his head, and clothed him; and Yahweh's angel was standing by. 

###### v6 
Yahweh's angel protested to Joshua, saying, 

###### v7 
"Yahweh of Armies says: 'If you will walk in my ways, and if you will follow my instructions, then you also shall judge my house, and shall also keep my courts, and I will give you a place of access among these who stand by. 

###### v8 
Hear now, Joshua the high priest, you and your fellows who sit before you; for they are men who are a sign: for, behold, I will bring out my servant, the Branch. 

###### v9 
For, behold, the stone that I have set before Joshua; on one stone are seven eyes: behold, I will engrave its engraving,' says Yahweh of Armies, 'and I will remove the iniquity of that land in one day. 

###### v10 
In that day,' says Yahweh of Armies, 'you will invite every man his neighbor under the vine and under the fig tree.'"

***
[[Zech-02|← Zechariah 02]] | [[Zechariah]] | [[Zech-04|Zechariah 04 →]]
