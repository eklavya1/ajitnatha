# Zechariah 4

[[Zech-03|← Zechariah 03]] | [[Zechariah]] | [[Zech-05|Zechariah 05 →]]
***



###### v1 
The angel who talked with me came again, and wakened me, as a man who is wakened out of his sleep. 

###### v2 
He said to me, "What do you see?" I said, "I have seen, and behold, a lamp stand all of gold, with its bowl on the top of it, and its seven lamps on it; there are seven pipes to each of the lamps, which are on the top of it; 

###### v3 
and two olive trees by it, one on the right side of the bowl, and the other on the left side of it." 

###### v4 
I answered and spoke to the angel who talked with me, saying, "What are these, my lord?" 

###### v5 
Then the angel who talked with me answered me, "Don't you know what these are?" I said, "No, my lord." 

###### v6 
Then he answered and spoke to me, saying, "This is Yahweh's word to Zerubbabel, saying, 'Not by might, nor by power, but by my Spirit,' says Yahweh of Armies. 

###### v7 
Who are you, great mountain? Before Zerubbabel you are a plain; and he will bring out the capstone with shouts of 'Grace, grace, to it!'" 

###### v8 
Moreover Yahweh's word came to me, saying, 

###### v9 
"The hands of Zerubbabel have laid the foundation of this house. His hands shall also finish it; and you will know that Yahweh of Armies has sent me to you. 

###### v10 
Indeed, who despises the day of small things? For these seven shall rejoice, and shall see the plumb line in the hand of Zerubbabel. These are Yahweh's eyes, which run back and forth through the whole earth." 

###### v11 
Then I asked him, "What are these two olive trees on the right side of the lamp stand and on the left side of it?" 

###### v12 
I asked him the second time, "What are these two olive branches, which are beside the two golden spouts, that pour the golden oil out of themselves?" 

###### v13 
He answered me, "Don't you know what these are?" I said, "No, my lord." 

###### v14 
Then he said, "These are the two anointed ones who stand by the Lord of the whole earth."

***
[[Zech-03|← Zechariah 03]] | [[Zechariah]] | [[Zech-05|Zechariah 05 →]]
