# Zechariah 13

[[Zech-12|← Zechariah 12]] | [[Zechariah]] | [[Zech-14|Zechariah 14 →]]
***



###### v1 
"In that day there will be a spring opened to David's house and to the inhabitants of Jerusalem, for sin and for uncleanness. 

###### v2 
It will come to pass in that day, says Yahweh of Armies, that I will cut off the names of the idols out of the land, and they will be remembered no more. I will also cause the prophets and the spirit of impurity to pass out of the land. 

###### v3 
It will happen that, when anyone still prophesies, then his father and his mother who bore him will tell him, 'You must die, because you speak lies in Yahweh's name;' and his father and his mother who bore him will stab him when he prophesies. 

###### v4 
It will happen in that day, that the prophets will each be ashamed of his vision, when he prophesies; neither will they wear a hairy mantle to deceive: 

###### v5 
but he will say, 'I am no prophet, I am a tiller of the ground; for I have been made a bondservant from my youth.' 

###### v6 
One will say to him, 'What are these wounds between your arms?' Then he will answer, 'Those with which I was wounded in the house of my friends.' 

###### v7 
"Awake, sword, against my shepherd, and against the man who is close to me," says Yahweh of Armies. "Strike the shepherd, and the sheep will be scattered; and I will turn my hand against the little ones. 

###### v8 
It shall happen that in all the land," says Yahweh, "two parts in it will be cut off and die; but the third will be left in it. 

###### v9 
I will bring the third part into the fire, and will refine them as silver is refined, and will test them like gold is tested. They will call on my name, and I will hear them. I will say, 'It is my people;' and they will say, 'Yahweh is my God.'"

***
[[Zech-12|← Zechariah 12]] | [[Zechariah]] | [[Zech-14|Zechariah 14 →]]
