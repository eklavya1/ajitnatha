# Zechariah 7

[[Zech-06|← Zechariah 06]] | [[Zechariah]] | [[Zech-08|Zechariah 08 →]]
***



###### v1 
In the fourth year of king Darius, Yahweh's word came to Zechariah in the fourth day of the ninth month, the month of Chislev. 

###### v2 
The people of Bethel sent Sharezer and Regem Melech, and their men, to entreat Yahweh's favor, 

###### v3 
and to speak to the priests of the house of Yahweh of Armies, and to the prophets, saying, "Should I weep in the fifth month, separating myself, as I have done these so many years?" 

###### v4 
Then the word of Yahweh of Armies came to me, saying, 

###### v5 
"Speak to all the people of the land, and to the priests, saying, 'When you fasted and mourned in the fifth and in the seventh month for these seventy years, did you at all fast to me, really to me? 

###### v6 
When you eat, and when you drink, don't you eat for yourselves, and drink for yourselves? 

###### v7 
Aren't these the words which Yahweh proclaimed by the former prophets, when Jerusalem was inhabited and in prosperity, and its cities around her, and the South and the lowland were inhabited?'" 

###### v8 
Yahweh's word came to Zechariah, saying, 

###### v9 
"Thus has Yahweh of Armies spoken, saying, 'Execute true judgment, and show kindness and compassion every man to his brother. 

###### v10 
Don't oppress the widow, nor the fatherless, the foreigner, nor the poor; and let none of you devise evil against his brother in your heart.' 

###### v11 
But they refused to listen, and turned their backs, and stopped their ears, that they might not hear. 

###### v12 
Yes, they made their hearts as hard as flint, lest they might hear the law, and the words which Yahweh of Armies had sent by his Spirit by the former prophets. Therefore great wrath came from Yahweh of Armies. 

###### v13 
It has come to pass that, as he called, and they refused to listen, so they will call, and I will not listen," said Yahweh of Armies; 

###### v14 
"but I will scatter them with a whirlwind among all the nations which they have not known. Thus the land was desolate after them, so that no man passed through nor returned: for they made the pleasant land desolate."

***
[[Zech-06|← Zechariah 06]] | [[Zechariah]] | [[Zech-08|Zechariah 08 →]]
