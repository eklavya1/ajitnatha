# Zechariah 1

[[Zechariah]] | [[Zech-02|Zechariah 02 →]]
***



###### v1 
In the eighth month, in the second year of Darius, Yahweh's word came to Zechariah the son of Berechiah, the son of Iddo, the prophet, saying, 

###### v2 
"Yahweh was very displeased with your fathers. 

###### v3 
Therefore tell them: Yahweh of Armies says: 'Return to me,' says Yahweh of Armies, 'and I will return to you,' says Yahweh of Armies. 

###### v4 
Don't you be like your fathers, to whom the former prophets proclaimed, saying: Yahweh of Armies says, 'Return now from your evil ways, and from your evil doings;' but they didn't hear, nor listen to me, says Yahweh. 

###### v5 
Your fathers, where are they? And the prophets, do they live forever? 

###### v6 
But my words and my decrees, which I commanded my servants the prophets, didn't they overtake your fathers? "Then they repented and said, 'Just as Yahweh of Armies determined to do to us, according to our ways, and according to our practices, so he has dealt with us.'" 

###### v7 
On the twenty-fourth day of the eleventh month, which is the month Shebat, in the second year of Darius, Yahweh's word came to Zechariah the son of Berechiah, the son of Iddo, the prophet, saying, 

###### v8 
"I had a vision in the night, and behold, a man riding on a red horse, and he stood among the myrtle trees that were in a ravine; and behind him there were red, brown, and white horses. 

###### v9 
Then I asked, 'My lord, what are these?'" The angel who talked with me said to me, "I will show you what these are." 

###### v10 
The man who stood among the myrtle trees answered, "They are the ones Yahweh has sent to go back and forth through the earth." 

###### v11 
They reported to Yahweh's angel who stood among the myrtle trees, and said, "We have walked back and forth through the earth, and behold, all the earth is at rest and in peace." 

###### v12 
Then Yahweh's angel replied, "O Yahweh of Armies, how long will you not have mercy on Jerusalem and on the cities of Judah, against which you have had indignation these seventy years?" 

###### v13 
Yahweh answered the angel who talked with me with kind and comforting words. 

###### v14 
So the angel who talked with me said to me, "Proclaim, saying, 'Yahweh of Armies says: "I am jealous for Jerusalem and for Zion with a great jealousy. 

###### v15 
I am very angry with the nations that are at ease; for I was but a little displeased, but they added to the calamity." 

###### v16 
Therefore Yahweh says: "I have returned to Jerusalem with mercy. My house shall be built in it," says Yahweh of Armies, "and a line shall be stretched out over Jerusalem."' 

###### v17 
"Proclaim further, saying, 'Yahweh of Armies says: "My cities will again overflow with prosperity, and Yahweh will again comfort Zion, and will again choose Jerusalem."'" 

###### v18 
I lifted up my eyes, and saw, and behold, four horns. 

###### v19 
I asked the angel who talked with me, "What are these?" He answered me, "These are the horns which have scattered Judah, Israel, and Jerusalem." 

###### v20 
Yahweh showed me four craftsmen. 

###### v21 
Then I asked, "What are these coming to do?" He said, "These are the horns which scattered Judah, so that no man lifted up his head; but these have come to terrify them, to cast down the horns of the nations, which lifted up their horn against the land of Judah to scatter it."

***
[[Zechariah]] | [[Zech-02|Zechariah 02 →]]
