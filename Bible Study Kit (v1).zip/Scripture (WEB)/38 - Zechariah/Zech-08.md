# Zechariah 8

[[Zech-07|← Zechariah 07]] | [[Zechariah]] | [[Zech-09|Zechariah 09 →]]
***



###### v1 
The word of Yahweh of Armies came to me. 

###### v2 
Yahweh of Armies says: "I am jealous for Zion with great jealousy, and I am jealous for her with great wrath." 

###### v3 
Yahweh says: "I have returned to Zion, and will dwell in the middle of Jerusalem. Jerusalem shall be called 'The City of Truth;' and the mountain of Yahweh of Armies, 'The Holy Mountain.'" 

###### v4 
Yahweh of Armies says: "Old men and old women will again dwell in the streets of Jerusalem, every man with his staff in his hand for very age. 

###### v5 
The streets of the city will be full of boys and girls playing in its streets." 

###### v6 
Yahweh of Armies says: "If it is marvelous in the eyes of the remnant of this people in those days, should it also be marvelous in my eyes?" says Yahweh of Armies. 

###### v7 
Yahweh of Armies says: "Behold, I will save my people from the east country, and from the west country; 

###### v8 
and I will bring them, and they will dwell within Jerusalem; and they will be my people, and I will be their God, in truth and in righteousness." 

###### v9 
Yahweh of Armies says: "Let your hands be strong, you who hear in these days these words from the mouth of the prophets who were in the day that the foundation of the house of Yahweh of Armies was laid, even the temple, that it might be built. 

###### v10 
For before those days there was no wages for man, nor any wages for an animal; neither was there any peace to him who went out or came in, because of the adversary. For I set all men everyone against his neighbor. 

###### v11 
But now I will not be to the remnant of this people as in the former days," says Yahweh of Armies. 

###### v12 
"For the seed of peace and the vine will yield its fruit, and the ground will give its increase, and the heavens will give their dew; and I will cause the remnant of this people to inherit all these things. 

###### v13 
It shall come to pass that, as you were a curse among the nations, house of Judah and house of Israel, so I will save you, and you shall be a blessing. Don't be afraid. Let your hands be strong." 

###### v14 
For Yahweh of Armies says: "As I thought to do evil to you, when your fathers provoked me to wrath," says Yahweh of Armies, "and I didn't repent; 

###### v15 
so again I have thought in these days to do good to Jerusalem and to the house of Judah. Don't be afraid. 

###### v16 
These are the things that you shall do: speak every man the truth with his neighbor. Execute the judgment of truth and peace in your gates, 

###### v17 
and let none of you devise evil in your hearts against his neighbor, and love no false oath: for all these are things that I hate," says Yahweh. 

###### v18 
The word of Yahweh of Armies came to me. 

###### v19 
Yahweh of Armies says: "The fasts of the fourth, fifth, seventh, and tenth months shall be for the house of Judah joy and gladness, and cheerful feasts. Therefore love truth and peace." 

###### v20 
Yahweh of Armies says: "Many peoples, and the inhabitants of many cities will yet come; 

###### v21 
and the inhabitants of one shall go to another, saying, 'Let's go speedily to entreat the favor of Yahweh, and to seek Yahweh of Armies. I will go also.' 

###### v22 
Yes, many peoples and strong nations will come to seek Yahweh of Armies in Jerusalem, and to entreat the favor of Yahweh." 

###### v23 
Yahweh of Armies says: "In those days, ten men will take hold, out of all the languages of the nations, they will take hold of the skirt of him who is a Jew, saying, 'We will go with you, for we have heard that God is with you.'"

***
[[Zech-07|← Zechariah 07]] | [[Zechariah]] | [[Zech-09|Zechariah 09 →]]
