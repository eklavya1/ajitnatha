# Zechariah 6

[[Zech-05|← Zechariah 05]] | [[Zechariah]] | [[Zech-07|Zechariah 07 →]]
***



###### v1 
Again I lifted up my eyes, and saw, and behold, four chariots came out from between two mountains; and the mountains were mountains of bronze. 

###### v2 
In the first chariot were red horses; in the second chariot black horses; 

###### v3 
in the third chariot white horses; and in the fourth chariot dappled horses, all of them powerful. 

###### v4 
Then I asked the angel who talked with me, "What are these, my lord?" 

###### v5 
The angel answered me, "These are the four winds of the sky, which go out from standing before the Lord of all the earth. 

###### v6 
The one with the black horses goes out toward the north country; and the white went out after them; and the dappled went out toward the south country." 

###### v7 
The strong went out, and sought to go that they might walk back and forth through the earth: and he said, "Go around and through the earth!" So they walked back and forth through the earth. 

###### v8 
Then he called to me, and spoke to me, saying, "Behold, those who go toward the north country have quieted my spirit in the north country." 

###### v9 
Yahweh's word came to me, saying, 

###### v10 
"Take of them of the captivity, even of Heldai, of Tobijah, and of Jedaiah; and come the same day, and go into the house of Josiah the son of Zephaniah, where they have come from Babylon. 

###### v11 
Yes, take silver and gold, and make crowns, and set them on the head of Joshua the son of Jehozadak, the high priest; 

###### v12 
and speak to him, saying, 'Yahweh of Armies says, "Behold, the man whose name is the Branch: and he shall grow up out of his place; and he shall build Yahweh's temple; 

###### v13 
even he shall build Yahweh's temple; and he shall bear the glory, and shall sit and rule on his throne; and he shall be a priest on his throne; and the counsel of peace shall be between them both. 

###### v14 
The crowns shall be to Helem, and to Tobijah, and to Jedaiah, and to Hen the son of Zephaniah, for a memorial in Yahweh's temple. 

###### v15 
Those who are far off shall come and build in Yahweh's temple; and you shall know that Yahweh of Armies has sent me to you. This will happen, if you will diligently obey Yahweh your God's voice."'"

***
[[Zech-05|← Zechariah 05]] | [[Zechariah]] | [[Zech-07|Zechariah 07 →]]
