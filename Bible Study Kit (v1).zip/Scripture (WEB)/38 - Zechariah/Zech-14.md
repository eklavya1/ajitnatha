# Zechariah 14

[[Zech-13|← Zechariah 13]] | [[Zechariah]]
***



###### v1 
Behold, a day of Yahweh comes, when your plunder will be divided within you. 

###### v2 
For I will gather all nations against Jerusalem to battle; and the city will be taken, the houses rifled, and the women ravished. Half of the city will go out into captivity, and the rest of the people will not be cut off from the city. 

###### v3 
Then Yahweh will go out and fight against those nations, as when he fought in the day of battle. 

###### v4 
His feet will stand in that day on the Mount of Olives, which is before Jerusalem on the east; and the Mount of Olives will be split in two, from east to west, making a very great valley. Half of the mountain will move toward the north, and half of it toward the south. 

###### v5 
You shall flee by the valley of my mountains; for the valley of the mountains shall reach to Azel; yes, you shall flee, just like you fled from before the earthquake in the days of Uzziah king of Judah. Yahweh my God will come, and all the holy ones with you. 

###### v6 
It will happen in that day, that there will not be light, cold, or frost. 

###### v7 
It will be a unique day which is known to Yahweh; not day, and not night; but it will come to pass, that at evening time there will be light. 

###### v8 
It will happen in that day, that living waters will go out from Jerusalem: half of them toward the eastern sea, and half of them toward the western sea. It will be so in summer and in winter. 

###### v9 
Yahweh will be King over all the earth. In that day Yahweh will be one, and his name one. 

###### v10 
All the land will be made like the Arabah, from Geba to Rimmon south of Jerusalem; and she will be lifted up, and will dwell in her place, from Benjamin's gate to the place of the first gate, to the corner gate, and from the tower of Hananel to the king's wine presses. 

###### v11 
Men will dwell therein, and there will be no more curse; but Jerusalem will dwell safely. 

###### v12 
This will be the plague with which Yahweh will strike all the peoples who have fought against Jerusalem: their flesh will consume away while they stand on their feet, and their eyes will consume away in their sockets, and their tongue will consume away in their mouth. 

###### v13 
It will happen in that day, that a great panic from Yahweh will be among them; and they will each hold onto the hand of his neighbor, and his hand will rise up against the hand of his neighbor. 

###### v14 
Judah also will fight at Jerusalem; and the wealth of all the surrounding nations will be gathered together: gold, and silver, and clothing, in great abundance. 

###### v15 
A plague like this will fall on the horse, on the mule, on the camel, on the donkey, and on all the animals that will be in those camps. 

###### v16 
It will happen that everyone who is left of all the nations that came against Jerusalem will go up from year to year to worship the King, Yahweh of Armies, and to keep the feast of booths. 

###### v17 
It will be, that whoever of all the families of the earth doesn't go up to Jerusalem to worship the King, Yahweh of Armies, on them there will be no rain. 

###### v18 
If the family of Egypt doesn't go up, and doesn't come, neither will it rain on them. This will be the plague with which Yahweh will strike the nations that don't go up to keep the feast of booths. 

###### v19 
This will be the punishment of Egypt, and the punishment of all the nations that don't go up to keep the feast of booths. 

###### v20 
In that day there will be on the bells of the horses, "HOLY TO YAHWEH"; and the pots in Yahweh's house will be like the bowls before the altar. 

###### v21 
Yes, every pot in Jerusalem and in Judah will be holy to Yahweh of Armies; and all those who sacrifice will come and take of them, and cook in them. In that day there will no longer be a Canaanite in the house of Yahweh of Armies.

***
[[Zech-13|← Zechariah 13]] | [[Zechariah]]
