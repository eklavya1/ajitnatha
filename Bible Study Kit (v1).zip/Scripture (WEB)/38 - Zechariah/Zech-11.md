# Zechariah 11

[[Zech-10|← Zechariah 10]] | [[Zechariah]] | [[Zech-12|Zechariah 12 →]]
***



###### v1 
Open your doors, Lebanon, that the fire may devour your cedars. 

###### v2 
Wail, cypress tree, for the cedar has fallen, because the stately ones are destroyed. Wail, you oaks of Bashan, for the strong forest has come down. 

###### v3 
A voice of the wailing of the shepherds! For their glory is destroyed: a voice of the roaring of young lions! For the pride of the Jordan is ruined. 

###### v4 
Yahweh my God says: "Feed the flock of slaughter. 

###### v5 
Their buyers slaughter them, and go unpunished. Those who sell them say, 'Blessed be Yahweh, for I am rich;' and their own shepherds don't pity them. 

###### v6 
For I will no more pity the inhabitants of the land," says Yahweh; "but, behold, I will deliver every one of the men into his neighbor's hand, and into the hand of his king. They will strike the land, and out of their hand I will not deliver them." 

###### v7 
So I fed the flock of slaughter, especially the oppressed of the flock. I took for myself two staffs. The one I called "Favor", and the other I called "Union", and I fed the flock. 

###### v8 
I cut off the three shepherds in one month; for my soul was weary of them, and their soul also loathed me. 

###### v9 
Then I said, "I will not feed you. That which dies, let it die; and that which is to be cut off, let it be cut off; and let those who are left eat each other's flesh." 

###### v10 
I took my staff Favor, and cut it apart, that I might break my covenant that I had made with all the peoples. 

###### v11 
It was broken in that day; and thus the poor of the flock that listened to me knew that it was Yahweh's word. 

###### v12 
I said to them, "If you think it best, give me my wages; and if not, keep them." So they weighed for my wages thirty pieces of silver. 

###### v13 
Yahweh said to me, "Throw it to the potter, the handsome price that I was valued at by them!" I took the thirty pieces of silver, and threw them to the potter, in Yahweh's house. 

###### v14 
Then I cut apart my other staff, even Union, that I might break the brotherhood between Judah and Israel. 

###### v15 
Yahweh said to me, "Take for yourself yet again the equipment of a foolish shepherd. 

###### v16 
For, behold, I will raise up a shepherd in the land, who will not visit those who are cut off, neither will seek those who are scattered, nor heal that which is broken, nor feed that which is sound; but he will eat the meat of the fat sheep, and will tear their hoofs in pieces. 

###### v17 
Woe to the worthless shepherd who leaves the flock! The sword will be on his arm, and on his right eye. His arm will be completely withered, and his right eye will be totally blinded!"

***
[[Zech-10|← Zechariah 10]] | [[Zechariah]] | [[Zech-12|Zechariah 12 →]]
