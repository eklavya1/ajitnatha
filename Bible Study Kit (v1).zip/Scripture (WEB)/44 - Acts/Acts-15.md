# Acts 15

[[Acts-14|← Acts 14]] | [[Acts]] | [[Acts-16|Acts 16 →]]
***



###### v1 
Some men came down from Judea and taught the brothers, "Unless you are circumcised after the custom of Moses, you can't be saved." 

###### v2 
Therefore when Paul and Barnabas had no small discord and discussion with them, they appointed Paul and Barnabas, and some others of them, to go up to Jerusalem to the apostles and elders about this question. 

###### v3 
They, being sent on their way by the assembly, passed through both Phoenicia and Samaria, declaring the conversion of the Gentiles. They caused great joy to all the brothers. 

###### v4 
When they had come to Jerusalem, they were received by the assembly and the apostles and the elders, and they reported everything that God had done with them. 

###### v5 
But some of the sect of the Pharisees who believed rose up, saying, "It is necessary to circumcise them, and to command them to keep the law of Moses." 

###### v6 
The apostles and the elders were gathered together to see about this matter. 

###### v7 
When there had been much discussion, Peter rose up and said to them, "Brothers, you know that a good while ago God made a choice among you that by my mouth the nations should hear the word of the Good News and believe. 

###### v8 
God, who knows the heart, testified about them, giving them the Holy Spirit, just like he did to us. 

###### v9 
He made no distinction between us and them, cleansing their hearts by faith. 

###### v10 
Now therefore why do you tempt God, that you should put a yoke on the neck of the disciples which neither our fathers nor we were able to bear? 

###### v11 
But we believe that we are saved through the grace of the Lord Jesus, just as they are." 

###### v12 
All the multitude kept silence, and they listened to Barnabas and Paul reporting what signs and wonders God had done among the nations through them. 

###### v13 
After they were silent, James answered, "Brothers, listen to me. 

###### v14 
Simeon has reported how God first visited the nations to take out of them a people for his name. 

###### v15 
This agrees with the words of the prophets. As it is written, 

###### v16 
'After these things I will return. I will again build the tabernacle of David, which has fallen. I will again build its ruins. I will set it up <sup class="versenum mid-line">17</sup>that the rest of men may seek after the Lord; all the Gentiles who are called by my name, says the Lord, who does all these things.' 

###### v18 
"All of God's works are known to him from eternity. 

###### v19 
Therefore my judgment is that we don't trouble those from among the Gentiles who turn to God, 

###### v20 
but that we write to them that they abstain from the pollution of idols, from sexual immorality, from what is strangled, and from blood. 

###### v21 
For Moses from generations of old has in every city those who preach him, being read in the synagogues every Sabbath." 

###### v22 
Then it seemed good to the apostles and the elders, with the whole assembly, to choose men out of their company, and send them to Antioch with Paul and Barnabas: Judas called Barsabbas, and Silas, chief men among the brothers. 

###### v23 
They wrote these things by their hand: "The apostles, the elders, and the brothers, to the brothers who are of the Gentiles in Antioch, Syria, and Cilicia: greetings. 

###### v24 
Because we have heard that some who went out from us have troubled you with words, unsettling your souls, saying, 'You must be circumcised and keep the law,' to whom we gave no commandment; 

###### v25 
it seemed good to us, having come to one accord, to choose out men and send them to you with our beloved Barnabas and Paul, 

###### v26 
men who have risked their lives for the name of our Lord Jesus Christ. 

###### v27 
We have sent therefore Judas and Silas, who themselves will also tell you the same things by word of mouth. 

###### v28 
For it seemed good to the Holy Spirit, and to us, to lay no greater burden on you than these necessary things: 

###### v29 
that you abstain from things sacrificed to idols, from blood, from things strangled, and from sexual immorality, from which if you keep yourselves, it will be well with you. Farewell." 

###### v30 
So, when they were sent off, they came to Antioch. Having gathered the multitude together, they delivered the letter. 

###### v31 
When they had read it, they rejoiced over the encouragement. 

###### v32 
Judas and Silas, also being prophets themselves, encouraged the brothers with many words and strengthened them. 

###### v33 
After they had spent some time there, they were dismissed in peace from the brothers to the apostles. 

###### v34 


###### v35 
But Paul and Barnabas stayed in Antioch, teaching and preaching the word of the Lord, with many others also. 

###### v36 
After some days Paul said to Barnabas, "Let's return now and visit our brothers in every city in which we proclaimed the word of the Lord, to see how they are doing." 

###### v37 
Barnabas planned to take John, who was called Mark, with them also. 

###### v38 
But Paul didn't think that it was a good idea to take with them someone who had withdrawn from them in Pamphylia, and didn't go with them to do the work. 

###### v39 
Then the contention grew so sharp that they separated from each other. Barnabas took Mark with him and sailed away to Cyprus, 

###### v40 
but Paul chose Silas and went out, being commended by the brothers to the grace of God. 

###### v41 
He went through Syria and Cilicia, strengthening the assemblies.

***
[[Acts-14|← Acts 14]] | [[Acts]] | [[Acts-16|Acts 16 →]]
