# Acts 22

[[Acts-21|← Acts 21]] | [[Acts]] | [[Acts-23|Acts 23 →]]
***



###### v1 
"Brothers and fathers, listen to the defense which I now make to you." 

###### v2 
When they heard that he spoke to them in the Hebrew language, they were even more quiet. He said, 

###### v3 
"I am indeed a Jew, born in Tarsus of Cilicia, but brought up in this city at the feet of Gamaliel, instructed according to the strict tradition of the law of our fathers, being zealous for God, even as you all are today. 

###### v4 
I persecuted this Way to the death, binding and delivering into prisons both men and women, 

###### v5 
as also the high priest and all the council of the elders testify, from whom also I received letters to the brothers, and traveled to Damascus to bring them also who were there to Jerusalem in bonds to be punished. 

###### v6 
As I made my journey, and came close to Damascus, about noon, suddenly a great light shone around me from the sky. 

###### v7 
I fell to the ground, and heard a voice saying to me, 'Saul, Saul, why are you persecuting me?' 

###### v8 
I answered, 'Who are you, Lord?' He said to me, 'I am Jesus of Nazareth, whom you persecute.' 

###### v9 
"Those who were with me indeed saw the light and were afraid, but they didn't understand the voice of him who spoke to me. 

###### v10 
I said, 'What shall I do, Lord?' The Lord said to me, 'Arise, and go into Damascus. There you will be told about all things which are appointed for you to do.' 

###### v11 
When I couldn't see for the glory of that light, being led by the hand of those who were with me, I came into Damascus. 

###### v12 
One Ananias, a devout man according to the law, well reported of by all the Jews who lived in Damascus, 

###### v13 
came to me, and standing by me said to me, 'Brother Saul, receive your sight!' In that very hour I looked up at him. 

###### v14 
He said, 'The God of our fathers has appointed you to know his will, and to see the Righteous One, and to hear a voice from his mouth. 

###### v15 
For you will be a witness for him to all men of what you have seen and heard. 

###### v16 
Now why do you wait? Arise, be baptized, and wash away your sins, calling on the name of the Lord.' 

###### v17 
"When I had returned to Jerusalem, and while I prayed in the temple, I fell into a trance, 

###### v18 
and saw him saying to me, 'Hurry and get out of Jerusalem quickly, because they will not receive testimony concerning me from you.' 

###### v19 
I said, 'Lord, they themselves know that I imprisoned and beat in every synagogue those who believed in you. 

###### v20 
When the blood of Stephen, your witness, was shed, I also was standing by, consenting to his death, and guarding the cloaks of those who killed him.' 

###### v21 
"He said to me, 'Depart, for I will send you out far from here to the Gentiles.'" 

###### v22 
They listened to him until he said that; then they lifted up their voice and said, "Rid the earth of this fellow, for he isn't fit to live!" 

###### v23 
As they cried out, threw off their cloaks, and threw dust into the air, 

###### v24 
the commanding officer commanded him to be brought into the barracks, ordering him to be examined by scourging, that he might know for what crime they shouted against him like that. 

###### v25 
When they had tied him up with thongs, Paul asked the centurion who stood by, "Is it lawful for you to scourge a man who is a Roman, and not found guilty?" 

###### v26 
When the centurion heard it, he went to the commanding officer and told him, "Watch what you are about to do, for this man is a Roman!" 

###### v27 
The commanding officer came and asked him, "Tell me, are you a Roman?" He said, "Yes." 

###### v28 
The commanding officer answered, "I bought my citizenship for a great price." Paul said, "But I was born a Roman." 

###### v29 
Immediately those who were about to examine him departed from him, and the commanding officer also was afraid when he realized that he was a Roman, because he had bound him. 

###### v30 
But on the next day, desiring to know the truth about why he was accused by the Jews, he freed him from the bonds, and commanded the chief priests and all the council to come together, and brought Paul down and set him before them.

***
[[Acts-21|← Acts 21]] | [[Acts]] | [[Acts-23|Acts 23 →]]
