# Acts 4

[[Acts-03|← Acts 03]] | [[Acts]] | [[Acts-05|Acts 05 →]]
***



###### v1 
As they spoke to the people, the priests and the captain of the temple and the Sadducees came to them, 

###### v2 
being upset because they taught the people and proclaimed in Jesus the resurrection from the dead. 

###### v3 
They laid hands on them, and put them in custody until the next day, for it was now evening. 

###### v4 
But many of those who heard the word believed, and the number of the men came to be about five thousand. 

###### v5 
In the morning, their rulers, elders, and scribes were gathered together in Jerusalem. 

###### v6 
Annas the high priest was there, with Caiaphas, John, Alexander, and as many as were relatives of the high priest. 

###### v7 
When they had stood Peter and John in the middle of them, they inquired, "By what power, or in what name, have you done this?" 

###### v8 
Then Peter, filled with the Holy Spirit, said to them, "You rulers of the people, and elders of Israel, 

###### v9 
if we are examined today concerning a good deed done to a crippled man, by what means this man has been healed, 

###### v10 
may it be known to you all, and to all the people of Israel, that in the name of Jesus Christ of Nazareth, whom you crucified, whom God raised from the dead, this man stands here before you whole in him. 

###### v11 
He is 'the stone which was regarded as worthless by you, the builders, which has become the head of the corner.' 

###### v12 
There is salvation in no one else, for there is no other name under heaven that is given among men, by which we must be saved!" 

###### v13 
Now when they saw the boldness of Peter and John, and had perceived that they were unlearned and ignorant men, they marveled. They recognized that they had been with Jesus. 

###### v14 
Seeing the man who was healed standing with them, they could say nothing against it. 

###### v15 
But when they had commanded them to go aside out of the council, they conferred among themselves, 

###### v16 
saying, "What shall we do to these men? Because indeed a notable miracle has been done through them, as can be plainly seen by all who dwell in Jerusalem, and we can't deny it. 

###### v17 
But so that this spreads no further among the people, let's threaten them, that from now on they don't speak to anyone in this name." 

###### v18 
They called them, and commanded them not to speak at all nor teach in the name of Jesus. 

###### v19 
But Peter and John answered them, "Whether it is right in the sight of God to listen to you rather than to God, judge for yourselves, 

###### v20 
for we can't help telling the things which we saw and heard." 

###### v21 
When they had further threatened them, they let them go, finding no way to punish them, because of the people; for everyone glorified God for that which was done. 

###### v22 
For the man on whom this miracle of healing was performed was more than forty years old. 

###### v23 
Being let go, they came to their own company and reported all that the chief priests and the elders had said to them. 

###### v24 
When they heard it, they lifted up their voice to God with one accord, and said, "O Lord, you are God, who made the heaven, the earth, the sea, and all that is in them; 

###### v25 
who by the mouth of your servant, David, said, 'Why do the nations rage, and the peoples plot a vain thing? 

###### v26 
The kings of the earth take a stand, and the rulers take council together, against the Lord, and against his Christ.' 

###### v27 
"For truly, both Herod and Pontius Pilate, with the Gentiles and the people of Israel, were gathered together against your holy servant, Jesus, whom you anointed, 

###### v28 
to do whatever your hand and your council foreordained to happen. 

###### v29 
Now, Lord, look at their threats, and grant to your servants to speak your word with all boldness, 

###### v30 
while you stretch out your hand to heal; and that signs and wonders may be done through the name of your holy Servant Jesus." 

###### v31 
When they had prayed, the place was shaken where they were gathered together. They were all filled with the Holy Spirit, and they spoke the word of God with boldness. 

###### v32 
The multitude of those who believed were of one heart and soul. Not one of them claimed that anything of the things which he possessed was his own, but they had all things in common. 

###### v33 
With great power, the apostles gave their testimony of the resurrection of the Lord Jesus. Great grace was on them all. 

###### v34 
For neither was there among them any who lacked, for as many as were owners of lands or houses sold them, and brought the proceeds of the things that were sold, 

###### v35 
and laid them at the apostles' feet, and distribution was made to each, according as anyone had need. 

###### v36 
Joses, who by the apostles was also called Barnabas (which is, being interpreted, Son of Encouragement), a Levite, a man of Cyprus by race, 

###### v37 
having a field, sold it and brought the money and laid it at the apostles' feet.

***
[[Acts-03|← Acts 03]] | [[Acts]] | [[Acts-05|Acts 05 →]]
