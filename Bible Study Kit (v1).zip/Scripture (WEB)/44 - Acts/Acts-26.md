# Acts 26

[[Acts-25|← Acts 25]] | [[Acts]] | [[Acts-27|Acts 27 →]]
***



###### v1 
Agrippa said to Paul, "You may speak for yourself." Then Paul stretched out his hand, and made his defense. 

###### v2 
"I think myself happy, King Agrippa, that I am to make my defense before you today concerning all the things that I am accused by the Jews, 

###### v3 
especially because you are expert in all customs and questions which are among the Jews. Therefore I beg you to hear me patiently. 

###### v4 
"Indeed, all the Jews know my way of life from my youth up, which was from the beginning among my own nation and at Jerusalem; 

###### v5 
having known me from the first, if they are willing to testify, that after the strictest sect of our religion I lived a Pharisee. 

###### v6 
Now I stand here to be judged for the hope of the promise made by God to our fathers, 

###### v7 
which our twelve tribes, earnestly serving night and day, hope to attain. Concerning this hope I am accused by the Jews, King Agrippa! 

###### v8 
Why is it judged incredible with you, if God does raise the dead? 

###### v9 
"I myself most certainly thought that I ought to do many things contrary to the name of Jesus of Nazareth. 

###### v10 
I also did this in Jerusalem. I both shut up many of the saints in prisons, having received authority from the chief priests, and when they were put to death I gave my vote against them. 

###### v11 
Punishing them often in all the synagogues, I tried to make them blaspheme. Being exceedingly enraged against them, I persecuted them even to foreign cities. 

###### v12 
"Whereupon as I traveled to Damascus with the authority and commission from the chief priests, 

###### v13 
at noon, O king, I saw on the way a light from the sky, brighter than the sun, shining around me and those who traveled with me. 

###### v14 
When we had all fallen to the earth, I heard a voice saying to me in the Hebrew language, 'Saul, Saul, why are you persecuting me? It is hard for you to kick against the goads.' 

###### v15 
"I said, 'Who are you, Lord?' "He said, 'I am Jesus, whom you are persecuting. 

###### v16 
But arise, and stand on your feet, for I have appeared to you for this purpose: to appoint you a servant and a witness both of the things which you have seen, and of the things which I will reveal to you; 

###### v17 
delivering you from the people, and from the Gentiles, to whom I send you, 

###### v18 
to open their eyes, that they may turn from darkness to light and from the power of Satan to God, that they may receive remission of sins and an inheritance among those who are sanctified by faith in me.' 

###### v19 
"Therefore, King Agrippa, I was not disobedient to the heavenly vision, 

###### v20 
but declared first to them of Damascus, at Jerusalem, and throughout all the country of Judea, and also to the Gentiles, that they should repent and turn to God, doing works worthy of repentance. 

###### v21 
For this reason the Jews seized me in the temple and tried to kill me. 

###### v22 
Having therefore obtained the help that is from God, I stand to this day testifying both to small and great, saying nothing but what the prophets and Moses said would happen, 

###### v23 
how the Christ must suffer, and how, by the resurrection of the dead, he would be first to proclaim light both to these people and to the Gentiles." 

###### v24 
As he thus made his defense, Festus said with a loud voice, "Paul, you are crazy! Your great learning is driving you insane!" 

###### v25 
But he said, "I am not crazy, most excellent Festus, but boldly declare words of truth and reasonableness. 

###### v26 
For the king knows of these things, to whom also I speak freely. For I am persuaded that none of these things is hidden from him, for this has not been done in a corner. 

###### v27 
King Agrippa, do you believe the prophets? I know that you believe." 

###### v28 
Agrippa said to Paul, "With a little persuasion are you trying to make me a Christian?" 

###### v29 
Paul said, "I pray to God, that whether with little or with much, not only you, but also all that hear me today, might become such as I am, except for these bonds." 

###### v30 
The king rose up with the governor, and Bernice, and those who sat with them. 

###### v31 
When they had withdrawn, they spoke to one another, saying, "This man does nothing worthy of death or of bonds." 

###### v32 
Agrippa said to Festus, "This man might have been set free if he had not appealed to Caesar."

***
[[Acts-25|← Acts 25]] | [[Acts]] | [[Acts-27|Acts 27 →]]
