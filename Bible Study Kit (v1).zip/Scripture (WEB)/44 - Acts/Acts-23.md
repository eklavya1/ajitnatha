# Acts 23

[[Acts-22|← Acts 22]] | [[Acts]] | [[Acts-24|Acts 24 →]]
***



###### v1 
Paul, looking steadfastly at the council, said, "Brothers, I have lived before God in all good conscience until today." 

###### v2 
The high priest, Ananias, commanded those who stood by him to strike him on the mouth. 

###### v3 
Then Paul said to him, "God will strike you, you whitewashed wall! Do you sit to judge me according to the law, and command me to be struck contrary to the law?" 

###### v4 
Those who stood by said, "Do you malign God's high priest?" 

###### v5 
Paul said, "I didn't know, brothers, that he was high priest. For it is written, 'You shall not speak evil of a ruler of your people.'" 

###### v6 
But when Paul perceived that the one part were Sadducees and the other Pharisees, he cried out in the council, "Men and brothers, I am a Pharisee, a son of Pharisees. Concerning the hope and resurrection of the dead I am being judged!" 

###### v7 
When he had said this, an argument arose between the Pharisees and Sadducees, and the crowd was divided. 

###### v8 
For the Sadducees say that there is no resurrection, nor angel, nor spirit; but the Pharisees confess all of these. 

###### v9 
A great clamor arose, and some of the scribes of the Pharisees' part stood up, and contended, saying, "We find no evil in this man. But if a spirit or angel has spoken to him, let's not fight against God!" 

###### v10 
When a great argument arose, the commanding officer, fearing that Paul would be torn in pieces by them, commanded the soldiers to go down and take him by force from among them, and bring him into the barracks. 

###### v11 
The following night, the Lord stood by him and said, "Cheer up, Paul, for as you have testified about me at Jerusalem, so you must testify also at Rome." 

###### v12 
When it was day, some of the Jews banded together, and bound themselves under a curse, saying that they would neither eat nor drink until they had killed Paul. 

###### v13 
There were more than forty people who had made this conspiracy. 

###### v14 
They came to the chief priests and the elders, and said, "We have bound ourselves under a great curse to taste nothing until we have killed Paul. 

###### v15 
Now therefore, you with the council inform the commanding officer that he should bring him down to you tomorrow, as though you were going to judge his case more exactly. We are ready to kill him before he comes near." 

###### v16 
But Paul's sister's son heard they were lying in wait, and he came and entered into the barracks and told Paul. 

###### v17 
Paul summoned one of the centurions, and said, "Bring this young man to the commanding officer, for he has something to tell him." 

###### v18 
So he took him, and brought him to the commanding officer, and said, "Paul, the prisoner, summoned me and asked me to bring this young man to you. He has something to tell you." 

###### v19 
The commanding officer took him by the hand, and going aside, asked him privately, "What is it that you have to tell me?" 

###### v20 
He said, "The Jews have agreed to ask you to bring Paul down to the council tomorrow, as though intending to inquire somewhat more accurately concerning him. 

###### v21 
Therefore don't yield to them, for more than forty men lie in wait for him, who have bound themselves under a curse to neither eat nor drink until they have killed him. Now they are ready, looking for the promise from you." 

###### v22 
So the commanding officer let the young man go, charging him, "Tell no one that you have revealed these things to me." 

###### v23 
He called to himself two of the centurions, and said, "Prepare two hundred soldiers to go as far as Caesarea, with seventy horsemen, and two hundred men armed with spears, at the third hour of the night." 

###### v24 
He asked them to provide animals, that they might set Paul on one, and bring him safely to Felix the governor. 

###### v25 
He wrote a letter like this: 

###### v26 
"Claudius Lysias to the most excellent governor Felix: Greetings. 

###### v27 
"This man was seized by the Jews, and was about to be killed by them, when I came with the soldiers and rescued him, having learned that he was a Roman. 

###### v28 
Desiring to know the cause why they accused him, I brought him down to their council. 

###### v29 
I found him to be accused about questions of their law, but not to be charged with anything worthy of death or of imprisonment. 

###### v30 
When I was told that the Jews lay in wait for the man, I sent him to you immediately, charging his accusers also to bring their accusations against him before you. Farewell." 

###### v31 
So the soldiers, carrying out their orders, took Paul and brought him by night to Antipatris. 

###### v32 
But on the next day they left the horsemen to go with him, and returned to the barracks. 

###### v33 
When they came to Caesarea and delivered the letter to the governor, they also presented Paul to him. 

###### v34 
When the governor had read it, he asked what province he was from. When he understood that he was from Cilicia, he said, 

###### v35 
"I will hear you fully when your accusers also arrive." He commanded that he be kept in Herod's palace.

***
[[Acts-22|← Acts 22]] | [[Acts]] | [[Acts-24|Acts 24 →]]
