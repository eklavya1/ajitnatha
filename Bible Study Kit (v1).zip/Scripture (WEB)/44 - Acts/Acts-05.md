# Acts 5

[[Acts-04|← Acts 04]] | [[Acts]] | [[Acts-06|Acts 06 →]]
***



###### v1 
But a certain man named Ananias, with Sapphira, his wife, sold a possession, 

###### v2 
and kept back part of the price, his wife also being aware of it, then brought a certain part and laid it at the apostles' feet. 

###### v3 
But Peter said, "Ananias, why has Satan filled your heart to lie to the Holy Spirit and to keep back part of the price of the land? 

###### v4 
While you kept it, didn't it remain your own? After it was sold, wasn't it in your power? How is it that you have conceived this thing in your heart? You haven't lied to men, but to God." 

###### v5 
Ananias, hearing these words, fell down and died. Great fear came on all who heard these things. 

###### v6 
The young men arose and wrapped him up, and they carried him out and buried him. 

###### v7 
About three hours later, his wife, not knowing what had happened, came in. 

###### v8 
Peter answered her, "Tell me whether you sold the land for so much." She said, "Yes, for so much." 

###### v9 
But Peter asked her, "How is it that you have agreed together to tempt the Spirit of the Lord? Behold, the feet of those who have buried your husband are at the door, and they will carry you out." 

###### v10 
She fell down immediately at his feet and died. The young men came in and found her dead, and they carried her out and buried her by her husband. 

###### v11 
Great fear came on the whole assembly, and on all who heard these things. 

###### v12 
By the hands of the apostles many signs and wonders were done among the people. They were all with one accord in Solomon's porch. 

###### v13 
None of the rest dared to join them, however the people honored them. 

###### v14 
More believers were added to the Lord, multitudes of both men and women. 

###### v15 
They even carried out the sick into the streets, and laid them on cots and mattresses, so that as Peter came by, at the least his shadow might overshadow some of them. 

###### v16 
The multitude also came together from the cities around Jerusalem, bringing sick people and those who were tormented by unclean spirits: and they were all healed. 

###### v17 
But the high priest rose up, and all those who were with him (which is the sect of the Sadducees), and they were filled with jealousy 

###### v18 
and laid hands on the apostles, then put them in public custody. 

###### v19 
But an angel of the Lord opened the prison doors by night, and brought them out and said, 

###### v20 
"Go stand and speak in the temple to the people all the words of this life." 

###### v21 
When they heard this, they entered into the temple about daybreak and taught. But the high priest came, and those who were with him, and called the council together, and all the senate of the children of Israel, and sent to the prison to have them brought. 

###### v22 
But the officers who came didn't find them in the prison. They returned and reported, 

###### v23 
"We found the prison shut and locked, and the guards standing before the doors, but when we opened them, we found no one inside!" 

###### v24 
Now when the high priest, the captain of the temple, and the chief priests heard these words, they were very perplexed about them and what might become of this. 

###### v25 
One came and told them, "Behold, the men whom you put in prison are in the temple, standing and teaching the people." 

###### v26 
Then the captain went with the officers, and brought them without violence, for they were afraid that the people might stone them. 

###### v27 
When they had brought them, they set them before the council. The high priest questioned them, 

###### v28 
saying, "Didn't we strictly command you not to teach in this name? Behold, you have filled Jerusalem with your teaching, and intend to bring this man's blood on us." 

###### v29 
But Peter and the apostles answered, "We must obey God rather than men. 

###### v30 
The God of our fathers raised up Jesus, whom you killed, hanging him on a tree. 

###### v31 
God exalted him with his right hand to be a Prince and a Savior, to give repentance to Israel, and remission of sins. 

###### v32 
We are his witnesses of these things; and so also is the Holy Spirit, whom God has given to those who obey him." 

###### v33 
But they, when they heard this, were cut to the heart, and were determined to kill them. 

###### v34 
But one stood up in the council, a Pharisee named Gamaliel, a teacher of the law, honored by all the people, and commanded to put the apostles out for a little while. 

###### v35 
He said to them, "You men of Israel, be careful concerning these men, what you are about to do. 

###### v36 
For before these days Theudas rose up, making himself out to be somebody; to whom a number of men, about four hundred, joined themselves. He was slain; and all, as many as obeyed him, were dispersed, and came to nothing. 

###### v37 
After this man, Judas of Galilee rose up in the days of the enrollment, and drew away some people after him. He also perished, and all, as many as obeyed him, were scattered abroad. 

###### v38 
Now I tell you, withdraw from these men, and leave them alone. For if this counsel or this work is of men, it will be overthrown. 

###### v39 
But if it is of God, you will not be able to overthrow it, and you would be found even to be fighting against God!" 

###### v40 
They agreed with him. Summoning the apostles, they beat them and commanded them not to speak in the name of Jesus, and let them go. 

###### v41 
They therefore departed from the presence of the council, rejoicing that they were counted worthy to suffer dishonor for Jesus' name. 

###### v42 
Every day, in the temple and at home, they never stopped teaching and preaching Jesus, the Christ.

***
[[Acts-04|← Acts 04]] | [[Acts]] | [[Acts-06|Acts 06 →]]
