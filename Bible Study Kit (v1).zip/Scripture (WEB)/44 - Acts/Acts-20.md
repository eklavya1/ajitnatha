# Acts 20

[[Acts-19|← Acts 19]] | [[Acts]] | [[Acts-21|Acts 21 →]]
***



###### v1 
After the uproar had ceased, Paul sent for the disciples, took leave of them, and departed to go into Macedonia. 

###### v2 
When he had gone through those parts, and had encouraged them with many words, he came into Greece. 

###### v3 
When he had spent three months there, and a plot was made against him by Jews as he was about to set sail for Syria, he determined to return through Macedonia. 

###### v4 
These accompanied him as far as Asia: Sopater of Beroea; Aristarchus and Secundus of the Thessalonians; Gaius of Derbe; Timothy; and Tychicus and Trophimus of Asia. 

###### v5 
But these had gone ahead, and were waiting for us at Troas. 

###### v6 
We sailed away from Philippi after the days of Unleavened Bread, and came to them at Troas in five days, where we stayed seven days. 

###### v7 
On the first day of the week, when the disciples were gathered together to break bread, Paul talked with them, intending to depart on the next day, and continued his speech until midnight. 

###### v8 
There were many lights in the upper room where we were gathered together. 

###### v9 
A certain young man named Eutychus sat in the window, weighed down with deep sleep. As Paul spoke still longer, being weighed down by his sleep, he fell down from the third floor and was taken up dead. 

###### v10 
Paul went down and fell upon him, and embracing him said, "Don't be troubled, for his life is in him." 

###### v11 
When he had gone up, and had broken bread and eaten, and had talked with them a long while, even until break of day, he departed. 

###### v12 
They brought the boy in alive, and were greatly comforted. 

###### v13 
But we, going ahead to the ship, set sail for Assos, intending to take Paul aboard there; for he had so arranged, intending himself to go by land. 

###### v14 
When he met us at Assos, we took him aboard, and came to Mitylene. 

###### v15 
Sailing from there, we came the following day opposite Chios. The next day we touched at Samos and stayed at Trogyllium, and the day after we came to Miletus. 

###### v16 
For Paul had determined to sail past Ephesus, that he might not have to spend time in Asia; for he was hastening, if it were possible for him, to be in Jerusalem on the day of Pentecost. 

###### v17 
From Miletus he sent to Ephesus, and called to himself the elders of the assembly. 

###### v18 
When they had come to him, he said to them, "You yourselves know, from the first day that I set foot in Asia, how I was with you all the time, 

###### v19 
serving the Lord with all humility, with many tears, and with trials which happened to me by the plots of the Jews; 

###### v20 
how I didn't shrink from declaring to you anything that was profitable, teaching you publicly and from house to house, 

###### v21 
testifying both to Jews and to Greeks repentance toward God, and faith toward our Lord Jesus. 

###### v22 
Now, behold, I go bound by the Spirit to Jerusalem, not knowing what will happen to me there; 

###### v23 
except that the Holy Spirit testifies in every city, saying that bonds and afflictions wait for me. 

###### v24 
But these things don't count; nor do I hold my life dear to myself, so that I may finish my race with joy, and the ministry which I received from the Lord Jesus, to fully testify to the Good News of the grace of God. 

###### v25 
"Now, behold, I know that you all, among whom I went about preaching God's Kingdom, will see my face no more. 

###### v26 
Therefore I testify to you today that I am clean from the blood of all men, 

###### v27 
for I didn't shrink from declaring to you the whole counsel of God. 

###### v28 
Take heed, therefore, to yourselves, and to all the flock, in which the Holy Spirit has made you overseers, to shepherd the assembly of the Lord and God which he purchased with his own blood. 

###### v29 
For I know that after my departure, vicious wolves will enter in among you, not sparing the flock. 

###### v30 
Men will arise from among your own selves, speaking perverse things, to draw away the disciples after them. 

###### v31 
Therefore watch, remembering that for a period of three years I didn't cease to admonish everyone night and day with tears. 

###### v32 
Now, brothers, I entrust you to God and to the word of his grace, which is able to build up, and to give you the inheritance among all those who are sanctified. 

###### v33 
I coveted no one's silver, gold, or clothing. 

###### v34 
You yourselves know that these hands served my necessities, and those who were with me. 

###### v35 
In all things I gave you an example, that so laboring you ought to help the weak, and to remember the words of the Lord Jesus, that he himself said, 'It is more blessed to give than to receive.'" 

###### v36 
When he had spoken these things, he knelt down and prayed with them all. 

###### v37 
They all wept freely, and fell on Paul's neck and kissed him, 

###### v38 
sorrowing most of all because of the word which he had spoken, that they should see his face no more. Then they accompanied him to the ship.

***
[[Acts-19|← Acts 19]] | [[Acts]] | [[Acts-21|Acts 21 →]]
