# Acts 14

[[Acts-13|← Acts 13]] | [[Acts]] | [[Acts-15|Acts 15 →]]
***



###### v1 
In Iconium, they entered together into the synagogue of the Jews, and so spoke that a great multitude both of Jews and of Greeks believed. 

###### v2 
But the disbelieving Jews stirred up and embittered the souls of the Gentiles against the brothers. 

###### v3 
Therefore they stayed there a long time, speaking boldly in the Lord, who testified to the word of his grace, granting signs and wonders to be done by their hands. 

###### v4 
But the multitude of the city was divided. Part sided with the Jews, and part with the apostles. 

###### v5 
When some of both the Gentiles and the Jews, with their rulers, made a violent attempt to mistreat and stone them, 

###### v6 
they became aware of it and fled to the cities of Lycaonia, Lystra, Derbe, and the surrounding region. 

###### v7 
There they preached the Good News. 

###### v8 
At Lystra a certain man sat, impotent in his feet, a cripple from his mother's womb, who never had walked. 

###### v9 
He was listening to Paul speaking, who, fastening eyes on him, and seeing that he had faith to be made whole, 

###### v10 
said with a loud voice, "Stand upright on your feet!" He leaped up and walked. 

###### v11 
When the multitude saw what Paul had done, they lifted up their voice, saying in the language of Lycaonia, "The gods have come down to us in the likeness of men!" 

###### v12 
They called Barnabas "Jupiter", and Paul "Mercury", because he was the chief speaker. 

###### v13 
The priest of Jupiter, whose temple was in front of their city, brought oxen and garlands to the gates, and would have made a sacrifice along with the multitudes. 

###### v14 
But when the apostles, Barnabas and Paul, heard of it, they tore their clothes, and sprang into the multitude, crying out, 

###### v15 
"Men, why are you doing these things? We also are men of like passions with you, and bring you good news, that you should turn from these vain things to the living God, who made the sky, the earth, the sea, and all that is in them; 

###### v16 
who in the generations gone by allowed all the nations to walk in their own ways. 

###### v17 
Yet he didn't leave himself without witness, in that he did good and gave you rains from the sky and fruitful seasons, filling our hearts with food and gladness." 

###### v18 
Even saying these things, they hardly stopped the multitudes from making a sacrifice to them. 

###### v19 
But some Jews from Antioch and Iconium came there, and having persuaded the multitudes, they stoned Paul, and dragged him out of the city, supposing that he was dead. 

###### v20 
But as the disciples stood around him, he rose up, and entered into the city. On the next day he went out with Barnabas to Derbe. 

###### v21 
When they had preached the Good News to that city, and had made many disciples, they returned to Lystra, Iconium, and Antioch, 

###### v22 
strengthening the souls of the disciples, exhorting them to continue in the faith, and that through many afflictions we must enter into God's Kingdom. 

###### v23 
When they had appointed elders for them in every assembly, and had prayed with fasting, they commended them to the Lord, on whom they had believed. 

###### v24 
They passed through Pisidia, and came to Pamphylia. 

###### v25 
When they had spoken the word in Perga, they went down to Attalia. 

###### v26 
From there they sailed to Antioch, from where they had been committed to the grace of God for the work which they had fulfilled. 

###### v27 
When they had arrived, and had gathered the assembly together, they reported all the things that God had done with them, and that he had opened a door of faith to the nations. 

###### v28 
They stayed there with the disciples for a long time.

***
[[Acts-13|← Acts 13]] | [[Acts]] | [[Acts-15|Acts 15 →]]
