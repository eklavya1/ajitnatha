# Acts 8

[[Acts-07|← Acts 07]] | [[Acts]] | [[Acts-09|Acts 09 →]]
***



###### v1 
Saul was consenting to his death. A great persecution arose against the assembly which was in Jerusalem in that day. They were all scattered abroad throughout the regions of Judea and Samaria, except for the apostles. 

###### v2 
Devout men buried Stephen and lamented greatly over him. 

###### v3 
But Saul ravaged the assembly, entering into every house and dragged both men and women off to prison. 

###### v4 
Therefore those who were scattered abroad went around preaching the word. 

###### v5 
Philip went down to the city of Samaria, and proclaimed to them the Christ. 

###### v6 
The multitudes listened with one accord to the things that were spoken by Philip when they heard and saw the signs which he did. 

###### v7 
For unclean spirits came out of many of those who had them. They came out, crying with a loud voice. Many who had been paralyzed and lame were healed. 

###### v8 
There was great joy in that city. 

###### v9 
But there was a certain man, Simon by name, who used to practice sorcery in the city and amazed the people of Samaria, making himself out to be some great one, 

###### v10 
to whom they all listened, from the least to the greatest, saying, "This man is that great power of God." 

###### v11 
They listened to him, because for a long time he had amazed them with his sorceries. 

###### v12 
But when they believed Philip preaching good news concerning God's Kingdom and the name of Jesus Christ, they were baptized, both men and women. 

###### v13 
Simon himself also believed. Being baptized, he continued with Philip. Seeing signs and great miracles occurring, he was amazed. 

###### v14 
Now when the apostles who were at Jerusalem heard that Samaria had received the word of God, they sent Peter and John to them, 

###### v15 
who, when they had come down, prayed for them, that they might receive the Holy Spirit; 

###### v16 
for as yet he had fallen on none of them. They had only been baptized in the name of Christ Jesus. 

###### v17 
Then they laid their hands on them, and they received the Holy Spirit. 

###### v18 
Now when Simon saw that the Holy Spirit was given through the laying on of the apostles' hands, he offered them money, 

###### v19 
saying, "Give me also this power, that whomever I lay my hands on may receive the Holy Spirit." 

###### v20 
But Peter said to him, "May your silver perish with you, because you thought you could obtain the gift of God with money! 

###### v21 
You have neither part nor lot in this matter, for your heart isn't right before God. 

###### v22 
Repent therefore of this, your wickedness, and ask God if perhaps the thought of your heart may be forgiven you. 

###### v23 
For I see that you are in the poison of bitterness and in the bondage of iniquity." 

###### v24 
Simon answered, "Pray for me to the Lord, that none of the things which you have spoken happen to me." 

###### v25 
They therefore, when they had testified and spoken the word of the Lord, returned to Jerusalem, and preached the Good News to many villages of the Samaritans. 

###### v26 
But an angel of the Lord spoke to Philip, saying, "Arise, and go toward the south to the way that goes down from Jerusalem to Gaza. This is a desert." 

###### v27 
He arose and went; and behold, there was a man of Ethiopia, a eunuch of great authority under Candace, queen of the Ethiopians, who was over all her treasure, who had come to Jerusalem to worship. 

###### v28 
He was returning and sitting in his chariot, and was reading the prophet Isaiah. 

###### v29 
The Spirit said to Philip, "Go near, and join yourself to this chariot." 

###### v30 
Philip ran to him, and heard him reading Isaiah the prophet, and said, "Do you understand what you are reading?" 

###### v31 
He said, "How can I, unless someone explains it to me?" He begged Philip to come up and sit with him. 

###### v32 
Now the passage of the Scripture which he was reading was this, "He was led as a sheep to the slaughter. As a lamb before his shearer is silent, so he doesn't open his mouth. 

###### v33 
In his humiliation, his judgment was taken away. Who will declare His generation? For his life is taken from the earth." 

###### v34 
The eunuch answered Philip, "Who is the prophet talking about? About himself, or about someone else?" 

###### v35 
Philip opened his mouth, and beginning from this Scripture, preached to him about Jesus. 

###### v36 
As they went on the way, they came to some water, and the eunuch said, "Behold, here is water. What is keeping me from being baptized?" 

###### v37 


###### v38 
He commanded the chariot to stand still, and they both went down into the water, both Philip and the eunuch, and he baptized him. 

###### v39 
When they came up out of the water, the Spirit of the Lord caught Philip away, and the eunuch didn't see him any more, for he went on his way rejoicing. 

###### v40 
But Philip was found at Azotus. Passing through, he preached the Good News to all the cities, until he came to Caesarea.

***
[[Acts-07|← Acts 07]] | [[Acts]] | [[Acts-09|Acts 09 →]]
