# Acts 9

[[Acts-08|← Acts 08]] | [[Acts]] | [[Acts-10|Acts 10 →]]
***



###### v1 
But Saul, still breathing threats and slaughter against the disciples of the Lord, went to the high priest 

###### v2 
and asked for letters from him to the synagogues of Damascus, that if he found any who were of the Way, whether men or women, he might bring them bound to Jerusalem. 

###### v3 
As he traveled, he got close to Damascus, and suddenly a light from the sky shone around him. 

###### v4 
He fell on the earth, and heard a voice saying to him, "Saul, Saul, why do you persecute me?" 

###### v5 
He said, "Who are you, Lord?" The Lord said, "I am Jesus, whom you are persecuting. 

###### v6 
But rise up and enter into the city, then you will be told what you must do." 

###### v7 
The men who traveled with him stood speechless, hearing the sound, but seeing no one. 

###### v8 
Saul arose from the ground, and when his eyes were opened, he saw no one. They led him by the hand, and brought him into Damascus. 

###### v9 
He was without sight for three days, and neither ate nor drank. 

###### v10 
Now there was a certain disciple at Damascus named Ananias. The Lord said to him in a vision, "Ananias!" He said, "Behold, it's me, Lord." 

###### v11 
The Lord said to him, "Arise, and go to the street which is called Straight, and inquire in the house of Judah for one named Saul, a man of Tarsus. For behold, he is praying, 

###### v12 
and in a vision he has seen a man named Ananias coming in and laying his hands on him, that he might receive his sight." 

###### v13 
But Ananias answered, "Lord, I have heard from many about this man, how much evil he did to your saints at Jerusalem. 

###### v14 
Here he has authority from the chief priests to bind all who call on your name." 

###### v15 
But the Lord said to him, "Go your way, for he is my chosen vessel to bear my name before the nations and kings, and the children of Israel. 

###### v16 
For I will show him how many things he must suffer for my name's sake." 

###### v17 
Ananias departed and entered into the house. Laying his hands on him, he said, "Brother Saul, the Lord, who appeared to you on the road by which you came, has sent me that you may receive your sight and be filled with the Holy Spirit." 

###### v18 
Immediately something like scales fell from his eyes, and he received his sight. He arose and was baptized. 

###### v19 
He took food and was strengthened. Saul stayed several days with the disciples who were at Damascus. 

###### v20 
Immediately in the synagogues he proclaimed the Christ, that he is the Son of God. 

###### v21 
All who heard him were amazed, and said, "Isn't this he who in Jerusalem made havoc of those who called on this name? And he had come here intending to bring them bound before the chief priests!" 

###### v22 
But Saul increased more in strength, and confounded the Jews who lived at Damascus, proving that this is the Christ. 

###### v23 
When many days were fulfilled, the Jews conspired together to kill him, 

###### v24 
but their plot became known to Saul. They watched the gates both day and night that they might kill him, 

###### v25 
but his disciples took him by night and let him down through the wall, lowering him in a basket. 

###### v26 
When Saul had come to Jerusalem, he tried to join himself to the disciples; but they were all afraid of him, not believing that he was a disciple. 

###### v27 
But Barnabas took him and brought him to the apostles, and declared to them how he had seen the Lord on the way, and that he had spoken to him, and how at Damascus he had preached boldly in the name of Jesus. 

###### v28 
He was with them entering into Jerusalem, 

###### v29 
preaching boldly in the name of the Lord Jesus. He spoke and disputed against the Hellenists, but they were seeking to kill him. 

###### v30 
When the brothers knew it, they brought him down to Caesarea, and sent him off to Tarsus. 

###### v31 
So the assemblies throughout all Judea, Galilee, and Samaria had peace, and were built up. They were multiplied, walking in the fear of the Lord and in the comfort of the Holy Spirit. 

###### v32 
As Peter went throughout all those parts, he came down also to the saints who lived at Lydda. 

###### v33 
There he found a certain man named Aeneas, who had been bedridden for eight years, because he was paralyzed. 

###### v34 
Peter said to him, "Aeneas, Jesus Christ heals you. Get up and make your bed!" Immediately he arose. 

###### v35 
All who lived at Lydda and in Sharon saw him, and they turned to the Lord. 

###### v36 
Now there was at Joppa a certain disciple named Tabitha, which when translated, means Dorcas. This woman was full of good works and acts of mercy which she did. 

###### v37 
In those days, she became sick, and died. When they had washed her, they laid her in an upper room. 

###### v38 
As Lydda was near Joppa, the disciples, hearing that Peter was there, sent two men to him, imploring him not to delay in coming to them. 

###### v39 
Peter got up and went with them. When he had come, they brought him into the upper room. All the widows stood by him weeping, and showing the coats and garments which Dorcas had made while she was with them. 

###### v40 
Peter sent them all out, and knelt down and prayed. Turning to the body, he said, "Tabitha, get up!" She opened her eyes, and when she saw Peter, she sat up. 

###### v41 
He gave her his hand, and raised her up. Calling the saints and widows, he presented her alive. 

###### v42 
This became known throughout all Joppa, and many believed in the Lord. 

###### v43 
He stayed many days in Joppa with a tanner named Simon.

***
[[Acts-08|← Acts 08]] | [[Acts]] | [[Acts-10|Acts 10 →]]
