# Acts 10

[[Acts-09|← Acts 09]] | [[Acts]] | [[Acts-11|Acts 11 →]]
***



###### v1 
Now there was a certain man in Caesarea, Cornelius by name, a centurion of what was called the Italian Regiment, 

###### v2 
a devout man, and one who feared God with all his house, who gave gifts for the needy generously to the people, and always prayed to God. 

###### v3 
At about the ninth hour of the day, he clearly saw in a vision an angel of God coming to him, and saying to him, "Cornelius!" 

###### v4 
He, fastening his eyes on him, and being frightened, said, "What is it, Lord?" He said to him, "Your prayers and your gifts to the needy have gone up for a memorial before God. 

###### v5 
Now send men to Joppa, and get Simon, who is also called Peter. 

###### v6 
He is staying with a tanner named Simon, whose house is by the seaside. 

###### v7 
When the angel who spoke to him had departed, Cornelius called two of his household servants and a devout soldier of those who waited on him continually. 

###### v8 
Having explained everything to them, he sent them to Joppa. 

###### v9 
Now on the next day as they were on their journey, and got close to the city, Peter went up on the housetop to pray at about noon. 

###### v10 
He became hungry and desired to eat, but while they were preparing, he fell into a trance. 

###### v11 
He saw heaven opened and a certain container descending to him, like a great sheet let down by four corners on the earth, 

###### v12 
in which were all kinds of four-footed animals of the earth, wild animals, reptiles, and birds of the sky. 

###### v13 
A voice came to him, "Rise, Peter, kill and eat!" 

###### v14 
But Peter said, "Not so, Lord; for I have never eaten anything that is common or unclean." 

###### v15 
A voice came to him again the second time, "What God has cleansed, you must not call unclean." 

###### v16 
This was done three times, and immediately the vessel was received up into heaven. 

###### v17 
Now while Peter was very perplexed in himself what the vision which he had seen might mean, behold, the men who were sent by Cornelius, having made inquiry for Simon's house, stood before the gate, 

###### v18 
and called and asked whether Simon, who was also called Peter, was lodging there. 

###### v19 
While Peter was pondering the vision, the Spirit said to him, "Behold, three men seek you. 

###### v20 
But arise, get down, and go with them, doubting nothing; for I have sent them." 

###### v21 
Peter went down to the men, and said, "Behold, I am he whom you seek. Why have you come?" 

###### v22 
They said, "Cornelius, a centurion, a righteous man and one who fears God, and well spoken of by all the nation of the Jews, was directed by a holy angel to invite you to his house, and to listen to what you say." 

###### v23 
So he called them in and provided a place to stay. On the next day Peter arose and went out with them, and some of the brothers from Joppa accompanied him. 

###### v24 
On the next day they entered into Caesarea. Cornelius was waiting for them, having called together his relatives and his near friends. 

###### v25 
When Peter entered, Cornelius met him, fell down at his feet, and worshiped him. 

###### v26 
But Peter raised him up, saying, "Stand up! I myself am also a man." 

###### v27 
As he talked with him, he went in and found many gathered together. 

###### v28 
He said to them, "You yourselves know how it is an unlawful thing for a man who is a Jew to join himself or come to one of another nation, but God has shown me that I shouldn't call any man unholy or unclean. 

###### v29 
Therefore I also came without complaint when I was sent for. I ask therefore, why did you send for me?" 

###### v30 
Cornelius said, "Four days ago, I was fasting until this hour, and at the ninth hour, I prayed in my house, and behold, a man stood before me in bright clothing, 

###### v31 
and said, 'Cornelius, your prayer is heard, and your gifts to the needy are remembered in the sight of God. 

###### v32 
Send therefore to Joppa and summon Simon, who is also called Peter. He is staying in the house of a tanner named Simon, by the seaside. When he comes, he will speak to you.' 

###### v33 
Therefore I sent to you at once, and it was good of you to come. Now therefore we are all here present in the sight of God to hear all things that have been commanded you by God." 

###### v34 
Peter opened his mouth and said, "Truly I perceive that God doesn't show favoritism; 

###### v35 
but in every nation he who fears him and works righteousness is acceptable to him. 

###### v36 
The word which he sent to the children of Israel, preaching good news of peace by Jesus Christ--he is Lord of all-- 

###### v37 
you yourselves know what happened, which was proclaimed throughout all Judea, beginning from Galilee, after the baptism which John preached; 

###### v38 
even Jesus of Nazareth, how God anointed him with the Holy Spirit and with power, who went about doing good and healing all who were oppressed by the devil, for God was with him. 

###### v39 
We are witnesses of everything he did both in the country of the Jews, and in Jerusalem; whom they also killed, hanging him on a tree. 

###### v40 
God raised him up the third day, and gave him to be revealed, 

###### v41 
not to all the people, but to witnesses who were chosen before by God, to us, who ate and drank with him after he rose from the dead. 

###### v42 
He commanded us to preach to the people and to testify that this is he who is appointed by God as the Judge of the living and the dead. 

###### v43 
All the prophets testify about him, that through his name everyone who believes in him will receive remission of sins." 

###### v44 
While Peter was still speaking these words, the Holy Spirit fell on all those who heard the word. 

###### v45 
They of the circumcision who believed were amazed, as many as came with Peter, because the gift of the Holy Spirit was also poured out on the Gentiles. 

###### v46 
For they heard them speaking in other languages and magnifying God. Then Peter answered, 

###### v47 
"Can anyone forbid these people from being baptized with water? They have received the Holy Spirit just like us." 

###### v48 
He commanded them to be baptized in the name of Jesus Christ. Then they asked him to stay some days.

***
[[Acts-09|← Acts 09]] | [[Acts]] | [[Acts-11|Acts 11 →]]
