# Acts 16

[[Acts-15|← Acts 15]] | [[Acts]] | [[Acts-17|Acts 17 →]]
***



###### v1 
He came to Derbe and Lystra: and behold, a certain disciple was there, named Timothy, the son of a Jewess who believed; but his father was a Greek. 

###### v2 
The brothers who were at Lystra and Iconium gave a good testimony about him. 

###### v3 
Paul wanted to have him go out with him, and he took and circumcised him because of the Jews who were in those parts; for they all knew that his father was a Greek. 

###### v4 
As they went on their way through the cities, they delivered the decrees to them to keep which had been ordained by the apostles and elders who were at Jerusalem. 

###### v5 
So the assemblies were strengthened in the faith, and increased in number daily. 

###### v6 
When they had gone through the region of Phrygia and Galatia, they were forbidden by the Holy Spirit to speak the word in Asia. 

###### v7 
When they had come opposite Mysia, they tried to go into Bithynia, but the Spirit didn't allow them. 

###### v8 
Passing by Mysia, they came down to Troas. 

###### v9 
A vision appeared to Paul in the night. There was a man of Macedonia standing, begging him, and saying, "Come over into Macedonia and help us." 

###### v10 
When he had seen the vision, immediately we sought to go out to Macedonia, concluding that the Lord had called us to preach the Good News to them. 

###### v11 
Setting sail therefore from Troas, we made a straight course to Samothrace, and the day following to Neapolis; 

###### v12 
and from there to Philippi, which is a city of Macedonia, the foremost of the district, a Roman colony. We were staying some days in this city. 

###### v13 
On the Sabbath day we went outside of the city by a riverside, where we supposed there was a place of prayer, and we sat down and spoke to the women who had come together. 

###### v14 
A certain woman named Lydia, a seller of purple, of the city of Thyatira, one who worshiped God, heard us. The Lord opened her heart to listen to the things which were spoken by Paul. 

###### v15 
When she and her household were baptized, she begged us, saying, "If you have judged me to be faithful to the Lord, come into my house and stay." So she persuaded us. 

###### v16 
As we were going to prayer, a certain girl having a spirit of divination met us, who brought her masters much gain by fortune telling. 

###### v17 
Following Paul and us, she cried out, "These men are servants of the Most High God, who proclaim to us a way of salvation!" 

###### v18 
She was doing this for many days. But Paul, becoming greatly annoyed, turned and said to the spirit, "I command you in the name of Jesus Christ to come out of her!" It came out that very hour. 

###### v19 
But when her masters saw that the hope of their gain was gone, they seized Paul and Silas, and dragged them into the marketplace before the rulers. 

###### v20 
When they had brought them to the magistrates, they said, "These men, being Jews, are agitating our city 

###### v21 
and advocate customs which it is not lawful for us to accept or to observe, being Romans." 

###### v22 
The multitude rose up together against them and the magistrates tore their clothes from them, then commanded them to be beaten with rods. 

###### v23 
When they had laid many stripes on them, they threw them into prison, charging the jailer to keep them safely, 

###### v24 
who, having received such a command, threw them into the inner prison, and secured their feet in the stocks. 

###### v25 
But about midnight Paul and Silas were praying and singing hymns to God, and the prisoners were listening to them. 

###### v26 
Suddenly there was a great earthquake, so that the foundations of the prison were shaken; and immediately all the doors were opened, and everyone's bonds were loosened. 

###### v27 
The jailer, being roused out of sleep and seeing the prison doors open, drew his sword and was about to kill himself, supposing that the prisoners had escaped. 

###### v28 
But Paul cried with a loud voice, saying, "Don't harm yourself, for we are all here!" 

###### v29 
He called for lights, sprang in, fell down trembling before Paul and Silas, 

###### v30 
brought them out, and said, "Sirs, what must I do to be saved?" 

###### v31 
They said, "Believe in the Lord Jesus Christ, and you will be saved, you and your household." 

###### v32 
They spoke the word of the Lord to him, and to all who were in his house. 

###### v33 
He took them the same hour of the night and washed their stripes, and was immediately baptized, he and all his household. 

###### v34 
He brought them up into his house, and set food before them, and rejoiced greatly, with all his household, having believed in God. 

###### v35 
But when it was day, the magistrates sent the sergeants, saying, "Let those men go." 

###### v36 
The jailer reported these words to Paul, saying, "The magistrates have sent to let you go; now therefore come out and go in peace." 

###### v37 
But Paul said to them, "They have beaten us publicly without a trial, men who are Romans, and have cast us into prison! Do they now release us secretly? No, most certainly, but let them come themselves and bring us out!" 

###### v38 
The sergeants reported these words to the magistrates, and they were afraid when they heard that they were Romans, 

###### v39 
and they came and begged them. When they had brought them out, they asked them to depart from the city. 

###### v40 
They went out of the prison, and entered into Lydia's house. When they had seen the brothers, they encouraged them, then departed.

***
[[Acts-15|← Acts 15]] | [[Acts]] | [[Acts-17|Acts 17 →]]
