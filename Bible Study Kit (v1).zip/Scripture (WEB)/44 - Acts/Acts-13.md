# Acts 13

[[Acts-12|← Acts 12]] | [[Acts]] | [[Acts-14|Acts 14 →]]
***



###### v1 
Now in the assembly that was at Antioch there were some prophets and teachers: Barnabas, Simeon who was called Niger, Lucius of Cyrene, Manaen the foster brother of Herod the tetrarch, and Saul. 

###### v2 
As they served the Lord and fasted, the Holy Spirit said, "Separate Barnabas and Saul for me, for the work to which I have called them." 

###### v3 
Then, when they had fasted and prayed and laid their hands on them, they sent them away. 

###### v4 
So, being sent out by the Holy Spirit, they went down to Seleucia. From there they sailed to Cyprus. 

###### v5 
When they were at Salamis, they proclaimed God's word in the Jewish synagogues. They also had John as their attendant. 

###### v6 
When they had gone through the island to Paphos, they found a certain sorcerer, a false prophet, a Jew, whose name was Bar Jesus, 

###### v7 
who was with the proconsul, Sergius Paulus, a man of understanding. This man summoned Barnabas and Saul, and sought to hear the word of God. 

###### v8 
But Elymas the sorcerer (for so is his name by interpretation) withstood them, seeking to turn the proconsul away from the faith. 

###### v9 
But Saul, who is also called Paul, filled with the Holy Spirit, fastened his eyes on him, 

###### v10 
and said, "You son of the devil, full of all deceit and all cunning, you enemy of all righteousness, will you not cease to pervert the right ways of the Lord? 

###### v11 
Now, behold, the hand of the Lord is on you, and you will be blind, not seeing the sun for a season!" Immediately a mist and darkness fell on him. He went around seeking someone to lead him by the hand. 

###### v12 
Then the proconsul, when he saw what was done, believed, being astonished at the teaching of the Lord. 

###### v13 
Now Paul and his company set sail from Paphos, and came to Perga in Pamphylia. John departed from them and returned to Jerusalem. 

###### v14 
But they, passing on from Perga, came to Antioch of Pisidia. They went into the synagogue on the Sabbath day, and sat down. 

###### v15 
After the reading of the law and the prophets, the rulers of the synagogue sent to them, saying, "Brothers, if you have any word of exhortation for the people, speak." 

###### v16 
Paul stood up, and beckoning with his hand said, "Men of Israel, and you who fear God, listen. 

###### v17 
The God of this people chose our fathers, and exalted the people when they stayed as aliens in the land of Egypt, and with an uplifted arm, he led them out of it. 

###### v18 
For a period of about forty years he put up with them in the wilderness. 

###### v19 
When he had destroyed seven nations in the land of Canaan, he gave them their land for an inheritance for about four hundred fifty years. 

###### v20 
After these things, he gave them judges until Samuel the prophet. 

###### v21 
Afterward they asked for a king, and God gave to them Saul the son of Kish, a man of the tribe of Benjamin, for forty years. 

###### v22 
When he had removed him, he raised up David to be their king, to whom he also testified, 'I have found David the son of Jesse, a man after my heart, who will do all my will.' 

###### v23 
From this man's offspring, God has brought salvation to Israel according to his promise, 

###### v24 
before his coming, when John had first preached the baptism of repentance to Israel. 

###### v25 
As John was fulfilling his course, he said, 'What do you suppose that I am? I am not he. But behold, one comes after me, the sandals of whose feet I am not worthy to untie.' 

###### v26 
Brothers, children of the stock of Abraham, and those among you who fear God, the word of this salvation is sent out to you. 

###### v27 
For those who dwell in Jerusalem, and their rulers, because they didn't know him, nor the voices of the prophets which are read every Sabbath, fulfilled them by condemning him. 

###### v28 
Though they found no cause for death, they still asked Pilate to have him killed. 

###### v29 
When they had fulfilled all things that were written about him, they took him down from the tree, and laid him in a tomb. 

###### v30 
But God raised him from the dead, 

###### v31 
and he was seen for many days by those who came up with him from Galilee to Jerusalem, who are his witnesses to the people. 

###### v32 
We bring you good news of the promise made to the fathers, 

###### v33 
that God has fulfilled this to us, their children, in that he raised up Jesus. As it is also written in the second psalm, 'You are my Son. Today I have become your father.' 

###### v34 
"Concerning that he raised him up from the dead, now no more to return to corruption, he has spoken thus: 'I will give you the holy and sure blessings of David.' 

###### v35 
Therefore he says also in another psalm, 'You will not allow your Holy One to see decay.' 

###### v36 
For David, after he had in his own generation served the counsel of God, fell asleep, was laid with his fathers, and saw decay. 

###### v37 
But he whom God raised up saw no decay. 

###### v38 
Be it known to you therefore, brothers, that through this man is proclaimed to you remission of sins, 

###### v39 
and by him everyone who believes is justified from all things, from which you could not be justified by the law of Moses. 

###### v40 
Beware therefore, lest that come on you which is spoken in the prophets: 

###### v41 
'Behold, you scoffers, and wonder, and perish; for I work a work in your days, a work which you will in no way believe, if one declares it to you.'"  

###### v42 
So when the Jews went out of the synagogue, the Gentiles begged that these words might be preached to them the next Sabbath. 

###### v43 
Now when the synagogue broke up, many of the Jews and of the devout proselytes followed Paul and Barnabas; who, speaking to them, urged them to continue in the grace of God. 

###### v44 
The next Sabbath, almost the whole city was gathered together to hear the word of God. 

###### v45 
But when the Jews saw the multitudes, they were filled with jealousy, and contradicted the things which were spoken by Paul, and blasphemed. 

###### v46 
Paul and Barnabas spoke out boldly, and said, "It was necessary that God's word should be spoken to you first. Since indeed you thrust it from yourselves, and judge yourselves unworthy of eternal life, behold, we turn to the Gentiles. 

###### v47 
For so has the Lord commanded us, saying, 'I have set you as a light for the Gentiles, that you should bring salvation to the uttermost parts of the earth.'"  

###### v48 
As the Gentiles heard this, they were glad, and glorified the word of God. As many as were appointed to eternal life believed. 

###### v49 
The Lord's word was spread abroad throughout all the region. 

###### v50 
But the Jews stirred up the devout and prominent women and the chief men of the city, and stirred up a persecution against Paul and Barnabas, and threw them out of their borders. 

###### v51 
But they shook off the dust of their feet against them, and came to Iconium. 

###### v52 
The disciples were filled with joy and with the Holy Spirit.

***
[[Acts-12|← Acts 12]] | [[Acts]] | [[Acts-14|Acts 14 →]]
