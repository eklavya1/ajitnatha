# Acts 18

[[Acts-17|← Acts 17]] | [[Acts]] | [[Acts-19|Acts 19 →]]
***



###### v1 
After these things Paul departed from Athens, and came to Corinth. 

###### v2 
He found a certain Jew named Aquila, a man of Pontus by race, who had recently come from Italy, with his wife Priscilla, because Claudius had commanded all the Jews to depart from Rome. He came to them, 

###### v3 
and because he practiced the same trade, he lived with them and worked, for by trade they were tent makers. 

###### v4 
He reasoned in the synagogue every Sabbath and persuaded Jews and Greeks. 

###### v5 
But when Silas and Timothy came down from Macedonia, Paul was compelled by the Spirit, testifying to the Jews that Jesus was the Christ. 

###### v6 
When they opposed him and blasphemed, he shook out his clothing and said to them, "Your blood be on your own heads! I am clean. From now on, I will go to the Gentiles!" 

###### v7 
He departed there, and went into the house of a certain man named Justus, one who worshiped God, whose house was next door to the synagogue. 

###### v8 
Crispus, the ruler of the synagogue, believed in the Lord with all his house. Many of the Corinthians, when they heard, believed and were baptized. 

###### v9 
The Lord said to Paul in the night by a vision, "Don't be afraid, but speak and don't be silent; 

###### v10 
for I am with you, and no one will attack you to harm you, for I have many people in this city." 

###### v11 
He lived there a year and six months, teaching the word of God among them. 

###### v12 
But when Gallio was proconsul of Achaia, the Jews with one accord rose up against Paul and brought him before the judgment seat, 

###### v13 
saying, "This man persuades men to worship God contrary to the law." 

###### v14 
But when Paul was about to open his mouth, Gallio said to the Jews, "If indeed it were a matter of wrong or of wicked crime, you Jews, it would be reasonable that I should bear with you; 

###### v15 
but if they are questions about words and names and your own law, look to it yourselves. For I don't want to be a judge of these matters." 

###### v16 
So he drove them from the judgment seat. 

###### v17 
Then all the Greeks seized Sosthenes, the ruler of the synagogue, and beat him before the judgment seat. Gallio didn't care about any of these things. 

###### v18 
Paul, having stayed after this many more days, took his leave of the brothers, and sailed from there for Syria, together with Priscilla and Aquila. He shaved his head in Cenchreae, for he had a vow. 

###### v19 
He came to Ephesus, and he left them there; but he himself entered into the synagogue, and reasoned with the Jews. 

###### v20 
When they asked him to stay with them a longer time, he declined; 

###### v21 
but taking his leave of them, he said, "I must by all means keep this coming feast in Jerusalem, but I will return again to you if God wills." Then he set sail from Ephesus. 

###### v22 
When he had landed at Caesarea, he went up and greeted the assembly, and went down to Antioch. 

###### v23 
Having spent some time there, he departed, and went through the region of Galatia, and Phrygia, in order, establishing all the disciples. 

###### v24 
Now a certain Jew named Apollos, an Alexandrian by race, an eloquent man, came to Ephesus. He was mighty in the Scriptures. 

###### v25 
This man had been instructed in the way of the Lord; and being fervent in spirit, he spoke and taught accurately the things concerning Jesus, although he knew only the baptism of John. 

###### v26 
He began to speak boldly in the synagogue. But when Priscilla and Aquila heard him, they took him aside, and explained to him the way of God more accurately. 

###### v27 
When he had determined to pass over into Achaia, the brothers encouraged him, and wrote to the disciples to receive him. When he had come, he greatly helped those who had believed through grace; 

###### v28 
for he powerfully refuted the Jews, publicly showing by the Scriptures that Jesus was the Christ.

***
[[Acts-17|← Acts 17]] | [[Acts]] | [[Acts-19|Acts 19 →]]
