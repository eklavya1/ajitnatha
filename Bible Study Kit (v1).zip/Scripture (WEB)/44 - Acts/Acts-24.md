# Acts 24

[[Acts-23|← Acts 23]] | [[Acts]] | [[Acts-25|Acts 25 →]]
***



###### v1 
After five days, the high priest, Ananias, came down with certain elders and an orator, one Tertullus. They informed the governor against Paul. 

###### v2 
When he was called, Tertullus began to accuse him, saying, "Seeing that by you we enjoy much peace, and that prosperity is coming to this nation by your foresight, 

###### v3 
we accept it in all ways and in all places, most excellent Felix, with all thankfulness. 

###### v4 
But that I don't delay you, I entreat you to bear with us and hear a few words. 

###### v5 
For we have found this man to be a plague, an instigator of insurrections among all the Jews throughout the world, and a ringleader of the sect of the Nazarenes. 

###### v6 
He even tried to profane the temple, and we arrested him. 

###### v7 


###### v8 
By examining him yourself you may ascertain all these things of which we accuse him." 

###### v9 
The Jews also joined in the attack, affirming that these things were so. 

###### v10 
When the governor had beckoned to him to speak, Paul answered, "Because I know that you have been a judge of this nation for many years, I cheerfully make my defense, 

###### v11 
seeing that you can verify that it is not more than twelve days since I went up to worship at Jerusalem. 

###### v12 
In the temple they didn't find me disputing with anyone or stirring up a crowd, either in the synagogues, or in the city. 

###### v13 
Nor can they prove to you the things of which they now accuse me. 

###### v14 
But this I confess to you, that after the Way, which they call a sect, so I serve the God of our fathers, believing all things which are according to the law, and which are written in the prophets; 

###### v15 
having hope toward God, which these also themselves look for, that there will be a resurrection of the dead, both of the just and unjust. 

###### v16 
In this I also practice always having a conscience void of offense toward God and men. 

###### v17 
Now after some years, I came to bring gifts for the needy to my nation, and offerings; 

###### v18 
amid which certain Jews from Asia found me purified in the temple, not with a mob, nor with turmoil. 

###### v19 
They ought to have been here before you, and to make accusation, if they had anything against me. 

###### v20 
Or else let these men themselves say what injustice they found in me when I stood before the council, 

###### v21 
unless it is for this one thing that I cried standing among them, 'Concerning the resurrection of the dead I am being judged before you today!'" 

###### v22 
But Felix, having more exact knowledge concerning the Way, deferred them, saying, "When Lysias, the commanding officer, comes down, I will decide your case." 

###### v23 
He ordered the centurion that Paul should be kept in custody, and should have some privileges, and not to forbid any of his friends to serve him or to visit him. 

###### v24 
But after some days, Felix came with Drusilla, his wife, who was a Jewess, and sent for Paul, and heard him concerning the faith in Christ Jesus. 

###### v25 
As he reasoned about righteousness, self-control, and the judgment to come, Felix was terrified, and answered, "Go your way for this time, and when it is convenient for me, I will summon you." 

###### v26 
Meanwhile, he also hoped that money would be given to him by Paul, that he might release him. Therefore also he sent for him more often and talked with him. 

###### v27 
But when two years were fulfilled, Felix was succeeded by Porcius Festus, and desiring to gain favor with the Jews, Felix left Paul in bonds.

***
[[Acts-23|← Acts 23]] | [[Acts]] | [[Acts-25|Acts 25 →]]
