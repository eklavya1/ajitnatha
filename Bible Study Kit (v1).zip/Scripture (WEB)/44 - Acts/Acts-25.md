# Acts 25

[[Acts-24|← Acts 24]] | [[Acts]] | [[Acts-26|Acts 26 →]]
***



###### v1 
Festus therefore, having come into the province, after three days went up to Jerusalem from Caesarea. 

###### v2 
Then the high priest and the principal men of the Jews informed him against Paul, and they begged him, 

###### v3 
asking a favor against him, that he would summon him to Jerusalem; plotting to kill him on the way. 

###### v4 
However Festus answered that Paul should be kept in custody at Caesarea, and that he himself was about to depart shortly. 

###### v5 
"Let them therefore", he said, "that are in power among you go down with me, and if there is anything wrong in the man, let them accuse him." 

###### v6 
When he had stayed among them more than ten days, he went down to Caesarea, and on the next day he sat on the judgment seat, and commanded Paul to be brought. 

###### v7 
When he had come, the Jews who had come down from Jerusalem stood around him, bringing against him many and grievous charges which they could not prove, 

###### v8 
while he said in his defense, "Neither against the law of the Jews, nor against the temple, nor against Caesar, have I sinned at all." 

###### v9 
But Festus, desiring to gain favor with the Jews, answered Paul and said, "Are you willing to go up to Jerusalem, and be judged by me there concerning these things?" 

###### v10 
But Paul said, "I am standing before Caesar's judgment seat, where I ought to be tried. I have done no wrong to the Jews, as you also know very well. 

###### v11 
For if I have done wrong and have committed anything worthy of death, I don't refuse to die; but if none of those things is true that they accuse me of, no one can give me up to them. I appeal to Caesar!" 

###### v12 
Then Festus, when he had conferred with the council, answered, "You have appealed to Caesar. To Caesar you shall go." 

###### v13 
Now when some days had passed, King Agrippa and Bernice arrived at Caesarea, and greeted Festus. 

###### v14 
As he stayed there many days, Festus laid Paul's case before the king, saying, "There is a certain man left a prisoner by Felix; 

###### v15 
about whom, when I was at Jerusalem, the chief priests and the elders of the Jews informed me, asking for a sentence against him. 

###### v16 
I answered them that it is not the custom of the Romans to give up any man to destruction before the accused has met the accusers face to face and has had opportunity to make his defense concerning the matter laid against him. 

###### v17 
When therefore they had come together here, I didn't delay, but on the next day sat on the judgment seat and commanded the man to be brought. 

###### v18 
When the accusers stood up, they brought no charges against him of such things as I supposed; 

###### v19 
but had certain questions against him about their own religion, and about one Jesus, who was dead, whom Paul affirmed to be alive. 

###### v20 
Being perplexed how to inquire concerning these things, I asked whether he was willing to go to Jerusalem and there be judged concerning these matters. 

###### v21 
But when Paul had appealed to be kept for the decision of the emperor, I commanded him to be kept until I could send him to Caesar." 

###### v22 
Agrippa said to Festus, "I also would like to hear the man myself." "Tomorrow," he said, "you shall hear him." 

###### v23 
So on the next day, when Agrippa and Bernice had come with great pomp, and they had entered into the place of hearing with the commanding officers and the principal men of the city, at the command of Festus, Paul was brought in. 

###### v24 
Festus said, "King Agrippa, and all men who are here present with us, you see this man about whom all the multitude of the Jews petitioned me, both at Jerusalem and here, crying that he ought not to live any longer. 

###### v25 
But when I found that he had committed nothing worthy of death, and as he himself appealed to the emperor I determined to send him, 

###### v26 
of whom I have no certain thing to write to my lord. Therefore I have brought him out before you, and especially before you, King Agrippa, that, after examination, I may have something to write. 

###### v27 
For it seems to me unreasonable, in sending a prisoner, not to also specify the charges against him."

***
[[Acts-24|← Acts 24]] | [[Acts]] | [[Acts-26|Acts 26 →]]
