# Acts 21

[[Acts-20|← Acts 20]] | [[Acts]] | [[Acts-22|Acts 22 →]]
***



###### v1 
When we had departed from them and had set sail, we came with a straight course to Cos, and the next day to Rhodes, and from there to Patara. 

###### v2 
Having found a ship crossing over to Phoenicia, we went aboard, and set sail. 

###### v3 
When we had come in sight of Cyprus, leaving it on the left hand, we sailed to Syria and landed at Tyre, for the ship was there to unload her cargo. 

###### v4 
Having found disciples, we stayed there seven days. These said to Paul through the Spirit that he should not go up to Jerusalem. 

###### v5 
When those days were over, we departed and went on our journey. They all, with wives and children, brought us on our way until we were out of the city. Kneeling down on the beach, we prayed. 

###### v6 
After saying goodbye to each other, we went on board the ship, and they returned home again. 

###### v7 
When we had finished the voyage from Tyre, we arrived at Ptolemais. We greeted the brothers and stayed with them one day. 

###### v8 
On the next day, we who were Paul's companions departed, and came to Caesarea. We entered into the house of Philip the evangelist, who was one of the seven, and stayed with him. 

###### v9 
Now this man had four virgin daughters who prophesied. 

###### v10 
As we stayed there some days, a certain prophet named Agabus came down from Judea. 

###### v11 
Coming to us and taking Paul's belt, he bound his own feet and hands, and said, "The Holy Spirit says: 'So the Jews at Jerusalem will bind the man who owns this belt, and will deliver him into the hands of the Gentiles.'" 

###### v12 
When we heard these things, both we and the people of that place begged him not to go up to Jerusalem. 

###### v13 
Then Paul answered, "What are you doing, weeping and breaking my heart? For I am ready not only to be bound, but also to die at Jerusalem for the name of the Lord Jesus." 

###### v14 
When he would not be persuaded, we ceased, saying, "The Lord's will be done." 

###### v15 
After these days we took up our baggage and went up to Jerusalem. 

###### v16 
Some of the disciples from Caesarea also went with us, bringing one Mnason of Cyprus, an early disciple, with whom we would stay. 

###### v17 
When we had come to Jerusalem, the brothers received us gladly. 

###### v18 
The day following, Paul went in with us to James; and all the elders were present. 

###### v19 
When he had greeted them, he reported one by one the things which God had worked among the Gentiles through his ministry. 

###### v20 
They, when they heard it, glorified God. They said to him, "You see, brother, how many thousands there are among the Jews of those who have believed, and they are all zealous for the law. 

###### v21 
They have been informed about you, that you teach all the Jews who are among the Gentiles to forsake Moses, telling them not to circumcise their children and not to walk after the customs. 

###### v22 
What then? The assembly must certainly meet, for they will hear that you have come. 

###### v23 
Therefore do what we tell you. We have four men who have taken a vow. 

###### v24 
Take them and purify yourself with them, and pay their expenses for them, that they may shave their heads. Then all will know that there is no truth in the things that they have been informed about you, but that you yourself also walk keeping the law. 

###### v25 
But concerning the Gentiles who believe, we have written our decision that they should observe no such thing, except that they should keep themselves from food offered to idols, from blood, from strangled things, and from sexual immorality." 

###### v26 
Then Paul took the men, and the next day purified himself and went with them into the temple, declaring the fulfillment of the days of purification, until the offering was offered for every one of them. 

###### v27 
When the seven days were almost completed, the Jews from Asia, when they saw him in the temple, stirred up all the multitude and laid hands on him, 

###### v28 
crying out, "Men of Israel, help! This is the man who teaches all men everywhere against the people, and the law, and this place. Moreover, he also brought Greeks into the temple, and has defiled this holy place!" 

###### v29 
For they had seen Trophimus, the Ephesian, with him in the city, and they supposed that Paul had brought him into the temple. 

###### v30 
All the city was moved and the people ran together. They seized Paul and dragged him out of the temple. Immediately the doors were shut. 

###### v31 
As they were trying to kill him, news came up to the commanding officer of the regiment that all Jerusalem was in an uproar. 

###### v32 
Immediately he took soldiers and centurions and ran down to them. They, when they saw the chief captain and the soldiers, stopped beating Paul. 

###### v33 
Then the commanding officer came near, arrested him, commanded him to be bound with two chains, and inquired who he was and what he had done. 

###### v34 
Some shouted one thing, and some another, among the crowd. When he couldn't find out the truth because of the noise, he commanded him to be brought into the barracks. 

###### v35 
When he came to the stairs, he was carried by the soldiers because of the violence of the crowd; 

###### v36 
for the multitude of the people followed after, crying out, "Away with him!" 

###### v37 
As Paul was about to be brought into the barracks, he asked the commanding officer, "May I speak to you?" He said, "Do you know Greek? 

###### v38 
Aren't you then the Egyptian, who before these days stirred up to sedition and led out into the wilderness the four thousand men of the Assassins?" 

###### v39 
But Paul said, "I am a Jew, from Tarsus in Cilicia, a citizen of no insignificant city. I beg you, allow me to speak to the people." 

###### v40 
When he had given him permission, Paul, standing on the stairs, beckoned with his hand to the people. When there was a great silence, he spoke to them in the Hebrew language, saying,

***
[[Acts-20|← Acts 20]] | [[Acts]] | [[Acts-22|Acts 22 →]]
