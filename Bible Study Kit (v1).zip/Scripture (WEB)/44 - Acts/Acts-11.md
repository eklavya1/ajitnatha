# Acts 11

[[Acts-10|← Acts 10]] | [[Acts]] | [[Acts-12|Acts 12 →]]
***



###### v1 
Now the apostles and the brothers who were in Judea heard that the Gentiles had also received the word of God. 

###### v2 
When Peter had come up to Jerusalem, those who were of the circumcision contended with him, 

###### v3 
saying, "You went in to uncircumcised men, and ate with them!" 

###### v4 
But Peter began, and explained to them in order, saying, 

###### v5 
"I was in the city of Joppa praying, and in a trance I saw a vision: a certain container descending, like it was a great sheet let down from heaven by four corners. It came as far as me. 

###### v6 
When I had looked intently at it, I considered, and saw the four-footed animals of the earth, wild animals, creeping things, and birds of the sky. 

###### v7 
I also heard a voice saying to me, 'Rise, Peter, kill and eat!' 

###### v8 
But I said, 'Not so, Lord, for nothing unholy or unclean has ever entered into my mouth.' 

###### v9 
But a voice answered me the second time out of heaven, 'What God has cleansed, don't you call unclean.' 

###### v10 
This was done three times, and all were drawn up again into heaven. 

###### v11 
Behold, immediately three men stood before the house where I was, having been sent from Caesarea to me. 

###### v12 
The Spirit told me to go with them, without discriminating. These six brothers also accompanied me, and we entered into the man's house. 

###### v13 
He told us how he had seen the angel standing in his house, and saying to him, 'Send to Joppa, and get Simon, who is called Peter, 

###### v14 
who will speak to you words by which you will be saved, you and all your house.' 

###### v15 
As I began to speak, the Holy Spirit fell on them, even as on us at the beginning. 

###### v16 
I remembered the word of the Lord, how he said, 'John indeed baptized in water, but you will be baptized in the Holy Spirit.' 

###### v17 
If then God gave to them the same gift as us, when we believed in the Lord Jesus Christ, who was I, that I could withstand God?" 

###### v18 
When they heard these things, they held their peace, and glorified God, saying, "Then God has also granted to the Gentiles repentance to life!" 

###### v19 
They therefore who were scattered abroad by the oppression that arose about Stephen traveled as far as Phoenicia, Cyprus, and Antioch, speaking the word to no one except to Jews only. 

###### v20 
But there were some of them, men of Cyprus and Cyrene, who, when they had come to Antioch, spoke to the Hellenists, preaching the Lord Jesus. 

###### v21 
The hand of the Lord was with them, and a great number believed and turned to the Lord. 

###### v22 
The report concerning them came to the ears of the assembly which was in Jerusalem. They sent out Barnabas to go as far as Antioch, 

###### v23 
who, when he had come, and had seen the grace of God, was glad. He exhorted them all, that with purpose of heart they should remain near to the Lord. 

###### v24 
For he was a good man, and full of the Holy Spirit and of faith, and many people were added to the Lord. 

###### v25 
Barnabas went out to Tarsus to look for Saul. 

###### v26 
When he had found him, he brought him to Antioch. For a whole year they were gathered together with the assembly, and taught many people. The disciples were first called Christians in Antioch. 

###### v27 
Now in these days, prophets came down from Jerusalem to Antioch. 

###### v28 
One of them named Agabus stood up, and indicated by the Spirit that there should be a great famine all over the world, which also happened in the days of Claudius. 

###### v29 
As any of the disciples had plenty, each determined to send relief to the brothers who lived in Judea; 

###### v30 
which they also did, sending it to the elders by the hands of Barnabas and Saul.

***
[[Acts-10|← Acts 10]] | [[Acts]] | [[Acts-12|Acts 12 →]]
