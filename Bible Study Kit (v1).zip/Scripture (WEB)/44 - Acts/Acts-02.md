# Acts 2

[[Acts-01|← Acts 01]] | [[Acts]] | [[Acts-03|Acts 03 →]]
***



###### v1 
Now when the day of Pentecost had come, they were all with one accord in one place. 

###### v2 
Suddenly there came from the sky a sound like the rushing of a mighty wind, and it filled all the house where they were sitting. 

###### v3 
Tongues like fire appeared and were distributed to them, and one sat on each of them. 

###### v4 
They were all filled with the Holy Spirit, and began to speak with other languages, as the Spirit gave them the ability to speak. 

###### v5 
Now there were dwelling in Jerusalem Jews, devout men, from every nation under the sky. 

###### v6 
When this sound was heard, the multitude came together and were bewildered, because everyone heard them speaking in his own language. 

###### v7 
They were all amazed and marveled, saying to one another, "Behold, aren't all these who speak Galileans? 

###### v8 
How do we hear, everyone in our own native language? 

###### v9 
Parthians, Medes, Elamites, and people from Mesopotamia, Judea, Cappadocia, Pontus, Asia, 

###### v10 
Phrygia, Pamphylia, Egypt, the parts of Libya around Cyrene, visitors from Rome, both Jews and proselytes, 

###### v11 
Cretans and Arabians: we hear them speaking in our languages the mighty works of God!" 

###### v12 
They were all amazed, and were perplexed, saying to one another, "What does this mean?" 

###### v13 
Others, mocking, said, "They are filled with new wine." 

###### v14 
But Peter, standing up with the eleven, lifted up his voice and spoke out to them, "You men of Judea, and all you who dwell at Jerusalem, let this be known to you, and listen to my words. 

###### v15 
For these aren't drunken, as you suppose, seeing it is only the third hour of the day. 

###### v16 
But this is what has been spoken through the prophet Joel: 

###### v17 
'It will be in the last days, says God, that I will pour out my Spirit on all flesh. Your sons and your daughters will prophesy. Your young men will see visions. Your old men will dream dreams. 

###### v18 
Yes, and on my servants and on my handmaidens in those days, I will pour out my Spirit, and they will prophesy. 

###### v19 
I will show wonders in the sky above, and signs on the earth beneath: blood, and fire, and billows of smoke. 

###### v20 
The sun will be turned into darkness, and the moon into blood, before the great and glorious day of the Lord comes. 

###### v21 
It will be that whoever will call on the name of the Lord will be saved.' 

###### v22 
"Men of Israel, hear these words! Jesus of Nazareth, a man approved by God to you by mighty works and wonders and signs which God did by him among you, even as you yourselves know, 

###### v23 
him, being delivered up by the determined counsel and foreknowledge of God, you have taken by the hand of lawless men, crucified and killed; 

###### v24 
whom God raised up, having freed him from the agony of death, because it was not possible that he should be held by it. 

###### v25 
For David says concerning him, 'I saw the Lord always before my face, for he is on my right hand, that I should not be moved. 

###### v26 
Therefore my heart was glad, and my tongue rejoiced. Moreover my flesh also will dwell in hope; 

###### v27 
because you will not leave my soul in Hades, neither will you allow your Holy One to see decay. 

###### v28 
You made known to me the ways of life. You will make me full of gladness with your presence.' 

###### v29 
"Brothers, I may tell you freely of the patriarch David, that he both died and was buried, and his tomb is with us to this day. 

###### v30 
Therefore, being a prophet, and knowing that God had sworn with an oath to him that of the fruit of his body, according to the flesh, he would raise up the Christ to sit on his throne, 

###### v31 
he foreseeing this spoke about the resurrection of the Christ, that his soul wasn't left in Hades, and his flesh didn't see decay. 

###### v32 
This Jesus God raised up, to which we all are witnesses. 

###### v33 
Being therefore exalted by the right hand of God, and having received from the Father the promise of the Holy Spirit, he has poured out this, which you now see and hear. 

###### v34 
For David didn't ascend into the heavens, but he says himself, 'The Lord said to my Lord, "Sit by my right hand 

###### v35 
until I make your enemies a footstool for your feet."' 

###### v36 
"Let all the house of Israel therefore know certainly that God has made him both Lord and Christ, this Jesus whom you crucified." 

###### v37 
Now when they heard this, they were cut to the heart, and said to Peter and the rest of the apostles, "Brothers, what shall we do?" 

###### v38 
Peter said to them, "Repent, and be baptized, every one of you, in the name of Jesus Christ for the forgiveness of sins, and you will receive the gift of the Holy Spirit. 

###### v39 
For the promise is to you, and to your children, and to all who are far off, even as many as the Lord our God will call to himself." 

###### v40 
With many other words he testified, and exhorted them, saying, "Save yourselves from this crooked generation!" 

###### v41 
Then those who gladly received his word were baptized. There were added that day about three thousand souls. 

###### v42 
They continued steadfastly in the apostles' teaching and fellowship, in the breaking of bread, and prayer. 

###### v43 
Fear came on every soul, and many wonders and signs were done through the apostles. 

###### v44 
All who believed were together, and had all things in common. 

###### v45 
They sold their possessions and goods, and distributed them to all, according as anyone had need. 

###### v46 
Day by day, continuing steadfastly with one accord in the temple, and breaking bread at home, they took their food with gladness and singleness of heart, 

###### v47 
praising God, and having favor with all the people. The Lord added to the assembly day by day those who were being saved.

***
[[Acts-01|← Acts 01]] | [[Acts]] | [[Acts-03|Acts 03 →]]
