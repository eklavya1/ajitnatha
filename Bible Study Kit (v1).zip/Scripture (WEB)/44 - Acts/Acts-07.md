# Acts 7

[[Acts-06|← Acts 06]] | [[Acts]] | [[Acts-08|Acts 08 →]]
***



###### v1 
The high priest said, "Are these things so?" 

###### v2 
He said, "Brothers and fathers, listen. The God of glory appeared to our father Abraham when he was in Mesopotamia, before he lived in Haran, 

###### v3 
and said to him, 'Get out of your land and away from your relatives, and come into a land which I will show you.' 

###### v4 
Then he came out of the land of the Chaldaeans and lived in Haran. From there, when his father was dead, God moved him into this land, where you are now living. 

###### v5 
He gave him no inheritance in it, no, not so much as to set his foot on. He promised that he would give it to him for a possession, and to his offspring after him, when he still had no child. 

###### v6 
God spoke in this way: that his offspring would live as aliens in a strange land, and that they would be enslaved and mistreated for four hundred years. 

###### v7 
'I will judge the nation to which they will be in bondage,' said God, 'and after that they will come out, and serve me in this place.' 

###### v8 
He gave him the covenant of circumcision. So Abraham became the father of Isaac, and circumcised him the eighth day. Isaac became the father of Jacob, and Jacob became the father of the twelve patriarchs. 

###### v9 
"The patriarchs, moved with jealousy against Joseph, sold him into Egypt. God was with him, 

###### v10 
and delivered him out of all his afflictions, and gave him favor and wisdom before Pharaoh, king of Egypt. He made him governor over Egypt and all his house. 

###### v11 
Now a famine came over all the land of Egypt and Canaan, and great affliction. Our fathers found no food. 

###### v12 
But when Jacob heard that there was grain in Egypt, he sent out our fathers the first time. 

###### v13 
On the second time Joseph was made known to his brothers, and Joseph's race was revealed to Pharaoh. 

###### v14 
Joseph sent and summoned Jacob, his father, and all his relatives, seventy-five souls. 

###### v15 
Jacob went down into Egypt and he died, himself and our fathers, 

###### v16 
and they were brought back to Shechem, and laid in the tomb that Abraham bought for a price in silver from the children of Hamor of Shechem. 

###### v17 
"But as the time of the promise came close which God had sworn to Abraham, the people grew and multiplied in Egypt, 

###### v18 
until there arose a different king, who didn't know Joseph. 

###### v19 
The same took advantage of our race, and mistreated our fathers, and forced them to throw out their babies, so that they wouldn't stay alive. 

###### v20 
At that time Moses was born, and was exceedingly handsome. He was nourished three months in his father's house. 

###### v21 
When he was thrown out, Pharaoh's daughter took him up and reared him as her own son. 

###### v22 
Moses was instructed in all the wisdom of the Egyptians. He was mighty in his words and works. 

###### v23 
But when he was forty years old, it came into his heart to visit his brothers, the children of Israel. 

###### v24 
Seeing one of them suffer wrong, he defended him, and avenged him who was oppressed, striking the Egyptian. 

###### v25 
He supposed that his brothers understood that God, by his hand, was giving them deliverance; but they didn't understand. 

###### v26 
"The day following, he appeared to them as they fought, and urged them to be at peace again, saying, 'Sirs, you are brothers. Why do you wrong one another?' 

###### v27 
But he who did his neighbor wrong pushed him away, saying, 'Who made you a ruler and a judge over us? 

###### v28 
Do you want to kill me, as you killed the Egyptian yesterday?' 

###### v29 
Moses fled at this saying, and became a stranger in the land of Midian, where he became the father of two sons. 

###### v30 
"When forty years were fulfilled, an angel of the Lord appeared to him in the wilderness of Mount Sinai, in a flame of fire in a bush. 

###### v31 
When Moses saw it, he wondered at the sight. As he came close to see, a voice of the Lord came to him, 

###### v32 
'I am the God of your fathers, the God of Abraham, the God of Isaac, and the God of Jacob.' Moses trembled, and dared not look. 

###### v33 
The Lord said to him, 'Take off your sandals, for the place where you stand is holy ground. 

###### v34 
I have surely seen the affliction of my people that is in Egypt, and have heard their groaning. I have come down to deliver them. Now come, I will send you into Egypt.' 

###### v35 
"This Moses, whom they refused, saying, 'Who made you a ruler and a judge?'--God has sent him as both a ruler and a deliverer by the hand of the angel who appeared to him in the bush. 

###### v36 
This man led them out, having worked wonders and signs in Egypt, in the Red Sea, and in the wilderness for forty years. 

###### v37 
This is that Moses, who said to the children of Israel, 'The Lord our God will raise up a prophet for you from among your brothers, like me.' 

###### v38 
This is he who was in the assembly in the wilderness with the angel that spoke to him on Mount Sinai, and with our fathers, who received living revelations to give to us, 

###### v39 
to whom our fathers wouldn't be obedient, but rejected him, and turned back in their hearts to Egypt, 

###### v40 
saying to Aaron, 'Make us gods that will go before us, for as for this Moses, who led us out of the land of Egypt, we don't know what has become of him.' 

###### v41 
They made a calf in those days, and brought a sacrifice to the idol, and rejoiced in the works of their hands. 

###### v42 
But God turned, and gave them up to serve the army of the sky, as it is written in the book of the prophets, 'Did you offer to me slain animals and sacrifices forty years in the wilderness, O house of Israel? 

###### v43 
You took up the tabernacle of Moloch, the star of your god Rephan, the figures which you made to worship. I will carry you away beyond Babylon.' 

###### v44 
"Our fathers had the tabernacle of the testimony in the wilderness, even as he who spoke to Moses commanded him to make it according to the pattern that he had seen; 

###### v45 
which also our fathers, in their turn, brought in with Joshua when they entered into the possession of the nations, whom God drove out before the face of our fathers, to the days of David, 

###### v46 
who found favor in the sight of God, and asked to find a habitation for the God of Jacob. 

###### v47 
But Solomon built him a house. 

###### v48 
However, the Most High doesn't dwell in temples made with hands, as the prophet says, 

###### v49 
'heaven is my throne, and the earth a footstool for my feet. What kind of house will you build me?' says the Lord. 'Or what is the place of my rest? 

###### v50 
Didn't my hand make all these things?' 

###### v51 
"You stiff-necked and uncircumcised in heart and ears, you always resist the Holy Spirit! As your fathers did, so you do. 

###### v52 
Which of the prophets didn't your fathers persecute? They killed those who foretold the coming of the Righteous One, of whom you have now become betrayers and murderers. 

###### v53 
You received the law as it was ordained by angels, and didn't keep it!" 

###### v54 
Now when they heard these things, they were cut to the heart, and they gnashed at him with their teeth. 

###### v55 
But he, being full of the Holy Spirit, looked up steadfastly into heaven and saw the glory of God, and Jesus standing on the right hand of God, 

###### v56 
and said, "Behold, I see the heavens opened, and the Son of Man standing at the right hand of God!" 

###### v57 
But they cried out with a loud voice and stopped their ears, then rushed at him with one accord. 

###### v58 
They threw him out of the city and stoned him. The witnesses placed their garments at the feet of a young man named Saul. 

###### v59 
They stoned Stephen as he called out, saying, "Lord Jesus, receive my spirit!" 

###### v60 
He kneeled down, and cried with a loud voice, "Lord, don't hold this sin against them!" When he had said this, he fell asleep.

***
[[Acts-06|← Acts 06]] | [[Acts]] | [[Acts-08|Acts 08 →]]
