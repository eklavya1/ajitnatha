# Acts 3

[[Acts-02|← Acts 02]] | [[Acts]] | [[Acts-04|Acts 04 →]]
***



###### v1 
Peter and John were going up into the temple at the hour of prayer, the ninth hour. 

###### v2 
A certain man who was lame from his mother's womb was being carried, whom they laid daily at the door of the temple which is called Beautiful, to ask gifts for the needy of those who entered into the temple. 

###### v3 
Seeing Peter and John about to go into the temple, he asked to receive gifts for the needy. 

###### v4 
Peter, fastening his eyes on him, with John, said, "Look at us." 

###### v5 
He listened to them, expecting to receive something from them. 

###### v6 
But Peter said, "I have no silver or gold, but what I have, that I give you. In the name of Jesus Christ of Nazareth, get up and walk!" 

###### v7 
He took him by the right hand and raised him up. Immediately his feet and his ankle bones received strength. 

###### v8 
Leaping up, he stood and began to walk. He entered with them into the temple, walking, leaping, and praising God. 

###### v9 
All the people saw him walking and praising God. 

###### v10 
They recognized him, that it was he who used to sit begging for gifts for the needy at the Beautiful Gate of the temple. They were filled with wonder and amazement at what had happened to him. 

###### v11 
As the lame man who was healed held on to Peter and John, all the people ran together to them in the porch that is called Solomon's, greatly wondering. 

###### v12 
When Peter saw it, he responded to the people, "You men of Israel, why do you marvel at this man? Why do you fasten your eyes on us, as though by our own power or godliness we had made him walk? 

###### v13 
The God of Abraham, Isaac, and Jacob, the God of our fathers, has glorified his Servant Jesus, whom you delivered up, and denied in the presence of Pilate, when he had determined to release him. 

###### v14 
But you denied the Holy and Righteous One and asked for a murderer to be granted to you, 

###### v15 
and killed the Prince of life, whom God raised from the dead, to which we are witnesses. 

###### v16 
By faith in his name, his name has made this man strong, whom you see and know. Yes, the faith which is through him has given him this perfect soundness in the presence of you all. 

###### v17 
"Now, brothers, I know that you did this in ignorance, as did also your rulers. 

###### v18 
But the things which God announced by the mouth of all his prophets, that Christ should suffer, he thus fulfilled. 

###### v19 
"Repent therefore, and turn again, that your sins may be blotted out, so that there may come times of refreshing from the presence of the Lord, 

###### v20 
and that he may send Christ Jesus, who was ordained for you before, 

###### v21 
whom heaven must receive until the times of restoration of all things, which God spoke long ago by the mouth of his holy prophets. 

###### v22 
For Moses indeed said to the fathers, 'The Lord God will raise up a prophet for you from among your brothers, like me. You shall listen to him in all things whatever he says to you. 

###### v23 
It will be that every soul that will not listen to that prophet will be utterly destroyed from among the people.' 

###### v24 
Yes, and all the prophets from Samuel and those who followed after, as many as have spoken, they also told of these days. 

###### v25 
You are the children of the prophets, and of the covenant which God made with our fathers, saying to Abraham, 'All the families of the earth will be blessed through your offspring.' 

###### v26 
God, having raised up his servant Jesus, sent him to you first to bless you, in turning away every one of you from your wickedness."

***
[[Acts-02|← Acts 02]] | [[Acts]] | [[Acts-04|Acts 04 →]]
