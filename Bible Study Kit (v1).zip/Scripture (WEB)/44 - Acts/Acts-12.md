# Acts 12

[[Acts-11|← Acts 11]] | [[Acts]] | [[Acts-13|Acts 13 →]]
***



###### v1 
Now about that time, King Herod stretched out his hands to oppress some of the assembly. 

###### v2 
He killed James, the brother of John, with the sword. 

###### v3 
When he saw that it pleased the Jews, he proceeded to seize Peter also. This was during the days of unleavened bread. 

###### v4 
When he had arrested him, he put him in prison, and delivered him to four squads of four soldiers each to guard him, intending to bring him out to the people after the Passover. 

###### v5 
Peter therefore was kept in the prison, but constant prayer was made by the assembly to God for him. 

###### v6 
The same night when Herod was about to bring him out, Peter was sleeping between two soldiers, bound with two chains. Guards in front of the door kept the prison. 

###### v7 
And behold, an angel of the Lord stood by him, and a light shone in the cell. He struck Peter on the side, and woke him up, saying, "Stand up quickly!" His chains fell off his hands. 

###### v8 
The angel said to him, "Get dressed and put on your sandals." He did so. He said to him, "Put on your cloak and follow me." 

###### v9 
And he went out and followed him. He didn't know that what was being done by the angel was real, but thought he saw a vision. 

###### v10 
When they were past the first and the second guard, they came to the iron gate that leads into the city, which opened to them by itself. They went out, and went down one street, and immediately the angel departed from him. 

###### v11 
When Peter had come to himself, he said, "Now I truly know that the Lord has sent out his angel and delivered me out of the hand of Herod, and from everything the Jewish people were expecting." 

###### v12 
Thinking about that, he came to the house of Mary, the mother of John who was called Mark, where many were gathered together and were praying. 

###### v13 
When Peter knocked at the door of the gate, a servant girl named Rhoda came to answer. 

###### v14 
When she recognized Peter's voice, she didn't open the gate for joy, but ran in, and reported that Peter was standing in front of the gate. 

###### v15 
They said to her, "You are crazy!" But she insisted that it was so. They said, "It is his angel." 

###### v16 
But Peter continued knocking. When they had opened, they saw him, and were amazed. 

###### v17 
But he, beckoning to them with his hand to be silent, declared to them how the Lord had brought him out of the prison. He said, "Tell these things to James and to the brothers." Then he departed and went to another place. 

###### v18 
Now as soon as it was day, there was no small stir among the soldiers about what had become of Peter. 

###### v19 
When Herod had sought for him, and didn't find him, he examined the guards, then commanded that they should be put to death. He went down from Judea to Caesarea, and stayed there. 

###### v20 
Now Herod was very angry with the people of Tyre and Sidon. They came with one accord to him, and, having made Blastus, the king's personal aide, their friend, they asked for peace, because their country depended on the king's country for food. 

###### v21 
On an appointed day, Herod dressed himself in royal clothing, sat on the throne, and gave a speech to them. 

###### v22 
The people shouted, "The voice of a god, and not of a man!" 

###### v23 
Immediately an angel of the Lord struck him, because he didn't give God the glory. Then he was eaten by worms and died. 

###### v24 
But the word of God grew and multiplied. 

###### v25 
Barnabas and Saul returned to Jerusalem when they had fulfilled their service, also taking with them John who was called Mark.

***
[[Acts-11|← Acts 11]] | [[Acts]] | [[Acts-13|Acts 13 →]]
