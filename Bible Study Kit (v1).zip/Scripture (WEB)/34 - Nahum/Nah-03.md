# Nahum 3

[[Nah-02|← Nahum 02]] | [[Nahum]]
***



###### v1 
Woe to the bloody city! It is all full of lies and robbery. The prey doesn't depart. 

###### v2 
The noise of the whip, the noise of the rattling of wheels, prancing horses, and bounding chariots, 

###### v3 
the horseman mounting, and the flashing sword, the glittering spear, and a multitude of slain, and a great heap of corpses, and there is no end of the bodies. They stumble on their bodies, 

###### v4 
because of the multitude of the prostitution of the alluring prostitute, the mistress of witchcraft, who sells nations through her prostitution, and families through her witchcraft. 

###### v5 
"Behold, I am against you," says Yahweh of Armies, "and I will lift your skirts over your face. I will show the nations your nakedness, and the kingdoms your shame. 

###### v6 
I will throw abominable filth on you, and make you vile, and will set you a spectacle. 

###### v7 
It will happen that all those who look at you will flee from you, and say, 'Nineveh is laid waste! Who will mourn for her?' Where will I seek comforters for you?" 

###### v8 
Are you better than No-Amon, who was situated among the rivers, who had the waters around her; whose rampart was the sea, and her wall was of the sea? 

###### v9 
Cush and Egypt were her boundless strength. Put and Libya were her helpers. 

###### v10 
Yet was she carried away. She went into captivity. Her young children also were dashed in pieces at the head of all the streets, and they cast lots for her honorable men, and all her great men were bound in chains. 

###### v11 
You also will be drunken. You will be hidden. You also will seek a stronghold because of the enemy. 

###### v12 
All your fortresses will be like fig trees with the first-ripe figs: if they are shaken, they fall into the mouth of the eater. 

###### v13 
Behold, your troops among you are women. The gates of your land are set wide open to your enemies. The fire has devoured your bars. 

###### v14 
Draw water for the siege. Strengthen your fortresses. Go into the clay, and tread the mortar. Make the brick kiln strong. 

###### v15 
There the fire will devour you. The sword will cut you off. It will devour you like the grasshopper. Multiply like grasshoppers. Multiply like the locust. 

###### v16 
You have increased your merchants more than the stars of the skies. The grasshopper strips, and flees away. 

###### v17 
Your guards are like the locusts, and your officials like the swarms of locusts, which settle on the walls on a cold day, but when the sun appears, they flee away, and their place is not known where they are. 

###### v18 
Your shepherds slumber, king of Assyria. Your nobles lie down. Your people are scattered on the mountains, and there is no one to gather them. 

###### v19 
There is no healing your wound, for your injury is fatal. All who hear the report of you clap their hands over you; for who hasn't felt your endless cruelty?

***
[[Nah-02|← Nahum 02]] | [[Nahum]]
