# Nahum 2

[[Nah-01|← Nahum 01]] | [[Nahum]] | [[Nah-03|Nahum 03 →]]
***



###### v1 
He who dashes in pieces has come up against you. Keep the fortress! Watch the way! Strengthen your waist! Fortify your power mightily! 

###### v2 
For Yahweh restores the excellency of Jacob, as the excellency of Israel; for the destroyers have destroyed them, and ruined their vine branches. 

###### v3 
The shield of his mighty men is made red. The valiant men are in scarlet. The chariots flash with steel in the day of his preparation, and the pine spears are brandished. 

###### v4 
The chariots rage in the streets. They rush back and forth in the wide ways. Their appearance is like torches. They run like the lightnings. 

###### v5 
He summons his picked troops. They stumble on their way. They dash to its wall, and the protective shield is put in place. 

###### v6 
The gates of the rivers are opened, and the palace is dissolved. 

###### v7 
It is decreed: she is uncovered, she is carried away; and her servants moan as with the voice of doves, beating on their breasts. 

###### v8 
But Nineveh has been from of old like a pool of water, yet they flee away. "Stop! Stop!" they cry, but no one looks back. 

###### v9 
Take the plunder of silver. Take the plunder of gold, for there is no end of the store, the glory of all goodly furniture. 

###### v10 
She is empty, void, and waste. The heart melts, the knees knock together, their bodies and faces have grown pale. 

###### v11 
Where is the den of the lions, and the feeding place of the young lions, where the lion and the lioness walked, the lion's cubs, and no one made them afraid? 

###### v12 
The lion tore in pieces enough for his cubs, and strangled for his lionesses, and filled his caves with the kill, and his dens with prey. 

###### v13 
"Behold, I am against you," says Yahweh of Armies, "and I will burn her chariots in the smoke, and the sword will devour your young lions; and I will cut off your prey from the earth, and the voice of your messengers will no longer be heard."

***
[[Nah-01|← Nahum 01]] | [[Nahum]] | [[Nah-03|Nahum 03 →]]
