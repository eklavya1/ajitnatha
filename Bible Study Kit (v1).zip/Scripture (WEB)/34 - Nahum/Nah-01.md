# Nahum 1

[[Nahum]] | [[Nah-02|Nahum 02 →]]
***



###### v1 
A revelation about Nineveh. The book of the vision of Nahum the Elkoshite. 

###### v2 
Yahweh is a jealous God and avenges. Yahweh avenges and is full of wrath. Yahweh takes vengeance on his adversaries, and he maintains wrath against his enemies. 

###### v3 
Yahweh is slow to anger, and great in power, and will by no means leave the guilty unpunished. Yahweh has his way in the whirlwind and in the storm, and the clouds are the dust of his feet. 

###### v4 
He rebukes the sea, and makes it dry, and dries up all the rivers. Bashan languishes, and Carmel; and the flower of Lebanon languishes. 

###### v5 
The mountains quake before him, and the hills melt away. The earth trembles at his presence, yes, the world, and all who dwell in it. 

###### v6 
Who can stand before his indignation? Who can endure the fierceness of his anger? His wrath is poured out like fire, and the rocks are broken apart by him. 

###### v7 
Yahweh is good, a stronghold in the day of trouble; and he knows those who take refuge in him. 

###### v8 
But with an overflowing flood, he will make a full end of her place, and will pursue his enemies into darkness. 

###### v9 
What do you plot against Yahweh? He will make a full end. Affliction won't rise up the second time. 

###### v10 
For entangled like thorns, and drunken as with their drink, they are consumed utterly like dry stubble. 

###### v11 
One has gone out of you who devises evil against Yahweh, who counsels wickedness. 

###### v12 
Yahweh says: "Though they be in full strength, and likewise many, even so they will be cut down, and he shall pass away. Though I have afflicted you, I will afflict you no more. 

###### v13 
Now I will break his yoke from off you, and will burst your bonds apart." 

###### v14 
Yahweh has commanded concerning you: "No more descendants will bear your name. Out of the house of your gods, I will cut off the engraved image and the molten image. I will make your grave, for you are vile." 

###### v15 
Behold, on the mountains the feet of him who brings good news, who publishes peace! Keep your feasts, Judah! Perform your vows, for the wicked one will no more pass through you. He is utterly cut off.

***
[[Nahum]] | [[Nah-02|Nahum 02 →]]
