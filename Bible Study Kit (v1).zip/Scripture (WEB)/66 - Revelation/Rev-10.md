# Revelation 10

[[Rev-09|← Revelation 09]] | [[Revelation]] | [[Rev-11|Revelation 11 →]]
***



###### v1 
I saw a mighty angel coming down out of the sky, clothed with a cloud. A rainbow was on his head. His face was like the sun, and his feet like pillars of fire. 

###### v2 
He had in his hand a little open book. He set his right foot on the sea, and his left on the land. 

###### v3 
He cried with a loud voice, as a lion roars. When he cried, the seven thunders uttered their voices. 

###### v4 
When the seven thunders sounded, I was about to write; but I heard a voice from the sky saying, "Seal up the things which the seven thunders said, and don't write them." 

###### v5 
The angel whom I saw standing on the sea and on the land lifted up his right hand to the sky, 

###### v6 
and swore by him who lives forever and ever, who created heaven and the things that are in it, the earth and the things that are in it, and the sea and the things that are in it, that there will no longer be delay, 

###### v7 
but in the days of the voice of the seventh angel, when he is about to sound, then the mystery of God is finished, as he declared to his servants, the prophets. 

###### v8 
The voice which I heard from heaven, again speaking with me, said, "Go, take the book which is open in the hand of the angel who stands on the sea and on the land." 

###### v9 
I went to the angel, telling him to give me the little book. He said to me, "Take it, and eat it. It will make your stomach bitter, but in your mouth it will be as sweet as honey." 

###### v10 
I took the little book out of the angel's hand, and ate it. It was as sweet as honey in my mouth. When I had eaten it, my stomach was made bitter. 

###### v11 
They told me, "You must prophesy again over many peoples, nations, languages, and kings."

***
[[Rev-09|← Revelation 09]] | [[Revelation]] | [[Rev-11|Revelation 11 →]]
