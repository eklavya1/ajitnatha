# Revelation 18

[[Rev-17|← Revelation 17]] | [[Revelation]] | [[Rev-19|Revelation 19 →]]
***



###### v1 
After these things, I saw another angel coming down out of the sky, having great authority. The earth was illuminated with his glory. 

###### v2 
He cried with a mighty voice, saying, "Fallen, fallen is Babylon the great, and she has become a habitation of demons, a prison of every unclean spirit, and a prison of every unclean and hateful bird! 

###### v3 
For all the nations have drunk of the wine of the wrath of her sexual immorality, the kings of the earth committed sexual immorality with her, and the merchants of the earth grew rich from the abundance of her luxury." 

###### v4 
I heard another voice from heaven, saying, "Come out of her, my people, that you have no participation in her sins, and that you don't receive of her plagues, 

###### v5 
for her sins have reached to the sky, and God has remembered her iniquities. 

###### v6 
Return to her just as she returned, and repay her double as she did, and according to her works. In the cup which she mixed, mix to her double. 

###### v7 
However much she glorified herself, and grew wanton, so much give her of torment and mourning. For she says in her heart, 'I sit a queen, and am no widow, and will in no way see mourning.' 

###### v8 
Therefore in one day her plagues will come: death, mourning, and famine; and she will be utterly burned with fire; for the Lord God who has judged her is strong. 

###### v9 
The kings of the earth who committed sexual immorality and lived wantonly with her will weep and wail over her, when they look at the smoke of her burning, 

###### v10 
standing far away for the fear of her torment, saying, 'Woe, woe, the great city, Babylon, the strong city! For your judgment has come in one hour.' 

###### v11 
The merchants of the earth weep and mourn over her, for no one buys their merchandise any more: 

###### v12 
merchandise of gold, silver, precious stones, pearls, fine linen, purple, silk, scarlet, all expensive wood, every vessel of ivory, every vessel made of most precious wood, and of brass, and iron, and marble; 

###### v13 
and cinnamon, incense, perfume, frankincense, wine, olive oil, fine flour, wheat, sheep, horses, chariots, and people's bodies and souls. 

###### v14 
The fruits which your soul lusted after have been lost to you. All things that were dainty and sumptuous have perished from you, and you will find them no more at all. 

###### v15 
The merchants of these things, who were made rich by her, will stand far away for the fear of her torment, weeping and mourning, 

###### v16 
saying, 'Woe, woe, the great city, she who was dressed in fine linen, purple, and scarlet, and decked with gold and precious stones and pearls! 

###### v17 
For in an hour such great riches are made desolate.' Every ship master, and everyone who sails anywhere, and mariners, and as many as gain their living by sea, stood far away, 

###### v18 
and cried out as they looked at the smoke of her burning, saying, 'What is like the great city?' 

###### v19 
They cast dust on their heads, and cried, weeping and mourning, saying, 'Woe, woe, the great city, in which all who had their ships in the sea were made rich by reason of her great wealth!' For she is made desolate in one hour. 

###### v20 
"Rejoice over her, O heaven, you saints, apostles, and prophets; for God has judged your judgment on her." 

###### v21 
A mighty angel took up a stone like a great millstone and cast it into the sea, saying, "Thus with violence will Babylon, the great city, be thrown down, and will be found no more at all. 

###### v22 
The voice of harpists, minstrels, flute players, and trumpeters will be heard no more at all in you. No craftsman, of whatever craft, will be found any more at all in you. The sound of a mill will be heard no more at all in you. 

###### v23 
The light of a lamp will shine no more at all in you. The voice of the bridegroom and of the bride will be heard no more at all in you; for your merchants were the princes of the earth; for with your sorcery all the nations were deceived. 

###### v24 
In her was found the blood of prophets and of saints, and of all who have been slain on the earth."

***
[[Rev-17|← Revelation 17]] | [[Revelation]] | [[Rev-19|Revelation 19 →]]
