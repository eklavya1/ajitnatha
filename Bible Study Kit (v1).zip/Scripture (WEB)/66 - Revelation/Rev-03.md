# Revelation 3

[[Rev-02|← Revelation 02]] | [[Revelation]] | [[Rev-04|Revelation 04 →]]
***



###### v1 
"And to the angel of the assembly in Sardis write: "He who has the seven Spirits of God and the seven stars says these things: "I know your works, that you have a reputation of being alive, but you are dead. 

###### v2 
Wake up and keep the things that remain, which you were about to throw away, for I have found no works of yours perfected before my God. 

###### v3 
Remember therefore how you have received and heard. Keep it and repent. If therefore you won't watch, I will come as a thief, and you won't know what hour I will come upon you. 

###### v4 
Nevertheless you have a few names in Sardis that didn't defile their garments. They will walk with me in white, for they are worthy. 

###### v5 
He who overcomes will be arrayed in white garments, and I will in no way blot his name out of the book of life, and I will confess his name before my Father, and before his angels. 

###### v6 
He who has an ear, let him hear what the Spirit says to the assemblies. 

###### v7 
"To the angel of the assembly in Philadelphia write: "He who is holy, he who is true, he who has the key of David, he who opens and no one can shut, and who shuts and no one opens, says these things: 

###### v8 
"I know your works (behold, I have set before you an open door, which no one can shut), that you have a little power, and kept my word, and didn't deny my name. 

###### v9 
Behold, I give some of the synagogue of Satan, of those who say they are Jews, and they are not, but lie--behold, I will make them to come and worship before your feet, and to know that I have loved you. 

###### v10 
Because you kept my command to endure, I also will keep you from the hour of testing which is to come on the whole world, to test those who dwell on the earth. 

###### v11 
I am coming quickly! Hold firmly that which you have, so that no one takes your crown. 

###### v12 
He who overcomes, I will make him a pillar in the temple of my God, and he will go out from there no more. I will write on him the name of my God and the name of the city of my God, the new Jerusalem, which comes down out of heaven from my God, and my own new name. 

###### v13 
He who has an ear, let him hear what the Spirit says to the assemblies. 

###### v14 
"To the angel of the assembly in Laodicea write: "The Amen, the Faithful and True Witness, the Beginning of God's creation, says these things: 

###### v15 
"I know your works, that you are neither cold nor hot. I wish you were cold or hot. 

###### v16 
So, because you are lukewarm, and neither hot nor cold, I will vomit you out of my mouth. 

###### v17 
Because you say, 'I am rich, and have gotten riches, and have need of nothing;' and don't know that you are the wretched one, miserable, poor, blind, and naked; 

###### v18 
I counsel you to buy from me gold refined by fire, that you may become rich; and white garments, that you may clothe yourself, and that the shame of your nakedness may not be revealed; and eye salve to anoint your eyes, that you may see. 

###### v19 
As many as I love, I reprove and chasten. Be zealous therefore, and repent. 

###### v20 
Behold, I stand at the door and knock. If anyone hears my voice and opens the door, then I will come in to him, and will dine with him, and he with me. 

###### v21 
He who overcomes, I will give to him to sit down with me on my throne, as I also overcame, and sat down with my Father on his throne. 

###### v22 
He who has an ear, let him hear what the Spirit says to the assemblies."

***
[[Rev-02|← Revelation 02]] | [[Revelation]] | [[Rev-04|Revelation 04 →]]
