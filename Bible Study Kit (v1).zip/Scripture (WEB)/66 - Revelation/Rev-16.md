# Revelation 16

[[Rev-15|← Revelation 15]] | [[Revelation]] | [[Rev-17|Revelation 17 →]]
***



###### v1 
I heard a loud voice out of the temple, saying to the seven angels, "Go and pour out the seven bowls of the wrath of God on the earth!" 

###### v2 
The first went, and poured out his bowl into the earth, and it became a harmful and evil sore on the people who had the mark of the beast, and who worshiped his image. 

###### v3 
The second angel poured out his bowl into the sea, and it became blood as of a dead man. Every living thing in the sea died. 

###### v4 
The third poured out his bowl into the rivers and springs of water, and they became blood. 

###### v5 
I heard the angel of the waters saying, "You are righteous, who are and who were, O Holy One, because you have judged these things. 

###### v6 
For they poured out the blood of saints and prophets, and you have given them blood to drink. They deserve this." 

###### v7 
I heard the altar saying, "Yes, Lord God, the Almighty, true and righteous are your judgments." 

###### v8 
The fourth poured out his bowl on the sun, and it was given to him to scorch men with fire. 

###### v9 
People were scorched with great heat, and people blasphemed the name of God who has the power over these plagues. They didn't repent and give him glory. 

###### v10 
The fifth poured out his bowl on the throne of the beast, and his kingdom was darkened. They gnawed their tongues because of the pain, 

###### v11 
and they blasphemed the God of heaven because of their pains and their sores. They still didn't repent of their works. 

###### v12 
The sixth poured out his bowl on the great river, the Euphrates. Its water was dried up, that the way might be prepared for the kings that come from the sunrise. 

###### v13 
I saw coming out of the mouth of the dragon, and out of the mouth of the beast, and out of the mouth of the false prophet, three unclean spirits, something like frogs; 

###### v14 
for they are spirits of demons, performing signs; which go out to the kings of the whole inhabited earth, to gather them together for the war of that great day of God, the Almighty. 

###### v15 
"Behold, I come like a thief. Blessed is he who watches, and keeps his clothes, so that he doesn't walk naked, and they see his shame." 

###### v16 
He gathered them together into the place which is called in Hebrew, "Megiddo". 

###### v17 
The seventh poured out his bowl into the air. A loud voice came out of the temple of heaven, from the throne, saying, "It is done!" 

###### v18 
There were lightnings, sounds, and thunders; and there was a great earthquake, such as has not happened since there were men on the earth, so great an earthquake, and so mighty. 

###### v19 
The great city was divided into three parts, and the cities of the nations fell. Babylon the great was remembered in the sight of God, to give to her the cup of the wine of the fierceness of his wrath. 

###### v20 
Every island fled away, and the mountains were not found. 

###### v21 
Great hailstones, about the weight of a talent, came down out of the sky on people. People blasphemed God because of the plague of the hail, for this plague is exceedingly severe.

***
[[Rev-15|← Revelation 15]] | [[Revelation]] | [[Rev-17|Revelation 17 →]]
