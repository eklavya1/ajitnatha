# Revelation 5

[[Rev-04|← Revelation 04]] | [[Revelation]] | [[Rev-06|Revelation 06 →]]
***



###### v1 
I saw, in the right hand of him who sat on the throne, a book written inside and outside, sealed shut with seven seals. 

###### v2 
I saw a mighty angel proclaiming with a loud voice, "Who is worthy to open the book, and to break its seals?" 

###### v3 
No one in heaven above, or on the earth, or under the earth, was able to open the book or to look in it. 

###### v4 
Then I wept much, because no one was found worthy to open the book or to look in it. 

###### v5 
One of the elders said to me, "Don't weep. Behold, the Lion who is of the tribe of Judah, the Root of David, has overcome: he who opens the book and its seven seals." 

###### v6 
I saw in the middle of the throne and of the four living creatures, and in the middle of the elders, a Lamb standing, as though it had been slain, having seven horns and seven eyes, which are the seven Spirits of God, sent out into all the earth. 

###### v7 
Then he came, and he took it out of the right hand of him who sat on the throne. 

###### v8 
Now when he had taken the book, the four living creatures and the twenty-four elders fell down before the Lamb, each one having a harp, and golden bowls full of incense, which are the prayers of the saints. 

###### v9 
They sang a new song, saying, "You are worthy to take the book and to open its seals: for you were killed, and bought us for God with your blood out of every tribe, language, people, and nation, 

###### v10 
and made us kings and priests to our God, and we will reign on the earth." 

###### v11 
I saw, and I heard something like a voice of many angels around the throne, the living creatures, and the elders. The number of them was ten thousands of ten thousands, and thousands of thousands; 

###### v12 
saying with a loud voice, "Worthy is the Lamb who has been killed to receive the power, wealth, wisdom, strength, honor, glory, and blessing!" 

###### v13 
I heard every created thing which is in heaven, on the earth, under the earth, on the sea, and everything in them, saying, "To him who sits on the throne, and to the Lamb be the blessing, the honor, the glory, and the dominion, forever and ever! Amen!" 

###### v14 
The four living creatures said, "Amen!" Then the elders fell down and worshiped.

***
[[Rev-04|← Revelation 04]] | [[Revelation]] | [[Rev-06|Revelation 06 →]]
