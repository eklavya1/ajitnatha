# Revelation 14

[[Rev-13|← Revelation 13]] | [[Revelation]] | [[Rev-15|Revelation 15 →]]
***



###### v1 
I saw, and behold, the Lamb standing on Mount Zion, and with him a number, one hundred forty-four thousand, having his name, and the name of his Father, written on their foreheads. 

###### v2 
I heard a sound from heaven, like the sound of many waters, and like the sound of a great thunder. The sound which I heard was like that of harpists playing on their harps. 

###### v3 
They sing a new song before the throne, and before the four living creatures and the elders. No one could learn the song except the one hundred forty-four thousand, those who had been redeemed out of the earth. 

###### v4 
These are those who were not defiled with women, for they are virgins. These are those who follow the Lamb wherever he goes. These were redeemed by Jesus from among men, the first fruits to God and to the Lamb. 

###### v5 
In their mouth was found no lie, for they are blameless. 

###### v6 
I saw an angel flying in mid heaven, having an eternal Good News to proclaim to those who dwell on the earth, and to every nation, tribe, language, and people. 

###### v7 
He said with a loud voice, "Fear the Lord, and give him glory; for the hour of his judgment has come. Worship him who made the heaven, the earth, the sea, and the springs of waters!" 

###### v8 
Another, a second angel, followed, saying, "Babylon the great has fallen, which has made all the nations to drink of the wine of the wrath of her sexual immorality." 

###### v9 
Another angel, a third, followed them, saying with a great voice, "If anyone worships the beast and his image, and receives a mark on his forehead, or on his hand, 

###### v10 
he also will drink of the wine of the wrath of God, which is prepared unmixed in the cup of his anger. He will be tormented with fire and sulfur in the presence of the holy angels, and in the presence of the Lamb. 

###### v11 
The smoke of their torment goes up forever and ever. They have no rest day and night, those who worship the beast and his image, and whoever receives the mark of his name. 

###### v12 
Here is the perseverance of the saints, those who keep the commandments of God, and the faith of Jesus." 

###### v13 
I heard a voice from heaven saying, "Write, 'Blessed are the dead who die in the Lord from now on.'" "Yes," says the Spirit, "that they may rest from their labors; for their works follow with them." 

###### v14 
I looked, and saw a white cloud, and on the cloud one sitting like a son of man, having on his head a golden crown, and in his hand a sharp sickle. 

###### v15 
Another angel came out of the temple, crying with a loud voice to him who sat on the cloud, "Send your sickle, and reap; for the hour to reap has come; for the harvest of the earth is ripe!" 

###### v16 
He who sat on the cloud thrust his sickle on the earth, and the earth was reaped. 

###### v17 
Another angel came out of the temple which is in heaven. He also had a sharp sickle. 

###### v18 
Another angel came out from the altar, he who has power over fire, and he called with a great voice to him who had the sharp sickle, saying, "Send your sharp sickle, and gather the clusters of the vine of the earth, for the earth's grapes are fully ripe!" 

###### v19 
The angel thrust his sickle into the earth, and gathered the vintage of the earth, and threw it into the great wine press of the wrath of God. 

###### v20 
The wine press was trodden outside of the city, and blood came out of the wine press, even to the bridles of the horses, as far as one thousand six hundred stadia.

***
[[Rev-13|← Revelation 13]] | [[Revelation]] | [[Rev-15|Revelation 15 →]]
