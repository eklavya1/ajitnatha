# Revelation 2

[[Rev-01|← Revelation 01]] | [[Revelation]] | [[Rev-03|Revelation 03 →]]
***



###### v1 
"To the angel of the assembly in Ephesus write: "He who holds the seven stars in his right hand, he who walks among the seven golden lamp stands says these things: 

###### v2 
"I know your works, and your toil and perseverance, and that you can't tolerate evil men, and have tested those who call themselves apostles, and they are not, and found them false. 

###### v3 
You have perseverance and have endured for my name's sake, and have not grown weary. 

###### v4 
But I have this against you, that you left your first love. 

###### v5 
Remember therefore from where you have fallen, and repent and do the first works; or else I am coming to you swiftly, and will move your lamp stand out of its place, unless you repent. 

###### v6 
But this you have, that you hate the works of the Nicolaitans, which I also hate. 

###### v7 
He who has an ear, let him hear what the Spirit says to the assemblies. To him who overcomes I will give to eat from the tree of life, which is in the Paradise of my God. 

###### v8 
"To the angel of the assembly in Smyrna write: "The first and the last, who was dead, and has come to life says these things: 

###### v9 
"I know your works, oppression, and your poverty (but you are rich), and the blasphemy of those who say they are Jews, and they are not, but are a synagogue of Satan. 

###### v10 
Don't be afraid of the things which you are about to suffer. Behold, the devil is about to throw some of you into prison, that you may be tested; and you will have oppression for ten days. Be faithful to death, and I will give you the crown of life. 

###### v11 
He who has an ear, let him hear what the Spirit says to the assemblies. He who overcomes won't be harmed by the second death. 

###### v12 
"To the angel of the assembly in Pergamum write: "He who has the sharp two-edged sword says these things: 

###### v13 
"I know your works and where you dwell, where Satan's throne is. You hold firmly to my name, and didn't deny my faith in the days of Antipas my witness, my faithful one, who was killed among you, where Satan dwells. 

###### v14 
But I have a few things against you, because you have there some who hold the teaching of Balaam, who taught Balak to throw a stumbling block before the children of Israel, to eat things sacrificed to idols, and to commit sexual immorality. 

###### v15 
So you also have some who hold to the teaching of the Nicolaitans likewise. 

###### v16 
Repent therefore, or else I am coming to you quickly, and I will make war against them with the sword of my mouth. 

###### v17 
He who has an ear, let him hear what the Spirit says to the assemblies. To him who overcomes, to him I will give of the hidden manna, and I will give him a white stone, and on the stone a new name written, which no one knows but he who receives it. 

###### v18 
"To the angel of the assembly in Thyatira write: "The Son of God, who has his eyes like a flame of fire, and his feet are like burnished brass, says these things: 

###### v19 
"I know your works, your love, faith, service, patient endurance, and that your last works are more than the first. 

###### v20 
But I have this against you, that you tolerate your woman, Jezebel, who calls herself a prophetess. She teaches and seduces my servants to commit sexual immorality, and to eat things sacrificed to idols. 

###### v21 
I gave her time to repent, but she refuses to repent of her sexual immorality. 

###### v22 
Behold, I will throw her and those who commit adultery with her into a bed of great oppression, unless they repent of her works. 

###### v23 
I will kill her children with Death, and all the assemblies will know that I am he who searches the minds and hearts. I will give to each one of you according to your deeds. 

###### v24 
But to you I say, to the rest who are in Thyatira, as many as don't have this teaching, who don't know what some call 'the deep things of Satan,' to you I say, I am not putting any other burden on you. 

###### v25 
Nevertheless, hold that which you have firmly until I come. 

###### v26 
He who overcomes, and he who keeps my works to the end, to him I will give authority over the nations. 

###### v27 
He will rule them with a rod of iron, shattering them like clay pots; as I also have received of my Father: 

###### v28 
and I will give him the morning star. 

###### v29 
He who has an ear, let him hear what the Spirit says to the assemblies.

***
[[Rev-01|← Revelation 01]] | [[Revelation]] | [[Rev-03|Revelation 03 →]]
