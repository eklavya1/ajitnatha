# Revelation 15

[[Rev-14|← Revelation 14]] | [[Revelation]] | [[Rev-16|Revelation 16 →]]
***



###### v1 
I saw another great and marvelous sign in the sky: seven angels having the seven last plagues, for in them God's wrath is finished. 

###### v2 
I saw something like a sea of glass mixed with fire, and those who overcame the beast, his image, and the number of his name, standing on the sea of glass, having harps of God. 

###### v3 
They sang the song of Moses, the servant of God, and the song of the Lamb, saying, "Great and marvelous are your works, Lord God, the Almighty! Righteous and true are your ways, you King of the nations. 

###### v4 
Who wouldn't fear you, Lord, and glorify your name? For you only are holy. For all the nations will come and worship before you. For your righteous acts have been revealed." 

###### v5 
After these things I looked, and the temple of the tabernacle of the testimony in heaven was opened. 

###### v6 
The seven angels who had the seven plagues came out, clothed with pure, bright linen, and wearing golden sashes around their breasts. 

###### v7 
One of the four living creatures gave to the seven angels seven golden bowls full of the wrath of God, who lives forever and ever. 

###### v8 
The temple was filled with smoke from the glory of God, and from his power. No one was able to enter into the temple until the seven plagues of the seven angels would be finished.

***
[[Rev-14|← Revelation 14]] | [[Revelation]] | [[Rev-16|Revelation 16 →]]
