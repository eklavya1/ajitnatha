# Revelation 9

[[Rev-08|← Revelation 08]] | [[Revelation]] | [[Rev-10|Revelation 10 →]]
***



###### v1 
The fifth angel sounded, and I saw a star from the sky which had fallen to the earth. The key to the pit of the abyss was given to him. 

###### v2 
He opened the pit of the abyss, and smoke went up out of the pit, like the smoke from a burning furnace. The sun and the air were darkened because of the smoke from the pit. 

###### v3 
Then out of the smoke came locusts on the earth, and power was given to them, as the scorpions of the earth have power. 

###### v4 
They were told that they should not hurt the grass of the earth, neither any green thing, neither any tree, but only those people who don't have God's seal on their foreheads. 

###### v5 
They were given power, not to kill them, but to torment them for five months. Their torment was like the torment of a scorpion when it strikes a person. 

###### v6 
In those days people will seek death, and will in no way find it. They will desire to die, and death will flee from them. 

###### v7 
The shapes of the locusts were like horses prepared for war. On their heads were something like golden crowns, and their faces were like people's faces. 

###### v8 
They had hair like women's hair, and their teeth were like those of lions. 

###### v9 
They had breastplates, like breastplates of iron. The sound of their wings was like the sound of chariots, or of many horses rushing to war. 

###### v10 
They have tails like those of scorpions, and stings. In their tails they have power to harm men for five months. 

###### v11 
They have over them as king the angel of the abyss. His name in Hebrew is "Abaddon", but in Greek, he has the name "Apollyon". 

###### v12 
The first woe is past. Behold, there are still two woes coming after this. 

###### v13 
The sixth angel sounded. I heard a voice from the horns of the golden altar which is before God, 

###### v14 
saying to the sixth angel who had the trumpet, "Free the four angels who are bound at the great river Euphrates!" 

###### v15 
The four angels were freed who had been prepared for that hour and day and month and year, so that they might kill one third of mankind. 

###### v16 
The number of the armies of the horsemen was two hundred million. I heard the number of them. 

###### v17 
Thus I saw the horses in the vision, and those who sat on them, having breastplates of fiery red, hyacinth blue, and sulfur yellow; and the horses' heads resembled lions' heads. Out of their mouths proceed fire, smoke, and sulfur. 

###### v18 
By these three plagues were one third of mankind killed: by the fire, the smoke, and the sulfur, which proceeded out of their mouths. 

###### v19 
For the power of the horses is in their mouths and in their tails. For their tails are like serpents, and have heads, and with them they harm. 

###### v20 
The rest of mankind, who were not killed with these plagues, didn't repent of the works of their hands, that they wouldn't worship demons, and the idols of gold, and of silver, and of brass, and of stone, and of wood; which can't see, hear, or walk. 

###### v21 
They didn't repent of their murders, their sorceries, their sexual immorality, or their thefts.

***
[[Rev-08|← Revelation 08]] | [[Revelation]] | [[Rev-10|Revelation 10 →]]
