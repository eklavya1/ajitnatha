# Revelation 11

[[Rev-10|← Revelation 10]] | [[Revelation]] | [[Rev-12|Revelation 12 →]]
***



###### v1 
A reed like a rod was given to me. Someone said, "Rise, and measure God's temple, and the altar, and those who worship in it. 

###### v2 
Leave out the court which is outside of the temple, and don't measure it, for it has been given to the nations. They will tread the holy city under foot for forty-two months. 

###### v3 
I will give power to my two witnesses, and they will prophesy one thousand two hundred sixty days, clothed in sackcloth." 

###### v4 
These are the two olive trees and the two lamp stands, standing before the Lord of the earth. 

###### v5 
If anyone desires to harm them, fire proceeds out of their mouth and devours their enemies. If anyone desires to harm them, he must be killed in this way. 

###### v6 
These have the power to shut up the sky, that it may not rain during the days of their prophecy. They have power over the waters, to turn them into blood, and to strike the earth with every plague, as often as they desire. 

###### v7 
When they have finished their testimony, the beast that comes up out of the abyss will make war with them, and overcome them, and kill them. 

###### v8 
Their dead bodies will be in the street of the great city, which spiritually is called Sodom and Egypt, where also their Lord was crucified. 

###### v9 
From among the peoples, tribes, languages, and nations, people will look at their dead bodies for three and a half days, and will not allow their dead bodies to be laid in a tomb. 

###### v10 
Those who dwell on the earth rejoice over them, and they will be glad. They will give gifts to one another, because these two prophets tormented those who dwell on the earth. 

###### v11 
After the three and a half days, the breath of life from God entered into them, and they stood on their feet. Great fear fell on those who saw them. 

###### v12 
I heard a loud voice from heaven saying to them, "Come up here!" They went up into heaven in the cloud, and their enemies saw them. 

###### v13 
In that day there was a great earthquake, and a tenth of the city fell. Seven thousand people were killed in the earthquake, and the rest were terrified, and gave glory to the God of heaven. 

###### v14 
The second woe is past. Behold, the third woe comes quickly. 

###### v15 
The seventh angel sounded, and great voices in heaven followed, saying, "The kingdom of the world has become the Kingdom of our Lord, and of his Christ. He will reign forever and ever!" 

###### v16 
The twenty-four elders, who sit on their thrones before God's throne, fell on their faces and worshiped God, 

###### v17 
saying: "We give you thanks, Lord God, the Almighty, the one who is and who was; because you have taken your great power and reigned. 

###### v18 
The nations were angry, and your wrath came, as did the time for the dead to be judged, and to give your bondservants the prophets, their reward, as well as to the saints, and those who fear your name, to the small and the great, and to destroy those who destroy the earth." 

###### v19 
God's temple that is in heaven was opened, and the ark of the Lord's covenant was seen in his temple. Lightnings, sounds, thunders, an earthquake, and great hail followed.

***
[[Rev-10|← Revelation 10]] | [[Revelation]] | [[Rev-12|Revelation 12 →]]
