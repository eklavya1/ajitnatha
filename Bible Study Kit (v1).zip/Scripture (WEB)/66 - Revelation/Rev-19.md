# Revelation 19

[[Rev-18|← Revelation 18]] | [[Revelation]] | [[Rev-20|Revelation 20 →]]
***



###### v1 
After these things I heard something like a loud voice of a great multitude in heaven, saying, "Hallelujah! Salvation, power, and glory belong to our God; 

###### v2 
for his judgments are true and righteous. For he has judged the great prostitute, who corrupted the earth with her sexual immorality, and he has avenged the blood of his servants at her hand." 

###### v3 
A second said, "Hallelujah! Her smoke goes up forever and ever." 

###### v4 
The twenty-four elders and the four living creatures fell down and worshiped God who sits on the throne, saying, "Amen! Hallelujah!" 

###### v5 
A voice came from the throne, saying, "Give praise to our God, all you his servants, you who fear him, the small and the great!" 

###### v6 
I heard something like the voice of a great multitude, and like the voice of many waters, and like the voice of mighty thunders, saying, "Hallelujah! For the Lord our God, the Almighty, reigns! 

###### v7 
Let's rejoice and be exceedingly glad, and let's give the glory to him. For the wedding of the Lamb has come, and his wife has made herself ready." 

###### v8 
It was given to her that she would array herself in bright, pure, fine linen: for the fine linen is the righteous acts of the saints. 

###### v9 
He said to me, "Write, 'Blessed are those who are invited to the wedding supper of the Lamb.'" He said to me, "These are true words of God." 

###### v10 
I fell down before his feet to worship him. He said to me, "Look! Don't do it! I am a fellow bondservant with you and with your brothers who hold the testimony of Jesus. Worship God, for the testimony of Jesus is the Spirit of Prophecy." 

###### v11 
I saw the heaven opened, and behold, a white horse, and he who sat on it is called Faithful and True. In righteousness he judges and makes war. 

###### v12 
His eyes are a flame of fire, and on his head are many crowns. He has names written and a name written which no one knows but he himself. 

###### v13 
He is clothed in a garment sprinkled with blood. His name is called "The Word of God." 

###### v14 
The armies which are in heaven followed him on white horses, clothed in white, pure, fine linen. 

###### v15 
Out of his mouth proceeds a sharp, double-edged sword, that with it he should strike the nations. He will rule them with an iron rod. He treads the wine press of the fierceness of the wrath of God, the Almighty. 

###### v16 
He has on his garment and on his thigh a name written, "KING OF KINGS, AND LORD OF LORDS." 

###### v17 
I saw an angel standing in the sun. He cried with a loud voice, saying to all the birds that fly in the sky, "Come! Be gathered together to the great supper of God, 

###### v18 
that you may eat the flesh of kings, the flesh of captains, the flesh of mighty men, and the flesh of horses and of those who sit on them, and the flesh of all men, both free and slave, small and great." 

###### v19 
I saw the beast, and the kings of the earth, and their armies, gathered together to make war against him who sat on the horse, and against his army. 

###### v20 
The beast was taken, and with him the false prophet who worked the signs in his sight, with which he deceived those who had received the mark of the beast and those who worshiped his image. These two were thrown alive into the lake of fire that burns with sulfur. 

###### v21 
The rest were killed with the sword of him who sat on the horse, the sword which came out of his mouth. So all the birds were filled with their flesh.

***
[[Rev-18|← Revelation 18]] | [[Revelation]] | [[Rev-20|Revelation 20 →]]
