# Revelation 21

[[Rev-20|← Revelation 20]] | [[Revelation]] | [[Rev-22|Revelation 22 →]]
***



###### v1 
I saw a new heaven and a new earth: for the first heaven and the first earth have passed away, and the sea is no more. 

###### v2 
I saw the holy city, New Jerusalem, coming down out of heaven from God, prepared like a bride adorned for her husband. 

###### v3 
I heard a loud voice out of heaven saying, "Behold, God's dwelling is with people, and he will dwell with them, and they will be his people, and God himself will be with them as their God. 

###### v4 
He will wipe away every tear from their eyes. Death will be no more; neither will there be mourning, nor crying, nor pain, any more. The first things have passed away." 

###### v5 
He who sits on the throne said, "Behold, I am making all things new." He said, "Write, for these words of God are faithful and true." 

###### v6 
He said to me, "I am the Alpha and the Omega, the Beginning and the End. I will give freely to him who is thirsty from the spring of the water of life. 

###### v7 
He who overcomes, I will give him these things. I will be his God, and he will be my son. 

###### v8 
But for the cowardly, unbelieving, sinners, abominable, murderers, sexually immoral, sorcerers, idolaters, and all liars, their part is in the lake that burns with fire and sulfur, which is the second death." 

###### v9 
One of the seven angels who had the seven bowls, who were loaded with the seven last plagues came, and he spoke with me, saying, "Come here. I will show you the wife, the Lamb's bride." 

###### v10 
He carried me away in the Spirit to a great and high mountain, and showed me the holy city, Jerusalem, coming down out of heaven from God, 

###### v11 
having the glory of God. Her light was like a most precious stone, as if it were a jasper stone, clear as crystal; 

###### v12 
having a great and high wall; having twelve gates, and at the gates twelve angels; and names written on them, which are the names of the twelve tribes of the children of Israel. 

###### v13 
On the east were three gates; and on the north three gates; and on the south three gates; and on the west three gates. 

###### v14 
The wall of the city had twelve foundations, and on them twelve names of the twelve Apostles of the Lamb. 

###### v15 
He who spoke with me had for a measure a golden reed to measure the city, its gates, and its walls. 

###### v16 
The city is square, and its length is as great as its width. He measured the city with the reed, twelve thousand twelve stadia. Its length, width, and height are equal. 

###### v17 
Its wall is one hundred forty-four cubits, by the measure of a man, that is, of an angel. 

###### v18 
The construction of its wall was jasper. The city was pure gold, like pure glass. 

###### v19 
The foundations of the city's wall were adorned with all kinds of precious stones. The first foundation was jasper; the second, sapphire; the third, chalcedony; the fourth, emerald; 

###### v20 
the fifth, sardonyx; the sixth, sardius; the seventh, chrysolite; the eighth, beryl; the ninth, topaz; the tenth, chrysoprase; the eleventh, jacinth; and the twelfth, amethyst. 

###### v21 
The twelve gates were twelve pearls. Each one of the gates was made of one pearl. The street of the city was pure gold, like transparent glass. 

###### v22 
I saw no temple in it, for the Lord God, the Almighty, and the Lamb, are its temple. 

###### v23 
The city has no need for the sun or moon to shine, for the very glory of God illuminated it, and its lamp is the Lamb. 

###### v24 
The nations will walk in its light. The kings of the earth bring the glory and honor of the nations into it. 

###### v25 
Its gates will in no way be shut by day (for there will be no night there), 

###### v26 
and they shall bring the glory and the honor of the nations into it so that they may enter. 

###### v27 
There will in no way enter into it anything profane, or one who causes an abomination or a lie, but only those who are written in the Lamb's book of life.

***
[[Rev-20|← Revelation 20]] | [[Revelation]] | [[Rev-22|Revelation 22 →]]
