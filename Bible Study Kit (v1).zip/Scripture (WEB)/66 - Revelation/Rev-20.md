# Revelation 20

[[Rev-19|← Revelation 19]] | [[Revelation]] | [[Rev-21|Revelation 21 →]]
***



###### v1 
I saw an angel coming down out of heaven, having the key of the abyss and a great chain in his hand. 

###### v2 
He seized the dragon, the old serpent, which is the devil and Satan, who deceives the whole inhabited earth, and bound him for a thousand years, 

###### v3 
and cast him into the abyss, and shut it, and sealed it over him, that he should deceive the nations no more, until the thousand years were finished. After this, he must be freed for a short time. 

###### v4 
I saw thrones, and they sat on them, and judgment was given to them. I saw the souls of those who had been beheaded for the testimony of Jesus, and for the word of God, and such as didn't worship the beast nor his image, and didn't receive the mark on their forehead and on their hand. They lived and reigned with Christ for a thousand years. 

###### v5 
The rest of the dead didn't live until the thousand years were finished. This is the first resurrection. 

###### v6 
Blessed and holy is he who has part in the first resurrection. Over these, the second death has no power, but they will be priests of God and of Christ, and will reign with him one thousand years. 

###### v7 
And after the thousand years, Satan will be released from his prison, 

###### v8 
and he will come out to deceive the nations which are in the four corners of the earth, Gog and Magog, to gather them together to the war; the number of whom is as the sand of the sea. 

###### v9 
They went up over the width of the earth, and surrounded the camp of the saints, and the beloved city. Fire came down out of heaven from God and devoured them. 

###### v10 
The devil who deceived them was thrown into the lake of fire and sulfur, where the beast and the false prophet are also. They will be tormented day and night forever and ever. 

###### v11 
I saw a great white throne, and him who sat on it, from whose face the earth and the heaven fled away. There was found no place for them. 

###### v12 
I saw the dead, the great and the small, standing before the throne, and they opened books. Another book was opened, which is the book of life. The dead were judged out of the things which were written in the books, according to their works. 

###### v13 
The sea gave up the dead who were in it. Death and Hades gave up the dead who were in them. They were judged, each one according to his works. 

###### v14 
Death and Hades were thrown into the lake of fire. This is the second death, the lake of fire. 

###### v15 
If anyone was not found written in the book of life, he was cast into the lake of fire.

***
[[Rev-19|← Revelation 19]] | [[Revelation]] | [[Rev-21|Revelation 21 →]]
