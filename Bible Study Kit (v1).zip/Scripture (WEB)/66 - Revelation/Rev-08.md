# Revelation 8

[[Rev-07|← Revelation 07]] | [[Revelation]] | [[Rev-09|Revelation 09 →]]
***



###### v1 
When he opened the seventh seal, there was silence in heaven for about half an hour. 

###### v2 
I saw the seven angels who stand before God, and seven trumpets were given to them. 

###### v3 
Another angel came and stood over the altar, having a golden censer. Much incense was given to him, that he should add it to the prayers of all the saints on the golden altar which was before the throne. 

###### v4 
The smoke of the incense, with the prayers of the saints, went up before God out of the angel's hand. 

###### v5 
The angel took the censer, and he filled it with the fire of the altar, then threw it on the earth. Thunders, sounds, lightnings, and an earthquake followed. 

###### v6 
The seven angels who had the seven trumpets prepared themselves to sound. 

###### v7 
The first sounded, and there followed hail and fire, mixed with blood, and they were thrown to the earth. One third of the earth was burned up, and one third of the trees were burned up, and all green grass was burned up. 

###### v8 
The second angel sounded, and something like a great burning mountain was thrown into the sea. One third of the sea became blood, 

###### v9 
and one third of the living creatures which were in the sea died. One third of the ships were destroyed. 

###### v10 
The third angel sounded, and a great star fell from the sky, burning like a torch, and it fell on one third of the rivers, and on the springs of the waters. 

###### v11 
The name of the star is called "Wormwood." One third of the waters became wormwood. Many people died from the waters, because they were made bitter. 

###### v12 
The fourth angel sounded, and one third of the sun was struck, and one third of the moon, and one third of the stars; so that one third of them would be darkened, and the day wouldn't shine for one third of it, and the night in the same way. 

###### v13 
I saw, and I heard an eagle, flying in mid heaven, saying with a loud voice, "Woe! Woe! Woe for those who dwell on the earth, because of the other voices of the trumpets of the three angels, who are yet to sound!"

***
[[Rev-07|← Revelation 07]] | [[Revelation]] | [[Rev-09|Revelation 09 →]]
