# Revelation 7

[[Rev-06|← Revelation 06]] | [[Revelation]] | [[Rev-08|Revelation 08 →]]
***



###### v1 
After this, I saw four angels standing at the four corners of the earth, holding the four winds of the earth, so that no wind would blow on the earth, or on the sea, or on any tree. 

###### v2 
I saw another angel ascend from the sunrise, having the seal of the living God. He cried with a loud voice to the four angels to whom it was given to harm the earth and the sea, 

###### v3 
saying, "Don't harm the earth, the sea, or the trees, until we have sealed the bondservants of our God on their foreheads!" 

###### v4 
I heard the number of those who were sealed, one hundred forty-four thousand, sealed out of every tribe of the children of Israel: 

###### v5 
of the tribe of Judah twelve thousand were sealed, of the tribe of Reuben twelve thousand, of the tribe of Gad twelve thousand, 

###### v6 
of the tribe of Asher twelve thousand, of the tribe of Naphtali twelve thousand, of the tribe of Manasseh twelve thousand, 

###### v7 
of the tribe of Simeon twelve thousand, of the tribe of Levi twelve thousand, of the tribe of Issachar twelve thousand, 

###### v8 
of the tribe of Zebulun twelve thousand, of the tribe of Joseph twelve thousand, and of the tribe of Benjamin twelve thousand were sealed. 

###### v9 
After these things I looked, and behold, a great multitude, which no man could count, out of every nation and of all tribes, peoples, and languages, standing before the throne and before the Lamb, dressed in white robes, with palm branches in their hands. 

###### v10 
They cried with a loud voice, saying, "Salvation be to our God, who sits on the throne, and to the Lamb!" 

###### v11 
All the angels were standing around the throne, the elders, and the four living creatures; and they fell on their faces before his throne, and worshiped God, 

###### v12 
saying, "Amen! Blessing, glory, wisdom, thanksgiving, honor, power, and might, be to our God forever and ever! Amen." 

###### v13 
One of the elders answered, saying to me, "These who are arrayed in the white robes, who are they, and where did they come from?" 

###### v14 
I told him, "My lord, you know." He said to me, "These are those who came out of the great suffering.They washed their robes, and made them white in the Lamb's blood. 

###### v15 
Therefore they are before the throne of God, they serve him day and night in his temple. He who sits on the throne will spread his tabernacle over them. 

###### v16 
They will never be hungry or thirsty any more. The sun won't beat on them, nor any heat; 

###### v17 
for the Lamb who is in the middle of the throne shepherds them and leads them to springs of life-giving waters. And God will wipe away every tear from their eyes."

***
[[Rev-06|← Revelation 06]] | [[Revelation]] | [[Rev-08|Revelation 08 →]]
