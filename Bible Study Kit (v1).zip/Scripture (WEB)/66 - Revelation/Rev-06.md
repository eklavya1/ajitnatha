# Revelation 6

[[Rev-05|← Revelation 05]] | [[Revelation]] | [[Rev-07|Revelation 07 →]]
***



###### v1 
I saw that the Lamb opened one of the seven seals, and I heard one of the four living creatures saying, as with a voice of thunder, "Come and see!" 

###### v2 
Then a white horse appeared, and he who sat on it had a bow. A crown was given to him, and he came out conquering, and to conquer. 

###### v3 
When he opened the second seal, I heard the second living creature saying, "Come!" 

###### v4 
Another came out: a red horse. To him who sat on it was given power to take peace from the earth, and that they should kill one another. There was given to him a great sword. 

###### v5 
When he opened the third seal, I heard the third living creature saying, "Come and see!" And behold, a black horse, and he who sat on it had a balance in his hand. 

###### v6 
I heard a voice in the middle of the four living creatures saying, "A choenix of wheat for a denarius, and three choenix of barley for a denarius! Don't damage the oil and the wine!" 

###### v7 
When he opened the fourth seal, I heard the fourth living creature saying, "Come and see!" 

###### v8 
And behold, a pale horse, and the name of he who sat on it was Death. Hades followed with him. Authority over one fourth of the earth, to kill with the sword, with famine, with death, and by the wild animals of the earth was given to him. 

###### v9 
When he opened the fifth seal, I saw underneath the altar the souls of those who had been killed for the Word of God, and for the testimony of the Lamb which they had. 

###### v10 
They cried with a loud voice, saying, "How long, Master, the holy and true, until you judge and avenge our blood on those who dwell on the earth?" 

###### v11 
A long white robe was given to each of them. They were told that they should rest yet for a while, until their fellow servants and their brothers, who would also be killed even as they were, should complete their course. 

###### v12 
I saw when he opened the sixth seal, and there was a great earthquake. The sun became black as sackcloth made of hair, and the whole moon became as blood. 

###### v13 
The stars of the sky fell to the earth, like a fig tree dropping its unripe figs when it is shaken by a great wind. 

###### v14 
The sky was removed like a scroll when it is rolled up. Every mountain and island was moved out of its place. 

###### v15 
The kings of the earth, the princes, the commanding officers, the rich, the strong, and every slave and free person, hid themselves in the caves and in the rocks of the mountains. 

###### v16 
They told the mountains and the rocks, "Fall on us, and hide us from the face of him who sits on the throne, and from the wrath of the Lamb, 

###### v17 
for the great day of his wrath has come; and who is able to stand?"

***
[[Rev-05|← Revelation 05]] | [[Revelation]] | [[Rev-07|Revelation 07 →]]
