# Revelation 13

[[Rev-12|← Revelation 12]] | [[Revelation]] | [[Rev-14|Revelation 14 →]]
***



###### v1 
Then I stood on the sand of the sea. I saw a beast coming up out of the sea, having ten horns and seven heads. On his horns were ten crowns, and on his heads, blasphemous names. 

###### v2 
The beast which I saw was like a leopard, and his feet were like those of a bear, and his mouth like the mouth of a lion. The dragon gave him his power, his throne, and great authority. 

###### v3 
One of his heads looked like it had been wounded fatally. His fatal wound was healed, and the whole earth marveled at the beast. 

###### v4 
They worshiped the dragon, because he gave his authority to the beast, and they worshiped the beast, saying, "Who is like the beast? Who is able to make war with him?" 

###### v5 
A mouth speaking great things and blasphemy was given to him. Authority to make war for forty-two months was given to him. 

###### v6 
He opened his mouth for blasphemy against God, to blaspheme his name, and his dwelling, those who dwell in heaven. 

###### v7 
It was given to him to make war with the saints, and to overcome them. Authority over every tribe, people, language, and nation was given to him. 

###### v8 
All who dwell on the earth will worship him, everyone whose name has not been written from the foundation of the world in the book of life of the Lamb who has been killed. 

###### v9 
If anyone has an ear, let him hear. 

###### v10 
If anyone is to go into captivity, he will go into captivity. If anyone is to be killed with the sword, he must be killed. Here is the endurance and the faith of the saints. 

###### v11 
I saw another beast coming up out of the earth. He had two horns like a lamb, and he spoke like a dragon. 

###### v12 
He exercises all the authority of the first beast in his presence. He makes the earth and those who dwell in it to worship the first beast, whose fatal wound was healed. 

###### v13 
He performs great signs, even making fire come down out of the sky to the earth in the sight of people. 

###### v14 
He deceives my own people who dwell on the earth because of the signs he was granted to do in front of the beast, saying to those who dwell on the earth that they should make an image to the beast who had the sword wound and lived. 

###### v15 
It was given to him to give breath to it, to the image of the beast, that the image of the beast should both speak, and cause as many as wouldn't worship the image of the beast to be killed. 

###### v16 
He causes all, the small and the great, the rich and the poor, and the free and the slave, to be given marks on their right hands, or on their foreheads; 

###### v17 
and that no one would be able to buy or to sell, unless he has that mark, which is the name of the beast or the number of his name. 

###### v18 
Here is wisdom. He who has understanding, let him calculate the number of the beast, for it is the number of a man. His number is six hundred sixty-six.

***
[[Rev-12|← Revelation 12]] | [[Revelation]] | [[Rev-14|Revelation 14 →]]
