# Revelation 22

[[Rev-21|← Revelation 21]] | [[Revelation]]
***



###### v1 
He showed me a river of water of life, clear as crystal, proceeding out of the throne of God and of the Lamb, 

###### v2 
in the middle of its street. On this side of the river and on that was the tree of life, bearing twelve kinds of fruits, yielding its fruit every month. The leaves of the tree were for the healing of the nations. 

###### v3 
There will be no curse any more. The throne of God and of the Lamb will be in it, and his servants will serve him. 

###### v4 
They will see his face, and his name will be on their foreheads. 

###### v5 
There will be no night, and they need no lamp light or sun light; for the Lord God will illuminate them. They will reign forever and ever. 

###### v6 
He said to me, "These words are faithful and true. The Lord God of the spirits of the prophets sent his angel to show to his bondservants the things which must happen soon." 

###### v7 
"Behold, I come quickly. Blessed is he who keeps the words of the prophecy of this book." 

###### v8 
Now I, John, am the one who heard and saw these things. When I heard and saw, I fell down to worship before the feet of the angel who had shown me these things. 

###### v9 
He said to me, "See you don't do it! I am a fellow bondservant with you and with your brothers, the prophets, and with those who keep the words of this book. Worship God." 

###### v10 
He said to me, "Don't seal up the words of the prophecy of this book, for the time is at hand. 

###### v11 
He who acts unjustly, let him act unjustly still. He who is filthy, let him be filthy still. He who is righteous, let him do righteousness still. He who is holy, let him be holy still." 

###### v12 
"Behold, I come quickly. My reward is with me, to repay to each man according to his work. 

###### v13 
I am the Alpha and the Omega, the First and the Last, the Beginning and the End. 

###### v14 
Blessed are those who do his commandments, that they may have the right to the tree of life, and may enter in by the gates into the city. 

###### v15 
Outside are the dogs, the sorcerers, the sexually immoral, the murderers, the idolaters, and everyone who loves and practices falsehood. 

###### v16 
I, Jesus, have sent my angel to testify these things to you for the assemblies. I am the root and the offspring of David, the Bright and Morning Star." 

###### v17 
The Spirit and the bride say, "Come!" He who hears, let him say, "Come!" He who is thirsty, let him come. He who desires, let him take the water of life freely. 

###### v18 
I testify to everyone who hears the words of the prophecy of this book, if anyone adds to them, may God add to him the plagues which are written in this book. 

###### v19 
If anyone takes away from the words of the book of this prophecy, may God take away his part from the tree of life, and out of the holy city, which are written in this book. 

###### v20 
He who testifies these things says, "Yes, I come quickly." Amen! Yes, come, Lord Jesus. 

###### v21 
The grace of the Lord Jesus Christ be with all the saints. Amen.

***
[[Rev-21|← Revelation 21]] | [[Revelation]]
