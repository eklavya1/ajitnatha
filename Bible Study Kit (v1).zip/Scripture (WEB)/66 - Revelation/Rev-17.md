# Revelation 17

[[Rev-16|← Revelation 16]] | [[Revelation]] | [[Rev-18|Revelation 18 →]]
***



###### v1 
One of the seven angels who had the seven bowls came and spoke with me, saying, "Come here. I will show you the judgment of the great prostitute who sits on many waters, 

###### v2 
with whom the kings of the earth committed sexual immorality. Those who dwell in the earth were made drunken with the wine of her sexual immorality." 

###### v3 
He carried me away in the Spirit into a wilderness. I saw a woman sitting on a scarlet-colored beast, full of blasphemous names, having seven heads and ten horns. 

###### v4 
The woman was dressed in purple and scarlet, and decked with gold and precious stones and pearls, having in her hand a golden cup full of abominations and the impurities of the sexual immorality of the earth. 

###### v5 
And on her forehead a name was written, "MYSTERY, BABYLON THE GREAT, THE MOTHER OF THE PROSTITUTES AND OF THE ABOMINATIONS OF THE EARTH." 

###### v6 
I saw the woman drunken with the blood of the saints, and with the blood of the martyrs of Jesus. When I saw her, I wondered with great amazement. 

###### v7 
The angel said to me, "Why do you wonder? I will tell you the mystery of the woman, and of the beast that carries her, which has the seven heads and the ten horns. 

###### v8 
The beast that you saw was, and is not; and is about to come up out of the abyss and to go into destruction. Those who dwell on the earth and whose names have not been written in the book of life from the foundation of the world will marvel when they see that the beast was, and is not, and shall be present. 

###### v9 
Here is the mind that has wisdom. The seven heads are seven mountains on which the woman sits. 

###### v10 
They are seven kings. Five have fallen, the one is, the other has not yet come. When he comes, he must continue a little while. 

###### v11 
The beast that was, and is not, is himself also an eighth, and is of the seven; and he goes to destruction. 

###### v12 
The ten horns that you saw are ten kings who have received no kingdom as yet, but they receive authority as kings with the beast for one hour. 

###### v13 
These have one mind, and they give their power and authority to the beast. 

###### v14 
These will war against the Lamb, and the Lamb will overcome them, for he is Lord of lords, and King of kings, and those who are with him are called chosen and faithful." 

###### v15 
He said to me, "The waters which you saw, where the prostitute sits, are peoples, multitudes, nations, and languages. 

###### v16 
The ten horns which you saw, and the beast, these will hate the prostitute, will make her desolate, will strip her naked, will eat her flesh, and will burn her utterly with fire. 

###### v17 
For God has put in their hearts to do what he has in mind, to be of one mind, and to give their kingdom to the beast, until the words of God should be accomplished. 

###### v18 
The woman whom you saw is the great city, which reigns over the kings of the earth."

***
[[Rev-16|← Revelation 16]] | [[Revelation]] | [[Rev-18|Revelation 18 →]]
