# Revelation 4

[[Rev-03|← Revelation 03]] | [[Revelation]] | [[Rev-05|Revelation 05 →]]
***



###### v1 
After these things I looked and saw a door opened in heaven, and the first voice that I heard, like a trumpet speaking with me, was one saying, "Come up here, and I will show you the things which must happen after this." 

###### v2 
Immediately I was in the Spirit. Behold, there was a throne set in heaven, and one sitting on the throne 

###### v3 
that looked like a jasper stone and a sardius. There was a rainbow around the throne, like an emerald to look at. 

###### v4 
Around the throne were twenty-four thrones. On the thrones were twenty-four elders sitting, dressed in white garments, with crowns of gold on their heads. 

###### v5 
Out of the throne proceed lightnings, sounds, and thunders. There were seven lamps of fire burning before his throne, which are the seven Spirits of God. 

###### v6 
Before the throne was something like a sea of glass, similar to crystal. In the middle of the throne, and around the throne were four living creatures full of eyes before and behind. 

###### v7 
The first creature was like a lion, and the second creature like a calf, and the third creature had a face like a man, and the fourth was like a flying eagle. 

###### v8 
The four living creatures, each one of them having six wings, are full of eyes around and within. They have no rest day and night, saying, "Holy, holy, holy is the Lord God, the Almighty, who was and who is and who is to come!" 

###### v9 
When the living creatures give glory, honor, and thanks to him who sits on the throne, to him who lives forever and ever, 

###### v10 
the twenty-four elders fall down before him who sits on the throne, and worship him who lives forever and ever, and throw their crowns before the throne, saying, 

###### v11 
"Worthy are you, our Lord and God, the Holy One, to receive the glory, the honor, and the power, for you created all things, and because of your desire they existed, and were created!"

***
[[Rev-03|← Revelation 03]] | [[Revelation]] | [[Rev-05|Revelation 05 →]]
