# Revelation 1

[[Revelation]] | [[Rev-02|Revelation 02 →]]
***



###### v1 
This is the Revelation of Jesus Christ, which God gave him to show to his servants the things which must happen soon, which he sent and made known by his angel to his servant, John, 

###### v2 
who testified to God's word and of the testimony of Jesus Christ, about everything that he saw. 

###### v3 
Blessed is he who reads and those who hear the words of the prophecy, and keep the things that are written in it, for the time is at hand. 

###### v4 
John, to the seven assemblies that are in Asia: Grace to you and peace from God, who is and who was and who is to come; and from the seven Spirits who are before his throne; 

###### v5 
and from Jesus Christ, the faithful witness, the firstborn of the dead, and the ruler of the kings of the earth. To him who loves us, and washed us from our sins by his blood-- 

###### v6 
and he made us to be a Kingdom, priests to his God and Father--to him be the glory and the dominion forever and ever. Amen. 

###### v7 
Behold, he is coming with the clouds, and every eye will see him, including those who pierced him. All the tribes of the earth will mourn over him. Even so, Amen. 

###### v8 
"I am the Alpha and the Omega, " says the Lord God, "who is and who was and who is to come, the Almighty." 

###### v9 
I John, your brother and partner with you in the oppression, Kingdom, and perseverance in Christ Jesus, was on the isle that is called Patmos because of God's Word and the testimony of Jesus Christ. 

###### v10 
I was in the Spirit on the Lord's day, and I heard behind me a loud voice, like a trumpet 

###### v11 
saying,"What you see, write in a book and send to the seven assemblies: to Ephesus, Smyrna, Pergamum, Thyatira, Sardis, Philadelphia, and to Laodicea." 

###### v12 
I turned to see the voice that spoke with me. Having turned, I saw seven golden lamp stands. 

###### v13 
And among the lamp stands was one like a son of man, clothed with a robe reaching down to his feet, and with a golden sash around his chest. 

###### v14 
His head and his hair were white as white wool, like snow. His eyes were like a flame of fire. 

###### v15 
His feet were like burnished brass, as if it had been refined in a furnace. His voice was like the voice of many waters. 

###### v16 
He had seven stars in his right hand. Out of his mouth proceeded a sharp two-edged sword. His face was like the sun shining at its brightest. 

###### v17 
When I saw him, I fell at his feet like a dead man. He laid his right hand on me, saying, "Don't be afraid. I am the first and the last, 

###### v18 
and the Living one. I was dead, and behold, I am alive forever and ever. Amen. I have the keys of Death and of Hades. 

###### v19 
Write therefore the things which you have seen, and the things which are, and the things which will happen hereafter. 

###### v20 
The mystery of the seven stars which you saw in my right hand, and the seven golden lamp stands is this: The seven stars are the angels of the seven assemblies. The seven lamp stands are seven assemblies.

***
[[Revelation]] | [[Rev-02|Revelation 02 →]]
