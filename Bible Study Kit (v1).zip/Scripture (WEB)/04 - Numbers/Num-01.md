# Numbers 1

[[Numbers]] | [[Num-02|Numbers 02 →]]
***



###### v1 
Yahweh spoke to Moses in the wilderness of Sinai, in the Tent of Meeting, on the first day of the second month, in the second year after they had come out of the land of Egypt, saying, 

###### v2 
"Take a census of all the congregation of the children of Israel, by their families, by their fathers' houses, according to the number of the names, every male, one by one, 

###### v3 
from twenty years old and upward, all who are able to go out to war in Israel. You and Aaron shall count them by their divisions. 

###### v4 
With you there shall be a man of every tribe, each one head of his fathers' house. 

###### v5 
These are the names of the men who shall stand with you: Of Reuben: Elizur the son of Shedeur. 

###### v6 
Of Simeon: Shelumiel the son of Zurishaddai. 

###### v7 
Of Judah: Nahshon the son of Amminadab. 

###### v8 
Of Issachar: Nethanel the son of Zuar. 

###### v9 
Of Zebulun: Eliab the son of Helon. 

###### v10 
Of the children of Joseph: of Ephraim: Elishama the son of Ammihud; of Manasseh: Gamaliel the son of Pedahzur. 

###### v11 
Of Benjamin: Abidan the son of Gideoni. 

###### v12 
Of Dan: Ahiezer the son of Ammishaddai. 

###### v13 
Of Asher: Pagiel the son of Ochran. 

###### v14 
Of Gad: Eliasaph the son of Deuel. 

###### v15 
Of Naphtali: Ahira the son of Enan." 

###### v16 
These are those who were called of the congregation, the princes of the tribes of their fathers; they were the heads of the thousands of Israel. 

###### v17 
Moses and Aaron took these men who are mentioned by name. 

###### v18 
They assembled all the congregation together on the first day of the second month; and they declared their ancestry by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, one by one. 

###### v19 
As Yahweh commanded Moses, so he counted them in the wilderness of Sinai. 

###### v20 
The children of Reuben, Israel's firstborn, their generations, by their families, by their fathers' houses, according to the number of the names, one by one, every male from twenty years old and upward, all who were able to go out to war: 

###### v21 
those who were counted of them, of the tribe of Reuben, were forty-six thousand five hundred. 

###### v22 
Of the children of Simeon, their generations, by their families, by their fathers' houses, those who were counted of it, according to the number of the names, one by one, every male from twenty years old and upward, all who were able to go out to war: 

###### v23 
those who were counted of them, of the tribe of Simeon, were fifty-nine thousand three hundred. 

###### v24 
Of the children of Gad, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v25 
those who were counted of them, of the tribe of Gad, were forty-five thousand six hundred fifty. 

###### v26 
Of the children of Judah, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v27 
those who were counted of them, of the tribe of Judah, were seventy-four thousand six hundred. 

###### v28 
Of the children of Issachar, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v29 
those who were counted of them, of the tribe of Issachar, were fifty-four thousand four hundred. 

###### v30 
Of the children of Zebulun, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v31 
those who were counted of them, of the tribe of Zebulun, were fifty-seven thousand four hundred. 

###### v32 
Of the children of Joseph: of the children of Ephraim, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v33 
those who were counted of them, of the tribe of Ephraim, were forty thousand five hundred. 

###### v34 
Of the children of Manasseh, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v35 
those who were counted of them, of the tribe of Manasseh, were thirty-two thousand two hundred. 

###### v36 
Of the children of Benjamin, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v37 
those who were counted of them, of the tribe of Benjamin, were thirty-five thousand four hundred. 

###### v38 
Of the children of Dan, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v39 
those who were counted of them, of the tribe of Dan, were sixty-two thousand seven hundred. 

###### v40 
Of the children of Asher, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v41 
those who were counted of them, of the tribe of Asher, were forty-one thousand five hundred. 

###### v42 
Of the children of Naphtali, their generations, by their families, by their fathers' houses, according to the number of the names, from twenty years old and upward, all who were able to go out to war: 

###### v43 
those who were counted of them, of the tribe of Naphtali, were fifty-three thousand four hundred. 

###### v44 
These are those who were counted, whom Moses and Aaron counted, and the twelve men who were princes of Israel, each one for his fathers' house. 

###### v45 
So all those who were counted of the children of Israel by their fathers' houses, from twenty years old and upward, all who were able to go out to war in Israel-- 

###### v46 
all those who were counted were six hundred three thousand five hundred fifty. 

###### v47 
But the Levites after the tribe of their fathers were not counted among them. 

###### v48 
For Yahweh spoke to Moses, saying, 

###### v49 
"Only the tribe of Levi you shall not count, neither shall you take a census of them among the children of Israel; 

###### v50 
but appoint the Levites over the Tabernacle of the Testimony, and over all its furnishings, and over all that belongs to it. They shall carry the tabernacle and all its furnishings; and they shall take care of it, and shall encamp around it. 

###### v51 
When the tabernacle is to move, the Levites shall take it down; and when the tabernacle is to be set up, the Levites shall set it up. The stranger who comes near shall be put to death. 

###### v52 
The children of Israel shall pitch their tents, every man by his own camp, and every man by his own standard, according to their divisions. 

###### v53 
But the Levites shall encamp around the Tabernacle of the Testimony, that there may be no wrath on the congregation of the children of Israel. The Levites shall be responsible for the Tabernacle of the Testimony." 

###### v54 
Thus the children of Israel did. According to all that Yahweh commanded Moses, so they did.

***
[[Numbers]] | [[Num-02|Numbers 02 →]]
