# Numbers 20

[[Num-19|← Numbers 19]] | [[Numbers]] | [[Num-21|Numbers 21 →]]
***



###### v1 
The children of Israel, even the whole congregation, came into the wilderness of Zin in the first month. The people stayed in Kadesh. Miriam died there, and was buried there. 

###### v2 
There was no water for the congregation; and they assembled themselves together against Moses and against Aaron. 

###### v3 
The people quarreled with Moses, and spoke, saying, "We wish that we had died when our brothers died before Yahweh! 

###### v4 
Why have you brought Yahweh's assembly into this wilderness, that we should die there, we and our animals? 

###### v5 
Why have you made us to come up out of Egypt, to bring us in to this evil place? It is no place of seed, or of figs, or of vines, or of pomegranates; neither is there any water to drink." 

###### v6 
Moses and Aaron went from the presence of the assembly to the door of the Tent of Meeting, and fell on their faces. Yahweh's glory appeared to them. 

###### v7 
Yahweh spoke to Moses, saying, 

###### v8 
"Take the rod, and assemble the congregation, you, and Aaron your brother, and speak to the rock before their eyes, that it pour out its water. You shall bring water to them out of the rock; so you shall give the congregation and their livestock drink." 

###### v9 
Moses took the rod from before Yahweh, as he commanded him. 

###### v10 
Moses and Aaron gathered the assembly together before the rock, and he said to them, "Hear now, you rebels! Shall we bring water out of this rock for you?" 

###### v11 
Moses lifted up his hand, and struck the rock with his rod twice, and water came out abundantly. The congregation and their livestock drank. 

###### v12 
Yahweh said to Moses and Aaron, "Because you didn't believe in me, to sanctify me in the eyes of the children of Israel, therefore you shall not bring this assembly into the land which I have given them." 

###### v13 
These are the waters of Meribah; because the children of Israel strove with Yahweh, and he was sanctified in them. 

###### v14 
Moses sent messengers from Kadesh to the king of Edom, saying: "Your brother Israel says: You know all the travail that has happened to us; 

###### v15 
how our fathers went down into Egypt, and we lived in Egypt a long time. The Egyptians mistreated us and our fathers. 

###### v16 
When we cried to Yahweh, he heard our voice, sent an angel, and brought us out of Egypt. Behold, we are in Kadesh, a city in the edge of your border. 

###### v17 
"Please let us pass through your land. We will not pass through field or through vineyard, neither will we drink from the water of the wells. We will go along the king's highway. We will not turn away to the right hand nor to the left, until we have passed your border." 

###### v18 
Edom said to him, "You shall not pass through me, lest I come out with the sword against you." 

###### v19 
The children of Israel said to him, "We will go up by the highway; and if we drink your water, I and my livestock, then I will give its price. Only let me, without doing anything else, pass through on my feet." 

###### v20 
He said, "You shall not pass through." Edom came out against him with many people, and with a strong hand. 

###### v21 
Thus Edom refused to give Israel passage through his border, so Israel turned away from him. 

###### v22 
They traveled from Kadesh, and the children of Israel, even the whole congregation, came to Mount Hor. 

###### v23 
Yahweh spoke to Moses and Aaron in Mount Hor, by the border of the land of Edom, saying, 

###### v24 
"Aaron shall be gathered to his people; for he shall not enter into the land which I have given to the children of Israel, because you rebelled against my word at the waters of Meribah. 

###### v25 
Take Aaron and Eleazar his son, and bring them up to Mount Hor; 

###### v26 
and strip Aaron of his garments, and put them on Eleazar his son. Aaron shall be gathered, and shall die there." 

###### v27 
Moses did as Yahweh commanded. They went up onto Mount Hor in the sight of all the congregation. 

###### v28 
Moses stripped Aaron of his garments, and put them on Eleazar his son. Aaron died there on the top of the mountain, and Moses and Eleazar came down from the mountain. 

###### v29 
When all the congregation saw that Aaron was dead, they wept for Aaron thirty days, even all the house of Israel.

***
[[Num-19|← Numbers 19]] | [[Numbers]] | [[Num-21|Numbers 21 →]]
