# Numbers 26

[[Num-25|← Numbers 25]] | [[Numbers]] | [[Num-27|Numbers 27 →]]
***



###### v1 
After the plague, Yahweh spoke to Moses and to Eleazar the son of Aaron the priest, saying, 

###### v2 
"Take a census of all the congregation of the children of Israel, from twenty years old and upward, by their fathers' houses, all who are able to go out to war in Israel." 

###### v3 
Moses and Eleazar the priest spoke with them in the plains of Moab by the Jordan at Jericho, saying, 

###### v4 
"Take a census, from twenty years old and upward, as Yahweh commanded Moses and the children of Israel." These are those who came out of the land of Egypt. 

###### v5 
Reuben, the firstborn of Israel; the sons of Reuben: of Hanoch, the family of the Hanochites; of Pallu, the family of the Palluites; 

###### v6 
of Hezron, the family of the Hezronites; of Carmi, the family of the Carmites. 

###### v7 
These are the families of the Reubenites; and those who were counted of them were forty-three thousand seven hundred thirty. 

###### v8 
The son of Pallu: Eliab. 

###### v9 
The sons of Eliab: Nemuel, Dathan, and Abiram. These are that Dathan and Abiram who were called by the congregation, who rebelled against Moses and against Aaron in the company of Korah when they rebelled against Yahweh; 

###### v10 
and the earth opened its mouth, and swallowed them up together with Korah when that company died; at the time the fire devoured two hundred fifty men, and they became a sign. 

###### v11 
Notwithstanding, the sons of Korah didn't die. 

###### v12 
The sons of Simeon after their families: of Nemuel, the family of the Nemuelites; of Jamin, the family of the Jaminites; of Jachin, the family of the Jachinites; 

###### v13 
of Zerah, the family of the Zerahites; of Shaul, the family of the Shaulites. 

###### v14 
These are the families of the Simeonites, twenty-two thousand two hundred. 

###### v15 
The sons of Gad after their families: of Zephon, the family of the Zephonites; of Haggi, the family of the Haggites; of Shuni, the family of the Shunites; 

###### v16 
of Ozni, the family of the Oznites; of Eri, the family of the Erites; 

###### v17 
of Arod, the family of the Arodites; of Areli, the family of the Arelites. 

###### v18 
These are the families of the sons of Gad according to those who were counted of them, forty thousand and five hundred. 

###### v19 
The sons of Judah: Er and Onan. Er and Onan died in the land of Canaan. 

###### v20 
The sons of Judah after their families were: of Shelah, the family of the Shelanites; of Perez, the family of the Perezites; of Zerah, the family of the Zerahites. 

###### v21 
The sons of Perez were: of Hezron, the family of the Hezronites; of Hamul, the family of the Hamulites. 

###### v22 
These are the families of Judah according to those who were counted of them, seventy-six thousand five hundred. 

###### v23 
The sons of Issachar after their families: of Tola, the family of the Tolaites; of Puvah, the family of the Punites; 

###### v24 
of Jashub, the family of the Jashubites; of Shimron, the family of the Shimronites. 

###### v25 
These are the families of Issachar according to those who were counted of them, sixty-four thousand three hundred. 

###### v26 
The sons of Zebulun after their families: of Sered, the family of the Seredites; of Elon, the family of the Elonites; of Jahleel, the family of the Jahleelites. 

###### v27 
These are the families of the Zebulunites according to those who were counted of them, sixty thousand five hundred. 

###### v28 
The sons of Joseph after their families: Manasseh and Ephraim. 

###### v29 
The sons of Manasseh: of Machir, the family of the Machirites; and Machir became the father of Gilead; of Gilead, the family of the Gileadites. 

###### v30 
These are the sons of Gilead: of Iezer, the family of the Iezerites; of Helek, the family of the Helekites; 

###### v31 
and Asriel, the family of the Asrielites; and Shechem, the family of the Shechemites; 

###### v32 
and Shemida, the family of the Shemidaites; and Hepher, the family of the Hepherites. 

###### v33 
Zelophehad the son of Hepher had no sons, but daughters: and the names of the daughters of Zelophehad were Mahlah, Noah, Hoglah, Milcah, and Tirzah. 

###### v34 
These are the families of Manasseh. Those who were counted of them were fifty-two thousand seven hundred. 

###### v35 
These are the sons of Ephraim after their families: of Shuthelah, the family of the Shuthelahites; of Becher, the family of the Becherites; of Tahan, the family of the Tahanites. 

###### v36 
These are the sons of Shuthelah: of Eran, the family of the Eranites. 

###### v37 
These are the families of the sons of Ephraim according to those who were counted of them, thirty-two thousand five hundred. These are the sons of Joseph after their families. 

###### v38 
The sons of Benjamin after their families: of Bela, the family of the Belaites; of Ashbel, the family of the Ashbelites; of Ahiram, the family of the Ahiramites; 

###### v39 
of Shephupham, the family of the Shuphamites; of Hupham, the family of the Huphamites. 

###### v40 
The sons of Bela were Ard and Naaman: the family of the Ardites; and of Naaman, the family of the Naamites. 

###### v41 
These are the sons of Benjamin after their families; and those who were counted of them were forty-five thousand six hundred. 

###### v42 
These are the sons of Dan after their families: of Shuham, the family of the Shuhamites. These are the families of Dan after their families. 

###### v43 
All the families of the Shuhamites, according to those who were counted of them, were sixty-four thousand four hundred. 

###### v44 
The sons of Asher after their families: of Imnah, the family of the Imnites; of Ishvi, the family of the Ishvites; of Beriah, the family of the Berites. 

###### v45 
Of the sons of Beriah: of Heber, the family of the Heberites; of Malchiel, the family of the Malchielites. 

###### v46 
The name of the daughter of Asher was Serah. 

###### v47 
These are the families of the sons of Asher according to those who were counted of them, fifty-three thousand four hundred. 

###### v48 
The sons of Naphtali after their families: of Jahzeel, the family of the Jahzeelites; of Guni, the family of the Gunites; 

###### v49 
of Jezer, the family of the Jezerites; of Shillem, the family of the Shillemites. 

###### v50 
These are the families of Naphtali according to their families; and those who were counted of them were forty-five thousand four hundred. 

###### v51 
These are those who were counted of the children of Israel, six hundred one thousand seven hundred thirty. 

###### v52 
Yahweh spoke to Moses, saying, 

###### v53 
"To these the land shall be divided for an inheritance according to the number of names. 

###### v54 
To the more you shall give the more inheritance, and to the fewer you shall give the less inheritance. To everyone according to those who were counted of him shall his inheritance be given. 

###### v55 
Notwithstanding, the land shall be divided by lot. According to the names of the tribes of their fathers they shall inherit. 

###### v56 
According to the lot shall their inheritance be divided between the more and the fewer." 

###### v57 
These are those who were counted of the Levites after their families: of Gershon, the family of the Gershonites; of Kohath, the family of the Kohathites; of Merari, the family of the Merarites. 

###### v58 
These are the families of Levi: the family of the Libnites, the family of the Hebronites, the family of the Mahlites, the family of the Mushites, and the family of the Korahites. Kohath became the father of Amram. 

###### v59 
The name of Amram's wife was Jochebed, the daughter of Levi, who was born to Levi in Egypt. She bore to Amram Aaron and Moses, and Miriam their sister. 

###### v60 
To Aaron were born Nadab and Abihu, Eleazar and Ithamar. 

###### v61 
Nadab and Abihu died when they offered strange fire before Yahweh. 

###### v62 
Those who were counted of them were twenty-three thousand, every male from a month old and upward; for they were not counted among the children of Israel, because there was no inheritance given them among the children of Israel. 

###### v63 
These are those who were counted by Moses and Eleazar the priest, who counted the children of Israel in the plains of Moab by the Jordan at Jericho. 

###### v64 
But among these there was not a man of them who were counted by Moses and Aaron the priest, who counted the children of Israel in the wilderness of Sinai. 

###### v65 
For Yahweh had said of them, "They shall surely die in the wilderness." There was not a man left of them, except Caleb the son of Jephunneh, and Joshua the son of Nun.

***
[[Num-25|← Numbers 25]] | [[Numbers]] | [[Num-27|Numbers 27 →]]
