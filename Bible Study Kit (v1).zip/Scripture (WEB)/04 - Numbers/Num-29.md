# Numbers 29

[[Num-28|← Numbers 28]] | [[Numbers]] | [[Num-30|Numbers 30 →]]
***



###### v1 
"'In the seventh month, on the first day of the month, you shall have a holy convocation; you shall do no regular work. It is a day of blowing of trumpets to you. 

###### v2 
You shall offer a burnt offering for a pleasant aroma to Yahweh: one young bull, one ram, seven male lambs a year old without defect; 

###### v3 
and their meal offering, fine flour mixed with oil: three tenths for the bull, two tenths for the ram, 

###### v4 
and one tenth for every lamb of the seven lambs; 

###### v5 
and one male goat for a sin offering, to make atonement for you; 

###### v6 
in addition to the burnt offering of the new moon with its meal offering, and the continual burnt offering with its meal offering, and their drink offerings, according to their ordinance, for a pleasant aroma, an offering made by fire to Yahweh. 

###### v7 
"'On the tenth day of this seventh month you shall have a holy convocation. You shall afflict your souls. You shall do no kind of work; 

###### v8 
but you shall offer a burnt offering to Yahweh for a pleasant aroma: one young bull, one ram, seven male lambs a year old, all without defect; 

###### v9 
and their meal offering, fine flour mixed with oil: three tenths for the bull, two tenths for the one ram, 

###### v10 
one tenth for every lamb of the seven lambs; 

###### v11 
one male goat for a sin offering, in addition to the sin offering of atonement, and the continual burnt offering, and its meal offering, and their drink offerings. 

###### v12 
"'On the fifteenth day of the seventh month you shall have a holy convocation. You shall do no regular work. You shall keep a feast to Yahweh seven days. 

###### v13 
You shall offer a burnt offering, an offering made by fire, of a pleasant aroma to Yahweh: thirteen young bulls, two rams, fourteen male lambs a year old, all without defect; 

###### v14 
and their meal offering, fine flour mixed with oil: three tenths for every bull of the thirteen bulls, two tenths for each ram of the two rams, 

###### v15 
and one tenth for every lamb of the fourteen lambs; 

###### v16 
and one male goat for a sin offering, in addition to the continual burnt offering, its meal offering, and its drink offering. 

###### v17 
"'On the second day you shall offer twelve young bulls, two rams, and fourteen male lambs a year old without defect; 

###### v18 
and their meal offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance; 

###### v19 
and one male goat for a sin offering, in addition to the continual burnt offering, with its meal offering and their drink offerings. 

###### v20 
"'On the third day: eleven bulls, two rams, fourteen male lambs a year old without defect; 

###### v21 
and their meal offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance; 

###### v22 
and one male goat for a sin offering, in addition to the continual burnt offering, and its meal offering, and its drink offering. 

###### v23 
"'On the fourth day ten bulls, two rams, fourteen male lambs a year old without defect; 

###### v24 
their meal offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance; 

###### v25 
and one male goat for a sin offering; in addition to the continual burnt offering, its meal offering, and its drink offering. 

###### v26 
"'On the fifth day: nine bulls, two rams, fourteen male lambs a year old without defect; 

###### v27 
and their meal offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance, 

###### v28 
and one male goat for a sin offering, in addition to the continual burnt offering, and its meal offering, and its drink offering. 

###### v29 
"'On the sixth day: eight bulls, two rams, fourteen male lambs a year old without defect; 

###### v30 
and their meal offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance, 

###### v31 
and one male goat for a sin offering; in addition to the continual burnt offering, its meal offering, and the drink offerings of it. 

###### v32 
"'On the seventh day: seven bulls, two rams, fourteen male lambs a year old without defect; 

###### v33 
and their meal offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance, 

###### v34 
and one male goat for a sin offering; in addition to the continual burnt offering, its meal offering, and its drink offering. 

###### v35 
"'On the eighth day you shall have a solemn assembly. You shall do no regular work; 

###### v36 
but you shall offer a burnt offering, an offering made by fire, a pleasant aroma to Yahweh: one bull, one ram, seven male lambs a year old without defect; 

###### v37 
their meal offering and their drink offerings for the bull, for the ram, and for the lambs, shall be according to their number, after the ordinance, 

###### v38 
and one male goat for a sin offering, in addition to the continual burnt offering, with its meal offering, and its drink offering. 

###### v39 
"'You shall offer these to Yahweh in your set feasts--in addition to your vows and your free will offerings--for your burnt offerings, your meal offerings, your drink offerings, and your peace offerings.'" 

###### v40 
Moses told the children of Israel according to all that Yahweh commanded Moses.

***
[[Num-28|← Numbers 28]] | [[Numbers]] | [[Num-30|Numbers 30 →]]
