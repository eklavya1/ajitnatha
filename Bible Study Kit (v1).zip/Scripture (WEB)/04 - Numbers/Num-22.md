# Numbers 22

[[Num-21|← Numbers 21]] | [[Numbers]] | [[Num-23|Numbers 23 →]]
***



###### v1 
The children of Israel traveled, and encamped in the plains of Moab beyond the Jordan at Jericho. 

###### v2 
Balak the son of Zippor saw all that Israel had done to the Amorites. 

###### v3 
Moab was very afraid of the people, because they were many. Moab was distressed because of the children of Israel. 

###### v4 
Moab said to the elders of Midian, "Now this multitude will lick up all that is around us, as the ox licks up the grass of the field." Balak the son of Zippor was king of Moab at that time. 

###### v5 
He sent messengers to Balaam the son of Beor, to Pethor, which is by the River, to the land of the children of his people, to call him, saying, "Behold, there is a people who came out of Egypt. Behold, they cover the surface of the earth, and they are staying opposite me. 

###### v6 
Please come now therefore, and curse this people for me; for they are too mighty for me. Perhaps I shall prevail, that we may strike them, and that I may drive them out of the land; for I know that he whom you bless is blessed, and he whom you curse is cursed." 

###### v7 
The elders of Moab and the elders of Midian departed with the rewards of divination in their hand. They came to Balaam, and spoke to him the words of Balak. 

###### v8 
He said to them, "Lodge here this night, and I will bring you word again, as Yahweh shall speak to me." The princes of Moab stayed with Balaam. 

###### v9 
God came to Balaam, and said, "Who are these men with you?" 

###### v10 
Balaam said to God, "Balak the son of Zippor, king of Moab, has said to me, 

###### v11 
'Behold, the people that has come out of Egypt covers the surface of the earth. Now, come curse them for me. Perhaps I shall be able to fight against them, and shall drive them out.'" 

###### v12 
God said to Balaam, "You shall not go with them. You shall not curse the people, for they are blessed." 

###### v13 
Balaam rose up in the morning, and said to the princes of Balak, "Go to your land; for Yahweh refuses to permit me to go with you." 

###### v14 
The princes of Moab rose up, and they went to Balak, and said, "Balaam refuses to come with us." 

###### v15 
Balak again sent princes, more, and more honorable than they. 

###### v16 
They came to Balaam, and said to him, "Balak the son of Zippor says, 'Please let nothing hinder you from coming to me, 

###### v17 
for I will promote you to very great honor, and whatever you say to me I will do. Please come therefore, and curse this people for me.'" 

###### v18 
Balaam answered the servants of Balak, "If Balak would give me his house full of silver and gold, I can't go beyond the word of Yahweh my God, to do less or more. 

###### v19 
Now therefore please stay here tonight as well, that I may know what else Yahweh will speak to me." 

###### v20 
God came to Balaam at night, and said to him, "If the men have come to call you, rise up, go with them; but only the word which I speak to you, that you shall do." 

###### v21 
Balaam rose up in the morning, and saddled his donkey, and went with the princes of Moab. 

###### v22 
God's anger burned because he went; and Yahweh's angel placed himself in the way as an adversary against him. Now he was riding on his donkey, and his two servants were with him. 

###### v23 
The donkey saw Yahweh's angel standing in the way, with his sword drawn in his hand; and the donkey turned out of the path, and went into the field. Balaam struck the donkey, to turn her into the path. 

###### v24 
Then Yahweh's angel stood in a narrow path between the vineyards, a wall being on this side, and a wall on that side. 

###### v25 
The donkey saw Yahweh's angel, and she thrust herself to the wall, and crushed Balaam's foot against the wall. He struck her again. 

###### v26 
Yahweh's angel went further, and stood in a narrow place, where there was no way to turn either to the right hand or to the left. 

###### v27 
The donkey saw Yahweh's angel, and she lay down under Balaam. Balaam's anger burned, and he struck the donkey with his staff. 

###### v28 
Yahweh opened the mouth of the donkey, and she said to Balaam, "What have I done to you, that you have struck me these three times?" 

###### v29 
Balaam said to the donkey, "Because you have mocked me, I wish there were a sword in my hand, for now I would have killed you." 

###### v30 
The donkey said to Balaam, "Am I not your donkey, on which you have ridden all your life long until today? Was I ever in the habit of doing so to you?" He said, "No." 

###### v31 
Then Yahweh opened the eyes of Balaam, and he saw Yahweh's angel standing in the way, with his sword drawn in his hand; and he bowed his head, and fell on his face. 

###### v32 
Yahweh's angel said to him, "Why have you struck your donkey these three times? Behold, I have come out as an adversary, because your way is perverse before me. 

###### v33 
The donkey saw me, and turned away before me these three times. Unless she had turned away from me, surely now I would have killed you, and saved her alive." 

###### v34 
Balaam said to Yahweh's angel, "I have sinned; for I didn't know that you stood in the way against me. Now therefore, if it displeases you, I will go back again." 

###### v35 
Yahweh's angel said to Balaam, "Go with the men; but you shall only speak the word that I shall speak to you." So Balaam went with the princes of Balak. 

###### v36 
When Balak heard that Balaam had come, he went out to meet him to the City of Moab, which is on the border of the Arnon, which is in the utmost part of the border. 

###### v37 
Balak said to Balaam, "Didn't I earnestly send for you to summon you? Why didn't you come to me? Am I not able indeed to promote you to honor?" 

###### v38 
Balaam said to Balak, "Behold, I have come to you. Have I now any power at all to speak anything? I will speak the word that God puts in my mouth." 

###### v39 
Balaam went with Balak, and they came to Kiriath Huzoth. 

###### v40 
Balak sacrificed cattle and sheep, and sent to Balaam, and to the princes who were with him. 

###### v41 
In the morning, Balak took Balaam, and brought him up into the high places of Baal; and he saw from there part of the people.

***
[[Num-21|← Numbers 21]] | [[Numbers]] | [[Num-23|Numbers 23 →]]
