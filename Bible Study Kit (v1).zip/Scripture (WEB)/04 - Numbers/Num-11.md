# Numbers 11

[[Num-10|← Numbers 10]] | [[Numbers]] | [[Num-12|Numbers 12 →]]
***



###### v1 
The people were complaining in the ears of Yahweh. When Yahweh heard it, his anger burned; and Yahweh's fire burned among them, and consumed some of the outskirts of the camp. 

###### v2 
The people cried to Moses; and Moses prayed to Yahweh, and the fire abated. 

###### v3 
The name of that place was called Taberah, because Yahweh's fire burned among them. 

###### v4 
The mixed multitude that was among them lusted exceedingly; and the children of Israel also wept again, and said, "Who will give us meat to eat? 

###### v5 
We remember the fish, which we ate in Egypt for nothing; the cucumbers, and the melons, and the leeks, and the onions, and the garlic; 

###### v6 
but now we have lost our appetite. There is nothing at all except this manna to look at." 

###### v7 
The manna was like coriander seed, and it looked like bdellium. 

###### v8 
The people went around, gathered it, and ground it in mills, or beat it in mortars, and boiled it in pots, and made cakes of it. Its taste was like the taste of fresh oil. 

###### v9 
When the dew fell on the camp in the night, the manna fell on it. 

###### v10 
Moses heard the people weeping throughout their families, every man at the door of his tent; and Yahweh's anger burned greatly; and Moses was displeased. 

###### v11 
Moses said to Yahweh, "Why have you treated your servant so badly? Why haven't I found favor in your sight, that you lay the burden of all this people on me? 

###### v12 
Have I conceived all this people? Have I brought them out, that you should tell me, 'Carry them in your bosom, as a nurse carries a nursing infant, to the land which you swore to their fathers?' 

###### v13 
Where could I get meat to give all these people? For they weep before me, saying, 'Give us meat, that we may eat.' 

###### v14 
I am not able to bear all this people alone, because it is too heavy for me. 

###### v15 
If you treat me this way, please kill me right now, if I have found favor in your sight; and don't let me see my wretchedness." 

###### v16 
Yahweh said to Moses, "Gather to me seventy men of the elders of Israel, whom you know to be the elders of the people and officers over them; and bring them to the Tent of Meeting, that they may stand there with you. 

###### v17 
I will come down and talk with you there. I will take of the Spirit which is on you, and will put it on them; and they shall bear the burden of the people with you, that you don't bear it yourself alone. 

###### v18 
"Say to the people, 'Sanctify yourselves in preparation for tomorrow, and you will eat meat; for you have wept in the ears of Yahweh, saying, "Who will give us meat to eat? For it was well with us in Egypt." Therefore Yahweh will give you meat, and you will eat. 

###### v19 
You will not eat just one day, or two days, or five days, or ten days, or twenty days, 

###### v20 
but a whole month, until it comes out at your nostrils, and it is loathsome to you; because you have rejected Yahweh who is among you, and have wept before him, saying, "Why did we come out of Egypt?"'" 

###### v21 
Moses said, "The people, among whom I am, are six hundred thousand men on foot; and you have said, 'I will give them meat, that they may eat a whole month.' 

###### v22 
Shall flocks and herds be slaughtered for them, to be sufficient for them? Shall all the fish of the sea be gathered together for them, to be sufficient for them?" 

###### v23 
Yahweh said to Moses, "Has Yahweh's hand grown short? Now you will see whether my word will happen to you or not." 

###### v24 
Moses went out, and told the people Yahweh's words; and he gathered seventy men of the elders of the people, and set them around the Tent. 

###### v25 
Yahweh came down in the cloud, and spoke to him, and took of the Spirit that was on him, and put it on the seventy elders. When the Spirit rested on them, they prophesied, but they did so no more. 

###### v26 
But two men remained in the camp. The name of one was Eldad, and the name of the other Medad; and the Spirit rested on them. They were of those who were written, but had not gone out to the Tent; and they prophesied in the camp. 

###### v27 
A young man ran, and told Moses, and said, "Eldad and Medad are prophesying in the camp!" 

###### v28 
Joshua the son of Nun, the servant of Moses, one of his chosen men, answered, "My lord Moses, forbid them!" 

###### v29 
Moses said to him, "Are you jealous for my sake? I wish that all Yahweh's people were prophets, that Yahweh would put his Spirit on them!" 

###### v30 
Moses went into the camp, he and the elders of Israel. 

###### v31 
A wind from Yahweh went out and brought quails from the sea, and let them fall by the camp, about a day's journey on this side, and a day's journey on the other side, around the camp, and about two cubits above the surface of the earth. 

###### v32 
The people rose up all that day, and all of that night, and all the next day, and gathered the quails. He who gathered least gathered ten homers; and they spread them all out for themselves around the camp. 

###### v33 
While the meat was still between their teeth, before it was chewed, Yahweh's anger burned against the people, and Yahweh struck the people with a very great plague. 

###### v34 
The name of that place was called Kibroth Hattaavah, because there they buried the people who lusted. 

###### v35 
From Kibroth Hattaavah the people traveled to Hazeroth; and they stayed at Hazeroth.

***
[[Num-10|← Numbers 10]] | [[Numbers]] | [[Num-12|Numbers 12 →]]
