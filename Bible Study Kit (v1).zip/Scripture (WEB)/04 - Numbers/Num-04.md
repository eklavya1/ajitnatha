# Numbers 4

[[Num-03|← Numbers 03]] | [[Numbers]] | [[Num-05|Numbers 05 →]]
***



###### v1 
Yahweh spoke to Moses and to Aaron, saying, 

###### v2 
"Take a census of the sons of Kohath from among the sons of Levi, by their families, by their fathers' houses, 

###### v3 
from thirty years old and upward even until fifty years old, all who enter into the service to do the work in the Tent of Meeting. 

###### v4 
"This is the service of the sons of Kohath in the Tent of Meeting, regarding the most holy things. 

###### v5 
When the camp moves forward, Aaron shall go in with his sons; and they shall take down the veil of the screen, cover the ark of the Testimony with it, 

###### v6 
put a covering of sealskin on it, spread a blue cloth over it, and put in its poles. 

###### v7 
"On the table of show bread they shall spread a blue cloth, and put on it the dishes, the spoons, the bowls, and the cups with which to pour out; and the continual bread shall be on it. 

###### v8 
They shall spread on them a scarlet cloth, and cover it with a covering of sealskin, and shall put in its poles. 

###### v9 
"They shall take a blue cloth and cover the lamp stand of the light, its lamps, its snuffers, its snuff dishes, and all its oil vessels, with which they minister to it. 

###### v10 
They shall put it and all its vessels within a covering of sealskin, and shall put it on the frame. 

###### v11 
"On the golden altar they shall spread a blue cloth, and cover it with a covering of sealskin, and shall put in its poles. 

###### v12 
"They shall take all the vessels of ministry with which they minister in the sanctuary, and put them in a blue cloth, cover them with a covering of sealskin, and shall put them on the frame. 

###### v13 
"They shall take away the ashes from the altar, and spread a purple cloth on it. 

###### v14 
They shall put on it all its vessels with which they minister about it, the fire pans, the meat hooks, the shovels, and the basins--all the vessels of the altar; and they shall spread on it a covering of sealskin, and put in its poles. 

###### v15 
"When Aaron and his sons have finished covering the sanctuary and all the furniture of the sanctuary, as the camp moves forward; after that, the sons of Kohath shall come to carry it; but they shall not touch the sanctuary, lest they die. The sons of Kohath shall carry these things belonging to the Tent of Meeting. 

###### v16 
"The duty of Eleazar the son of Aaron the priest shall be the oil for the light, the sweet incense, the continual meal offering, and the anointing oil, the requirements of all the tabernacle, and of all that is in it, the sanctuary, and its furnishings." 

###### v17 
Yahweh spoke to Moses and to Aaron, saying, 

###### v18 
"Don't cut off the tribe of the families of the Kohathites from among the Levites; 

###### v19 
but do this to them, that they may live, and not die, when they approach the most holy things: Aaron and his sons shall go in and appoint everyone to his service and to his burden; 

###### v20 
but they shall not go in to see the sanctuary even for a moment, lest they die." 

###### v21 
Yahweh spoke to Moses, saying, 

###### v22 
"Take a census of the sons of Gershon also, by their fathers' houses, by their families; 

###### v23 
you shall count them from thirty years old and upward until fifty years old: all who enter in to wait on the service, to do the work in the Tent of Meeting. 

###### v24 
"This is the service of the families of the Gershonites, in serving and in bearing burdens: 

###### v25 
they shall carry the curtains of the tabernacle and the Tent of Meeting, its covering, the covering of sealskin that is on it, the screen for the door of the Tent of Meeting, 

###### v26 
the hangings of the court, the screen for the door of the gate of the court which is by the tabernacle and around the altar, their cords, and all the instruments of their service, and whatever shall be done with them. They shall serve in there. 

###### v27 
At the commandment of Aaron and his sons shall be all the service of the sons of the Gershonites, in all their burden and in all their service; and you shall appoint their duty to them in all their responsibilities. 

###### v28 
This is the service of the families of the sons of the Gershonites in the Tent of Meeting. Their duty shall be under the hand of Ithamar the son of Aaron the priest. 

###### v29 
"As for the sons of Merari, you shall count them by their families, by their fathers' houses; 

###### v30 
you shall count them from thirty years old and upward even to fifty years old--everyone who enters on the service, to do the work of the Tent of Meeting. 

###### v31 
This is the duty of their burden, according to all their service in the Tent of Meeting: the tabernacle's boards, its bars, its pillars, its sockets, 

###### v32 
the pillars of the court around it, their sockets, their pins, their cords, with all their instruments, and with all their service. You shall appoint the instruments of the duty of their burden to them by name. 

###### v33 
This is the service of the families of the sons of Merari, according to all their service in the Tent of Meeting, under the hand of Ithamar the son of Aaron the priest." 

###### v34 
Moses and Aaron and the princes of the congregation counted the sons of the Kohathites by their families, and by their fathers' houses, 

###### v35 
from thirty years old and upward even to fifty years old, everyone who entered into the service for work in the Tent of Meeting. 

###### v36 
Those who were counted of them by their families were two thousand seven hundred fifty. 

###### v37 
These are those who were counted of the families of the Kohathites, all who served in the Tent of Meeting, whom Moses and Aaron counted according to the commandment of Yahweh by Moses. 

###### v38 
Those who were counted of the sons of Gershon, by their families, and by their fathers' houses, 

###### v39 
from thirty years old and upward even to fifty years old--everyone who entered into the service for work in the Tent of Meeting, 

###### v40 
even those who were counted of them, by their families, by their fathers' houses, were two thousand six hundred thirty. 

###### v41 
These are those who were counted of the families of the sons of Gershon, all who served in the Tent of Meeting, whom Moses and Aaron counted according to the commandment of Yahweh. 

###### v42 
Those who were counted of the families of the sons of Merari, by their families, by their fathers' houses, 

###### v43 
from thirty years old and upward even to fifty years old--everyone who entered into the service for work in the Tent of Meeting, 

###### v44 
even those who were counted of them by their families, were three thousand two hundred. 

###### v45 
These are those who were counted of the families of the sons of Merari, whom Moses and Aaron counted according to the commandment of Yahweh by Moses. 

###### v46 
All those who were counted of the Levites whom Moses and Aaron and the princes of Israel counted, by their families and by their fathers' houses, 

###### v47 
from thirty years old and upward even to fifty years old, everyone who entered in to do the work of service and the work of bearing burdens in the Tent of Meeting, 

###### v48 
even those who were counted of them, were eight thousand five hundred eighty. 

###### v49 
According to the commandment of Yahweh they were counted by Moses, everyone according to his service and according to his burden. Thus they were counted by him, as Yahweh commanded Moses.

***
[[Num-03|← Numbers 03]] | [[Numbers]] | [[Num-05|Numbers 05 →]]
