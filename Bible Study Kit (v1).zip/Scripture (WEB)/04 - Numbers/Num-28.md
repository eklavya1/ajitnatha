# Numbers 28

[[Num-27|← Numbers 27]] | [[Numbers]] | [[Num-29|Numbers 29 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Command the children of Israel, and tell them, 'See that you present my offering, my food for my offerings made by fire, as a pleasant aroma to me, in their due season.' 

###### v3 
You shall tell them, 'This is the offering made by fire which you shall offer to Yahweh: male lambs a year old without defect, two day by day, for a continual burnt offering. 

###### v4 
You shall offer the one lamb in the morning, and you shall offer the other lamb at evening, 

###### v5 
with one tenth of an ephah of fine flour for a meal offering, mixed with the fourth part of a hin of beaten oil. 

###### v6 
It is a continual burnt offering which was ordained in Mount Sinai for a pleasant aroma, an offering made by fire to Yahweh. 

###### v7 
Its drink offering shall be the fourth part of a hin for each lamb. You shall pour out a drink offering of strong drink to Yahweh in the holy place. 

###### v8 
The other lamb you shall offer at evening. As the meal offering of the morning, and as its drink offering, you shall offer it, an offering made by fire, for a pleasant aroma to Yahweh. 

###### v9 
"'On the Sabbath day, you shall offer two male lambs a year old without defect, and two tenths of an ephah of fine flour for a meal offering mixed with oil, and its drink offering: 

###### v10 
this is the burnt offering of every Sabbath, in addition to the continual burnt offering and its drink offering. 

###### v11 
"'In the beginnings of your months, you shall offer a burnt offering to Yahweh: two young bulls, one ram, seven male lambs a year old without defect, 

###### v12 
and three tenths of an ephah of fine flour for a meal offering mixed with oil, for each bull; and two tenth parts of fine flour for a meal offering mixed with oil, for the one ram; 

###### v13 
and one tenth part of fine flour mixed with oil for a meal offering to every lamb, as a burnt offering of a pleasant aroma, an offering made by fire to Yahweh. 

###### v14 
Their drink offerings shall be half a hin of wine for a bull, the third part of a hin for the ram, and the fourth part of a hin for a lamb. This is the burnt offering of every month throughout the months of the year. 

###### v15 
Also, one male goat for a sin offering to Yahweh shall be offered in addition to the continual burnt offering and its drink offering. 

###### v16 
"'In the first month, on the fourteenth day of the month, is Yahweh's Passover. 

###### v17 
On the fifteenth day of this month shall be a feast. Unleavened bread shall be eaten for seven days. 

###### v18 
In the first day shall be a holy convocation. You shall do no regular work, 

###### v19 
but you shall offer an offering made by fire, a burnt offering to Yahweh: two young bulls, one ram, and seven male lambs a year old. They shall be without defect, 

###### v20 
with their meal offering, fine flour mixed with oil. You shall offer three tenths for a bull, and two tenths for the ram. 

###### v21 
You shall offer one tenth for every lamb of the seven lambs; 

###### v22 
and one male goat for a sin offering, to make atonement for you. 

###### v23 
You shall offer these in addition to the burnt offering of the morning, which is for a continual burnt offering. 

###### v24 
In this way you shall offer daily, for seven days, the food of the offering made by fire, of a pleasant aroma to Yahweh. It shall be offered in addition to the continual burnt offering and its drink offering. 

###### v25 
On the seventh day you shall have a holy convocation. You shall do no regular work. 

###### v26 
"'Also in the day of the first fruits, when you offer a new meal offering to Yahweh in your feast of weeks, you shall have a holy convocation. You shall do no regular work; 

###### v27 
but you shall offer a burnt offering for a pleasant aroma to Yahweh: two young bulls, one ram, seven male lambs a year old; 

###### v28 
and their meal offering, fine flour mixed with oil, three tenths for each bull, two tenths for the one ram, 

###### v29 
one tenth for every lamb of the seven lambs; 

###### v30 
and one male goat, to make atonement for you. 

###### v31 
Besides the continual burnt offering and its meal offering, you shall offer them and their drink offerings. See that they are without defect.

***
[[Num-27|← Numbers 27]] | [[Numbers]] | [[Num-29|Numbers 29 →]]
