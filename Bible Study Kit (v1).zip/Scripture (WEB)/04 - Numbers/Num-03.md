# Numbers 3

[[Num-02|← Numbers 02]] | [[Numbers]] | [[Num-04|Numbers 04 →]]
***



###### v1 
Now this is the history of the generations of Aaron and Moses in the day that Yahweh spoke with Moses in Mount Sinai. 

###### v2 
These are the names of the sons of Aaron: Nadab the firstborn, and Abihu, Eleazar, and Ithamar. 

###### v3 
These are the names of the sons of Aaron, the priests who were anointed, whom he consecrated to minister in the priest's office. 

###### v4 
Nadab and Abihu died before Yahweh when they offered strange fire before Yahweh in the wilderness of Sinai, and they had no children. Eleazar and Ithamar ministered in the priest's office in the presence of Aaron their father. 

###### v5 
Yahweh spoke to Moses, saying, 

###### v6 
"Bring the tribe of Levi near, and set them before Aaron the priest, that they may minister to him. 

###### v7 
They shall keep his requirements, and the requirements of the whole congregation before the Tent of Meeting, to do the service of the tabernacle. 

###### v8 
They shall keep all the furnishings of the Tent of Meeting, and the obligations of the children of Israel, to do the service of the tabernacle. 

###### v9 
You shall give the Levites to Aaron and to his sons. They are wholly given to him on the behalf of the children of Israel. 

###### v10 
You shall appoint Aaron and his sons, and they shall keep their priesthood, but the stranger who comes near shall be put to death." 

###### v11 
Yahweh spoke to Moses, saying, 

###### v12 
"Behold, I have taken the Levites from among the children of Israel instead of all the firstborn who open the womb among the children of Israel; and the Levites shall be mine, 

###### v13 
for all the firstborn are mine. On the day that I struck down all the firstborn in the land of Egypt I made holy to me all the firstborn in Israel, both man and animal. They shall be mine. I am Yahweh." 

###### v14 
Yahweh spoke to Moses in the wilderness of Sinai, saying, 

###### v15 
"Count the children of Levi by their fathers' houses, by their families. You shall count every male from a month old and upward." 

###### v16 
Moses counted them according to Yahweh's word, as he was commanded. 

###### v17 
These were the sons of Levi by their names: Gershon, Kohath, and Merari. 

###### v18 
These are the names of the sons of Gershon by their families: Libni and Shimei. 

###### v19 
The sons of Kohath by their families: Amram, Izhar, Hebron, and Uzziel. 

###### v20 
The sons of Merari by their families: Mahli and Mushi. These are the families of the Levites according to their fathers' houses. 

###### v21 
Of Gershon was the family of the Libnites, and the family of the Shimeites. These are the families of the Gershonites. 

###### v22 
Those who were counted of them, according to the number of all the males from a month old and upward, even those who were counted of them were seven thousand five hundred. 

###### v23 
The families of the Gershonites shall encamp behind the tabernacle westward. 

###### v24 
Eliasaph the son of Lael shall be the prince of the fathers' house of the Gershonites. 

###### v25 
The duty of the sons of Gershon in the Tent of Meeting shall be the tabernacle, the tent, its covering, the screen for the door of the Tent of Meeting, 

###### v26 
the hangings of the court, the screen for the door of the court which is by the tabernacle and around the altar, and its cords for all of its service. 

###### v27 
Of Kohath was the family of the Amramites, the family of the Izharites, the family of the Hebronites, and the family of the Uzzielites. These are the families of the Kohathites. 

###### v28 
According to the number of all the males from a month old and upward, there were eight thousand six hundred keeping the requirements of the sanctuary. 

###### v29 
The families of the sons of Kohath shall encamp on the south side of the tabernacle. 

###### v30 
The prince of the fathers' house of the families of the Kohathites shall be Elizaphan the son of Uzziel. 

###### v31 
Their duty shall be the ark, the table, the lamp stand, the altars, the vessels of the sanctuary with which they minister, the screen, and all its service. 

###### v32 
Eleazar the son of Aaron the priest shall be prince of the princes of the Levites, with the oversight of those who keep the requirements of the sanctuary. 

###### v33 
Of Merari was the family of the Mahlites and the family of the Mushites. These are the families of Merari. 

###### v34 
Those who were counted of them, according to the number of all the males from a month old and upward, were six thousand two hundred. 

###### v35 
The prince of the fathers' house of the families of Merari was Zuriel the son of Abihail. They shall encamp on the north side of the tabernacle. 

###### v36 
The appointed duty of the sons of Merari shall be the tabernacle's boards, its bars, its pillars, its sockets, all its instruments, all its service, 

###### v37 
the pillars of the court around it, their sockets, their pins, and their cords. 

###### v38 
Those who encamp before the tabernacle eastward, in front of the Tent of Meeting toward the sunrise, shall be Moses, with Aaron and his sons, keeping the requirements of the sanctuary for the duty of the children of Israel. The outsider who comes near shall be put to death. 

###### v39 
All who were counted of the Levites, whom Moses and Aaron counted at the commandment of Yahweh, by their families, all the males from a month old and upward, were twenty-two thousand. 

###### v40 
Yahweh said to Moses, "Count all the firstborn males of the children of Israel from a month old and upward, and take the number of their names. 

###### v41 
You shall take the Levites for me--I am Yahweh--instead of all the firstborn among the children of Israel; and the livestock of the Levites instead of all the firstborn among the livestock of the children of Israel." 

###### v42 
Moses counted, as Yahweh commanded him, all the firstborn among the children of Israel. 

###### v43 
All the firstborn males according to the number of names from a month old and upward, of those who were counted of them, were twenty-two thousand two hundred seventy-three. 

###### v44 
Yahweh spoke to Moses, saying, 

###### v45 
"Take the Levites instead of all the firstborn among the children of Israel, and the livestock of the Levites instead of their livestock; and the Levites shall be mine. I am Yahweh. 

###### v46 
For the redemption of the two hundred seventy-three of the firstborn of the children of Israel who exceed the number of the Levites, 

###### v47 
you shall take five shekels apiece for each one; according to the shekel of the sanctuary you shall take them (the shekel is twenty gerahs); 

###### v48 
and you shall give the money, with which their remainder is redeemed, to Aaron and to his sons." 

###### v49 
Moses took the redemption money from those who exceeded the number of those who were redeemed by the Levites; 

###### v50 
from the firstborn of the children of Israel he took the money, one thousand three hundred sixty-five shekels, according to the shekel of the sanctuary; 

###### v51 
and Moses gave the redemption money to Aaron and to his sons, according to Yahweh's word, as Yahweh commanded Moses.

***
[[Num-02|← Numbers 02]] | [[Numbers]] | [[Num-04|Numbers 04 →]]
