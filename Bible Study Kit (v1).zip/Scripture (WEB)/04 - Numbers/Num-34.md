# Numbers 34

[[Num-33|← Numbers 33]] | [[Numbers]] | [[Num-35|Numbers 35 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Command the children of Israel, and tell them, 'When you come into the land of Canaan (this is the land that shall fall to you for an inheritance, even the land of Canaan according to its borders), 

###### v3 
then your south quarter shall be from the wilderness of Zin along by the side of Edom, and your south border shall be from the end of the Salt Sea eastward. 

###### v4 
Your border shall turn about southward of the ascent of Akrabbim, and pass along to Zin; and it shall pass southward of Kadesh Barnea; and it shall go from there to Hazar Addar, and pass along to Azmon. 

###### v5 
The border shall turn about from Azmon to the brook of Egypt, and it shall end at the sea. 

###### v6 
"'For the western border, you shall have the great sea and its border. This shall be your west border. 

###### v7 
"'This shall be your north border: from the great sea you shall mark out for yourselves Mount Hor. 

###### v8 
From Mount Hor you shall mark out to the entrance of Hamath; and the border shall pass by Zedad. 

###### v9 
Then the border shall go to Ziphron, and it shall end at Hazar Enan. This shall be your north border. 

###### v10 
"'You shall mark out your east border from Hazar Enan to Shepham. 

###### v11 
The border shall go down from Shepham to Riblah, on the east side of Ain. The border shall go down, and shall reach to the side of the sea of Chinnereth eastward. 

###### v12 
The border shall go down to the Jordan, and end at the Salt Sea. This shall be your land according to its borders around it.'" 

###### v13 
Moses commanded the children of Israel, saying, "This is the land which you shall inherit by lot, which Yahweh has commanded to give to the nine tribes, and to the half-tribe; 

###### v14 
for the tribe of the children of Reuben according to their fathers' houses, the tribe of the children of Gad according to their fathers' houses, and the half-tribe of Manasseh have received their inheritance. 

###### v15 
The two tribes and the half-tribe have received their inheritance beyond the Jordan at Jericho eastward, toward the sunrise." 

###### v16 
Yahweh spoke to Moses, saying, 

###### v17 
"These are the names of the men who shall divide the land to you for inheritance: Eleazar the priest, and Joshua the son of Nun. 

###### v18 
You shall take one prince of every tribe, to divide the land for inheritance. 

###### v19 
These are the names of the men: Of the tribe of Judah, Caleb the son of Jephunneh. 

###### v20 
Of the tribe of the children of Simeon, Shemuel the son of Ammihud. 

###### v21 
Of the tribe of Benjamin, Elidad the son of Chislon. 

###### v22 
Of the tribe of the children of Dan a prince, Bukki the son of Jogli. 

###### v23 
Of the children of Joseph: of the tribe of the children of Manasseh a prince, Hanniel the son of Ephod. 

###### v24 
Of the tribe of the children of Ephraim a prince, Kemuel the son of Shiphtan. 

###### v25 
Of the tribe of the children of Zebulun a prince, Elizaphan the son of Parnach. 

###### v26 
Of the tribe of the children of Issachar a prince, Paltiel the son of Azzan. 

###### v27 
Of the tribe of the children of Asher a prince, Ahihud the son of Shelomi. 

###### v28 
Of the tribe of the children of Naphtali a prince, Pedahel the son of Ammihud." 

###### v29 
These are they whom Yahweh commanded to divide the inheritance to the children of Israel in the land of Canaan.

***
[[Num-33|← Numbers 33]] | [[Numbers]] | [[Num-35|Numbers 35 →]]
