# Numbers 23

[[Num-22|← Numbers 22]] | [[Numbers]] | [[Num-24|Numbers 24 →]]
***



###### v1 
Balaam said to Balak, "Build here seven altars for me, and prepare here seven bulls and seven rams for me." 

###### v2 
Balak did as Balaam had spoken; and Balak and Balaam offered on every altar a bull and a ram. 

###### v3 
Balaam said to Balak, "Stand by your burnt offering, and I will go. Perhaps Yahweh will come to meet me. Whatever he shows me I will tell you." He went to a bare height. 

###### v4 
God met Balaam, and he said to him, "I have prepared the seven altars, and I have offered up a bull and a ram on every altar." 

###### v5 
Yahweh put a word in Balaam's mouth, and said, "Return to Balak, and thus you shall speak." 

###### v6 
He returned to him, and behold, he was standing by his burnt offering, he, and all the princes of Moab. 

###### v7 
He took up his parable, and said, "From Aram has Balak brought me, the king of Moab from the mountains of the East. Come, curse Jacob for me. Come, defy Israel. 

###### v8 
How shall I curse whom God has not cursed? How shall I defy whom Yahweh has not defied? 

###### v9 
For from the top of the rocks I see him. From the hills I see him. Behold, it is a people that dwells alone, and shall not be listed among the nations. 

###### v10 
Who can count the dust of Jacob, or count the fourth part of Israel? Let me die the death of the righteous! Let my last end be like his!" 

###### v11 
Balak said to Balaam, "What have you done to me? I took you to curse my enemies, and behold, you have blessed them altogether." 

###### v12 
He answered and said, "Must I not take heed to speak that which Yahweh puts in my mouth?" 

###### v13 
Balak said to him, "Please come with me to another place, where you may see them. You shall see just part of them, and shall not see them all. Curse them from there for me." 

###### v14 
He took him into the field of Zophim, to the top of Pisgah, and built seven altars, and offered up a bull and a ram on every altar. 

###### v15 
He said to Balak, "Stand here by your burnt offering, while I meet God over there." 

###### v16 
Yahweh met Balaam, and put a word in his mouth, and said, "Return to Balak, and say this." 

###### v17 
He came to him, and behold, he was standing by his burnt offering, and the princes of Moab with him. Balak said to him, "What has Yahweh spoken?" 

###### v18 
He took up his parable, and said, "Rise up, Balak, and hear! Listen to me, you son of Zippor. 

###### v19 
God is not a man, that he should lie, nor a son of man, that he should repent. Has he said, and he won't do it? Or has he spoken, and he won't make it good? 

###### v20 
Behold, I have received a command to bless. He has blessed, and I can't reverse it. 

###### v21 
He has not seen iniquity in Jacob. Neither has he seen perverseness in Israel. Yahweh his God is with him. The shout of a king is among them. 

###### v22 
God brings them out of Egypt. He has as it were the strength of the wild ox. 

###### v23 
Surely there is no enchantment with Jacob; Neither is there any divination with Israel. Now it shall be said of Jacob and of Israel, 'What has God done!' 

###### v24 
Behold, a people rises up as a lioness. As a lion he lifts himself up. He shall not lie down until he eats of the prey, and drinks the blood of the slain." 

###### v25 
Balak said to Balaam, "Neither curse them at all, nor bless them at all." 

###### v26 
But Balaam answered Balak, "Didn't I tell you, saying, 'All that Yahweh speaks, that I must do?'" 

###### v27 
Balak said to Balaam, "Come now, I will take you to another place; perhaps it will please God that you may curse them for me from there." 

###### v28 
Balak took Balaam to the top of Peor, that looks down on the desert. 

###### v29 
Balaam said to Balak, "Build seven altars for me here, and prepare seven bulls and seven rams for me here." 

###### v30 
Balak did as Balaam had said, and offered up a bull and a ram on every altar.

***
[[Num-22|← Numbers 22]] | [[Numbers]] | [[Num-24|Numbers 24 →]]
