# Numbers 15

[[Num-14|← Numbers 14]] | [[Numbers]] | [[Num-16|Numbers 16 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Speak to the children of Israel, and tell them, 'When you have come into the land of your habitations, which I give to you, 

###### v3 
and will make an offering by fire to Yahweh--a burnt offering, or a sacrifice, to accomplish a vow, or as a free will offering, or in your set feasts, to make a pleasant aroma to Yahweh, of the herd, or of the flock-- 

###### v4 
then he who offers his offering shall offer to Yahweh a meal offering of one tenth of an ephah of fine flour mixed with one fourth of a hin of oil. 

###### v5 
You shall prepare wine for the drink offering, one fourth of a hin, with the burnt offering or for the sacrifice, for each lamb. 

###### v6 
"'For a ram, you shall prepare for a meal offering two tenths of an ephah of fine flour mixed with the third part of a hin of oil; 

###### v7 
and for the drink offering you shall offer the third part of a hin of wine, of a pleasant aroma to Yahweh. 

###### v8 
When you prepare a bull for a burnt offering or for a sacrifice, to accomplish a vow, or for peace offerings to Yahweh, 

###### v9 
then he shall offer with the bull a meal offering of three tenths of an ephah of fine flour mixed with half a hin of oil; 

###### v10 
and you shall offer for the drink offering half a hin of wine, for an offering made by fire, of a pleasant aroma to Yahweh. 

###### v11 
Thus it shall be done for each bull, for each ram, for each of the male lambs, or of the young goats. 

###### v12 
According to the number that you shall prepare, so you shall do to everyone according to their number. 

###### v13 
"'All who are native-born shall do these things in this way, in offering an offering made by fire, of a pleasant aroma to Yahweh. 

###### v14 
If a stranger lives as a foreigner with you, or whoever may be among you throughout your generations, and will offer an offering made by fire, of a pleasant aroma to Yahweh, as you do, so he shall do. 

###### v15 
For the assembly, there shall be one statute for you and for the stranger who lives as a foreigner, a statute forever throughout your generations. As you are, so the foreigner shall be before Yahweh. 

###### v16 
One law and one ordinance shall be for you and for the stranger who lives as a foreigner with you.'" 

###### v17 
Yahweh spoke to Moses, saying, 

###### v18 
"Speak to the children of Israel, and tell them, 'When you come into the land where I bring you, 

###### v19 
then it shall be that when you eat of the bread of the land, you shall offer up a wave offering to Yahweh. 

###### v20 
Of the first of your dough you shall offer up a cake for a wave offering. As the wave offering of the threshing floor, so you shall heave it. 

###### v21 
Of the first of your dough, you shall give to Yahweh a wave offering throughout your generations. 

###### v22 
"'When you err, and don't observe all these commandments which Yahweh has spoken to Moses-- 

###### v23 
even all that Yahweh has commanded you by Moses, from the day that Yahweh gave commandment and onward throughout your generations-- 

###### v24 
then it shall be, if it was done unwittingly, without the knowledge of the congregation, that all the congregation shall offer one young bull for a burnt offering, for a pleasant aroma to Yahweh, with its meal offering and its drink offering, according to the ordinance, and one male goat for a sin offering. 

###### v25 
The priest shall make atonement for all the congregation of the children of Israel, and they shall be forgiven; for it was an error, and they have brought their offering, an offering made by fire to Yahweh, and their sin offering before Yahweh, for their error. 

###### v26 
All the congregation of the children of Israel shall be forgiven, as well as the stranger who lives as a foreigner among them; for with regard to all the people, it was done unwittingly. 

###### v27 
"'If a person sins unwittingly, then he shall offer a female goat a year old for a sin offering. 

###### v28 
The priest shall make atonement for the soul who errs when he sins unwittingly before Yahweh. He shall make atonement for him; and he shall be forgiven. 

###### v29 
You shall have one law for him who does anything unwittingly, for him who is native-born among the children of Israel, and for the stranger who lives as a foreigner among them. 

###### v30 
"'But the soul who does anything with a high hand, whether he is native-born or a foreigner, blasphemes Yahweh. That soul shall be cut off from among his people. 

###### v31 
Because he has despised Yahweh's word, and has broken his commandment, that soul shall be utterly cut off. His iniquity shall be on him.'" 

###### v32 
While the children of Israel were in the wilderness, they found a man gathering sticks on the Sabbath day. 

###### v33 
Those who found him gathering sticks brought him to Moses and Aaron, and to all the congregation. 

###### v34 
They put him in custody, because it had not been declared what should be done to him. 

###### v35 
Yahweh said to Moses, "The man shall surely be put to death. All the congregation shall stone him with stones outside of the camp." 

###### v36 
All the congregation brought him outside of the camp, and stoned him to death with stones, as Yahweh commanded Moses. 

###### v37 
Yahweh spoke to Moses, saying, 

###### v38 
"Speak to the children of Israel, and tell them that they should make themselves fringes on the borders of their garments throughout their generations, and that they put on the fringe of each border a cord of blue. 

###### v39 
It shall be to you for a fringe, that you may see it, and remember all Yahweh's commandments, and do them; and that you don't follow your own heart and your own eyes, after which you used to play the prostitute; 

###### v40 
so that you may remember and do all my commandments, and be holy to your God. 

###### v41 
I am Yahweh your God, who brought you out of the land of Egypt, to be your God: I am Yahweh your God."

***
[[Num-14|← Numbers 14]] | [[Numbers]] | [[Num-16|Numbers 16 →]]
