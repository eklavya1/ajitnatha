# Numbers 27

[[Num-26|← Numbers 26]] | [[Numbers]] | [[Num-28|Numbers 28 →]]
***



###### v1 
Then the daughters of Zelophehad, the son of Hepher, the son of Gilead, the son of Machir, the son of Manasseh, of the families of Manasseh the son of Joseph came near. These are the names of his daughters: Mahlah, Noah, Hoglah, Milcah, and Tirzah. 

###### v2 
They stood before Moses, before Eleazar the priest, and before the princes and all the congregation, at the door of the Tent of Meeting, saying, 

###### v3 
"Our father died in the wilderness. He was not among the company of those who gathered themselves together against Yahweh in the company of Korah, but he died in his own sin. He had no sons. 

###### v4 
Why should the name of our father be taken away from among his family, because he had no son? Give to us a possession among the brothers of our father." 

###### v5 
Moses brought their cause before Yahweh. 

###### v6 
Yahweh spoke to Moses, saying, 

###### v7 
"The daughters of Zelophehad speak right. You shall surely give them a possession of an inheritance among their father's brothers. You shall cause the inheritance of their father to pass to them. 

###### v8 
You shall speak to the children of Israel, saying, 'If a man dies, and has no son, then you shall cause his inheritance to pass to his daughter. 

###### v9 
If he has no daughter, then you shall give his inheritance to his brothers. 

###### v10 
If he has no brothers, then you shall give his inheritance to his father's brothers. 

###### v11 
If his father has no brothers, then you shall give his inheritance to his kinsman who is next to him of his family, and he shall possess it. This shall be a statute and ordinance for the children of Israel, as Yahweh commanded Moses.'" 

###### v12 
Yahweh said to Moses, "Go up into this mountain of Abarim, and see the land which I have given to the children of Israel. 

###### v13 
When you have seen it, you also shall be gathered to your people, as Aaron your brother was gathered; 

###### v14 
because in the strife of the congregation, you rebelled against my word in the wilderness of Zin, to honor me as holy at the waters before their eyes." (These are the waters of Meribah of Kadesh in the wilderness of Zin.) 

###### v15 
Moses spoke to Yahweh, saying, 

###### v16 
"Let Yahweh, the God of the spirits of all flesh, appoint a man over the congregation, 

###### v17 
who may go out before them, and who may come in before them, and who may lead them out, and who may bring them in, that the congregation of Yahweh may not be as sheep which have no shepherd." 

###### v18 
Yahweh said to Moses, "Take Joshua the son of Nun, a man in whom is the Spirit, and lay your hand on him. 

###### v19 
Set him before Eleazar the priest, and before all the congregation; and commission him in their sight. 

###### v20 
You shall give authority to him, that all the congregation of the children of Israel may obey. 

###### v21 
He shall stand before Eleazar the priest, who shall inquire for him by the judgment of the Urim before Yahweh. At his word they shall go out, and at his word they shall come in, both he and all the children of Israel with him, even all the congregation." 

###### v22 
Moses did as Yahweh commanded him. He took Joshua, and set him before Eleazar the priest and before all the congregation. 

###### v23 
He laid his hands on him and commissioned him, as Yahweh spoke by Moses.

***
[[Num-26|← Numbers 26]] | [[Numbers]] | [[Num-28|Numbers 28 →]]
