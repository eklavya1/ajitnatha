# Numbers 18

[[Num-17|← Numbers 17]] | [[Numbers]] | [[Num-19|Numbers 19 →]]
***



###### v1 
Yahweh said to Aaron, "You and your sons and your fathers' house with you shall bear the iniquity of the sanctuary; and you and your sons with you shall bear the iniquity of your priesthood. 

###### v2 
Bring your brothers also, the tribe of Levi, the tribe of your father, near with you, that they may be joined to you, and minister to you; but you and your sons with you shall be before the Tent of the Testimony. 

###### v3 
They shall keep your commands and the duty of the whole Tent; only they shall not come near to the vessels of the sanctuary and to the altar, that they not die, neither they nor you. 

###### v4 
They shall be joined to you and keep the responsibility of the Tent of Meeting, for all the service of the Tent. A stranger shall not come near to you. 

###### v5 
"You shall perform the duty of the sanctuary and the duty of the altar, that there be no more wrath on the children of Israel. 

###### v6 
Behold, I myself have taken your brothers the Levites from among the children of Israel. They are a gift to you, dedicated to Yahweh, to do the service of the Tent of Meeting. 

###### v7 
You and your sons with you shall keep your priesthood for everything of the altar, and for that within the veil. You shall serve. I give you the service of the priesthood as a gift. The stranger who comes near shall be put to death." 

###### v8 
Yahweh spoke to Aaron, "Behold, I myself have given you the command of my wave offerings, even all the holy things of the children of Israel. I have given them to you by reason of the anointing, and to your sons, as a portion forever. 

###### v9 
This shall be yours of the most holy things from the fire: every offering of theirs, even every meal offering of theirs, and every sin offering of theirs, and every trespass offering of theirs, which they shall render to me, shall be most holy for you and for your sons. 

###### v10 
You shall eat of it like the most holy things. Every male shall eat of it. It shall be holy to you. 

###### v11 
"This is yours, too: the wave offering of their gift, even all the wave offerings of the children of Israel. I have given them to you, and to your sons and to your daughters with you, as a portion forever. Everyone who is clean in your house shall eat of it. 

###### v12 
"I have given to you all the best of the oil, all the best of the vintage, and of the grain, the first fruits of them which they give to Yahweh. 

###### v13 
The first-ripe fruits of all that is in their land, which they bring to Yahweh, shall be yours. Everyone who is clean in your house shall eat of it. 

###### v14 
"Everything devoted in Israel shall be yours. 

###### v15 
Everything that opens the womb, of all flesh which they offer to Yahweh, both of man and animal, shall be yours. Nevertheless, you shall surely redeem the firstborn of man, and you shall redeem the firstborn of unclean animals. 

###### v16 
You shall redeem those who are to be redeemed of them from a month old, according to your estimation, for five shekels of money, according to the shekel of the sanctuary, which weighs twenty gerahs. 

###### v17 
"But you shall not redeem the firstborn of a cow, or the firstborn of a sheep, or the firstborn of a goat. They are holy. You shall sprinkle their blood on the altar, and shall burn their fat for an offering made by fire, for a pleasant aroma to Yahweh. 

###### v18 
Their meat shall be yours, as the wave offering breast and as the right thigh, it shall be yours. 

###### v19 
All the wave offerings of the holy things which the children of Israel offer to Yahweh, I have given you and your sons and your daughters with you, as a portion forever. It is a covenant of salt forever before Yahweh to you and to your offspring with you." 

###### v20 
Yahweh said to Aaron, "You shall have no inheritance in their land, neither shall you have any portion among them. I am your portion and your inheritance among the children of Israel. 

###### v21 
"To the children of Levi, behold, I have given all the tithe in Israel for an inheritance, in return for their service which they serve, even the service of the Tent of Meeting. 

###### v22 
Henceforth the children of Israel shall not come near the Tent of Meeting, lest they bear sin, and die. 

###### v23 
But the Levites shall do the service of the Tent of Meeting, and they shall bear their iniquity. It shall be a statute forever throughout your generations. Among the children of Israel, they shall have no inheritance. 

###### v24 
For the tithe of the children of Israel, which they offer as a wave offering to Yahweh, I have given to the Levites for an inheritance. Therefore I have said to them, 'Among the children of Israel they shall have no inheritance.'" 

###### v25 
Yahweh spoke to Moses, saying, 

###### v26 
"Moreover you shall speak to the Levites, and tell them, 'When you take of the children of Israel the tithe which I have given you from them for your inheritance, then you shall offer up a wave offering of it for Yahweh, a tithe of the tithe. 

###### v27 
Your wave offering shall be credited to you, as though it were the grain of the threshing floor, and as the fullness of the wine press. 

###### v28 
Thus you also shall offer a wave offering to Yahweh of all your tithes, which you receive of the children of Israel; and of it you shall give Yahweh's wave offering to Aaron the priest. 

###### v29 
Out of all your gifts, you shall offer every wave offering to Yahweh, of all its best parts, even the holy part of it.' 

###### v30 
"Therefore you shall tell them, 'When you heave its best from it, then it shall be credited to the Levites as the increase of the threshing floor, and as the increase of the wine press. 

###### v31 
You may eat it anywhere, you and your households, for it is your reward in return for your service in the Tent of Meeting. 

###### v32 
You shall bear no sin by reason of it, when you have heaved from it its best. You shall not profane the holy things of the children of Israel, that you not die.'"

***
[[Num-17|← Numbers 17]] | [[Numbers]] | [[Num-19|Numbers 19 →]]
