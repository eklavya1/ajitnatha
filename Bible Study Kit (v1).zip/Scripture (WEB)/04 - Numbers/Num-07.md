# Numbers 7

[[Num-06|← Numbers 06]] | [[Numbers]] | [[Num-08|Numbers 08 →]]
***



###### v1 
On the day that Moses had finished setting up the tabernacle, and had anointed it and sanctified it with all its furniture, and the altar with all its vessels, and had anointed and sanctified them; 

###### v2 
the princes of Israel, the heads of their fathers' houses, offered. These were the princes of the tribes. These are they who were over those who were counted; 

###### v3 
and they brought their offering before Yahweh, six covered wagons and twelve oxen; a wagon for every two of the princes, and for each one an ox. They presented them before the tabernacle. 

###### v4 
Yahweh spoke to Moses, saying, 

###### v5 
"Accept these from them, that they may be used in doing the service of the Tent of Meeting; and you shall give them to the Levites, to every man according to his service." 

###### v6 
Moses took the wagons and the oxen, and gave them to the Levites. 

###### v7 
He gave two wagons and four oxen to the sons of Gershon, according to their service. 

###### v8 
He gave four wagons and eight oxen to the sons of Merari, according to their service, under the direction of Ithamar the son of Aaron the priest. 

###### v9 
But to the sons of Kohath he gave none, because the service of the sanctuary belonged to them; they carried it on their shoulders. 

###### v10 
The princes gave offerings for the dedication of the altar in the day that it was anointed. The princes gave their offerings before the altar. 

###### v11 
Yahweh said to Moses, "They shall offer their offering, each prince on his day, for the dedication of the altar." 

###### v12 
He who offered his offering the first day was Nahshon the son of Amminadab, of the tribe of Judah, 

###### v13 
and his offering was: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v14 
one golden ladle of ten shekels, full of incense; 

###### v15 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v16 
one male goat for a sin offering; 

###### v17 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Nahshon the son of Amminadab. 

###### v18 
On the second day Nethanel the son of Zuar, prince of Issachar, gave his offering. 

###### v19 
He offered for his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v20 
one golden ladle of ten shekels, full of incense; 

###### v21 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v22 
one male goat for a sin offering; 

###### v23 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, five male lambs a year old. This was the offering of Nethanel the son of Zuar. 

###### v24 
On the third day Eliab the son of Helon, prince of the children of Zebulun, 

###### v25 
gave his offering: one silver platter, the weight of which was a hundred and thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v26 
one golden ladle of ten shekels, full of incense; 

###### v27 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v28 
one male goat for a sin offering; 

###### v29 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Eliab the son of Helon. 

###### v30 
On the fourth day Elizur the son of Shedeur, prince of the children of Reuben, 

###### v31 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v32 
one golden ladle of ten shekels, full of incense; 

###### v33 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v34 
one male goat for a sin offering; 

###### v35 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Elizur the son of Shedeur. 

###### v36 
On the fifth day Shelumiel the son of Zurishaddai, prince of the children of Simeon, 

###### v37 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v38 
one golden ladle of ten shekels, full of incense; 

###### v39 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v40 
one male goat for a sin offering; 

###### v41 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old: this was the offering of Shelumiel the son of Zurishaddai. 

###### v42 
On the sixth day, Eliasaph the son of Deuel, prince of the children of Gad, 

###### v43 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v44 
one golden ladle of ten shekels, full of incense; 

###### v45 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v46 
one male goat for a sin offering; 

###### v47 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Eliasaph the son of Deuel. 

###### v48 
On the seventh day Elishama the son of Ammihud, prince of the children of Ephraim, 

###### v49 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v50 
one golden ladle of ten shekels, full of incense; 

###### v51 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v52 
one male goat for a sin offering; 

###### v53 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Elishama the son of Ammihud. 

###### v54 
On the eighth day Gamaliel the son of Pedahzur, prince of the children of Manasseh, 

###### v55 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v56 
one golden ladle of ten shekels, full of incense; 

###### v57 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v58 
one male goat for a sin offering; 

###### v59 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Gamaliel the son of Pedahzur. 

###### v60 
On the ninth day Abidan the son of Gideoni, prince of the children of Benjamin, 

###### v61 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v62 
one golden ladle of ten shekels, full of incense; 

###### v63 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v64 
one male goat for a sin offering; 

###### v65 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Abidan the son of Gideoni. 

###### v66 
On the tenth day Ahiezer the son of Ammishaddai, prince of the children of Dan, 

###### v67 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v68 
one golden ladle of ten shekels, full of incense; 

###### v69 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v70 
one male goat for a sin offering; 

###### v71 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Ahiezer the son of Ammishaddai. 

###### v72 
On the eleventh day Pagiel the son of Ochran, prince of the children of Asher, 

###### v73 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v74 
one golden ladle of ten shekels, full of incense; 

###### v75 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v76 
one male goat for a sin offering; 

###### v77 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Pagiel the son of Ochran. 

###### v78 
On the twelfth day Ahira the son of Enan, prince of the children of Naphtali, 

###### v79 
gave his offering: one silver platter, the weight of which was one hundred thirty shekels, one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil for a meal offering; 

###### v80 
one golden spoon of ten shekels, full of incense; 

###### v81 
one young bull, one ram, one male lamb a year old, for a burnt offering; 

###### v82 
one male goat for a sin offering; 

###### v83 
and for the sacrifice of peace offerings, two head of cattle, five rams, five male goats, and five male lambs a year old. This was the offering of Ahira the son of Enan. 

###### v84 
This was the dedication offering of the altar, on the day when it was anointed, by the princes of Israel: twelve silver platters, twelve silver bowls, twelve golden ladles; 

###### v85 
each silver platter weighing one hundred thirty shekels, and each bowl seventy; all the silver of the vessels two thousand four hundred shekels, according to the shekel of the sanctuary; 

###### v86 
the twelve golden ladles, full of incense, weighing ten shekels apiece, according to the shekel of the sanctuary; all the gold of the ladles weighed one hundred twenty shekels; 

###### v87 
all the cattle for the burnt offering twelve bulls, the rams twelve, the male lambs a year old twelve, and their meal offering; and twelve male goats for a sin offering; 

###### v88 
and all the cattle for the sacrifice of peace offerings: twenty-four bulls, sixty rams, sixty male goats, and sixty male lambs a year old. This was the dedication offering of the altar, after it was anointed. 

###### v89 
When Moses went into the Tent of Meeting to speak with Yahweh, he heard his voice speaking to him from above the mercy seat that was on the ark of the Testimony, from between the two cherubim; and he spoke to him.

***
[[Num-06|← Numbers 06]] | [[Numbers]] | [[Num-08|Numbers 08 →]]
