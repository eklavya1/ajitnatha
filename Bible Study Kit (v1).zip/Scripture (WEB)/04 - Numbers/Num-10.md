# Numbers 10

[[Num-09|← Numbers 09]] | [[Numbers]] | [[Num-11|Numbers 11 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Make two trumpets of silver. You shall make them of beaten work. You shall use them for the calling of the congregation, and for the journeying of the camps. 

###### v3 
When they blow them, all the congregation shall gather themselves to you at the door of the Tent of Meeting. 

###### v4 
If they blow just one, then the princes, the heads of the thousands of Israel, shall gather themselves to you. 

###### v5 
When you blow an alarm, the camps that lie on the east side shall go forward. 

###### v6 
When you blow an alarm the second time, the camps that lie on the south side shall go forward. They shall blow an alarm for their journeys. 

###### v7 
But when the assembly is to be gathered together, you shall blow, but you shall not sound an alarm. 

###### v8 
"The sons of Aaron, the priests, shall blow the trumpets. This shall be to you for a statute forever throughout your generations. 

###### v9 
When you go to war in your land against the adversary who oppresses you, then you shall sound an alarm with the trumpets. Then you will be remembered before Yahweh your God, and you will be saved from your enemies. 

###### v10 
"Also in the day of your gladness, and in your set feasts, and in the beginnings of your months, you shall blow the trumpets over your burnt offerings, and over the sacrifices of your peace offerings; and they shall be to you for a memorial before your God. I am Yahweh your God." 

###### v11 
In the second year, in the second month, on the twentieth day of the month, the cloud was taken up from over the tabernacle of the covenant. 

###### v12 
The children of Israel went forward on their journeys out of the wilderness of Sinai; and the cloud stayed in the wilderness of Paran. 

###### v13 
They first went forward according to the commandment of Yahweh by Moses. 

###### v14 
First, the standard of the camp of the children of Judah went forward according to their armies. Nahshon the son of Amminadab was over his army. 

###### v15 
Nethanel the son of Zuar was over the army of the tribe of the children of Issachar. 

###### v16 
Eliab the son of Helon was over the army of the tribe of the children of Zebulun. 

###### v17 
The tabernacle was taken down; and the sons of Gershon and the sons of Merari, who bore the tabernacle, went forward. 

###### v18 
The standard of the camp of Reuben went forward according to their armies. Elizur the son of Shedeur was over his army. 

###### v19 
Shelumiel the son of Zurishaddai was over the army of the tribe of the children of Simeon. 

###### v20 
Eliasaph the son of Deuel was over the army of the tribe of the children of Gad. 

###### v21 
The Kohathites set forward, bearing the sanctuary. The others set up the tabernacle before they arrived. 

###### v22 
The standard of the camp of the children of Ephraim set forward according to their armies. Elishama the son of Ammihud was over his army. 

###### v23 
Gamaliel the son of Pedahzur was over the army of the tribe of the children of Manasseh. 

###### v24 
Abidan the son of Gideoni was over the army of the tribe of the children of Benjamin. 

###### v25 
The standard of the camp of the children of Dan, which was the rear guard of all the camps, set forward according to their armies. Ahiezer the son of Ammishaddai was over his army. 

###### v26 
Pagiel the son of Ochran was over the army of the tribe of the children of Asher. 

###### v27 
Ahira the son of Enan was over the army of the tribe of the children of Naphtali. 

###### v28 
Thus were the travels of the children of Israel according to their armies; and they went forward. 

###### v29 
Moses said to Hobab, the son of Reuel the Midianite, Moses' father-in-law, "We are journeying to the place of which Yahweh said, 'I will give it to you.' Come with us, and we will treat you well; for Yahweh has spoken good concerning Israel." 

###### v30 
He said to him, "I will not go; but I will depart to my own land, and to my relatives." 

###### v31 
Moses said, "Don't leave us, please; because you know how we are to encamp in the wilderness, and you can be our eyes. 

###### v32 
It shall be, if you go with us--yes, it shall be--that whatever good Yahweh does to us, we will do the same to you." 

###### v33 
They set forward from the Mount of Yahweh three days' journey. The ark of Yahweh's covenant went before them three days' journey, to seek out a resting place for them. 

###### v34 
The cloud of Yahweh was over them by day, when they set forward from the camp. 

###### v35 
When the ark went forward, Moses said, "Rise up, Yahweh, and let your enemies be scattered! Let those who hate you flee before you!" 

###### v36 
When it rested, he said, "Return, Yahweh, to the ten thousands of the thousands of Israel."

***
[[Num-09|← Numbers 09]] | [[Numbers]] | [[Num-11|Numbers 11 →]]
