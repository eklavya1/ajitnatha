# Numbers 36

[[Num-35|← Numbers 35]] | [[Numbers]]
***



###### v1 
The heads of the fathers' households of the family of the children of Gilead, the son of Machir, the son of Manasseh, of the families of the sons of Joseph, came near, and spoke before Moses and before the princes, the heads of the fathers' households of the children of Israel. 

###### v2 
They said, "Yahweh commanded my lord to give the land for inheritance by lot to the children of Israel. My lord was commanded by Yahweh to give the inheritance of Zelophehad our brother to his daughters. 

###### v3 
If they are married to any of the sons of the other tribes of the children of Israel, then their inheritance will be taken away from the inheritance of our fathers, and will be added to the inheritance of the tribe to which they shall belong. So it will be taken away from the lot of our inheritance. 

###### v4 
When the jubilee of the children of Israel comes, then their inheritance will be added to the inheritance of the tribe to which they shall belong. So their inheritance will be taken away from the inheritance of the tribe of our fathers." 

###### v5 
Moses commanded the children of Israel according to Yahweh's word, saying, "The tribe of the sons of Joseph speak what is right. 

###### v6 
This is the thing which Yahweh commands concerning the daughters of Zelophehad, saying, 'Let them be married to whom they think best, only they shall marry into the family of the tribe of their father. 

###### v7 
So shall no inheritance of the children of Israel move from tribe to tribe; for the children of Israel shall all keep the inheritance of the tribe of his fathers. 

###### v8 
Every daughter who possesses an inheritance in any tribe of the children of Israel shall be wife to one of the family of the tribe of her father, that the children of Israel may each possess the inheritance of his fathers. 

###### v9 
So shall no inheritance move from one tribe to another tribe; for the tribes of the children of Israel shall each keep his own inheritance.'" 

###### v10 
The daughters of Zelophehad did as Yahweh commanded Moses: 

###### v11 
for Mahlah, Tirzah, Hoglah, Milcah, and Noah, the daughters of Zelophehad, were married to their father's brothers' sons. 

###### v12 
They were married into the families of the sons of Manasseh the son of Joseph. Their inheritance remained in the tribe of the family of their father. 

###### v13 
These are the commandments and the ordinances which Yahweh commanded by Moses to the children of Israel in the plains of Moab by the Jordan at Jericho.

***
[[Num-35|← Numbers 35]] | [[Numbers]]
