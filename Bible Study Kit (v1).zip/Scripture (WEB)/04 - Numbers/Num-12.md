# Numbers 12

[[Num-11|← Numbers 11]] | [[Numbers]] | [[Num-13|Numbers 13 →]]
***



###### v1 
Miriam and Aaron spoke against Moses because of the Cushite woman whom he had married; for he had married a Cushite woman. 

###### v2 
They said, "Has Yahweh indeed spoken only with Moses? Hasn't he spoken also with us?" And Yahweh heard it. 

###### v3 
Now the man Moses was very humble, more than all the men who were on the surface of the earth. 

###### v4 
Yahweh spoke suddenly to Moses, to Aaron, and to Miriam, "You three come out to the Tent of Meeting!" The three of them came out. 

###### v5 
Yahweh came down in a pillar of cloud, and stood at the door of the Tent, and called Aaron and Miriam; and they both came forward. 

###### v6 
He said, "Now hear my words. If there is a prophet among you, I, Yahweh, will make myself known to him in a vision. I will speak with him in a dream. 

###### v7 
My servant Moses is not so. He is faithful in all my house. 

###### v8 
With him, I will speak mouth to mouth, even plainly, and not in riddles; and he shall see Yahweh's form. Why then were you not afraid to speak against my servant, against Moses?" 

###### v9 
Yahweh's anger burned against them; and he departed. 

###### v10 
The cloud departed from over the Tent; and behold, Miriam was leprous, as white as snow. Aaron looked at Miriam, and behold, she was leprous. 

###### v11 
Aaron said to Moses, "Oh, my lord, please don't count this sin against us, in which we have done foolishly, and in which we have sinned. 

###### v12 
Let her not, I pray, be as one dead, of whom the flesh is half consumed when he comes out of his mother's womb." 

###### v13 
Moses cried to Yahweh, saying, "Heal her, God, I beg you!" 

###### v14 
Yahweh said to Moses, "If her father had but spit in her face, shouldn't she be ashamed seven days? Let her be shut up outside of the camp seven days, and after that she shall be brought in again." 

###### v15 
Miriam was shut up outside of the camp seven days, and the people didn't travel until Miriam was brought in again. 

###### v16 
Afterward the people traveled from Hazeroth, and encamped in the wilderness of Paran.

***
[[Num-11|← Numbers 11]] | [[Numbers]] | [[Num-13|Numbers 13 →]]
