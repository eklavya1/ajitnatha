# Numbers 24

[[Num-23|← Numbers 23]] | [[Numbers]] | [[Num-25|Numbers 25 →]]
***



###### v1 
When Balaam saw that it pleased Yahweh to bless Israel, he didn't go, as at the other times, to use divination, but he set his face toward the wilderness. 

###### v2 
Balaam lifted up his eyes, and he saw Israel dwelling according to their tribes; and the Spirit of God came on him. 

###### v3 
He took up his parable, and said, "Balaam the son of Beor says, the man whose eyes are open says; 

###### v4 
he says, who hears the words of God, who sees the vision of the Almighty, falling down, and having his eyes open: 

###### v5 
How goodly are your tents, Jacob, and your dwellings, Israel! 

###### v6 
As valleys they are spread out, as gardens by the riverside, as aloes which Yahweh has planted, as cedar trees beside the waters. 

###### v7 
Water shall flow from his buckets. His seed shall be in many waters. His king shall be higher than Agag. His kingdom shall be exalted. 

###### v8 
God brings him out of Egypt. He has as it were the strength of the wild ox. He shall consume the nations his adversaries, shall break their bones in pieces, and pierce them with his arrows. 

###### v9 
He couched, he lay down as a lion, as a lioness; who shall rouse him up? Everyone who blesses you is blessed. Everyone who curses you is cursed." 

###### v10 
Balak's anger burned against Balaam, and he struck his hands together. Balak said to Balaam, "I called you to curse my enemies, and, behold, you have altogether blessed them these three times. 

###### v11 
Therefore, flee to your place, now! I thought to promote you to great honor; but, behold, Yahweh has kept you back from honor." 

###### v12 
Balaam said to Balak, "Didn't I also tell your messengers whom you sent to me, saying, 

###### v13 
'If Balak would give me his house full of silver and gold, I can't go beyond Yahweh's word, to do either good or bad from my own mind. I will say what Yahweh says'? 

###### v14 
Now, behold, I go to my people. Come, I will inform you what this people shall do to your people in the latter days." 

###### v15 
He took up his parable, and said, "Balaam the son of Beor says, the man whose eyes are open says; 

###### v16 
he says, who hears the words of God, knows the knowledge of the Most High, and who sees the vision of the Almighty, falling down, and having his eyes open: 

###### v17 
I see him, but not now. I see him, but not near. A star will come out of Jacob. A scepter will rise out of Israel, and shall strike through the corners of Moab, and crush all the sons of Sheth. 

###### v18 
Edom shall be a possession. Seir, his enemy, also shall be a possession, while Israel does valiantly. 

###### v19 
Out of Jacob shall one have dominion, and shall destroy the remnant from the city." 

###### v20 
He looked at Amalek, and took up his parable, and said, "Amalek was the first of the nations, But his latter end shall come to destruction." 

###### v21 
He looked at the Kenite, and took up his parable, and said, "Your dwelling place is strong. Your nest is set in the rock. 

###### v22 
Nevertheless Kain shall be wasted, until Asshur carries you away captive." 

###### v23 
He took up his parable, and said, "Alas, who shall live when God does this? 

###### v24 
But ships shall come from the coast of Kittim. They shall afflict Asshur, and shall afflict Eber. He also shall come to destruction." 

###### v25 
Balaam rose up, and went and returned to his place; and Balak also went his way.

***
[[Num-23|← Numbers 23]] | [[Numbers]] | [[Num-25|Numbers 25 →]]
