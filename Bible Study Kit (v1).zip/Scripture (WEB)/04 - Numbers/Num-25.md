# Numbers 25

[[Num-24|← Numbers 24]] | [[Numbers]] | [[Num-26|Numbers 26 →]]
***



###### v1 
Israel stayed in Shittim; and the people began to play the prostitute with the daughters of Moab; 

###### v2 
for they called the people to the sacrifices of their gods. The people ate and bowed down to their gods. 

###### v3 
Israel joined himself to Baal Peor, and Yahweh's anger burned against Israel. 

###### v4 
Yahweh said to Moses, "Take all the chiefs of the people, and hang them up to Yahweh before the sun, that the fierce anger of Yahweh may turn away from Israel." 

###### v5 
Moses said to the judges of Israel, "Everyone kill his men who have joined themselves to Baal Peor." 

###### v6 
Behold, one of the children of Israel came and brought to his brothers a Midianite woman in the sight of Moses, and in the sight of all the congregation of the children of Israel, while they were weeping at the door of the Tent of Meeting. 

###### v7 
When Phinehas, the son of Eleazar, the son of Aaron the priest, saw it, he rose up from the middle of the congregation, and took a spear in his hand. 

###### v8 
He went after the man of Israel into the pavilion, and thrust both of them through, the man of Israel, and the woman through her body. So the plague was stopped among the children of Israel. 

###### v9 
Those who died by the plague were twenty-four thousand. 

###### v10 
Yahweh spoke to Moses, saying, 

###### v11 
"Phinehas, the son of Eleazar, the son of Aaron the priest, has turned my wrath away from the children of Israel, in that he was jealous with my jealousy among them, so that I didn't consume the children of Israel in my jealousy. 

###### v12 
Therefore say, 'Behold, I give to him my covenant of peace. 

###### v13 
It shall be to him, and to his offspring after him, the covenant of an everlasting priesthood, because he was jealous for his God, and made atonement for the children of Israel.'" 

###### v14 
Now the name of the man of Israel that was slain, who was slain with the Midianite woman, was Zimri, the son of Salu, a prince of a fathers' house among the Simeonites. 

###### v15 
The name of the Midianite woman who was slain was Cozbi, the daughter of Zur. He was head of the people of a fathers' house in Midian. 

###### v16 
Yahweh spoke to Moses, saying, 

###### v17 
"Harass the Midianites, and strike them; 

###### v18 
for they harassed you with their wiles, wherein they have deceived you in the matter of Peor, and in the incident regarding Cozbi, the daughter of the prince of Midian, their sister, who was slain on the day of the plague in the matter of Peor."

***
[[Num-24|← Numbers 24]] | [[Numbers]] | [[Num-26|Numbers 26 →]]
