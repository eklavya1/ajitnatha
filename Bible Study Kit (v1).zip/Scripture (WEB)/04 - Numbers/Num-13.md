# Numbers 13

[[Num-12|← Numbers 12]] | [[Numbers]] | [[Num-14|Numbers 14 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Send men, that they may spy out the land of Canaan, which I give to the children of Israel. Of every tribe of their fathers, you shall send a man, every one a prince among them." 

###### v3 
Moses sent them from the wilderness of Paran according to the commandment of Yahweh. All of them were men who were heads of the children of Israel. 

###### v4 
These were their names: Of the tribe of Reuben, Shammua the son of Zaccur. 

###### v5 
Of the tribe of Simeon, Shaphat the son of Hori. 

###### v6 
Of the tribe of Judah, Caleb the son of Jephunneh. 

###### v7 
Of the tribe of Issachar, Igal the son of Joseph. 

###### v8 
Of the tribe of Ephraim, Hoshea the son of Nun. 

###### v9 
Of the tribe of Benjamin, Palti the son of Raphu. 

###### v10 
Of the tribe of Zebulun, Gaddiel the son of Sodi. 

###### v11 
Of the tribe of Joseph, of the tribe of Manasseh, Gaddi the son of Susi. 

###### v12 
Of the tribe of Dan, Ammiel the son of Gemalli. 

###### v13 
Of the tribe of Asher, Sethur the son of Michael. 

###### v14 
Of the tribe of Naphtali, Nahbi the son of Vophsi. 

###### v15 
Of the tribe of Gad, Geuel the son of Machi. 

###### v16 
These are the names of the men who Moses sent to spy out the land. Moses called Hoshea the son of Nun Joshua. 

###### v17 
Moses sent them to spy out the land of Canaan, and said to them, "Go up this way by the South, and go up into the hill country. 

###### v18 
See the land, what it is; and the people who dwell therein, whether they are strong or weak, whether they are few or many; 

###### v19 
and what the land is that they dwell in, whether it is good or bad; and what cities they are that they dwell in, whether in camps, or in strongholds; 

###### v20 
and what the land is, whether it is fertile or poor, whether there is wood therein, or not. Be courageous, and bring some of the fruit of the land." Now the time was the time of the first-ripe grapes. 

###### v21 
So they went up, and spied out the land from the wilderness of Zin to Rehob, to the entrance of Hamath. 

###### v22 
They went up by the South, and came to Hebron; and Ahiman, Sheshai, and Talmai, the children of Anak, were there. (Now Hebron was built seven years before Zoan in Egypt.) 

###### v23 
They came to the valley of Eshcol, and cut down from there a branch with one cluster of grapes, and they bore it on a staff between two. They also brought some of the pomegranates and figs. 

###### v24 
That place was called the valley of Eshcol, because of the cluster which the children of Israel cut down from there. 

###### v25 
They returned from spying out the land at the end of forty days. 

###### v26 
They went and came to Moses, to Aaron, and to all the congregation of the children of Israel, to the wilderness of Paran, to Kadesh; and brought back word to them and to all the congregation. They showed them the fruit of the land. 

###### v27 
They told him, and said, "We came to the land where you sent us. Surely it flows with milk and honey, and this is its fruit. 

###### v28 
However, the people who dwell in the land are strong, and the cities are fortified and very large. Moreover, we saw the children of Anak there. 

###### v29 
Amalek dwells in the land of the South. The Hittite, the Jebusite, and the Amorite dwell in the hill country. The Canaanite dwells by the sea, and along the side of the Jordan." 

###### v30 
Caleb stilled the people before Moses, and said, "Let's go up at once, and possess it; for we are well able to overcome it!" 

###### v31 
But the men who went up with him said, "We aren't able to go up against the people; for they are stronger than we." 

###### v32 
They brought up an evil report of the land which they had spied out to the children of Israel, saying, "The land, through which we have gone to spy it out, is a land that eats up its inhabitants; and all the people who we saw in it are men of great stature. 

###### v33 
There we saw the Nephilim, the sons of Anak, who come from the Nephilim. We were in our own sight as grasshoppers, and so we were in their sight."

***
[[Num-12|← Numbers 12]] | [[Numbers]] | [[Num-14|Numbers 14 →]]
