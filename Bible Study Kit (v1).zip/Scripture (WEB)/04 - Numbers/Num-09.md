# Numbers 9

[[Num-08|← Numbers 08]] | [[Numbers]] | [[Num-10|Numbers 10 →]]
***



###### v1 
Yahweh spoke to Moses in the wilderness of Sinai, in the first month of the second year after they had come out of the land of Egypt, saying, 

###### v2 
"Let the children of Israel keep the Passover in its appointed season. 

###### v3 
On the fourteenth day of this month, at evening, you shall keep it in its appointed season. You shall keep it according to all its statutes and according to all its ordinances." 

###### v4 
Moses told the children of Israel that they should keep the Passover. 

###### v5 
They kept the Passover in the first month, on the fourteenth day of the month at evening, in the wilderness of Sinai. According to all that Yahweh commanded Moses, so the children of Israel did. 

###### v6 
There were certain men, who were unclean because of the dead body of a man, so that they could not keep the Passover on that day, and they came before Moses and Aaron on that day. 

###### v7 
Those men said to him, "We are unclean because of the dead body of a man. Why are we kept back, that we may not offer the offering of Yahweh in its appointed season among the children of Israel?" 

###### v8 
Moses answered them, "Wait, that I may hear what Yahweh will command concerning you." 

###### v9 
Yahweh spoke to Moses, saying, 

###### v10 
"Say to the children of Israel, 'If any man of you or of your generations is unclean by reason of a dead body, or is on a journey far away, he shall still keep the Passover to Yahweh. 

###### v11 
In the second month, on the fourteenth day at evening they shall keep it; they shall eat it with unleavened bread and bitter herbs. 

###### v12 
They shall leave none of it until the morning, nor break a bone of it. According to all the statute of the Passover they shall keep it. 

###### v13 
But the man who is clean, and is not on a journey, and fails to keep the Passover, that soul shall be cut off from his people. Because he didn't offer the offering of Yahweh in its appointed season, that man shall bear his sin. 

###### v14 
"'If a foreigner lives among you, and desires to keep the Passover to Yahweh, then he shall do so according to the statute of the Passover, and according to its ordinance. You shall have one statute, both for the foreigner, and for him who is born in the land.'" 

###### v15 
On the day that the tabernacle was raised up, the cloud covered the tabernacle, even the Tent of the Testimony. At evening it was over the tabernacle, as it were the appearance of fire, until morning. 

###### v16 
So it was continually. The cloud covered it, and the appearance of fire by night. 

###### v17 
Whenever the cloud was taken up from over the Tent, then after that the children of Israel traveled; and in the place where the cloud remained, there the children of Israel encamped. 

###### v18 
At the commandment of Yahweh, the children of Israel traveled, and at the commandment of Yahweh they encamped. As long as the cloud remained on the tabernacle they remained encamped. 

###### v19 
When the cloud stayed on the tabernacle many days, then the children of Israel kept Yahweh's command, and didn't travel. 

###### v20 
Sometimes the cloud was a few days on the tabernacle; then according to the commandment of Yahweh they remained encamped, and according to the commandment of Yahweh they traveled. 

###### v21 
Sometimes the cloud was from evening until morning; and when the cloud was taken up in the morning, they traveled; or by day and by night, when the cloud was taken up, they traveled. 

###### v22 
Whether it was two days, or a month, or a year that the cloud stayed on the tabernacle, remaining on it, the children of Israel remained encamped, and didn't travel; but when it was taken up, they traveled. 

###### v23 
At the commandment of Yahweh they encamped, and at the commandment of Yahweh they traveled. They kept Yahweh's command, at the commandment of Yahweh by Moses.

***
[[Num-08|← Numbers 08]] | [[Numbers]] | [[Num-10|Numbers 10 →]]
