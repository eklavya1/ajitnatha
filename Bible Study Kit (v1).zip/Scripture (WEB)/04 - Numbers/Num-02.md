# Numbers 2

[[Num-01|← Numbers 01]] | [[Numbers]] | [[Num-03|Numbers 03 →]]
***



###### v1 
Yahweh spoke to Moses and to Aaron, saying, 

###### v2 
"The children of Israel shall encamp every man by his own standard, with the banners of their fathers' houses. They shall encamp around the Tent of Meeting at a distance from it." 

###### v3 
Those who encamp on the east side toward the sunrise shall be of the standard of the camp of Judah, according to their divisions. The prince of the children of Judah shall be Nahshon the son of Amminadab. 

###### v4 
His division, and those who were counted of them, were seventy-four thousand six hundred. 

###### v5 
Those who encamp next to him shall be the tribe of Issachar. The prince of the children of Issachar shall be Nethanel the son of Zuar. 

###### v6 
His division, and those who were counted of it, were fifty-four thousand four hundred. 

###### v7 
The tribe of Zebulun: the prince of the children of Zebulun shall be Eliab the son of Helon. 

###### v8 
His division, and those who were counted of it, were fifty-seven thousand four hundred. 

###### v9 
All who were counted of the camp of Judah were one hundred eighty-six thousand four hundred, according to their divisions. They shall set out first. 

###### v10 
"On the south side shall be the standard of the camp of Reuben according to their divisions. The prince of the children of Reuben shall be Elizur the son of Shedeur. 

###### v11 
His division, and those who were counted of it, were forty-six thousand five hundred. 

###### v12 
"Those who encamp next to him shall be the tribe of Simeon. The prince of the children of Simeon shall be Shelumiel the son of Zurishaddai. 

###### v13 
His division, and those who were counted of them, were fifty-nine thousand three hundred. 

###### v14 
"The tribe of Gad: the prince of the children of Gad shall be Eliasaph the son of Reuel. 

###### v15 
His division, and those who were counted of them, were forty-five thousand six hundred fifty. 

###### v16 
"All who were counted of the camp of Reuben were one hundred fifty-one thousand four hundred fifty, according to their armies. They shall set out second. 

###### v17 
"Then the Tent of Meeting shall set out, with the camp of the Levites in the middle of the camps. As they encamp, so shall they set out, every man in his place, by their standards. 

###### v18 
"On the west side shall be the standard of the camp of Ephraim according to their divisions. The prince of the children of Ephraim shall be Elishama the son of Ammihud. 

###### v19 
His division, and those who were counted of them, were forty thousand five hundred. 

###### v20 
"Next to him shall be the tribe of Manasseh. The prince of the children of Manasseh shall be Gamaliel the son of Pedahzur. 

###### v21 
His division, and those who were counted of them, were thirty-two thousand two hundred. 

###### v22 
"The tribe of Benjamin: the prince of the children of Benjamin shall be Abidan the son of Gideoni. 

###### v23 
His army, and those who were counted of them, were thirty-five thousand four hundred. 

###### v24 
"All who were counted of the camp of Ephraim were one hundred eight thousand one hundred, according to their divisions. They shall set out third. 

###### v25 
"On the north side shall be the standard of the camp of Dan according to their divisions. The prince of the children of Dan shall be Ahiezer the son of Ammishaddai. 

###### v26 
His division, and those who were counted of them, were sixty-two thousand seven hundred. 

###### v27 
"Those who encamp next to him shall be the tribe of Asher. The prince of the children of Asher shall be Pagiel the son of Ochran. 

###### v28 
His division, and those who were counted of them, were forty-one thousand five hundred. 

###### v29 
"The tribe of Naphtali: the prince of the children of Naphtali shall be Ahira the son of Enan. 

###### v30 
His division, and those who were counted of them, were fifty-three thousand four hundred. 

###### v31 
"All who were counted of the camp of Dan were one hundred fifty-seven thousand six hundred. They shall set out last by their standards." 

###### v32 
These are those who were counted of the children of Israel by their fathers' houses. All who were counted of the camps according to their armies were six hundred three thousand five hundred fifty. 

###### v33 
But the Levites were not counted among the children of Israel, as Yahweh commanded Moses. 

###### v34 
Thus the children of Israel did. According to all that Yahweh commanded Moses, so they encamped by their standards, and so they set out, everyone by their families, according to their fathers' houses.

***
[[Num-01|← Numbers 01]] | [[Numbers]] | [[Num-03|Numbers 03 →]]
