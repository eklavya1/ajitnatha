# Numbers 32

[[Num-31|← Numbers 31]] | [[Numbers]] | [[Num-33|Numbers 33 →]]
***



###### v1 
Now the children of Reuben and the children of Gad had a very great multitude of livestock. They saw the land of Jazer, and the land of Gilead. Behold, the place was a place for livestock. 

###### v2 
Then the children of Gad and the children of Reuben came and spoke to Moses, and to Eleazar the priest, and to the princes of the congregation, saying, 

###### v3 
"Ataroth, Dibon, Jazer, Nimrah, Heshbon, Elealeh, Sebam, Nebo, and Beon, 

###### v4 
the land which Yahweh struck before the congregation of Israel, is a land for livestock; and your servants have livestock." 

###### v5 
They said, "If we have found favor in your sight, let this land be given to your servants for a possession. Don't bring us over the Jordan." 

###### v6 
Moses said to the children of Gad, and to the children of Reuben, "Shall your brothers go to war while you sit here? 

###### v7 
Why do you discourage the heart of the children of Israel from going over into the land which Yahweh has given them? 

###### v8 
Your fathers did so when I sent them from Kadesh Barnea to see the land. 

###### v9 
For when they went up to the valley of Eshcol, and saw the land, they discouraged the heart of the children of Israel, that they should not go into the land which Yahweh had given them. 

###### v10 
Yahweh's anger burned in that day, and he swore, saying, 

###### v11 
'Surely none of the men who came up out of Egypt, from twenty years old and upward, shall see the land which I swore to Abraham, to Isaac, and to Jacob; because they have not wholly followed me, 

###### v12 
except Caleb the son of Jephunneh the Kenizzite, and Joshua the son of Nun, because they have followed Yahweh completely.' 

###### v13 
Yahweh's anger burned against Israel, and he made them wander back and forth in the wilderness forty years, until all the generation who had done evil in Yahweh's sight was consumed. 

###### v14 
"Behold, you have risen up in your fathers' place, an increase of sinful men, to increase the fierce anger of Yahweh toward Israel. 

###### v15 
For if you turn away from after him, he will yet again leave them in the wilderness; and you will destroy all these people." 

###### v16 
They came near to him, and said, "We will build sheepfolds here for our livestock, and cities for our little ones; 

###### v17 
but we ourselves will be ready armed to go before the children of Israel, until we have brought them to their place. Our little ones shall dwell in the fortified cities because of the inhabitants of the land. 

###### v18 
We will not return to our houses until the children of Israel have all received their inheritance. 

###### v19 
For we will not inherit with them on the other side of the Jordan and beyond, because our inheritance has come to us on this side of the Jordan eastward." 

###### v20 
Moses said to them: "If you will do this thing, if you will arm yourselves to go before Yahweh to the war, 

###### v21 
and every one of your armed men will pass over the Jordan before Yahweh until he has driven out his enemies from before him, 

###### v22 
and the land is subdued before Yahweh; then afterward you shall return, and be clear of obligation to Yahweh and to Israel. Then this land shall be your possession before Yahweh. 

###### v23 
"But if you will not do so, behold, you have sinned against Yahweh; and be sure your sin will find you out. 

###### v24 
Build cities for your little ones, and folds for your sheep; and do that which has proceeded out of your mouth." 

###### v25 
The children of Gad and the children of Reuben spoke to Moses, saying, "Your servants will do as my lord commands. 

###### v26 
Our little ones, our wives, our flocks, and all our livestock shall be there in the cities of Gilead; 

###### v27 
but your servants will pass over, every man who is armed for war, before Yahweh to battle, as my lord says." 

###### v28 
So Moses commanded concerning them to Eleazar the priest, and to Joshua the son of Nun, and to the heads of the fathers' households of the tribes of the children of Israel. 

###### v29 
Moses said to them, "If the children of Gad and the children of Reuben will pass with you over the Jordan, every man who is armed to battle before Yahweh, and the land is subdued before you, then you shall give them the land of Gilead for a possession; 

###### v30 
but if they will not pass over with you armed, they shall have possessions among you in the land of Canaan." 

###### v31 
The children of Gad and the children of Reuben answered, saying, "As Yahweh has said to your servants, so will we do. 

###### v32 
We will pass over armed before Yahweh into the land of Canaan, and the possession of our inheritance shall remain with us beyond the Jordan." 

###### v33 
Moses gave to them, even to the children of Gad, and to the children of Reuben, and to the half-tribe of Manasseh the son of Joseph, the kingdom of Sihon king of the Amorites, and the kingdom of Og king of Bashan; the land, according to its cities and borders, even the cities of the surrounding land. 

###### v34 
The children of Gad built Dibon, Ataroth, Aroer, 

###### v35 
Atroth-shophan, Jazer, Jogbehah, 

###### v36 
Beth Nimrah, and Beth Haran: fortified cities and folds for sheep. 

###### v37 
The children of Reuben built Heshbon, Elealeh, Kiriathaim, 

###### v38 
Nebo, and Baal Meon, (their names being changed), and Sibmah. They gave other names to the cities which they built. 

###### v39 
The children of Machir the son of Manasseh went to Gilead, took it, and dispossessed the Amorites who were therein. 

###### v40 
Moses gave Gilead to Machir the son of Manasseh; and he lived therein. 

###### v41 
Jair the son of Manasseh went and took its villages, and called them Havvoth Jair. 

###### v42 
Nobah went and took Kenath and its villages, and called it Nobah, after his own name.

***
[[Num-31|← Numbers 31]] | [[Numbers]] | [[Num-33|Numbers 33 →]]
