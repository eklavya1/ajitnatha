# Numbers 16

[[Num-15|← Numbers 15]] | [[Numbers]] | [[Num-17|Numbers 17 →]]
***



###### v1 
Now Korah, the son of Izhar, the son of Kohath, the son of Levi, with Dathan and Abiram, the sons of Eliab, and On, the son of Peleth, sons of Reuben, took some men. 

###### v2 
They rose up before Moses, with some of the children of Israel, two hundred fifty princes of the congregation, called to the assembly, men of renown. 

###### v3 
They assembled themselves together against Moses and against Aaron, and said to them, "You take too much on yourself, since all the congregation are holy, everyone of them, and Yahweh is among them! Why do you lift yourselves up above Yahweh's assembly?" 

###### v4 
When Moses heard it, he fell on his face. 

###### v5 
He said to Korah and to all his company, "In the morning, Yahweh will show who are his, and who is holy, and will cause him to come near to him. Even him whom he shall choose, he will cause to come near to him. 

###### v6 
Do this: have Korah and all his company take censers, 

###### v7 
put fire in them, and put incense on them before Yahweh tomorrow. It shall be that the man whom Yahweh chooses, he shall be holy. You have gone too far, you sons of Levi!" 

###### v8 
Moses said to Korah, "Hear now, you sons of Levi! 

###### v9 
Is it a small thing to you that the God of Israel has separated you from the congregation of Israel, to bring you near to himself, to do the service of Yahweh's tabernacle, and to stand before the congregation to minister to them; 

###### v10 
and that he has brought you near, and all your brothers the sons of Levi with you? Do you seek the priesthood also? 

###### v11 
Therefore you and all your company have gathered together against Yahweh! What is Aaron that you complain against him?" 

###### v12 
Moses sent to call Dathan and Abiram, the sons of Eliab; and they said, "We won't come up! 

###### v13 
Is it a small thing that you have brought us up out of a land flowing with milk and honey, to kill us in the wilderness, but you must also make yourself a prince over us? 

###### v14 
Moreover you haven't brought us into a land flowing with milk and honey, nor given us inheritance of fields and vineyards. Will you put out the eyes of these men? We won't come up." 

###### v15 
Moses was very angry, and said to Yahweh, "Don't respect their offering. I have not taken one donkey from them, neither have I hurt one of them." 

###### v16 
Moses said to Korah, "You and all your company go before Yahweh, you, and they, and Aaron, tomorrow. 

###### v17 
Each man take his censer and put incense on it, and each man bring before Yahweh his censer, two hundred fifty censers; you also, and Aaron, each with his censer." 

###### v18 
They each took his censer, and put fire in it, and laid incense on it, and stood at the door of the Tent of Meeting with Moses and Aaron. 

###### v19 
Korah assembled all the congregation opposite them to the door of the Tent of Meeting. Yahweh's glory appeared to all the congregation. 

###### v20 
Yahweh spoke to Moses and to Aaron, saying, 

###### v21 
"Separate yourselves from among this congregation, that I may consume them in a moment!" 

###### v22 
They fell on their faces, and said, "God, the God of the spirits of all flesh, shall one man sin, and will you be angry with all the congregation?" 

###### v23 
Yahweh spoke to Moses, saying, 

###### v24 
"Speak to the congregation, saying, 'Get away from around the tent of Korah, Dathan, and Abiram!'" 

###### v25 
Moses rose up and went to Dathan and Abiram; and the elders of Israel followed him. 

###### v26 
He spoke to the congregation, saying, "Depart, please, from the tents of these wicked men, and touch nothing of theirs, lest you be consumed in all their sins!" 

###### v27 
So they went away from the tent of Korah, Dathan, and Abiram, on every side. Dathan and Abiram came out, and stood at the door of their tents with their wives, their sons, and their little ones. 

###### v28 
Moses said, "Hereby you shall know that Yahweh has sent me to do all these works; for they are not from my own mind. 

###### v29 
If these men die the common death of all men, or if they experience what all men experience, then Yahweh hasn't sent me. 

###### v30 
But if Yahweh makes a new thing, and the ground opens its mouth, and swallows them up with all that belong to them, and they go down alive into Sheol, then you shall understand that these men have despised Yahweh." 

###### v31 
As he finished speaking all these words, the ground that was under them split apart. 

###### v32 
The earth opened its mouth and swallowed them up with their households, all of Korah's men, and all their goods. 

###### v33 
So they, and all that belonged to them went down alive into Sheol. The earth closed on them, and they perished from among the assembly. 

###### v34 
All Israel that were around them fled at their cry; for they said, "Lest the earth swallow us up!" 

###### v35 
Fire came out from Yahweh, and devoured the two hundred fifty men who offered the incense. 

###### v36 
Yahweh spoke to Moses, saying, 

###### v37 
"Speak to Eleazar the son of Aaron the priest, that he take up the censers out of the burning, and scatter the fire away from the camp; for they are holy, 

###### v38 
even the censers of those who sinned against their own lives. Let them be beaten into plates for a covering of the altar, for they offered them before Yahweh. Therefore they are holy. They shall be a sign to the children of Israel." 

###### v39 
Eleazar the priest took the bronze censers which those who were burned had offered; and they beat them out for a covering of the altar, 

###### v40 
to be a memorial to the children of Israel, to the end that no stranger who isn't of the offspring of Aaron, would come near to burn incense before Yahweh, that he not be as Korah and as his company; as Yahweh spoke to him by Moses. 

###### v41 
But on the next day all the congregation of the children of Israel complained against Moses and against Aaron, saying, "You have killed Yahweh's people!" 

###### v42 
When the congregation was assembled against Moses and against Aaron, they looked toward the Tent of Meeting. Behold, the cloud covered it, and Yahweh's glory appeared. 

###### v43 
Moses and Aaron came to the front of the Tent of Meeting. 

###### v44 
Yahweh spoke to Moses, saying, 

###### v45 
"Get away from among this congregation, that I may consume them in a moment!" They fell on their faces. 

###### v46 
Moses said to Aaron, "Take your censer, put fire from the altar in it, lay incense on it, carry it quickly to the congregation, and make atonement for them; for wrath has gone out from Yahweh! The plague has begun." 

###### v47 
Aaron did as Moses said, and ran into the middle of the assembly. The plague had already begun among the people. He put on the incense, and made atonement for the people. 

###### v48 
He stood between the dead and the living; and the plague was stayed. 

###### v49 
Now those who died by the plague were fourteen thousand seven hundred, in addition to those who died about the matter of Korah. 

###### v50 
Aaron returned to Moses to the door of the Tent of Meeting, and the plague was stopped.

***
[[Num-15|← Numbers 15]] | [[Numbers]] | [[Num-17|Numbers 17 →]]
