# Numbers 19

[[Num-18|← Numbers 18]] | [[Numbers]] | [[Num-20|Numbers 20 →]]
***



###### v1 
Yahweh spoke to Moses and to Aaron, saying, 

###### v2 
"This is the statute of the law which Yahweh has commanded. Tell the children of Israel to bring you a red heifer without spot, in which is no defect, and which was never yoked. 

###### v3 
You shall give her to Eleazar the priest, and he shall bring her outside of the camp, and one shall kill her before his face. 

###### v4 
Eleazar the priest shall take some of her blood with his finger, and sprinkle her blood toward the front of the Tent of Meeting seven times. 

###### v5 
One shall burn the heifer in his sight; her skin, and her meat, and her blood, with her dung, shall he burn. 

###### v6 
The priest shall take cedar wood, hyssop, and scarlet, and cast it into the middle of the burning of the heifer. 

###### v7 
Then the priest shall wash his clothes, and he shall bathe his flesh in water, and afterward he shall come into the camp, and the priest shall be unclean until the evening. 

###### v8 
He who burns her shall wash his clothes in water, and bathe his flesh in water, and shall be unclean until the evening. 

###### v9 
"A man who is clean shall gather up the ashes of the heifer, and lay them up outside of the camp in a clean place; and it shall be kept for the congregation of the children of Israel for use in water for cleansing impurity. It is a sin offering. 

###### v10 
He who gathers the ashes of the heifer shall wash his clothes, and be unclean until the evening. It shall be to the children of Israel, and to the stranger who lives as a foreigner among them, for a statute forever. 

###### v11 
"He who touches the dead body of any man shall be unclean seven days. 

###### v12 
He shall purify himself with water on the third day, and on the seventh day he shall be clean; but if he doesn't purify himself the third day, then the seventh day he shall not be clean. 

###### v13 
Whoever touches a dead person, the body of a man who has died, and doesn't purify himself, defiles Yahweh's tabernacle; and that soul shall be cut off from Israel; because the water for impurity was not sprinkled on him, he shall be unclean. His uncleanness is yet on him. 

###### v14 
"This is the law when a man dies in a tent: everyone who comes into the tent, and everyone who is in the tent, shall be unclean seven days. 

###### v15 
Every open vessel, which has no covering bound on it, is unclean. 

###### v16 
"Whoever in the open field touches one who is slain with a sword, or a dead body, or a bone of a man, or a grave, shall be unclean seven days. 

###### v17 
"For the unclean, they shall take of the ashes of the burning of the sin offering; and running water shall be poured on them in a vessel. 

###### v18 
A clean person shall take hyssop, dip it in the water, and sprinkle it on the tent, on all the vessels, on the persons who were there, and on him who touched the bone, or the slain, or the dead, or the grave. 

###### v19 
The clean person shall sprinkle on the unclean on the third day, and on the seventh day. On the seventh day, he shall purify him. He shall wash his clothes and bathe himself in water, and shall be clean at evening. 

###### v20 
But the man who shall be unclean, and shall not purify himself, that soul shall be cut off from among the assembly, because he has defiled the sanctuary of Yahweh. The water for impurity has not been sprinkled on him. He is unclean. 

###### v21 
It shall be a perpetual statute to them. He who sprinkles the water for impurity shall wash his clothes, and he who touches the water for impurity shall be unclean until evening. 

###### v22 
"Whatever the unclean person touches shall be unclean; and the soul that touches it shall be unclean until evening."

***
[[Num-18|← Numbers 18]] | [[Numbers]] | [[Num-20|Numbers 20 →]]
