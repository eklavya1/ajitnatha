# Numbers 33

[[Num-32|← Numbers 32]] | [[Numbers]] | [[Num-34|Numbers 34 →]]
***



###### v1 
These are the journeys of the children of Israel, when they went out of the land of Egypt by their armies under the hand of Moses and Aaron. 

###### v2 
Moses wrote the starting points of their journeys by the commandment of Yahweh. These are their journeys according to their starting points. 

###### v3 
They traveled from Rameses in the first month, on the fifteenth day of the first month; on the next day after the Passover, the children of Israel went out with a high hand in the sight of all the Egyptians, 

###### v4 
while the Egyptians were burying all their firstborn, whom Yahweh had struck among them. Yahweh also executed judgments on their gods. 

###### v5 
The children of Israel traveled from Rameses, and encamped in Succoth. 

###### v6 
They traveled from Succoth, and encamped in Etham, which is in the edge of the wilderness. 

###### v7 
They traveled from Etham, and turned back to Pihahiroth, which is before Baal Zephon, and they encamped before Migdol. 

###### v8 
They traveled from before Hahiroth, and crossed through the middle of the sea into the wilderness. They went three days' journey in the wilderness of Etham, and encamped in Marah. 

###### v9 
They traveled from Marah, and came to Elim. In Elim, there were twelve springs of water and seventy palm trees, and they encamped there. 

###### v10 
They traveled from Elim, and encamped by the Red Sea. 

###### v11 
They traveled from the Red Sea, and encamped in the wilderness of Sin. 

###### v12 
They traveled from the wilderness of Sin, and encamped in Dophkah. 

###### v13 
They traveled from Dophkah, and encamped in Alush. 

###### v14 
They traveled from Alush, and encamped in Rephidim, where there was no water for the people to drink. 

###### v15 
They traveled from Rephidim, and encamped in the wilderness of Sinai. 

###### v16 
They traveled from the wilderness of Sinai, and encamped in Kibroth Hattaavah. 

###### v17 
They traveled from Kibroth Hattaavah, and encamped in Hazeroth. 

###### v18 
They traveled from Hazeroth, and encamped in Rithmah. 

###### v19 
They traveled from Rithmah, and encamped in Rimmon Perez. 

###### v20 
They traveled from Rimmon Perez, and encamped in Libnah. 

###### v21 
They traveled from Libnah, and encamped in Rissah. 

###### v22 
They traveled from Rissah, and encamped in Kehelathah. 

###### v23 
They traveled from Kehelathah, and encamped in Mount Shepher. 

###### v24 
They traveled from Mount Shepher, and encamped in Haradah. 

###### v25 
They traveled from Haradah, and encamped in Makheloth. 

###### v26 
They traveled from Makheloth, and encamped in Tahath. 

###### v27 
They traveled from Tahath, and encamped in Terah. 

###### v28 
They traveled from Terah, and encamped in Mithkah. 

###### v29 
They traveled from Mithkah, and encamped in Hashmonah. 

###### v30 
They traveled from Hashmonah, and encamped in Moseroth. 

###### v31 
They traveled from Moseroth, and encamped in Bene Jaakan. 

###### v32 
They traveled from Bene Jaakan, and encamped in Hor Haggidgad. 

###### v33 
They traveled from Hor Haggidgad, and encamped in Jotbathah. 

###### v34 
They traveled from Jotbathah, and encamped in Abronah. 

###### v35 
They traveled from Abronah, and encamped in Ezion Geber. 

###### v36 
They traveled from Ezion Geber, and encamped at Kadesh in the wilderness of Zin. 

###### v37 
They traveled from Kadesh, and encamped in Mount Hor, in the edge of the land of Edom. 

###### v38 
Aaron the priest went up into Mount Hor at the commandment of Yahweh and died there, in the fortieth year after the children of Israel had come out of the land of Egypt, in the fifth month, on the first day of the month. 

###### v39 
Aaron was one hundred twenty-three years old when he died in Mount Hor. 

###### v40 
The Canaanite king of Arad, who lived in the South in the land of Canaan, heard of the coming of the children of Israel. 

###### v41 
They traveled from Mount Hor, and encamped in Zalmonah. 

###### v42 
They traveled from Zalmonah, and encamped in Punon. 

###### v43 
They traveled from Punon, and encamped in Oboth. 

###### v44 
They traveled from Oboth, and encamped in Iye Abarim, in the border of Moab. 

###### v45 
They traveled from Iyim, and encamped in Dibon Gad. 

###### v46 
They traveled from Dibon Gad, and encamped in Almon Diblathaim. 

###### v47 
They traveled from Almon Diblathaim, and encamped in the mountains of Abarim, before Nebo. 

###### v48 
They traveled from the mountains of Abarim, and encamped in the plains of Moab by the Jordan at Jericho. 

###### v49 
They encamped by the Jordan, from Beth Jeshimoth even to Abel Shittim in the plains of Moab. 

###### v50 
Yahweh spoke to Moses in the plains of Moab by the Jordan at Jericho, saying, 

###### v51 
Speak to the children of Israel, and tell them, "When you pass over the Jordan into the land of Canaan, 

###### v52 
then you shall drive out all the inhabitants of the land from before you, destroy all their stone idols, destroy all their molten images, and demolish all their high places. 

###### v53 
You shall take possession of the land, and dwell therein; for I have given the land to you to possess it. 

###### v54 
You shall inherit the land by lot according to your families; to the larger groups you shall give a larger inheritance, and to the smaller you shall give a smaller inheritance. Wherever the lot falls to any man, that shall be his. You shall inherit according to the tribes of your fathers. 

###### v55 
"But if you do not drive out the inhabitants of the land from before you, then those you let remain of them will be like pricks in your eyes and thorns in your sides. They will harass you in the land in which you dwell. 

###### v56 
It shall happen that as I thought to do to them, so I will do to you."

***
[[Num-32|← Numbers 32]] | [[Numbers]] | [[Num-34|Numbers 34 →]]
