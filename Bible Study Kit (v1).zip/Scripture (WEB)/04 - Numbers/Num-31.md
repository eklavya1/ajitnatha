# Numbers 31

[[Num-30|← Numbers 30]] | [[Numbers]] | [[Num-32|Numbers 32 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Avenge the children of Israel on the Midianites. Afterward you shall be gathered to your people." 

###### v3 
Moses spoke to the people, saying, "Arm men from among you for war, that they may go against Midian, to execute Yahweh's vengeance on Midian. 

###### v4 
You shall send one thousand out of every tribe, throughout all the tribes of Israel, to the war." 

###### v5 
So there were delivered, out of the thousands of Israel, a thousand from every tribe, twelve thousand armed for war. 

###### v6 
Moses sent them, one thousand of every tribe, to the war with Phinehas the son of Eleazar the priest, to the war, with the vessels of the sanctuary and the trumpets for the alarm in his hand. 

###### v7 
They fought against Midian, as Yahweh commanded Moses. They killed every male. 

###### v8 
They killed the kings of Midian with the rest of their slain: Evi, Rekem, Zur, Hur, and Reba, the five kings of Midian. They also killed Balaam the son of Beor with the sword. 

###### v9 
The children of Israel took the women of Midian captive with their little ones; and all their livestock, all their flocks, and all their goods, they took as plunder. 

###### v10 
All their cities in the places in which they lived, and all their encampments, they burned with fire. 

###### v11 
They took all the captives, and all the plunder, both of man and of animal. 

###### v12 
They brought the captives with the prey and the plunder, to Moses, and to Eleazar the priest, and to the congregation of the children of Israel, to the camp at the plains of Moab, which are by the Jordan at Jericho. 

###### v13 
Moses and Eleazar the priest, with all the princes of the congregation, went out to meet them outside of the camp. 

###### v14 
Moses was angry with the officers of the army, the captains of thousands and the captains of hundreds, who came from the service of the war. 

###### v15 
Moses said to them, "Have you saved all the women alive? 

###### v16 
Behold, these caused the children of Israel, through the counsel of Balaam, to commit trespass against Yahweh in the matter of Peor, and so the plague was among the congregation of Yahweh. 

###### v17 
Now therefore kill every male among the little ones, and kill every woman who has known man by lying with him. 

###### v18 
But all the girls, who have not known man by lying with him, keep alive for yourselves. 

###### v19 
"Encamp outside of the camp for seven days. Whoever has killed any person, and whoever has touched any slain, purify yourselves on the third day and on the seventh day, you and your captives. 

###### v20 
You shall purify every garment, and all that is made of skin, and all work of goats' hair, and all things made of wood." 

###### v21 
Eleazar the priest said to the men of war who went to the battle, "This is the statute of the law which Yahweh has commanded Moses. 

###### v22 
However the gold, and the silver, the bronze, the iron, the tin, and the lead, 

###### v23 
everything that may withstand the fire, you shall make to go through the fire, and it shall be clean; nevertheless it shall be purified with the water for impurity. All that doesn't withstand the fire you shall make to go through the water. 

###### v24 
You shall wash your clothes on the seventh day, and you shall be clean. Afterward you shall come into the camp." 

###### v25 
Yahweh spoke to Moses, saying, 

###### v26 
"Count the plunder that was taken, both of man and of animal, you, and Eleazar the priest, and the heads of the fathers' households of the congregation; 

###### v27 
and divide the plunder into two parts: between the men skilled in war, who went out to battle, and all the congregation. 

###### v28 
Levy a tribute to Yahweh of the men of war who went out to battle: one soul of five hundred; of the persons, of the cattle, of the donkeys, and of the flocks. 

###### v29 
Take it from their half, and give it to Eleazar the priest, for Yahweh's wave offering. 

###### v30 
Of the children of Israel's half, you shall take one drawn out of every fifty, of the persons, of the cattle, of the donkeys, and of the flocks, of all the livestock, and give them to the Levites, who perform the duty of Yahweh's tabernacle." 

###### v31 
Moses and Eleazar the priest did as Yahweh commanded Moses. 

###### v32 
Now the plunder, over and above the booty which the men of war took, was six hundred seventy-five thousand sheep, 

###### v33 
seventy-two thousand head of cattle, 

###### v34 
sixty-one thousand donkeys, 

###### v35 
and thirty-two thousand persons in all, of the women who had not known man by lying with him. 

###### v36 
The half, which was the portion of those who went out to war, was in number three hundred thirty-seven thousand five hundred sheep; 

###### v37 
and Yahweh's tribute of the sheep was six hundred seventy-five. 

###### v38 
The cattle were thirty-six thousand, of which Yahweh's tribute was seventy-two. 

###### v39 
The donkeys were thirty thousand five hundred, of which Yahweh's tribute was sixty-one. 

###### v40 
The persons were sixteen thousand, of whom Yahweh's tribute was thirty-two persons. 

###### v41 
Moses gave the tribute, which was Yahweh's wave offering, to Eleazar the priest, as Yahweh commanded Moses. 

###### v42 
Of the children of Israel's half, which Moses divided off from the men who fought 

###### v43 
(now the congregation's half was three hundred thirty-seven thousand five hundred sheep, 

###### v44 
thirty-six thousand head of cattle, 

###### v45 
thirty thousand five hundred donkeys, 

###### v46 
and sixteen thousand persons), 

###### v47 
even of the children of Israel's half, Moses took one drawn out of every fifty, both of man and of animal, and gave them to the Levites, who performed the duty of Yahweh's tabernacle, as Yahweh commanded Moses. 

###### v48 
The officers who were over the thousands of the army, the captains of thousands, and the captains of hundreds, came near to Moses. 

###### v49 
They said to Moses, "Your servants have taken the sum of the men of war who are under our command, and there lacks not one man of us. 

###### v50 
We have brought Yahweh's offering, what every man found: gold ornaments, armlets, bracelets, signet rings, earrings, and necklaces, to make atonement for our souls before Yahweh." 

###### v51 
Moses and Eleazar the priest took their gold, even all worked jewels. 

###### v52 
All the gold of the wave offering that they offered up to Yahweh, of the captains of thousands, and of the captains of hundreds, was sixteen thousand seven hundred fifty shekels. 

###### v53 
The men of war had taken booty, every man for himself. 

###### v54 
Moses and Eleazar the priest took the gold of the captains of thousands and of hundreds, and brought it into the Tent of Meeting for a memorial for the children of Israel before Yahweh.

***
[[Num-30|← Numbers 30]] | [[Numbers]] | [[Num-32|Numbers 32 →]]
