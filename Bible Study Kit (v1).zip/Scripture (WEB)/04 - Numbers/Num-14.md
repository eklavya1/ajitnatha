# Numbers 14

[[Num-13|← Numbers 13]] | [[Numbers]] | [[Num-15|Numbers 15 →]]
***



###### v1 
All the congregation lifted up their voice, and cried; and the people wept that night. 

###### v2 
All the children of Israel murmured against Moses and against Aaron. The whole congregation said to them, "We wish that we had died in the land of Egypt, or that we had died in this wilderness! 

###### v3 
Why does Yahweh bring us to this land, to fall by the sword? Our wives and our little ones will be captured or killed! Wouldn't it be better for us to return into Egypt?" 

###### v4 
They said to one another, "Let's choose a leader, and let's return into Egypt." 

###### v5 
Then Moses and Aaron fell on their faces before all the assembly of the congregation of the children of Israel. 

###### v6 
Joshua the son of Nun and Caleb the son of Jephunneh, who were of those who spied out the land, tore their clothes. 

###### v7 
They spoke to all the congregation of the children of Israel, saying, "The land, which we passed through to spy it out, is an exceedingly good land. 

###### v8 
If Yahweh delights in us, then he will bring us into this land, and give it to us: a land which flows with milk and honey. 

###### v9 
Only don't rebel against Yahweh, neither fear the people of the land; for they are bread for us. Their defense is removed from over them, and Yahweh is with us. Don't fear them." 

###### v10 
But all the congregation threatened to stone them with stones. Yahweh's glory appeared in the Tent of Meeting to all the children of Israel. 

###### v11 
Yahweh said to Moses, "How long will this people despise me? How long will they not believe in me, for all the signs which I have worked among them? 

###### v12 
I will strike them with the pestilence, and disinherit them, and will make of you a nation greater and mightier than they." 

###### v13 
Moses said to Yahweh, "Then the Egyptians will hear it; for you brought up this people in your might from among them. 

###### v14 
They will tell it to the inhabitants of this land. They have heard that you Yahweh are among this people; for you Yahweh are seen face to face, and your cloud stands over them, and you go before them, in a pillar of cloud by day, and in a pillar of fire by night. 

###### v15 
Now if you killed this people as one man, then the nations which have heard the fame of you will speak, saying, 

###### v16 
'Because Yahweh was not able to bring this people into the land which he swore to them, therefore he has slain them in the wilderness.' 

###### v17 
Now please let the power of the Lord be great, according as you have spoken, saying, 

###### v18 
'Yahweh is slow to anger, and abundant in loving kindness, forgiving iniquity and disobedience; and he will by no means clear the guilty, visiting the iniquity of the fathers on the children, on the third and on the fourth generation.' 

###### v19 
Please pardon the iniquity of this people according to the greatness of your loving kindness, and just as you have forgiven this people, from Egypt even until now." 

###### v20 
Yahweh said, "I have pardoned according to your word; 

###### v21 
but in very deed--as I live, and as all the earth shall be filled with Yahweh's glory-- 

###### v22 
because all those men who have seen my glory and my signs, which I worked in Egypt and in the wilderness, yet have tempted me these ten times, and have not listened to my voice; 

###### v23 
surely they shall not see the land which I swore to their fathers, neither shall any of those who despised me see it. 

###### v24 
But my servant Caleb, because he had another spirit with him, and has followed me fully, him I will bring into the land into which he went. His offspring shall possess it. 

###### v25 
Since the Amalekite and the Canaanite dwell in the valley, tomorrow turn and go into the wilderness by the way to the Red Sea." 

###### v26 
Yahweh spoke to Moses and to Aaron, saying, 

###### v27 
"How long shall I bear with this evil congregation that complain against me? I have heard the complaints of the children of Israel, which they complain against me. 

###### v28 
Tell them, 'As I live, says Yahweh, surely as you have spoken in my ears, so I will do to you. 

###### v29 
Your dead bodies shall fall in this wilderness; and all who were counted of you, according to your whole number, from twenty years old and upward, who have complained against me, 

###### v30 
surely you shall not come into the land concerning which I swore that I would make you dwell therein, except Caleb the son of Jephunneh, and Joshua the son of Nun. 

###### v31 
But I will bring in your little ones that you said should be captured or killed, and they shall know the land which you have rejected. 

###### v32 
But as for you, your dead bodies shall fall in this wilderness. 

###### v33 
Your children shall be wanderers in the wilderness forty years, and shall bear your prostitution, until your dead bodies are consumed in the wilderness. 

###### v34 
After the number of the days in which you spied out the land, even forty days, for every day a year, you will bear your iniquities, even forty years, and you will know my alienation.' 

###### v35 
I, Yahweh, have spoken. I will surely do this to all this evil congregation who are gathered together against me. In this wilderness they shall be consumed, and there they shall die." 

###### v36 
The men whom Moses sent to spy out the land, who returned and made all the congregation to murmur against him by bringing up an evil report against the land, 

###### v37 
even those men who brought up an evil report of the land, died by the plague before Yahweh. 

###### v38 
But Joshua the son of Nun and Caleb the son of Jephunneh remained alive of those men who went to spy out the land. 

###### v39 
Moses told these words to all the children of Israel, and the people mourned greatly. 

###### v40 
They rose up early in the morning and went up to the top of the mountain, saying, "Behold, we are here, and will go up to the place which Yahweh has promised; for we have sinned." 

###### v41 
Moses said, "Why now do you disobey the commandment of Yahweh, since it shall not prosper? 

###### v42 
Don't go up, for Yahweh isn't among you; that way you won't be struck down before your enemies. 

###### v43 
For there the Amalekite and the Canaanite are before you, and you will fall by the sword because you turned back from following Yahweh; therefore Yahweh will not be with you." 

###### v44 
But they presumed to go up to the top of the mountain. Nevertheless, the ark of Yahweh's covenant and Moses didn't depart out of the camp. 

###### v45 
Then the Amalekites came down, and the Canaanites who lived in that mountain, and struck them and beat them down even to Hormah.

***
[[Num-13|← Numbers 13]] | [[Numbers]] | [[Num-15|Numbers 15 →]]
