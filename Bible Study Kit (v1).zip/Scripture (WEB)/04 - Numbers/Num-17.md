# Numbers 17

[[Num-16|← Numbers 16]] | [[Numbers]] | [[Num-18|Numbers 18 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Speak to the children of Israel, and take rods from them, one for each fathers' house, of all their princes according to their fathers' houses, twelve rods. Write each man's name on his rod. 

###### v3 
You shall write Aaron's name on Levi's rod. There shall be one rod for each head of their fathers' houses. 

###### v4 
You shall lay them up in the Tent of Meeting before the covenant, where I meet with you. 

###### v5 
It shall happen that the rod of the man whom I shall choose shall bud. I will make the murmurings of the children of Israel, which they murmur against you, cease from me." 

###### v6 
Moses spoke to the children of Israel; and all their princes gave him rods, for each prince one, according to their fathers' houses, a total of twelve rods. Aaron's rod was among their rods. 

###### v7 
Moses laid up the rods before Yahweh in the Tent of the Testimony. 

###### v8 
On the next day, Moses went into the Tent of the Testimony; and behold, Aaron's rod for the house of Levi had sprouted, budded, produced blossoms, and bore ripe almonds. 

###### v9 
Moses brought out all the rods from before Yahweh to all the children of Israel. They looked, and each man took his rod. 

###### v10 
Yahweh said to Moses, "Put back the rod of Aaron before the covenant, to be kept for a token against the children of rebellion; that you may make an end of their complaining against me, that they not die." 

###### v11 
Moses did so. As Yahweh commanded him, so he did. 

###### v12 
The children of Israel spoke to Moses, saying, "Behold, we perish! We are undone! We are all undone! 

###### v13 
Everyone who keeps approaching Yahweh's tabernacle, dies! Will we all perish?"

***
[[Num-16|← Numbers 16]] | [[Numbers]] | [[Num-18|Numbers 18 →]]
