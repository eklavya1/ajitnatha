# Numbers 5

[[Num-04|← Numbers 04]] | [[Numbers]] | [[Num-06|Numbers 06 →]]
***



###### v1 
Yahweh spoke to Moses, saying, 

###### v2 
"Command the children of Israel that they put out of the camp every leper, everyone who has a discharge, and whoever is unclean by a corpse. 

###### v3 
You shall put both male and female outside of the camp so that they don't defile their camp, in the midst of which I dwell." 

###### v4 
The children of Israel did so, and put them outside of the camp; as Yahweh spoke to Moses, so the children of Israel did. 

###### v5 
Yahweh spoke to Moses, saying, 

###### v6 
"Speak to the children of Israel: 'When a man or woman commits any sin that men commit, so as to trespass against Yahweh, and that soul is guilty, 

###### v7 
then he shall confess his sin which he has done; and he shall make restitution for his guilt in full, add to it the fifth part of it, and give it to him in respect of whom he has been guilty. 

###### v8 
But if the man has no kinsman to whom restitution may be made for the guilt, the restitution for guilt which is made to Yahweh shall be the priest's, in addition to the ram of the atonement, by which atonement shall be made for him. 

###### v9 
Every heave offering of all the holy things of the children of Israel, which they present to the priest, shall be his. 

###### v10 
Every man's holy things shall be his; whatever any man gives the priest, it shall be his.'" 

###### v11 
Yahweh spoke to Moses, saying, 

###### v12 
"Speak to the children of Israel, and tell them: 'If any man's wife goes astray and is unfaithful to him, 

###### v13 
and a man lies with her carnally, and it is hidden from the eyes of her husband and this is kept concealed, and she is defiled, there is no witness against her, and she isn't taken in the act; 

###### v14 
and the spirit of jealousy comes on him, and he is jealous of his wife and she is defiled; or if the spirit of jealousy comes on him, and he is jealous of his wife and she isn't defiled; 

###### v15 
then the man shall bring his wife to the priest, and shall bring her offering for her: one tenth of an ephah of barley meal. He shall pour no oil on it, nor put frankincense on it, for it is a meal offering of jealousy, a meal offering of memorial, bringing iniquity to memory. 

###### v16 
The priest shall bring her near, and set her before Yahweh. 

###### v17 
The priest shall take holy water in an earthen vessel; and the priest shall take some of the dust that is on the floor of the tabernacle and put it into the water. 

###### v18 
The priest shall set the woman before Yahweh, and let the hair of the woman's head go loose, and put the meal offering of memorial in her hands, which is the meal offering of jealousy. The priest shall have in his hand the water of bitterness that brings a curse. 

###### v19 
The priest shall cause her to take an oath and shall tell the woman, "If no man has lain with you, and if you haven't gone aside to uncleanness, being under your husband's authority, be free from this water of bitterness that brings a curse. 

###### v20 
But if you have gone astray, being under your husband's authority, and if you are defiled, and some man has lain with you besides your husband--" 

###### v21 
then the priest shall cause the woman to swear with the oath of cursing, and the priest shall tell the woman, "May Yahweh make you a curse and an oath among your people, when Yahweh allows your thigh to fall away, and your body to swell; 

###### v22 
and this water that brings a curse will go into your bowels, and make your body swell, and your thigh fall away." The woman shall say, "Amen, Amen." 

###### v23 
"'The priest shall write these curses in a book, and he shall wipe them into the water of bitterness. 

###### v24 
He shall make the woman drink the water of bitterness that causes the curse; and the water that causes the curse shall enter into her and become bitter. 

###### v25 
The priest shall take the meal offering of jealousy out of the woman's hand, and shall wave the meal offering before Yahweh, and bring it to the altar. 

###### v26 
The priest shall take a handful of the meal offering, as its memorial portion, and burn it on the altar, and afterward shall make the woman drink the water. 

###### v27 
When he has made her drink the water, then it shall happen, if she is defiled and has committed a trespass against her husband, that the water that causes the curse will enter into her and become bitter, and her body will swell, and her thigh will fall away; and the woman will be a curse among her people. 

###### v28 
If the woman isn't defiled, but is clean; then she shall be free, and shall conceive offspring. 

###### v29 
"'This is the law of jealousy, when a wife, being under her husband, goes astray, and is defiled, 

###### v30 
or when the spirit of jealousy comes on a man, and he is jealous of his wife; then he shall set the woman before Yahweh, and the priest shall execute on her all this law. 

###### v31 
The man shall be free from iniquity, and that woman shall bear her iniquity.'"

***
[[Num-04|← Numbers 04]] | [[Numbers]] | [[Num-06|Numbers 06 →]]
