# Numbers 21

[[Num-20|← Numbers 20]] | [[Numbers]] | [[Num-22|Numbers 22 →]]
***



###### v1 
The Canaanite, the king of Arad, who lived in the South, heard that Israel came by the way of Atharim. He fought against Israel, and took some of them captive. 

###### v2 
Israel vowed a vow to Yahweh, and said, "If you will indeed deliver this people into my hand, then I will utterly destroy their cities." 

###### v3 
Yahweh listened to the voice of Israel, and delivered up the Canaanites; and they utterly destroyed them and their cities. The name of the place was called Hormah. 

###### v4 
They traveled from Mount Hor by the way to the Red Sea, to go around the land of Edom. The soul of the people was very discouraged because of the journey. 

###### v5 
The people spoke against God and against Moses: "Why have you brought us up out of Egypt to die in the wilderness? For there is no bread, there is no water, and our soul loathes this disgusting food!" 

###### v6 
Yahweh sent venomous snakes among the people, and they bit the people. Many people of Israel died. 

###### v7 
The people came to Moses, and said, "We have sinned, because we have spoken against Yahweh and against you. Pray to Yahweh, that he take away the serpents from us." Moses prayed for the people. 

###### v8 
Yahweh said to Moses, "Make a venomous snake, and set it on a pole. It shall happen that everyone who is bitten, when he sees it, shall live." 

###### v9 
Moses made a serpent of bronze, and set it on the pole. If a serpent had bitten any man, when he looked at the serpent of bronze, he lived. 

###### v10 
The children of Israel traveled, and encamped in Oboth. 

###### v11 
They traveled from Oboth, and encamped at Iyeabarim, in the wilderness which is before Moab, toward the sunrise. 

###### v12 
From there they traveled, and encamped in the valley of Zered. 

###### v13 
From there they traveled, and encamped on the other side of the Arnon, which is in the wilderness that comes out of the border of the Amorites; for the Arnon is the border of Moab, between Moab and the Amorites. 

###### v14 
Therefore it is said in <bk>The Book of the Wars of Yahweh</bk>, "Vaheb in Suphah, the valleys of the Arnon, 

###### v15 
the slope of the valleys that incline toward the dwelling of Ar, leans on the border of Moab." 

###### v16 
From there they traveled to Beer; that is the well of which Yahweh said to Moses, "Gather the people together, and I will give them water." 

###### v17 
Then Israel sang this song: "Spring up, well! Sing to it, 

###### v18 
the well, which the princes dug, which the nobles of the people dug, with the scepter, and with their poles." From the wilderness they traveled to Mattanah; 

###### v19 
and from Mattanah to Nahaliel; and from Nahaliel to Bamoth; 

###### v20 
and from Bamoth to the valley that is in the field of Moab, to the top of Pisgah, which looks down on the desert. 

###### v21 
Israel sent messengers to Sihon king of the Amorites, saying, 

###### v22 
"Let me pass through your land. We will not turn away into field or vineyard. We will not drink of the water of the wells. We will go by the king's highway, until we have passed your border." 

###### v23 
Sihon would not allow Israel to pass through his border, but Sihon gathered all his people together, and went out against Israel into the wilderness, and came to Jahaz. He fought against Israel. 

###### v24 
Israel struck him with the edge of the sword, and possessed his land from the Arnon to the Jabbok, even to the children of Ammon; for the border of the children of Ammon was fortified. 

###### v25 
Israel took all these cities. Israel lived in all the cities of the Amorites, in Heshbon, and in all its villages. 

###### v26 
For Heshbon was the city of Sihon the king of the Amorites, who had fought against the former king of Moab, and taken all his land out of his hand, even to the Arnon. 

###### v27 
Therefore those who speak in proverbs say, "Come to Heshbon. Let the city of Sihon be built and established; 

###### v28 
for a fire has gone out of Heshbon, a flame from the city of Sihon. It has devoured Ar of Moab, The lords of the high places of the Arnon. 

###### v29 
Woe to you, Moab! You are undone, people of Chemosh! He has given his sons as fugitives, and his daughters into captivity, to Sihon king of the Amorites. 

###### v30 
We have shot at them. Heshbon has perished even to Dibon. We have laid waste even to Nophah, Which reaches to Medeba." 

###### v31 
Thus Israel lived in the land of the Amorites. 

###### v32 
Moses sent to spy out Jazer. They took its villages, and drove out the Amorites who were there. 

###### v33 
They turned and went up by the way of Bashan. Og the king of Bashan went out against them, he and all his people, to battle at Edrei. 

###### v34 
Yahweh said to Moses, "Don't fear him, for I have delivered him into your hand, with all his people, and his land. You shall do to him as you did to Sihon king of the Amorites, who lived at Heshbon." 

###### v35 
So they struck him, with his sons and all his people, until there were no survivors; and they possessed his land.

***
[[Num-20|← Numbers 20]] | [[Numbers]] | [[Num-22|Numbers 22 →]]
