# Numbers 30

[[Num-29|← Numbers 29]] | [[Numbers]] | [[Num-31|Numbers 31 →]]
***



###### v1 
Moses spoke to the heads of the tribes of the children of Israel, saying, "This is the thing which Yahweh has commanded. 

###### v2 
When a man vows a vow to Yahweh, or swears an oath to bind his soul with a bond, he shall not break his word. He shall do according to all that proceeds out of his mouth. 

###### v3 
"Also, when a woman vows a vow to Yahweh and binds herself by a pledge, being in her father's house, in her youth, 

###### v4 
and her father hears her vow and her pledge with which she has bound her soul, and her father says nothing to her, then all her vows shall stand, and every pledge with which she has bound her soul shall stand. 

###### v5 
But if her father forbids her in the day that he hears, none of her vows or of her pledges with which she has bound her soul, shall stand. Yahweh will forgive her, because her father has forbidden her. 

###### v6 
"If she has a husband, while her vows are on her, or the rash utterance of her lips with which she has bound her soul, 

###### v7 
and her husband hears it, and says nothing to her in the day that he hears it; then her vows shall stand, and her pledges with which she has bound her soul shall stand. 

###### v8 
But if her husband forbids her in the day that he hears it, then he makes void her vow which is on her and the rash utterance of her lips, with which she has bound her soul. Yahweh will forgive her. 

###### v9 
"But the vow of a widow, or of her who is divorced, everything with which she has bound her soul shall stand against her. 

###### v10 
"If she vowed in her husband's house or bound her soul by a bond with an oath, 

###### v11 
and her husband heard it, and held his peace at her and didn't disallow her, then all her vows shall stand, and every pledge with which she bound her soul shall stand. 

###### v12 
But if her husband made them null and void in the day that he heard them, then whatever proceeded out of her lips concerning her vows, or concerning the bond of her soul, shall not stand. Her husband has made them void. Yahweh will forgive her. 

###### v13 
Every vow, and every binding oath to afflict the soul, her husband may establish it, or her husband may make it void. 

###### v14 
But if her husband says nothing to her from day to day, then he establishes all her vows or all her pledges which are on her. He has established them, because he said nothing to her in the day that he heard them. 

###### v15 
But if he makes them null and void after he has heard them, then he shall bear her iniquity." 

###### v16 
These are the statutes which Yahweh commanded Moses, between a man and his wife, between a father and his daughter, being in her youth, in her father's house.

***
[[Num-29|← Numbers 29]] | [[Numbers]] | [[Num-31|Numbers 31 →]]
