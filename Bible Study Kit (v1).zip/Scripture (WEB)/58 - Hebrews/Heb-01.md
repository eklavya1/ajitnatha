# Hebrews 1

[[Hebrews]] | [[Heb-02|Hebrews 02 →]]
***



###### v1 
God, having in the past spoken to the fathers through the prophets at many times and in various ways, 

###### v2 
has at the end of these days spoken to us by his Son, whom he appointed heir of all things, through whom also he made the worlds. 

###### v3 
His Son is the radiance of his glory, the very image of his substance, and upholding all things by the word of his power, who, when he had by himself purified us of our sins, sat down on the right hand of the Majesty on high, 

###### v4 
having become as much better than the angels as the more excellent name he has inherited is better than theirs. 

###### v5 
For to which of the angels did he say at any time, "You are my Son. Today I have become your father?" 

###### v6 
When he again brings in the firstborn into the world he says, "Let all the angels of God worship him." 

###### v7 
Of the angels he says, "He makes his angels winds, and his servants a flame of fire." 

###### v8 
But of the Son he says, "Your throne, O God, is forever and ever. The scepter of uprightness is the scepter of your Kingdom. 

###### v9 
You have loved righteousness and hated iniquity; therefore God, your God, has anointed you with the oil of gladness above your fellows." 

###### v10 
And, "You, Lord, in the beginning, laid the foundation of the earth. The heavens are the works of your hands. 

###### v11 
They will perish, but you continue. They all will grow old like a garment does. 

###### v12 
You will roll them up like a mantle, and they will be changed; but you are the same. Your years won't fail." 

###### v13 
But which of the angels has he told at any time, "Sit at my right hand, until I make your enemies the footstool of your feet?" 

###### v14 
Aren't they all serving spirits, sent out to do service for the sake of those who will inherit salvation?

***
[[Hebrews]] | [[Heb-02|Hebrews 02 →]]
