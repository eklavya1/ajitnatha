# Hebrews 9

[[Heb-08|← Hebrews 08]] | [[Hebrews]] | [[Heb-10|Hebrews 10 →]]
***



###### v1 
Now indeed even the first covenant had ordinances of divine service and an earthly sanctuary. 

###### v2 
For a tabernacle was prepared. In the first part were the lamp stand, the table, and the show bread; which is called the Holy Place. 

###### v3 
After the second veil was the tabernacle which is called the Holy of Holies, 

###### v4 
having a golden altar of incense, and the ark of the covenant overlaid on all sides with gold, in which was a golden pot holding the manna, Aaron's rod that budded, and the tablets of the covenant; 

###### v5 
and above it cherubim of glory overshadowing the mercy seat, of which things we can't speak now in detail. 

###### v6 
Now these things having been thus prepared, the priests go in continually into the first tabernacle, accomplishing the services, 

###### v7 
but into the second the high priest alone, once in the year, not without blood, which he offers for himself, and for the errors of the people. 

###### v8 
The Holy Spirit is indicating this, that the way into the Holy Place wasn't yet revealed while the first tabernacle was still standing. 

###### v9 
This is a symbol of the present age, where gifts and sacrifices are offered that are incapable, concerning the conscience, of making the worshiper perfect, 

###### v10 
being only (with meats and drinks and various washings) fleshly ordinances, imposed until a time of reformation. 

###### v11 
But Christ having come as a high priest of the coming good things, through the greater and more perfect tabernacle, not made with hands, that is to say, not of this creation, 

###### v12 
nor yet through the blood of goats and calves, but through his own blood, entered in once for all into the Holy Place, having obtained eternal redemption. 

###### v13 
For if the blood of goats and bulls, and the ashes of a heifer sprinkling those who have been defiled, sanctify to the cleanness of the flesh, 

###### v14 
how much more will the blood of Christ, who through the eternal Spirit offered himself without defect to God, cleanse your conscience from dead works to serve the living God? 

###### v15 
For this reason he is the mediator of a new covenant, since a death has occurred for the redemption of the transgressions that were under the first covenant, that those who have been called may receive the promise of the eternal inheritance. 

###### v16 
For where a last will and testament is, there must of necessity be the death of him who made it. 

###### v17 
For a will is in force where there has been death, for it is never in force while he who made it lives. 

###### v18 
Therefore even the first covenant has not been dedicated without blood. 

###### v19 
For when every commandment had been spoken by Moses to all the people according to the law, he took the blood of the calves and the goats, with water and scarlet wool and hyssop, and sprinkled both the book itself and all the people, 

###### v20 
saying, "This is the blood of the covenant which God has commanded you." 

###### v21 
Moreover he sprinkled the tabernacle and all the vessels of the ministry in the same way with the blood. 

###### v22 
According to the law, nearly everything is cleansed with blood, and apart from shedding of blood there is no remission. 

###### v23 
It was necessary therefore that the copies of the things in the heavens should be cleansed with these, but the heavenly things themselves with better sacrifices than these. 

###### v24 
For Christ hasn't entered into holy places made with hands, which are representations of the true, but into heaven itself, now to appear in the presence of God for us; 

###### v25 
nor yet that he should offer himself often, as the high priest enters into the holy place year by year with blood not his own, 

###### v26 
or else he must have suffered often since the foundation of the world. But now once at the end of the ages, he has been revealed to put away sin by the sacrifice of himself. 

###### v27 
Inasmuch as it is appointed for men to die once, and after this, judgment, 

###### v28 
so Christ also, having been offered once to bear the sins of many, will appear a second time, without sin, to those who are eagerly waiting for him for salvation.

***
[[Heb-08|← Hebrews 08]] | [[Hebrews]] | [[Heb-10|Hebrews 10 →]]
