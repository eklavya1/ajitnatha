# Hebrews 8

[[Heb-07|← Hebrews 07]] | [[Hebrews]] | [[Heb-09|Hebrews 09 →]]
***



###### v1 
Now in the things which we are saying, the main point is this. We have such a high priest, who sat down on the right hand of the throne of the Majesty in the heavens, 

###### v2 
a servant of the sanctuary and of the true tabernacle, which the Lord pitched, not man. 

###### v3 
For every high priest is appointed to offer both gifts and sacrifices. Therefore it is necessary that this high priest also have something to offer. 

###### v4 
For if he were on earth, he would not be a priest at all, seeing there are priests who offer the gifts according to the law, 

###### v5 
who serve a copy and shadow of the heavenly things, even as Moses was warned by God when he was about to make the tabernacle, for he said, "See, you shall make everything according to the pattern that was shown to you on the mountain." 

###### v6 
But now he has obtained a more excellent ministry, by so much as he is also the mediator of a better covenant, which on better promises has been given as law. 

###### v7 
For if that first covenant had been faultless, then no place would have been sought for a second. 

###### v8 
For finding fault with them, he said, "Behold, the days come", says the Lord, "that I will make a new covenant with the house of Israel and with the house of Judah; 

###### v9 
not according to the covenant that I made with their fathers, in the day that I took them by the hand to lead them out of the land of Egypt; for they didn't continue in my covenant, and I disregarded them," says the Lord. 

###### v10 
"For this is the covenant that I will make with the house of Israel. After those days," says the Lord; "I will put my laws into their mind, I will also write them on their heart. I will be their God, and they will be my people. 

###### v11 
They will not teach every man his fellow citizen, and every man his brother, saying, 'Know the Lord,' for all will know me, from their least to their greatest. 

###### v12 
For I will be merciful to their unrighteousness. I will remember their sins and lawless deeds no more." 

###### v13 
In that he says, "A new covenant", he has made the first old. But that which is becoming old and grows aged is near to vanishing away.

***
[[Heb-07|← Hebrews 07]] | [[Hebrews]] | [[Heb-09|Hebrews 09 →]]
