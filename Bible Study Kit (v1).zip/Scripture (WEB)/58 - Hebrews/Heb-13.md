# Hebrews 13

[[Heb-12|← Hebrews 12]] | [[Hebrews]]
***



###### v1 
Let brotherly love continue. 

###### v2 
Don't forget to show hospitality to strangers, for in doing so, some have entertained angels without knowing it. 

###### v3 
Remember those who are in bonds, as bound with them, and those who are ill-treated, since you are also in the body. 

###### v4 
Let marriage be held in honor among all, and let the bed be undefiled; but God will judge the sexually immoral and adulterers. 

###### v5 
Be free from the love of money, content with such things as you have, for he has said, "I will in no way leave you, neither will I in any way forsake you." 

###### v6 
So that with good courage we say, "The Lord is my helper. I will not fear. What can man do to me?" 

###### v7 
Remember your leaders, men who spoke to you the word of God, and considering the results of their conduct, imitate their faith. 

###### v8 
Jesus Christ is the same yesterday, today, and forever. 

###### v9 
Don't be carried away by various and strange teachings, for it is good that the heart be established by grace, not by food, through which those who were so occupied were not benefited. 

###### v10 
We have an altar from which those who serve the holy tabernacle have no right to eat. 

###### v11 
For the bodies of those animals, whose blood is brought into the holy place by the high priest as an offering for sin, are burned outside of the camp. 

###### v12 
Therefore Jesus also, that he might sanctify the people through his own blood, suffered outside of the gate. 

###### v13 
Let's therefore go out to him outside of the camp, bearing his reproach. 

###### v14 
For we don't have here an enduring city, but we seek that which is to come. 

###### v15 
Through him, then, let's offer up a sacrifice of praise to God  continually, that is, the fruit of lips which proclaim allegiance to his name. 

###### v16 
But don't forget to be doing good and sharing, for with such sacrifices God is well pleased. 

###### v17 
Obey your leaders and submit to them, for they watch on behalf of your souls, as those who will give account, that they may do this with joy, and not with groaning, for that would be unprofitable for you. 

###### v18 
Pray for us, for we are persuaded that we have a good conscience, desiring to live honorably in all things. 

###### v19 
I strongly urge you to do this, that I may be restored to you sooner. 

###### v20 
Now may the God of peace, who brought again from the dead the great shepherd of the sheep with the blood of an eternal covenant, our Lord Jesus, 

###### v21 
make you complete in every good work to do his will, working in you that which is well pleasing in his sight, through Jesus Christ, to whom be the glory forever and ever. Amen. 

###### v22 
But I exhort you, brothers, endure the word of exhortation; for I have written to you in few words. 

###### v23 
Know that our brother Timothy has been freed, with whom, if he comes shortly, I will see you. 

###### v24 
Greet all of your leaders and all the saints. The Italians greet you. 

###### v25 
Grace be with you all. Amen.

***
[[Heb-12|← Hebrews 12]] | [[Hebrews]]
