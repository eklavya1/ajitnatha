# Hebrews 5

[[Heb-04|← Hebrews 04]] | [[Hebrews]] | [[Heb-06|Hebrews 06 →]]
***



###### v1 
For every high priest, being taken from among men, is appointed for men in things pertaining to God, that he may offer both gifts and sacrifices for sins. 

###### v2 
The high priest can deal gently with those who are ignorant and going astray, because he himself is also surrounded with weakness. 

###### v3 
Because of this, he must offer sacrifices for sins for the people, as well as for himself. 

###### v4 
Nobody takes this honor on himself, but he is called by God, just like Aaron was. 

###### v5 
So also Christ didn't glorify himself to be made a high priest, but it was he who said to him, "You are my Son. Today I have become your father." 

###### v6 
As he says also in another place, "You are a priest forever, after the order of Melchizedek." 

###### v7 
He, in the days of his flesh, having offered up prayers and petitions with strong crying and tears to him who was able to save him from death, and having been heard for his godly fear, 

###### v8 
though he was a Son, yet learned obedience by the things which he suffered. 

###### v9 
Having been made perfect, he became to all of those who obey him the author of eternal salvation, 

###### v10 
named by God a high priest after the order of Melchizedek. 

###### v11 
About him we have many words to say, and hard to interpret, seeing you have become dull of hearing. 

###### v12 
For although by this time you should be teachers, you again need to have someone teach you the rudiments of the first principles of the revelations of God. You have come to need milk, and not solid food. 

###### v13 
For everyone who lives on milk is not experienced in the word of righteousness, for he is a baby. 

###### v14 
But solid food is for those who are full grown, who by reason of use have their senses exercised to discern good and evil.

***
[[Heb-04|← Hebrews 04]] | [[Hebrews]] | [[Heb-06|Hebrews 06 →]]
