# Hebrews 3

[[Heb-02|← Hebrews 02]] | [[Hebrews]] | [[Heb-04|Hebrews 04 →]]
***



###### v1 
Therefore, holy brothers, partakers of a heavenly calling, consider the Apostle and High Priest of our confession: Jesus, 

###### v2 
who was faithful to him who appointed him, as also Moses was in all his house. 

###### v3 
For he has been counted worthy of more glory than Moses, because he who built the house has more honor than the house. 

###### v4 
For every house is built by someone; but he who built all things is God. 

###### v5 
Moses indeed was faithful in all his house as a servant, for a testimony of those things which were afterward to be spoken, 

###### v6 
but Christ is faithful as a Son over his house. We are his house, if we hold fast our confidence and the glorying of our hope firm to the end. 

###### v7 
Therefore, even as the Holy Spirit says, "Today if you will hear his voice, 

###### v8 
don't harden your hearts, as in the rebellion, in the day of the trial in the wilderness, 

###### v9 
where your fathers tested me and tried me, and saw my deeds for forty years. 

###### v10 
Therefore I was displeased with that generation, and said, 'They always err in their heart, but they didn't know my ways.' 

###### v11 
As I swore in my wrath, 'They will not enter into my rest.'" 

###### v12 
Beware, brothers, lest perhaps there might be in any one of you an evil heart of unbelief, in falling away from the living God; 

###### v13 
but exhort one another day by day, so long as it is called "today", lest any one of you be hardened by the deceitfulness of sin. 

###### v14 
For we have become partakers of Christ, if we hold the beginning of our confidence firm to the end, 

###### v15 
while it is said, "Today if you will hear his voice, don't harden your hearts, as in the rebellion." 

###### v16 
For who, when they heard, rebelled? Wasn't it all those who came out of Egypt led by Moses? 

###### v17 
With whom was he displeased forty years? Wasn't it with those who sinned, whose bodies fell in the wilderness? 

###### v18 
To whom did he swear that they wouldn't enter into his rest, but to those who were disobedient? 

###### v19 
We see that they weren't able to enter in because of unbelief.

***
[[Heb-02|← Hebrews 02]] | [[Hebrews]] | [[Heb-04|Hebrews 04 →]]
