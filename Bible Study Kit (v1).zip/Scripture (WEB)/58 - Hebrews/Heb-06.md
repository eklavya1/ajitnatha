# Hebrews 6

[[Heb-05|← Hebrews 05]] | [[Hebrews]] | [[Heb-07|Hebrews 07 →]]
***



###### v1 
Therefore leaving the teaching of the first principles of Christ, let's press on to perfection--not laying again a foundation of repentance from dead works, of faith toward God, 

###### v2 
of the teaching of baptisms, of laying on of hands, of resurrection of the dead, and of eternal judgment. 

###### v3 
This will we do, if God permits. 

###### v4 
For concerning those who were once enlightened and tasted of the heavenly gift, and were made partakers of the Holy Spirit, 

###### v5 
and tasted the good word of God and the powers of the age to come, 

###### v6 
and then fell away, it is impossible to renew them again to repentance; seeing they crucify the Son of God for themselves again, and put him to open shame. 

###### v7 
For the land which has drunk the rain that comes often on it and produces a crop suitable for them for whose sake it is also tilled, receives blessing from God; 

###### v8 
but if it bears thorns and thistles, it is rejected and near being cursed, whose end is to be burned. 

###### v9 
But, beloved, we are persuaded of better things for you, and things that accompany salvation, even though we speak like this. 

###### v10 
For God is not unrighteous, so as to forget your work and the labor of love which you showed toward his name, in that you served the saints, and still do serve them. 

###### v11 
We desire that each one of you may show the same diligence to the fullness of hope even to the end, 

###### v12 
that you won't be sluggish, but imitators of those who through faith and perseverance inherited the promises. 

###### v13 
For when God made a promise to Abraham, since he could swear by no one greater, he swore by himself, 

###### v14 
saying, "Surely blessing I will bless you, and multiplying I will multiply you." 

###### v15 
Thus, having patiently endured, he obtained the promise. 

###### v16 
For men indeed swear by a greater one, and in every dispute of theirs the oath is final for confirmation. 

###### v17 
In this way God, being determined to show more abundantly to the heirs of the promise the immutability of his counsel, interposed with an oath, 

###### v18 
that by two immutable things, in which it is impossible for God to lie, we may have a strong encouragement, who have fled for refuge to take hold of the hope set before us. 

###### v19 
This hope we have as an anchor of the soul, a hope both sure and steadfast and entering into that which is within the veil; 

###### v20 
where as a forerunner Jesus entered for us, having become a high priest forever after the order of Melchizedek.

***
[[Heb-05|← Hebrews 05]] | [[Hebrews]] | [[Heb-07|Hebrews 07 →]]
