# Hebrews 4

[[Heb-03|← Hebrews 03]] | [[Hebrews]] | [[Heb-05|Hebrews 05 →]]
***



###### v1 
Let's fear therefore, lest perhaps anyone of you should seem to have come short of a promise of entering into his rest. 

###### v2 
For indeed we have had good news preached to us, even as they also did, but the word they heard didn't profit them, because it wasn't mixed with faith by those who heard. 

###### v3 
For we who have believed do enter into that rest, even as he has said, "As I swore in my wrath, they will not enter into my rest;" although the works were finished from the foundation of the world. 

###### v4 
For he has said this somewhere about the seventh day, "God rested on the seventh day from all his works;" 

###### v5 
and in this place again, "They will not enter into my rest." 

###### v6 
Seeing therefore it remains that some should enter into it, and they to whom the good news was preached before failed to enter in because of disobedience, 

###### v7 
he again defines a certain day, today, saying through David so long a time afterward (just as has been said), "Today if you will hear his voice, don't harden your hearts." 

###### v8 
For if Joshua had given them rest, he would not have spoken afterward of another day. 

###### v9 
There remains therefore a Sabbath rest for the people of God. 

###### v10 
For he who has entered into his rest has himself also rested from his works, as God did from his. 

###### v11 
Let's therefore give diligence to enter into that rest, lest anyone fall after the same example of disobedience. 

###### v12 
For the word of God is living and active, and sharper than any two-edged sword, piercing even to the dividing of soul and spirit, of both joints and marrow, and is able to discern the thoughts and intentions of the heart. 

###### v13 
There is no creature that is hidden from his sight, but all things are naked and laid open before the eyes of him to whom we must give an account. 

###### v14 
Having then a great high priest who has passed through the heavens, Jesus, the Son of God, let's hold tightly to our confession. 

###### v15 
For we don't have a high priest who can't be touched with the feeling of our infirmities, but one who has been in all points tempted like we are, yet without sin. 

###### v16 
Let's therefore draw near with boldness to the throne of grace, that we may receive mercy and may find grace for help in time of need.

***
[[Heb-03|← Hebrews 03]] | [[Hebrews]] | [[Heb-05|Hebrews 05 →]]
