# Hebrews 7

[[Heb-06|← Hebrews 06]] | [[Hebrews]] | [[Heb-08|Hebrews 08 →]]
***



###### v1 
For this Melchizedek, king of Salem, priest of God Most High, who met Abraham returning from the slaughter of the kings and blessed him, 

###### v2 
to whom also Abraham divided a tenth part of all (being first, by interpretation, "king of righteousness", and then also "king of Salem", which means "king of peace", 

###### v3 
without father, without mother, without genealogy, having neither beginning of days nor end of life, but made like the Son of God), remains a priest continually. 

###### v4 
Now consider how great this man was, to whom even Abraham, the patriarch, gave a tenth out of the best plunder. 

###### v5 
They indeed of the sons of Levi who receive the priest's office have a commandment to take tithes of the people according to the law, that is, of their brothers, though these have come out of the body of Abraham, 

###### v6 
but he whose genealogy is not counted from them has accepted tithes from Abraham, and has blessed him who has the promises. 

###### v7 
But without any dispute the lesser is blessed by the greater. 

###### v8 
Here people who die receive tithes, but there one receives tithes of whom it is testified that he lives. 

###### v9 
We can say that through Abraham even Levi, who receives tithes, has paid tithes, 

###### v10 
for he was yet in the body of his father when Melchizedek met him. 

###### v11 
Now if perfection was through the Levitical priesthood (for under it the people have received the law), what further need was there for another priest to arise after the order of Melchizedek, and not be called after the order of Aaron? 

###### v12 
For the priesthood being changed, there is of necessity a change made also in the law. 

###### v13 
For he of whom these things are said belongs to another tribe, from which no one has officiated at the altar. 

###### v14 
For it is evident that our Lord has sprung out of Judah, about which tribe Moses spoke nothing concerning priesthood. 

###### v15 
This is yet more abundantly evident, if after the likeness of Melchizedek there arises another priest, 

###### v16 
who has been made, not after the law of a fleshly commandment, but after the power of an endless life; 

###### v17 
for it is testified, "You are a priest forever, according to the order of Melchizedek." 

###### v18 
For there is an annulling of a foregoing commandment because of its weakness and uselessness 

###### v19 
(for the law made nothing perfect), and a bringing in of a better hope, through which we draw near to God. 

###### v20 
Inasmuch as he was not made priest without the taking of an oath 

###### v21 
(for they indeed have been made priests without an oath), but he with an oath by him that says of him, "The Lord swore and will not change his mind, 'You are a priest forever, according to the order of Melchizedek.'" 

###### v22 
By so much, Jesus has become the collateral of a better covenant. 

###### v23 
Many, indeed, have been made priests, because they are hindered from continuing by death. 

###### v24 
But he, because he lives forever, has his priesthood unchangeable. 

###### v25 
Therefore he is also able to save to the uttermost those who draw near to God through him, seeing that he lives forever to make intercession for them. 

###### v26 
For such a high priest was fitting for us: holy, guiltless, undefiled, separated from sinners, and made higher than the heavens; 

###### v27 
who doesn't need, like those high priests, to offer up sacrifices daily, first for his own sins, and then for the sins of the people. For he did this once for all, when he offered up himself. 

###### v28 
For the law appoints men as high priests who have weakness, but the word of the oath which came after the law appoints a Son forever who has been perfected.

***
[[Heb-06|← Hebrews 06]] | [[Hebrews]] | [[Heb-08|Hebrews 08 →]]
