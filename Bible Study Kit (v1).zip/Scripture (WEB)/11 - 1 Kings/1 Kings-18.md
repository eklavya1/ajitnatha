# 1 Kings 18

[[1 Kings-17|← 1 Kings 17]] | [[1 Kings]] | [[1 Kings-19|1 Kings 19 →]]
***



###### v1 
After many days, Yahweh's word came to Elijah, in the third year, saying, "Go, show yourself to Ahab; and I will send rain on the earth." 

###### v2 
Elijah went to show himself to Ahab. The famine was severe in Samaria. 

###### v3 
Ahab called Obadiah, who was over the household. (Now Obadiah feared Yahweh greatly; 

###### v4 
for when Jezebel cut off Yahweh's prophets, Obadiah took one hundred prophets, and hid them fifty to a cave, and fed them with bread and water.) 

###### v5 
Ahab said to Obadiah, "Go through the land, to all the springs of water, and to all the brooks. Perhaps we may find grass and save the horses and mules alive, that we not lose all the animals." 

###### v6 
So they divided the land between them to pass throughout it. Ahab went one way by himself, and Obadiah went another way by himself. 

###### v7 
As Obadiah was on the way, behold, Elijah met him. He recognized him, and fell on his face, and said, "Is it you, my lord Elijah?" 

###### v8 
He answered him, "It is I. Go, tell your lord, 'Behold, Elijah is here!'" 

###### v9 
He said, "How have I sinned, that you would deliver your servant into the hand of Ahab, to kill me? 

###### v10 
As Yahweh your God lives, there is no nation or kingdom where my lord has not sent to seek you. When they said, 'He is not here,' he took an oath of the kingdom and nation, that they didn't find you. 

###### v11 
Now you say, 'Go, tell your lord, "Behold, Elijah is here."' 

###### v12 
It will happen, as soon as I leave you, that Yahweh's Spirit will carry you I don't know where; and so when I come and tell Ahab, and he can't find you, he will kill me. But I, your servant, have feared Yahweh from my youth. 

###### v13 
Wasn't it told my lord what I did when Jezebel killed Yahweh's prophets, how I hid one hundred men of Yahweh's prophets with fifty to a cave, and fed them with bread and water? 

###### v14 
Now you say, 'Go, tell your lord, "Behold, Elijah is here".' He will kill me." 

###### v15 
Elijah said, "As Yahweh of Armies lives, before whom I stand, I will surely show myself to him today." 

###### v16 
So Obadiah went to meet Ahab, and told him; and Ahab went to meet Elijah. 

###### v17 
When Ahab saw Elijah, Ahab said to him, "Is that you, you troubler of Israel?" 

###### v18 
He answered, "I have not troubled Israel; but you, and your father's house, in that you have forsaken Yahweh's commandments, and you have followed the Baals. 

###### v19 
Now therefore send, and gather to me all Israel to Mount Carmel, and four hundred fifty of the prophets of Baal, and four hundred of the prophets of the Asherah, who eat at Jezebel's table." 

###### v20 
So Ahab sent to all the children of Israel, and gathered the prophets together to Mount Carmel. 

###### v21 
Elijah came near to all the people, and said, "How long will you waver between the two sides? If Yahweh is God, follow him; but if Baal, then follow him." The people didn't say a word. 

###### v22 
Then Elijah said to the people, "I, even I only, am left as a prophet of Yahweh; but Baal's prophets are four hundred fifty men. 

###### v23 
Let them therefore give us two bulls; and let them choose one bull for themselves, and cut it in pieces, and lay it on the wood, and put no fire under; and I will dress the other bull, and lay it on the wood, and put no fire under it. 

###### v24 
You call on the name of your god, and I will call on Yahweh's name. The God who answers by fire, let him be God." All the people answered, "What you say is good." 

###### v25 
Elijah said to the prophets of Baal, "Choose one bull for yourselves, and dress it first; for you are many; and call on the name of your god, but put no fire under it." 

###### v26 
They took the bull which was given them, and they dressed it, and called on the name of Baal from morning even until noon, saying, "Baal, hear us!" But there was no voice, and nobody answered. They leaped about the altar which was made. 

###### v27 
At noon, Elijah mocked them, and said, "Cry aloud; for he is a god. Either he is deep in thought, or he has gone somewhere, or he is on a journey, or perhaps he sleeps and must be awakened." 

###### v28 
They cried aloud, and cut themselves in their way with knives and lances, until the blood gushed out on them. 

###### v29 
When midday was past, they prophesied until the time of the evening offering; but there was no voice, no answer, and nobody paid attention. 

###### v30 
Elijah said to all the people, "Come near to me!"; and all the people came near to him. He repaired Yahweh's altar that had been thrown down. 

###### v31 
Elijah took twelve stones, according to the number of the tribes of the sons of Jacob, to whom Yahweh's word came, saying, "Israel shall be your name." 

###### v32 
With the stones he built an altar in Yahweh's name. He made a trench around the altar, large enough to contain two seahs of seed. 

###### v33 
He put the wood in order, and cut the bull in pieces, and laid it on the wood. He said, "Fill four jars with water, and pour it on the burnt offering, and on the wood." 

###### v34 
He said, "Do it a second time;" and they did it the second time. He said, "Do it a third time;" and they did it the third time. 

###### v35 
The water ran around the altar; and he also filled the trench with water. 

###### v36 
At the time of the evening offering, Elijah the prophet came near, and said, "Yahweh, the God of Abraham, of Isaac, and of Israel, let it be known today that you are God in Israel, and that I am your servant, and that I have done all these things at your word. 

###### v37 
Hear me, Yahweh, hear me, that this people may know that you, Yahweh, are God, and that you have turned their heart back again." 

###### v38 
Then Yahweh's fire fell, and consumed the burnt offering, the wood, the stones, and the dust, and licked up the water that was in the trench. 

###### v39 
When all the people saw it, they fell on their faces. They said, "Yahweh, he is God! Yahweh, he is God!" 

###### v40 
Elijah said to them, "Seize the prophets of Baal! Don't let one of them escape!" They seized them; and Elijah brought them down to the brook Kishon, and killed them there. 

###### v41 
Elijah said to Ahab, "Get up, eat and drink; for there is the sound of abundance of rain." 

###### v42 
So Ahab went up to eat and to drink. Elijah went up to the top of Carmel; and he bowed himself down on the earth, and put his face between his knees. 

###### v43 
He said to his servant, "Go up now, and look toward the sea." He went up, and looked, and said, "There is nothing." He said, "Go again" seven times. 

###### v44 
On the seventh time, he said, "Behold, a small cloud, like a man's hand, is rising out of the sea." He said, "Go up, tell Ahab, 'Get ready and go down, so that the rain doesn't stop you.'" 

###### v45 
In a little while, the sky grew black with clouds and wind, and there was a great rain. Ahab rode, and went to Jezreel. 

###### v46 
Yahweh's hand was on Elijah; and he tucked his cloak into his belt and ran before Ahab to the entrance of Jezreel.

***
[[1 Kings-17|← 1 Kings 17]] | [[1 Kings]] | [[1 Kings-19|1 Kings 19 →]]
