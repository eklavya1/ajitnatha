# 1 Kings 8

[[1 Kings-07|← 1 Kings 07]] | [[1 Kings]] | [[1 Kings-09|1 Kings 09 →]]
***



###### v1 
Then Solomon assembled the elders of Israel, with all the heads of the tribes, the princes of the fathers' households of the children of Israel, to king Solomon in Jerusalem, to bring up the ark of Yahweh's covenant out of David's city, which is Zion. 

###### v2 
All the men of Israel assembled themselves to king Solomon at the feast, in the month Ethanim, which is the seventh month. 

###### v3 
All the elders of Israel came, and the priests picked up the ark. 

###### v4 
They brought up Yahweh's ark, the Tent of Meeting, and all the holy vessels that were in the Tent. The priests and the Levites brought these up. 

###### v5 
King Solomon and all the congregation of Israel, who were assembled to him, were with him before the ark, sacrificing sheep and cattle, that could not be counted or numbered for multitude. 

###### v6 
The priests brought in the ark of Yahweh's covenant to its place, into the inner sanctuary of the house, to the most holy place, even under the cherubim's wings. 

###### v7 
For the cherubim spread their wings out over the place of the ark, and the cherubim covered the ark and its poles above. 

###### v8 
The poles were so long that the ends of the poles were seen from the holy place before the inner sanctuary; but they were not seen outside. They are there to this day. 

###### v9 
There was nothing in the ark except the two stone tablets which Moses put there at Horeb, when Yahweh made a covenant with the children of Israel, when they came out of the land of Egypt. 

###### v10 
It came to pass, when the priests had come out of the holy place, that the cloud filled Yahweh's house, 

###### v11 
so that the priests could not stand to minister by reason of the cloud; for Yahweh's glory filled Yahweh's house. 

###### v12 
Then Solomon said, "Yahweh has said that he would dwell in the thick darkness. 

###### v13 
I have surely built you a house of habitation, a place for you to dwell in forever." 

###### v14 
The king turned his face around, and blessed all the assembly of Israel; and all the assembly of Israel stood. 

###### v15 
He said, "Blessed is Yahweh, the God of Israel, who spoke with his mouth to David your father, and has with his hand fulfilled it, saying, 

###### v16 
'Since the day that I brought my people Israel out of Egypt, I chose no city out of all the tribes of Israel to build a house, that my name might be there; but I chose David to be over my people Israel.' 

###### v17 
"Now it was in the heart of David my father to build a house for the name of Yahweh, the God of Israel. 

###### v18 
But Yahweh said to David my father, 'Whereas it was in your heart to build a house for my name, you did well that it was in your heart. 

###### v19 
Nevertheless, you shall not build the house; but your son who shall come out of your body, he shall build the house for my name.' 

###### v20 
Yahweh has established his word that he spoke; for I have risen up in the place of David my father, and I sit on the throne of Israel, as Yahweh promised, and have built the house for the name of Yahweh, the God of Israel. 

###### v21 
There I have set a place for the ark, in which is Yahweh's covenant, which he made with our fathers, when he brought them out of the land of Egypt." 

###### v22 
Solomon stood before Yahweh's altar in the presence of all the assembly of Israel, and spread out his hands toward heaven; 

###### v23 
and he said, "Yahweh, the God of Israel, there is no God like you, in heaven above, or on earth beneath; who keeps covenant and loving kindness with your servants, who walk before you with all their heart; 

###### v24 
who has kept with your servant David my father that which you promised him. Yes, you spoke with your mouth, and have fulfilled it with your hand, as it is today. 

###### v25 
Now therefore, may Yahweh, the God of Israel, keep with your servant David my father that which you have promised him, saying, 'There shall not fail from you a man in my sight to sit on the throne of Israel, if only your children take heed to their way, to walk before me as you have walked before me.' 

###### v26 
"Now therefore, God of Israel, please let your word be verified, which you spoke to your servant David my father. 

###### v27 
But will God in very deed dwell on the earth? Behold, heaven and the heaven of heavens can't contain you; how much less this house that I have built! 

###### v28 
Yet have respect for the prayer of your servant, and for his supplication, Yahweh my God, to listen to the cry and to the prayer which your servant prays before you today; 

###### v29 
that your eyes may be open toward this house night and day, even toward the place of which you have said, 'My name shall be there;' to listen to the prayer which your servant prays toward this place. 

###### v30 
Listen to the supplication of your servant, and of your people Israel, when they pray toward this place. Yes, hear in heaven, your dwelling place; and when you hear, forgive. 

###### v31 
"If a man sins against his neighbor, and an oath is laid on him to cause him to swear, and he comes and swears before your altar in this house; 

###### v32 
then hear in heaven, and act, and judge your servants, condemning the wicked, to bring his way on his own head, and justifying the righteous, to give him according to his righteousness. 

###### v33 
"When your people Israel are struck down before the enemy, because they have sinned against you; if they turn again to you, and confess your name, and pray and make supplication to you in this house; 

###### v34 
then hear in heaven, and forgive the sin of your people Israel, and bring them again to the land which you gave to their fathers. 

###### v35 
"When the sky is shut up, and there is no rain, because they have sinned against you; if they pray toward this place, and confess your name, and turn from their sin, when you afflict them, 

###### v36 
then hear in heaven, and forgive the sin of your servants, and of your people Israel, when you teach them the good way in which they should walk; and send rain on your land, which you have given to your people for an inheritance. 

###### v37 
"If there is famine in the land, if there is pestilence, if there is blight, mildew, locust or caterpillar; if their enemy besieges them in the land of their cities; whatever plague, whatever sickness there is; 

###### v38 
whatever prayer and supplication is made by any man, or by all your people Israel, who shall each know the plague of his own heart, and spread out his hands toward this house, 

###### v39 
then hear in heaven, your dwelling place, and forgive, and act, and give to every man according to all his ways, whose heart you know (for you, even you only, know the hearts of all the children of men); 

###### v40 
that they may fear you all the days that they live in the land which you gave to our fathers. 

###### v41 
"Moreover concerning the foreigner, who is not of your people Israel, when he comes out of a far country for your name's sake 

###### v42 
(for they shall hear of your great name, and of your mighty hand, and of your outstretched arm); when he comes and prays toward this house; 

###### v43 
hear in heaven, your dwelling place, and do according to all that the foreigner calls to you for; that all the peoples of the earth may know your name, to fear you, as do your people Israel, and that they may know that this house which I have built is called by your name. 

###### v44 
"If your people go out to battle against their enemy, by whatever way you shall send them, and they pray to Yahweh toward the city which you have chosen, and toward the house which I have built for your name; 

###### v45 
then hear in heaven their prayer and their supplication, and maintain their cause. 

###### v46 
If they sin against you (for there is no man who doesn't sin), and you are angry with them, and deliver them to the enemy, so that they carry them away captive to the land of the enemy, far off or near; 

###### v47 
yet if they repent in the land where they are carried captive, and turn again, and make supplication to you in the land of those who carried them captive, saying, 'We have sinned, and have done perversely; we have dealt wickedly;' 

###### v48 
if they return to you with all their heart and with all their soul in the land of their enemies, who carried them captive, and pray to you toward their land, which you gave to their fathers, the city which you have chosen, and the house which I have built for your name; 

###### v49 
then hear their prayer and their supplication in heaven, your dwelling place, and maintain their cause; 

###### v50 
and forgive your people who have sinned against you, and all their transgressions in which they have transgressed against you; and give them compassion before those who carried them captive, that they may have compassion on them 

###### v51 
(for they are your people, and your inheritance, which you brought out of Egypt, from the middle of the iron furnace); 

###### v52 
that your eyes may be open to the supplication of your servant, and to the supplication of your people Israel, to listen to them whenever they cry to you. 

###### v53 
For you separated them from among all the peoples of the earth, to be your inheritance, as you spoke by Moses your servant, when you brought our fathers out of Egypt, Lord Yahweh." 

###### v54 
It was so, that when Solomon had finished praying all this prayer and supplication to Yahweh, he arose from before Yahweh's altar, from kneeling on his knees with his hands spread out toward heaven. 

###### v55 
He stood, and blessed all the assembly of Israel with a loud voice, saying, 

###### v56 
"Blessed be Yahweh, who has given rest to his people Israel, according to all that he promised. There has not failed one word of all his good promise, which he promised by Moses his servant. 

###### v57 
May Yahweh our God be with us, as he was with our fathers. Let him not leave us or forsake us; 

###### v58 
that he may incline our hearts to him, to walk in all his ways, and to keep his commandments, and his statutes, and his ordinances, which he commanded our fathers. 

###### v59 
Let these my words, with which I have made supplication before Yahweh, be near to Yahweh our God day and night, that he may maintain the cause of his servant, and the cause of his people Israel, as every day requires; 

###### v60 
that all the peoples of the earth may know that Yahweh himself is God. There is no one else. 

###### v61 
"Let your heart therefore be perfect with Yahweh our God, to walk in his statutes, and to keep his commandments, as it is today." 

###### v62 
The king, and all Israel with him, offered sacrifice before Yahweh. 

###### v63 
Solomon offered for the sacrifice of peace offerings, which he offered to Yahweh, twenty two thousand head of cattle, and one hundred twenty thousand sheep. So the king and all the children of Israel dedicated Yahweh's house. 

###### v64 
The same day the king made the middle of the court holy that was before Yahweh's house; for there he offered the burnt offering, and the meal offering, and the fat of the peace offerings, because the bronze altar that was before Yahweh was too little to receive the burnt offering, the meal offering, and the fat of the peace offerings. 

###### v65 
So Solomon held the feast at that time, and all Israel with him, a great assembly, from the entrance of Hamath to the brook of Egypt, before Yahweh our God, seven days and seven more days, even fourteen days. 

###### v66 
On the eighth day he sent the people away; and they blessed the king, and went to their tents joyful and glad in their hearts for all the goodness that Yahweh had shown to David his servant, and to Israel his people.

***
[[1 Kings-07|← 1 Kings 07]] | [[1 Kings]] | [[1 Kings-09|1 Kings 09 →]]
