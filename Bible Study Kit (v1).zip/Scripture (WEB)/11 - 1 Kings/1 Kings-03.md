# 1 Kings 3

[[1 Kings-02|← 1 Kings 02]] | [[1 Kings]] | [[1 Kings-04|1 Kings 04 →]]
***



###### v1 
Solomon made an alliance with Pharaoh king of Egypt, and took Pharaoh's daughter, and brought her into David's city, until he had finished building his own house, Yahweh's house, and the wall around Jerusalem. 

###### v2 
However the people sacrificed in the high places, because there was not yet a house built for Yahweh's name. 

###### v3 
Solomon loved Yahweh, walking in the statutes of David his father; except that he sacrificed and burned incense in the high places. 

###### v4 
The king went to Gibeon to sacrifice there; for that was the great high place. Solomon offered a thousand burnt offerings on that altar. 

###### v5 
In Gibeon, Yahweh appeared to Solomon in a dream by night; and God said, "Ask for what I should give you." 

###### v6 
Solomon said, "You have shown to your servant David my father great loving kindness, because he walked before you in truth, in righteousness, and in uprightness of heart with you. You have kept for him this great loving kindness, that you have given him a son to sit on his throne, as it is today. 

###### v7 
Now, Yahweh my God, you have made your servant king instead of David my father. I am just a little child. I don't know how to go out or come in. 

###### v8 
Your servant is among your people which you have chosen, a great people, that can't be numbered or counted for multitude. 

###### v9 
Give your servant therefore an understanding heart to judge your people, that I may discern between good and evil; for who is able to judge this great people of yours?" 

###### v10 
This request pleased the Lord, that Solomon had asked this thing. 

###### v11 
God said to him, "Because you have asked this thing, and have not asked for yourself long life, nor have you asked for riches for yourself, nor have you asked for the life of your enemies, but have asked for yourself understanding to discern justice; 

###### v12 
behold, I have done according to your word. Behold, I have given you a wise and understanding heart; so that there has been no one like you before you, and after you none will arise like you. 

###### v13 
I have also given you that which you have not asked, both riches and honor, so that there will not be any among the kings like you for all your days. 

###### v14 
If you will walk in my ways, to keep my statutes and my commandments, as your father David walked, then I will lengthen your days." 

###### v15 
Solomon awoke; and behold, it was a dream. Then he came to Jerusalem, and stood before the ark of Yahweh's covenant, and offered up burnt offerings, offered peace offerings, and made a feast for all his servants. 

###### v16 
Then two women who were prostitutes came to the king, and stood before him. 

###### v17 
The one woman said, "Oh, my lord, I and this woman dwell in one house. I delivered a child with her in the house. 

###### v18 
The third day after I delivered, this woman delivered also. We were together. There was no stranger with us in the house, just us two in the house. 

###### v19 
This woman's child died in the night, because she lay on it. 

###### v20 
She arose at midnight, and took my son from beside me, while your servant slept, and laid it in her bosom, and laid her dead child in my bosom. 

###### v21 
When I rose in the morning to nurse my child, behold, it was dead; but when I had looked at it in the morning, behold, it was not my son, whom I bore." 

###### v22 
The other woman said, "No; but the living one is my son, and the dead one is your son." The first one said, "No; but the dead one is your son, and the living one is my son." They argued like this before the king. 

###### v23 
Then the king said, "One says, 'This is my son who lives, and your son is the dead;' and the other says, 'No; but your son is the dead one, and my son is the living one.'" 

###### v24 
The king said, "Get me a sword." So they brought a sword before the king. 

###### v25 
The king said, "Divide the living child in two, and give half to the one, and half to the other." 

###### v26 
Then the woman whose the living child was spoke to the king, for her heart yearned over her son, and she said, "Oh, my lord, give her the living child, and in no way kill him!" But the other said, "He shall be neither mine nor yours. Divide him." 

###### v27 
Then the king answered, "Give her the living child, and definitely do not kill him. She is his mother." 

###### v28 
All Israel heard of the judgment which the king had judged; and they feared the king; for they saw that the wisdom of God was in him, to do justice.

***
[[1 Kings-02|← 1 Kings 02]] | [[1 Kings]] | [[1 Kings-04|1 Kings 04 →]]
