# 1 Kings 7

[[1 Kings-06|← 1 Kings 06]] | [[1 Kings]] | [[1 Kings-08|1 Kings 08 →]]
***



###### v1 
Solomon was building his own house thirteen years, and he finished all his house. 

###### v2 
For he built the House of the Forest of Lebanon. Its length was one hundred cubits, its width fifty cubits, and its height thirty cubits, on four rows of cedar pillars, with cedar beams on the pillars. 

###### v3 
It was covered with cedar above over the forty-five beams, that were on the pillars, fifteen in a row. 

###### v4 
There were beams in three rows, and window was facing window in three ranks. 

###### v5 
All the doors and posts were made square with beams: and window was facing window in three ranks. 

###### v6 
He made the porch of pillars. Its length was fifty cubits and its width thirty cubits; with a porch before them, and pillars and a threshold before them. 

###### v7 
He made the porch of the throne where he was to judge, even the porch of judgment; and it was covered with cedar from floor to floor. 

###### v8 
His house where he was to dwell, the other court within the porch, was of the like work. He made also a house for Pharaoh's daughter (whom Solomon had taken as wife), like this porch. 

###### v9 
All these were of costly stones, even of cut stone, according to measure, sawed with saws, inside and outside, even from the foundation to the coping, and so on the outside to the great court. 

###### v10 
The foundation was of costly stones, even great stones, stones of ten cubits, and stones of eight cubits. 

###### v11 
Above were costly stones, even cut stone, according to measure, and cedar wood. 

###### v12 
The great court around had three courses of cut stone, and a course of cedar beams; like the inner court of Yahweh's house and the porch of the house. 

###### v13 
King Solomon sent and brought Hiram out of Tyre. 

###### v14 
He was the son of a widow of the tribe of Naphtali, and his father was a man of Tyre, a worker in bronze; and he was filled with wisdom and understanding and skill, to work all works in bronze. He came to king Solomon, and performed all his work. 

###### v15 
For he fashioned the two pillars of bronze, eighteen cubits high apiece; and a line of twelve cubits encircled either of them. 

###### v16 
He made two capitals of molten bronze, to set on the tops of the pillars. The height of the one capital was five cubits, and the height of the other capital was five cubits. 

###### v17 
There were nets of checker work, and wreaths of chain work, for the capitals which were on the top of the pillars; seven for the one capital, and seven for the other capital. 

###### v18 
So he made the pillars; and there were two rows around on the one network, to cover the capitals that were on the top of the pillars: and he did so for the other capital. 

###### v19 
The capitals that were on the top of the pillars in the porch were of lily work, four cubits. 

###### v20 
There were capitals above also on the two pillars, close by the belly which was beside the network. There were two hundred pomegranates in rows around the other capital. 

###### v21 
He set up the pillars at the porch of the temple. He set up the right pillar, and called its name Jachin; and he set up the left pillar, and called its name Boaz. 

###### v22 
On the top of the pillars was lily work: so the work of the pillars was finished. 

###### v23 
He made the molten sea of ten cubits from brim to brim, round in shape. Its height was five cubits; and a line of thirty cubits encircled it. 

###### v24 
Under its brim around there were buds which encircled it for ten cubits, encircling the sea. The buds were in two rows, cast when it was cast. 

###### v25 
It stood on twelve oxen, three looking toward the north, and three looking toward the west, and three looking toward the south, and three looking toward the east; and the sea was set on them above, and all their hindquarters were inward. 

###### v26 
It was a hand width thick. Its brim was worked like the brim of a cup, like the flower of a lily. It held two thousand baths. 

###### v27 
He made the ten bases of bronze. The length of one base was four cubits, four cubits its width, and three cubits its height. 

###### v28 
The work of the bases was like this: they had panels; and there were panels between the ledges; 

###### v29 
and on the panels that were between the ledges were lions, oxen, and cherubim; and on the ledges there was a pedestal above; and beneath the lions and oxen were wreaths of hanging work. 

###### v30 
Every base had four bronze wheels, and axles of bronze; and the four feet of it had supports. The supports were cast beneath the basin, with wreaths at the side of each. 

###### v31 
Its mouth within the capital and above was a cubit. Its mouth was round after the work of a pedestal, a cubit and a half; and also on its mouth were engravings, and their panels were square, not round. 

###### v32 
The four wheels were underneath the panels; and the axles of the wheels were in the base. The height of a wheel was a cubit and half a cubit. 

###### v33 
The work of the wheels was like the work of a chariot wheel. Their axles, and their rims, and their spokes, and their naves, were all of cast metal. 

###### v34 
There were four supports at the four corners of each base. Its supports were of the base itself. 

###### v35 
In the top of the base there was a round band half a cubit high; and on the top of the base its supports and its panels were the same. 

###### v36 
On the plates of its supports, and on its panels, he engraved cherubim, lions, and palm trees, each in its space, with wreaths all around. 

###### v37 
He made the ten bases in this way: all of them had one casting, one measure, and one form. 

###### v38 
He made ten basins of bronze. One basin contained forty baths; and every basin was four cubits; and on every one of the ten bases one basin. 

###### v39 
He set the bases, five on the right side of the house, and five on the left side of the house. He set the sea on the right side of the house eastward and toward the south. 

###### v40 
Hiram made the pots, the shovels, and the basins. So Hiram finished doing all the work that he worked for king Solomon in Yahweh's house: 

###### v41 
the two pillars; the two bowls of the capitals that were on the top of the pillars; the two networks to cover the two bowls of the capitals that were on the top of the pillars; 

###### v42 
the four hundred pomegranates for the two networks; two rows of pomegranates for each network, to cover the two bowls of the capitals that were on the pillars; 

###### v43 
the ten bases; the ten basins on the bases; 

###### v44 
the one sea; the twelve oxen under the sea; 

###### v45 
the pots; the shovels; and the basins: even all these vessels, which Hiram made for king Solomon, in Yahweh's house, were of burnished bronze. 

###### v46 
The king cast them in the plain of the Jordan, in the clay ground between Succoth and Zarethan. 

###### v47 
Solomon left all the vessels unweighed, because there were so many of them. The weight of the bronze could not be determined. 

###### v48 
Solomon made all the vessels that were in Yahweh's house: the golden altar and the table that the show bread was on, of gold; 

###### v49 
and the lamp stands, five on the right side, and five on the left, before the inner sanctuary, of pure gold; and the flowers, the lamps, and the tongs, of gold; 

###### v50 
the cups, the snuffers, the basins, the spoons, and the fire pans, of pure gold; and the hinges, both for the doors of the inner house, the most holy place, and for the doors of the house, of the temple, of gold. 

###### v51 
Thus all the work that king Solomon did in Yahweh's house was finished. Solomon brought in the things which David his father had dedicated, the silver, the gold, and the vessels, and put them in the treasuries of Yahweh's house.

***
[[1 Kings-06|← 1 Kings 06]] | [[1 Kings]] | [[1 Kings-08|1 Kings 08 →]]
