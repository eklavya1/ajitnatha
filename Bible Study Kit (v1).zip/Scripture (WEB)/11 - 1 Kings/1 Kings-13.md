# 1 Kings 13

[[1 Kings-12|← 1 Kings 12]] | [[1 Kings]] | [[1 Kings-14|1 Kings 14 →]]
***



###### v1 
Behold, a man of God came out of Judah by Yahweh's word to Bethel; and Jeroboam was standing by the altar to burn incense. 

###### v2 
He cried against the altar by Yahweh's word, and said, "Altar! Altar! Yahweh says: 'Behold, a son will be born to David's house, Josiah by name. On you he will sacrifice the priests of the high places who burn incense on you, and they will burn men's bones on you.'" 

###### v3 
He gave a sign the same day, saying, "This is the sign which Yahweh has spoken: Behold, the altar will be split apart, and the ashes that are on it will be poured out." 

###### v4 
When the king heard the saying of the man of God, which he cried against the altar in Bethel, Jeroboam put out his hand from the altar, saying, "Seize him!" His hand, which he put out against him, dried up, so that he could not draw it back again to himself. 

###### v5 
The altar was also split apart, and the ashes poured out from the altar, according to the sign which the man of God had given by Yahweh's word. 

###### v6 
The king answered the man of God, "Now intercede for the favor of Yahweh your God, and pray for me, that my hand may be restored me again." The man of God interceded with Yahweh, and the king's hand was restored to him again, and became as it was before. 

###### v7 
The king said to the man of God, "Come home with me, and refresh yourself, and I will give you a reward." 

###### v8 
The man of God said to the king, "Even if you gave me half of your house, I would not go in with you, neither would I eat bread nor drink water in this place; 

###### v9 
for so was it commanded me by Yahweh's word, saying, 'You shall eat no bread, drink no water, and don't return by the way that you came.'" 

###### v10 
So he went another way, and didn't return by the way that he came to Bethel. 

###### v11 
Now an old prophet lived in Bethel, and one of his sons came and told him all the works that the man of God had done that day in Bethel. They also told their father the words which he had spoken to the king. 

###### v12 
Their father said to them, "Which way did he go?" Now his sons had seen which way the man of God went, who came from Judah. 

###### v13 
He said to his sons, "Saddle the donkey for me." So they saddled the donkey for him; and he rode on it. 

###### v14 
He went after the man of God, and found him sitting under an oak. He said to him, "Are you the man of God who came from Judah?" He said, "I am." 

###### v15 
Then he said to him, "Come home with me, and eat bread." 

###### v16 
He said, "I may not return with you, nor go in with you. I will not eat bread or drink water with you in this place. 

###### v17 
For it was said to me by Yahweh's word, 'You shall eat no bread or drink water there, and don't turn again to go by the way that you came.'" 

###### v18 
He said to him, "I also am a prophet as you are; and an angel spoke to me by Yahweh's word, saying, 'Bring him back with you into your house, that he may eat bread and drink water.'" He lied to him. 

###### v19 
So he went back with him, ate bread in his house, and drank water. 

###### v20 
As they sat at the table, Yahweh's word came to the prophet who brought him back; 

###### v21 
and he cried out to the man of God who came from Judah, saying, "Yahweh says, 'Because you have been disobedient to Yahweh's mouth, and have not kept the commandment which Yahweh your God commanded you, 

###### v22 
but came back, and have eaten bread and drank water in the place of which he said to you, "Eat no bread, and drink no water;" your body will not come to the tomb of your fathers.'" 

###### v23 
After he had eaten bread, and after he drank, he saddled the donkey for the prophet whom he had brought back. 

###### v24 
When he had gone, a lion met him by the way and killed him. His body was thrown on the path, and the donkey stood by it. The lion also stood by the body. 

###### v25 
Behold, men passed by, and saw the body thrown on the path, and the lion standing by the body; and they came and told it in the city where the old prophet lived. 

###### v26 
When the prophet who brought him back from the way heard of it, he said, "It is the man of God who was disobedient to Yahweh's mouth. Therefore Yahweh has delivered him to the lion, which has mauled him and slain him, according to Yahweh's word, which he spoke to him." 

###### v27 
He said to his sons, saying, "Saddle the donkey for me," and they saddled it. 

###### v28 
He went and found his body thrown on the path, and the donkey and the lion standing by the body. The lion had not eaten the body, nor mauled the donkey. 

###### v29 
The prophet took up the body of the man of God, and laid it on the donkey, and brought it back. He came to the city of the old prophet to mourn, and to bury him. 

###### v30 
He laid his body in his own grave; and they mourned over him, saying, "Alas, my brother!" 

###### v31 
After he had buried him, he spoke to his sons, saying, "When I am dead, bury me in the tomb in which the man of God is buried. Lay my bones beside his bones. 

###### v32 
For the saying which he cried by Yahweh's word against the altar in Bethel, and against all the houses of the high places which are in the cities of Samaria, will surely happen." 

###### v33 
After this thing Jeroboam didn't return from his evil way, but again made priests of the high places from among all the people. Whoever wanted to, he consecrated him, that there might be priests of the high places. 

###### v34 
This thing became sin to the house of Jeroboam, even to cut it off, and to destroy it from off the surface of the earth.

***
[[1 Kings-12|← 1 Kings 12]] | [[1 Kings]] | [[1 Kings-14|1 Kings 14 →]]
