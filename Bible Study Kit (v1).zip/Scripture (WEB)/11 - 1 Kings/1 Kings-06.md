# 1 Kings 6

[[1 Kings-05|← 1 Kings 05]] | [[1 Kings]] | [[1 Kings-07|1 Kings 07 →]]
***



###### v1 
In the four hundred and eightieth year after the children of Israel had come out of the land of Egypt, in the fourth year of Solomon's reign over Israel, in the month Ziv, which is the second month, he began to build Yahweh's house. 

###### v2 
The house which king Solomon built for Yahweh had a length of sixty cubits, and its width twenty, and its height thirty cubits. 

###### v3 
The porch in front of the temple of the house had a length of twenty cubits, which was along the width of the house. Ten cubits was its width in front of the house. 

###### v4 
He made windows of fixed lattice work for the house. 

###### v5 
Against the wall of the house, he built floors all around, against the walls of the house all around, both of the temple and of the inner sanctuary; and he made side rooms all around. 

###### v6 
The lowest floor was five cubits wide, and the middle was six cubits wide, and the third was seven cubits wide; for on the outside he made offsets in the wall of the house all around, that the beams should not be inserted into the walls of the house. 

###### v7 
The house, when it was under construction, was built of stone prepared at the quarry; and no hammer or ax or any tool of iron was heard in the house while it was under construction. 

###### v8 
The door for the middle side rooms was in the right side of the house. They went up by winding stairs into the middle floor, and out of the middle into the third. 

###### v9 
So he built the house, and finished it; and he covered the house with beams and planks of cedar. 

###### v10 
He built the floors all along the house, each five cubits high; and they rested on the house with timbers of cedar. 

###### v11 
Yahweh's word came to Solomon, saying, 

###### v12 
"Concerning this house which you are building, if you will walk in my statutes, and execute my ordinances, and keep all my commandments to walk in them; then I will establish my word with you, which I spoke to David your father. 

###### v13 
I will dwell among the children of Israel, and will not forsake my people Israel." 

###### v14 
So Solomon built the house, and finished it. 

###### v15 
He built the walls of the house within with boards of cedar: from the floor of the house to the walls of the ceiling, he covered them on the inside with wood; and he covered the floor of the house with cypress boards. 

###### v16 
He built twenty cubits on the back part of the house with boards of cedar from the floor to the ceiling. He built them for it within, for an inner sanctuary, even for the most holy place. 

###### v17 
In front of the temple sanctuary was forty cubits. 

###### v18 
There was cedar on the house within, carved with buds and open flowers. All was cedar. No stone was visible. 

###### v19 
He prepared an inner sanctuary in the middle of the house within, to set the ark of Yahweh's covenant there. 

###### v20 
Within the inner sanctuary was twenty cubits in length, and twenty cubits in width, and twenty cubits in its height; and he overlaid it with pure gold; and he covered the altar with cedar. 

###### v21 
So Solomon overlaid the house within with pure gold. He drew chains of gold across before the inner sanctuary, and he overlaid it with gold. 

###### v22 
He overlaid the whole house with gold, until all the house was finished. He also overlaid the whole altar that belonged to the inner sanctuary with gold. 

###### v23 
In the inner sanctuary he made two cherubim of olive wood, each ten cubits high. 

###### v24 
Five cubits was the one wing of the cherub, and five cubits the other wing of the cherub. From the tip of one wing to the tip of the other was ten cubits. 

###### v25 
The other cherub was ten cubits. Both the cherubim were of one measure and one form. 

###### v26 
One cherub was ten cubits high, and so was the other cherub. 

###### v27 
He set the cherubim within the inner house. The wings of the cherubim were stretched out, so that the wing of the one touched the one wall, and the wing of the other cherub touched the other wall; and their wings touched one another in the middle of the house. 

###### v28 
He overlaid the cherubim with gold. 

###### v29 
He carved all the walls of the house around with carved figures of cherubim, palm trees, and open flowers, inside and outside. 

###### v30 
He overlaid the floor of the house with gold, inside and outside. 

###### v31 
For the entrance of the inner sanctuary, he made doors of olive wood. The lintel and door posts were a fifth part of the wall. 

###### v32 
So he made two doors of olive wood; and he carved on them carvings of cherubim, palm trees, and open flowers, and overlaid them with gold. He spread the gold on the cherubim and on the palm trees. 

###### v33 
He also did so for the entrance of the temple door posts of olive wood, out of a fourth part of the wall; 

###### v34 
and two doors of cypress wood. The two leaves of the one door were folding, and the two leaves of the other door were folding. 

###### v35 
He carved cherubim, palm trees, and open flowers; and he overlaid them with gold fitted on the engraved work. 

###### v36 
He built the inner court with three courses of cut stone and a course of cedar beams. 

###### v37 
The foundation of Yahweh's house was laid in the fourth year, in the month Ziv. 

###### v38 
In the eleventh year, in the month Bul, which is the eighth month, the house was finished throughout all its parts, and according to all its specifications. So he spent seven years building it.

***
[[1 Kings-05|← 1 Kings 05]] | [[1 Kings]] | [[1 Kings-07|1 Kings 07 →]]
