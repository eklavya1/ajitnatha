# 1 Kings 17

[[1 Kings-16|← 1 Kings 16]] | [[1 Kings]] | [[1 Kings-18|1 Kings 18 →]]
***



###### v1 
Elijah the Tishbite, who was one of the settlers of Gilead, said to Ahab, "As Yahweh, the God of Israel, lives, before whom I stand, there shall not be dew nor rain these years, but according to my word." 

###### v2 
Then Yahweh's word came to him, saying, 

###### v3 
"Go away from here, turn eastward, and hide yourself by the brook Cherith, that is before the Jordan. 

###### v4 
You shall drink from the brook. I have commanded the ravens to feed you there." 

###### v5 
So he went and did according to Yahweh's word; for he went and lived by the brook Cherith that is before the Jordan. 

###### v6 
The ravens brought him bread and meat in the morning, and bread and meat in the evening; and he drank from the brook. 

###### v7 
After a while, the brook dried up, because there was no rain in the land. 

###### v8 
Yahweh's word came to him, saying, 

###### v9 
"Arise, go to Zarephath, which belongs to Sidon, and stay there. Behold, I have commanded a widow there to sustain you." 

###### v10 
So he arose and went to Zarephath; and when he came to the gate of the city, behold, a widow was there gathering sticks. He called to her, and said, "Please get me a little water in a jar, that I may drink." 

###### v11 
As she was going to get it, he called to her, and said, "Please bring me a morsel of bread in your hand." 

###### v12 
She said, "As Yahweh your God lives, I don't have a cake, but a handful of meal in a jar, and a little oil in a jar. Behold, I am gathering two sticks, that I may go in and bake it for me and my son, that we may eat it, and die." 

###### v13 
Elijah said to her, "Don't be afraid. Go and do as you have said; but make me a little cake from it first, and bring it out to me, and afterward make some for you and for your son. 

###### v14 
For Yahweh, the God of Israel says, 'The jar of meal will not run out, and the jar of oil will not fail, until the day that Yahweh sends rain on the earth.'" 

###### v15 
She went and did according to the saying of Elijah; and she, and he, and her house, ate many days. 

###### v16 
The jar of meal didn't run out, and the jar of oil didn't fail, according to Yahweh's word, which he spoke by Elijah. 

###### v17 
After these things, the son of the woman, the mistress of the house, became sick; and his sickness was so severe that there was no breath left in him. 

###### v18 
She said to Elijah, "What have I to do with you, you man of God? You have come to me to bring my sin to memory, and to kill my son!" 

###### v19 
He said to her, "Give me your son." He took him out of her bosom, and carried him up into the room where he stayed, and laid him on his own bed. 

###### v20 
He cried to Yahweh, and said, "Yahweh my God, have you also brought evil on the widow with whom I am staying, by killing her son?" 

###### v21 
He stretched himself on the child three times, and cried to Yahweh, and said, "Yahweh my God, please let this child's soul come into him again." 

###### v22 
Yahweh listened to the voice of Elijah; and the soul of the child came into him again, and he revived. 

###### v23 
Elijah took the child, and brought him down out of the room into the house, and delivered him to his mother; and Elijah said, "Behold, your son lives." 

###### v24 
The woman said to Elijah, "Now I know that you are a man of God, and that Yahweh's word in your mouth is truth."

***
[[1 Kings-16|← 1 Kings 16]] | [[1 Kings]] | [[1 Kings-18|1 Kings 18 →]]
