# Joshua 15

[[Josh-14|← Joshua 14]] | [[Joshua]] | [[Josh-16|Joshua 16 →]]
***



###### v1 
The lot for the tribe of the children of Judah according to their families was to the border of Edom, even to the wilderness of Zin southward, at the uttermost part of the south. 

###### v2 
Their south border was from the uttermost part of the Salt Sea, from the bay that looks southward; 

###### v3 
and it went out southward of the ascent of Akrabbim, and passed along to Zin, and went up by the south of Kadesh Barnea, and passed along by Hezron, went up to Addar, and turned toward Karka; 

###### v4 
and it passed along to Azmon, went out at the brook of Egypt; and the border ended at the sea. This shall be your south border. 

###### v5 
The east border was the Salt Sea, even to the end of the Jordan. The border of the north quarter was from the bay of the sea at the end of the Jordan. 

###### v6 
The border went up to Beth Hoglah, and passed along by the north of Beth Arabah; and the border went up to the stone of Bohan the son of Reuben. 

###### v7 
The border went up to Debir from the valley of Achor, and so northward, looking toward Gilgal, that faces the ascent of Adummim, which is on the south side of the river. The border passed along to the waters of En Shemesh, and ended at En Rogel. 

###### v8 
The border went up by the valley of the son of Hinnom to the side of the Jebusite (also called Jerusalem) southward; and the border went up to the top of the mountain that lies before the valley of Hinnom westward, which is at the farthest part of the valley of Rephaim northward. 

###### v9 
The border extended from the top of the mountain to the spring of the waters of Nephtoah, and went out to the cities of Mount Ephron; and the border extended to Baalah (also called Kiriath Jearim); 

###### v10 
and the border turned about from Baalah westward to Mount Seir, and passed along to the side of Mount Jearim (also called Chesalon) on the north, and went down to Beth Shemesh, and passed along by Timnah; 

###### v11 
and the border went out to the side of Ekron northward; and the border extended to Shikkeron, and passed along to Mount Baalah, and went out at Jabneel; and the goings out of the border were at the sea. 

###### v12 
The west border was to the shore of the great sea. This is the border of the children of Judah according to their families. 

###### v13 
He gave to Caleb the son of Jephunneh a portion among the children of Judah, according to the commandment of Yahweh to Joshua, even Kiriath Arba, named after the father of Anak (also called Hebron). 

###### v14 
Caleb drove out the three sons of Anak: Sheshai, and Ahiman, and Talmai, the children of Anak. 

###### v15 
He went up against the inhabitants of Debir: now the name of Debir before was Kiriath Sepher. 

###### v16 
Caleb said, "He who strikes Kiriath Sepher, and takes it, to him I will give Achsah my daughter as wife." 

###### v17 
Othniel the son of Kenaz, the brother of Caleb, took it: and he gave him Achsah his daughter as wife. 

###### v18 
When she came, she had him ask her father for a field. She got off her donkey, and Caleb said, "What do you want?" 

###### v19 
She said, "Give me a blessing. Because you have set me in the land of the South, give me also springs of water." So he gave her the upper springs and the lower springs. 

###### v20 
This is the inheritance of the tribe of the children of Judah according to their families. 

###### v21 
The farthest cities of the tribe of the children of Judah toward the border of Edom in the South were Kabzeel, Eder, Jagur, 

###### v22 
Kinah, Dimonah, Adadah, 

###### v23 
Kedesh, Hazor, Ithnan, 

###### v24 
Ziph, Telem, Bealoth, 

###### v25 
Hazor Hadattah, Kerioth Hezron (also called Hazor), 

###### v26 
Amam, Shema, Moladah, 

###### v27 
Hazar Gaddah, Heshmon, Beth Pelet, 

###### v28 
Hazar Shual, Beersheba, Biziothiah, 

###### v29 
Baalah, Iim, Ezem, 

###### v30 
Eltolad, Chesil, Hormah, 

###### v31 
Ziklag, Madmannah, Sansannah, 

###### v32 
Lebaoth, Shilhim, Ain, and Rimmon. All the cities are twenty-nine, with their villages. 

###### v33 
In the lowland, Eshtaol, Zorah, Ashnah, 

###### v34 
Zanoah, En Gannim, Tappuah, Enam, 

###### v35 
Jarmuth, Adullam, Socoh, Azekah, 

###### v36 
Shaaraim, Adithaim and Gederah (or Gederothaim); fourteen cities with their villages. 

###### v37 
Zenan, Hadashah, Migdal Gad, 

###### v38 
Dilean, Mizpah, Joktheel, 

###### v39 
Lachish, Bozkath, Eglon, 

###### v40 
Cabbon, Lahmam, Chitlish, 

###### v41 
Gederoth, Beth Dagon, Naamah, and Makkedah; sixteen cities with their villages. 

###### v42 
Libnah, Ether, Ashan, 

###### v43 
Iphtah, Ashnah, Nezib, 

###### v44 
Keilah, Achzib, and Mareshah; nine cities with their villages. 

###### v45 
Ekron, with its towns and its villages; 

###### v46 
from Ekron even to the sea, all that were by the side of Ashdod, with their villages. 

###### v47 
Ashdod, its towns and its villages; Gaza, its towns and its villages; to the brook of Egypt, and the great sea with its coastline. 

###### v48 
In the hill country, Shamir, Jattir, Socoh, 

###### v49 
Dannah, Kiriath Sannah (which is Debir), 

###### v50 
Anab, Eshtemoh, Anim, 

###### v51 
Goshen, Holon, and Giloh; eleven cities with their villages. 

###### v52 
Arab, Dumah, Eshan, 

###### v53 
Janim, Beth Tappuah, Aphekah, 

###### v54 
Humtah, Kiriath Arba (also called Hebron), and Zior; nine cities with their villages. 

###### v55 
Maon, Carmel, Ziph, Jutah, 

###### v56 
Jezreel, Jokdeam, Zanoah, 

###### v57 
Kain, Gibeah, and Timnah; ten cities with their villages. 

###### v58 
Halhul, Beth Zur, Gedor, 

###### v59 
Maarath, Beth Anoth, and Eltekon; six cities with their villages. 

###### v60 
Kiriath Baal (also called Kiriath Jearim), and Rabbah; two cities with their villages. 

###### v61 
In the wilderness, Beth Arabah, Middin, Secacah, 

###### v62 
Nibshan, the City of Salt, and En Gedi; six cities with their villages. 

###### v63 
As for the Jebusites, the inhabitants of Jerusalem, the children of Judah couldn't drive them out; but the Jebusites live with the children of Judah at Jerusalem to this day.

***
[[Josh-14|← Joshua 14]] | [[Joshua]] | [[Josh-16|Joshua 16 →]]
