# Joshua 8

[[Josh-07|← Joshua 07]] | [[Joshua]] | [[Josh-09|Joshua 09 →]]
***



###### v1 
Yahweh said to Joshua, "Don't be afraid, and don't be dismayed. Take all the warriors with you, and arise, go up to Ai. Behold, I have given into your hand the king of Ai, with his people, his city, and his land. 

###### v2 
You shall do to Ai and her king as you did to Jericho and her king, except you shall take its goods and its livestock for yourselves. Set an ambush for the city behind it." 

###### v3 
So Joshua arose, with all the warriors, to go up to Ai. Joshua chose thirty thousand men, the mighty men of valor, and sent them out by night. 

###### v4 
He commanded them, saying, "Behold, you shall lie in ambush against the city, behind the city. Don't go very far from the city, but all of you be ready. 

###### v5 
I and all the people who are with me will approach the city. It shall happen, when they come out against us, as at the first, that we will flee before them. 

###### v6 
They will come out after us until we have drawn them away from the city; for they will say, 'They flee before us, like the first time.' So we will flee before them, 

###### v7 
and you shall rise up from the ambush, and take possession of the city; for Yahweh your God will deliver it into your hand. 

###### v8 
It shall be, when you have seized the city, that you shall set the city on fire. You shall do this according to Yahweh's word. Behold, I have commanded you." 

###### v9 
Joshua sent them out; and they went to set up the ambush, and stayed between Bethel and Ai on the west side of Ai; but Joshua stayed among the people that night. 

###### v10 
Joshua rose up early in the morning, mustered the people, and went up, he and the elders of Israel, before the people to Ai. 

###### v11 
All the people, even the men of war who were with him, went up and came near, and came before the city and encamped on the north side of Ai. Now there was a valley between him and Ai. 

###### v12 
He took about five thousand men, and set them in ambush between Bethel and Ai, on the west side of the city. 

###### v13 
So they set the people, even all the army who was on the north of the city, and their ambush on the west of the city; and Joshua went that night into the middle of the valley. 

###### v14 
When the king of Ai saw it, they hurried and rose up early, and the men of the city went out against Israel to battle, he and all his people, at the time appointed, before the Arabah; but he didn't know that there was an ambush against him behind the city. 

###### v15 
Joshua and all Israel made as if they were beaten before them, and fled by the way of the wilderness. 

###### v16 
All the people who were in the city were called together to pursue after them. They pursued Joshua, and were drawn away from the city. 

###### v17 
There was not a man left in Ai or Bethel who didn't go out after Israel. They left the city open, and pursued Israel. 

###### v18 
Yahweh said to Joshua, "Stretch out the javelin that is in your hand toward Ai, for I will give it into your hand." Joshua stretched out the javelin that was in his hand toward the city. 

###### v19 
The ambush arose quickly out of their place, and they ran as soon as he had stretched out his hand and entered into the city and took it. They hurried and set the city on fire. 

###### v20 
When the men of Ai looked behind them, they saw, and behold, the smoke of the city ascended up to heaven, and they had no power to flee this way or that way. The people who fled to the wilderness turned back on the pursuers. 

###### v21 
When Joshua and all Israel saw that the ambush had taken the city, and that the smoke of the city ascended, then they turned back and killed the men of Ai. 

###### v22 
The others came out of the city against them, so they were in the middle of Israel, some on this side, and some on that side. They struck them, so that they let none of them remain or escape. 

###### v23 
They captured the king of Ai alive, and brought him to Joshua. 

###### v24 
When Israel had finished killing all the inhabitants of Ai in the field, in the wilderness in which they pursued them, and they had all fallen by the edge of the sword until they were consumed, all Israel returned to Ai and struck it with the edge of the sword. 

###### v25 
All that fell that day, both of men and women, were twelve thousand, even all the people of Ai. 

###### v26 
For Joshua didn't draw back his hand, with which he stretched out the javelin, until he had utterly destroyed all the inhabitants of Ai. 

###### v27 
Israel took for themselves only the livestock and the goods of that city, according to Yahweh's word which he commanded Joshua. 

###### v28 
So Joshua burned Ai and made it a heap forever, even a desolation, to this day. 

###### v29 
He hanged the king of Ai on a tree until the evening. At sundown, Joshua commanded, and they took his body down from the tree and threw it at the entrance of the gate of the city, and raised a great heap of stones on it that remains to this day. 

###### v30 
Then Joshua built an altar to Yahweh, the God of Israel, on Mount Ebal, 

###### v31 
as Moses the servant of Yahweh commanded the children of Israel, as it is written in the book of the law of Moses: an altar of uncut stones, on which no one had lifted up any iron. They offered burnt offerings on it to Yahweh and sacrificed peace offerings. 

###### v32 
He wrote there on the stones a copy of Moses' law, which he wrote in the presence of the children of Israel. 

###### v33 
All Israel, with their elders, officers, and judges, stood on both sides of the ark before the Levitical priests, who carried the ark of Yahweh's covenant, the foreigner as well as the native; half of them in front of Mount Gerizim, and half of them in front of Mount Ebal, as Moses the servant of Yahweh had commanded at the first, that they should bless the people of Israel. 

###### v34 
Afterward he read all the words of the law, the blessing and the curse, according to all that is written in the book of the law. 

###### v35 
There was not a word of all that Moses commanded which Joshua didn't read before all the assembly of Israel, with the women, the little ones, and the foreigners who were among them.

***
[[Josh-07|← Joshua 07]] | [[Joshua]] | [[Josh-09|Joshua 09 →]]
