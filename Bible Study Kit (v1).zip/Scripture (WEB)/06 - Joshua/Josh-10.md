# Joshua 10

[[Josh-09|← Joshua 09]] | [[Joshua]] | [[Josh-11|Joshua 11 →]]
***



###### v1 
Now when Adoni-Zedek king of Jerusalem heard how Joshua had taken Ai, and had utterly destroyed it; as he had done to Jericho and her king, so he had done to Ai and her king; and how the inhabitants of Gibeon had made peace with Israel, and were among them, 

###### v2 
they were very afraid, because Gibeon was a great city, as one of the royal cities, and because it was greater than Ai, and all its men were mighty. 

###### v3 
Therefore Adoni-Zedek king of Jerusalem sent to Hoham king of Hebron, Piram king of Jarmuth, Japhia king of Lachish, and Debir king of Eglon, saying, 

###### v4 
"Come up to me and help me. Let's strike Gibeon; for they have made peace with Joshua and with the children of Israel." 

###### v5 
Therefore the five kings of the Amorites, the king of Jerusalem, the king of Hebron, the king of Jarmuth, the king of Lachish, and the king of Eglon, gathered themselves together and went up, they and all their armies, and encamped against Gibeon, and made war against it. 

###### v6 
The men of Gibeon sent to Joshua at the camp at Gilgal, saying, "Don't abandon your servants! Come up to us quickly and save us! Help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us." 

###### v7 
So Joshua went up from Gilgal, he, and the whole army with him, including all the mighty men of valor. 

###### v8 
Yahweh said to Joshua, "Don't fear them, for I have delivered them into your hands. Not a man of them will stand before you." 

###### v9 
Joshua therefore came to them suddenly. He marched from Gilgal all night. 

###### v10 
Yahweh confused them before Israel. He killed them with a great slaughter at Gibeon, and chased them by the way of the ascent of Beth Horon, and struck them to Azekah and to Makkedah. 

###### v11 
As they fled from before Israel, while they were at the descent of Beth Horon, Yahweh hurled down great stones from the sky on them to Azekah, and they died. There were more who died from the hailstones than those whom the children of Israel killed with the sword. 

###### v12 
Then Joshua spoke to Yahweh in the day when Yahweh delivered up the Amorites before the children of Israel. He said in the sight of Israel, "Sun, stand still on Gibeon! You, moon, stop in the valley of Aijalon!" 

###### v13 
The sun stood still, and the moon stayed, until the nation had avenged themselves of their enemies. Isn't this written in the book of Jashar? The sun stayed in the middle of the sky, and didn't hurry to go down about a whole day. 

###### v14 
There was no day like that before it or after it, that Yahweh listened to the voice of a man; for Yahweh fought for Israel. 

###### v15 
Joshua returned, and all Israel with him, to the camp to Gilgal. 

###### v16 
These five kings fled, and hid themselves in the cave at Makkedah. 

###### v17 
Joshua was told, saying, "The five kings have been found, hidden in the cave at Makkedah." 

###### v18 
Joshua said, "Roll large stones to cover the cave's entrance, and set men by it to guard them; 

###### v19 
but don't stay there. Pursue your enemies, and attack them from the rear. Don't allow them to enter into their cities; for Yahweh your God has delivered them into your hand." 

###### v20 
When Joshua and the children of Israel had finished killing them with a very great slaughter until they were consumed, and the remnant which remained of them had entered into the fortified cities, 

###### v21 
all the people returned to the camp to Joshua at Makkedah in peace. None moved his tongue against any of the children of Israel. 

###### v22 
Then Joshua said, "Open the cave entrance, and bring those five kings out of the cave to me." 

###### v23 
They did so, and brought those five kings out of the cave to him: the king of Jerusalem, the king of Hebron, the king of Jarmuth, the king of Lachish, and the king of Eglon. 

###### v24 
When they brought those kings out to Joshua, Joshua called for all the men of Israel, and said to the chiefs of the men of war who went with him, "Come near. Put your feet on the necks of these kings." They came near, and put their feet on their necks. 

###### v25 
Joshua said to them, "Don't be afraid, nor be dismayed. Be strong and courageous, for Yahweh will do this to all your enemies against whom you fight." 

###### v26 
Afterward Joshua struck them, put them to death, and hanged them on five trees. They were hanging on the trees until the evening. 

###### v27 
At the time of the going down of the sun, Joshua commanded, and they took them down off the trees, and threw them into the cave in which they had hidden themselves, and laid great stones on the mouth of the cave, which remain to this very day. 

###### v28 
Joshua took Makkedah on that day, and struck it with the edge of the sword, with its king. He utterly destroyed it and all the souls who were in it. He left no one remaining. He did to the king of Makkedah as he had done to the king of Jericho. 

###### v29 
Joshua passed from Makkedah, and all Israel with him, to Libnah, and fought against Libnah. 

###### v30 
Yahweh delivered it also, with its king, into the hand of Israel. He struck it with the edge of the sword, and all the souls who were in it. He left no one remaining in it. He did to its king as he had done to the king of Jericho. 

###### v31 
Joshua passed from Libnah, and all Israel with him, to Lachish, and encamped against it, and fought against it. 

###### v32 
Yahweh delivered Lachish into the hand of Israel. He took it on the second day, and struck it with the edge of the sword, with all the souls who were in it, according to all that he had done to Libnah. 

###### v33 
Then Horam king of Gezer came up to help Lachish; and Joshua struck him and his people, until he had left him no one remaining. 

###### v34 
Joshua passed from Lachish, and all Israel with him, to Eglon; and they encamped against it and fought against it. 

###### v35 
They took it on that day, and struck it with the edge of the sword. He utterly destroyed all the souls who were in it that day, according to all that he had done to Lachish. 

###### v36 
Joshua went up from Eglon, and all Israel with him, to Hebron; and they fought against it. 

###### v37 
They took it, and struck it with the edge of the sword, with its king and all its cities, and all the souls who were in it. He left no one remaining, according to all that he had done to Eglon; but he utterly destroyed it, and all the souls who were in it. 

###### v38 
Joshua returned, and all Israel with him, to Debir, and fought against it. 

###### v39 
He took it, with its king and all its cities. They struck them with the edge of the sword, and utterly destroyed all the souls who were in it. He left no one remaining. As he had done to Hebron, so he did to Debir, and to its king; as he had done also to Libnah, and to its king. 

###### v40 
So Joshua struck all the land, the hill country, the South, the lowland, the slopes, and all their kings. He left no one remaining, but he utterly destroyed all that breathed, as Yahweh, the God of Israel, commanded. 

###### v41 
Joshua struck them from Kadesh Barnea even to Gaza, and all the country of Goshen, even to Gibeon. 

###### v42 
Joshua took all these kings and their land at one time because Yahweh, the God of Israel, fought for Israel. 

###### v43 
Joshua returned, and all Israel with him, to the camp to Gilgal.

***
[[Josh-09|← Joshua 09]] | [[Joshua]] | [[Josh-11|Joshua 11 →]]
