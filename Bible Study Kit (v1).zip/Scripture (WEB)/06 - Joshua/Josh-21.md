# Joshua 21

[[Josh-20|← Joshua 20]] | [[Joshua]] | [[Josh-22|Joshua 22 →]]
***



###### v1 
Then the heads of fathers' houses of the Levites came near to Eleazar the priest, and to Joshua the son of Nun, and to the heads of fathers' houses of the tribes of the children of Israel. 

###### v2 
They spoke to them at Shiloh in the land of Canaan, saying, "Yahweh commanded through Moses to give us cities to dwell in, with their pasture lands for our livestock." 

###### v3 
The children of Israel gave to the Levites out of their inheritance, according to the commandment of Yahweh, these cities with their pasture lands. 

###### v4 
The lot came out for the families of the Kohathites. The children of Aaron the priest, who were of the Levites, had thirteen cities by lot out of the tribe of Judah, out of the tribe of the Simeonites, and out of the tribe of Benjamin. 

###### v5 
The rest of the children of Kohath had ten cities by lot out of the families of the tribe of Ephraim, out of the tribe of Dan, and out of the half-tribe of Manasseh. 

###### v6 
The children of Gershon had thirteen cities by lot out of the families of the tribe of Issachar, out of the tribe of Asher, out of the tribe of Naphtali, and out of the half-tribe of Manasseh in Bashan. 

###### v7 
The children of Merari according to their families had twelve cities out of the tribe of Reuben, out of the tribe of Gad, and out of the tribe of Zebulun. 

###### v8 
The children of Israel gave these cities with their pasture lands by lot to the Levites, as Yahweh commanded by Moses. 

###### v9 
They gave out of the tribe of the children of Judah, and out of the tribe of the children of Simeon, these cities which are mentioned by name: 

###### v10 
and they were for the children of Aaron, of the families of the Kohathites, who were of the children of Levi; for theirs was the first lot. 

###### v11 
They gave them Kiriath Arba, named after the father of Anak (also called Hebron), in the hill country of Judah, with its pasture lands around it. 

###### v12 
But they gave the fields of the city and its villages to Caleb the son of Jephunneh for his possession. 

###### v13 
To the children of Aaron the priest they gave Hebron with its pasture lands, the city of refuge for the man slayer, Libnah with its pasture lands, 

###### v14 
Jattir with its pasture lands, Eshtemoa with its pasture lands, 

###### v15 
Holon with its pasture lands, Debir with its pasture lands, 

###### v16 
Ain with its pasture lands, Juttah with its pasture lands, and Beth Shemesh with its pasture lands: nine cities out of those two tribes. 

###### v17 
Out of the tribe of Benjamin, Gibeon with its pasture lands, Geba with its pasture lands, 

###### v18 
Anathoth with its pasture lands, and Almon with its pasture lands: four cities. 

###### v19 
All the cities of the children of Aaron, the priests, were thirteen cities with their pasture lands. 

###### v20 
The families of the children of Kohath, the Levites, even the rest of the children of Kohath, had the cities of their lot out of the tribe of Ephraim. 

###### v21 
They gave them Shechem with its pasture lands in the hill country of Ephraim, the city of refuge for the man slayer, and Gezer with its pasture lands, 

###### v22 
Kibzaim with its pasture lands, and Beth Horon with its pasture lands: four cities. 

###### v23 
Out of the tribe of Dan, Elteke with its pasture lands, Gibbethon with its pasture lands, 

###### v24 
Aijalon with its pasture lands, Gath Rimmon with its pasture lands: four cities. 

###### v25 
Out of the half-tribe of Manasseh, Taanach with its pasture lands, and Gath Rimmon with its pasture lands: two cities. 

###### v26 
All the cities of the families of the rest of the children of Kohath were ten with their pasture lands. 

###### v27 
They gave to the children of Gershon, of the families of the Levites, out of the half-tribe of Manasseh Golan in Bashan with its pasture lands, the city of refuge for the man slayer, and Be Eshterah with its pasture lands: two cities. 

###### v28 
Out of the tribe of Issachar, Kishion with its pasture lands, Daberath with its pasture lands, 

###### v29 
Jarmuth with its pasture lands, En Gannim with its pasture lands: four cities. 

###### v30 
Out of the tribe of Asher, Mishal with its pasture lands, Abdon with its pasture lands, 

###### v31 
Helkath with its pasture lands, and Rehob with its pasture lands: four cities. 

###### v32 
Out of the tribe of Naphtali, Kedesh in Galilee with its pasture lands, the city of refuge for the man slayer, Hammothdor with its pasture lands, and Kartan with its pasture lands: three cities. 

###### v33 
All the cities of the Gershonites according to their families were thirteen cities with their pasture lands. 

###### v34 
To the families of the children of Merari, the rest of the Levites, out of the tribe of Zebulun, Jokneam with its pasture lands, Kartah with its pasture lands, 

###### v35 
Dimnah with its pasture lands, and Nahalal with its pasture lands: four cities. 

###### v36 
Out of the tribe of Reuben, Bezer with its pasture lands, Jahaz with its pasture lands, 

###### v37 
Kedemoth with its pasture lands, and Mephaath with its pasture lands: four cities. 

###### v38 
Out of the tribe of Gad, Ramoth in Gilead with its pasture lands, the city of refuge for the man slayer, and Mahanaim with its pasture lands, 

###### v39 
Heshbon with its pasture lands, Jazer with its pasture lands: four cities in all. 

###### v40 
All these were the cities of the children of Merari according to their families, even the rest of the families of the Levites. Their lot was twelve cities. 

###### v41 
All the cities of the Levites among the possessions of the children of Israel were forty-eight cities with their pasture lands. 

###### v42 
Each of these cities included their pasture lands around them. It was this way with all these cities. 

###### v43 
So Yahweh gave to Israel all the land which he swore to give to their fathers. They possessed it, and lived in it. 

###### v44 
Yahweh gave them rest all around, according to all that he swore to their fathers. Not a man of all their enemies stood before them. Yahweh delivered all their enemies into their hand. 

###### v45 
Nothing failed of any good thing which Yahweh had spoken to the house of Israel. All came to pass.

***
[[Josh-20|← Joshua 20]] | [[Joshua]] | [[Josh-22|Joshua 22 →]]
