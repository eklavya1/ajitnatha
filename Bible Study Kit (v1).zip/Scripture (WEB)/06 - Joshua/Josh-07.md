# Joshua 7

[[Josh-06|← Joshua 06]] | [[Joshua]] | [[Josh-08|Joshua 08 →]]
***



###### v1 
But the children of Israel committed a trespass in the devoted things; for Achan, the son of Carmi, the son of Zabdi, the son of Zerah, of the tribe of Judah, took some of the devoted things. Therefore Yahweh's anger burned against the children of Israel. 

###### v2 
Joshua sent men from Jericho to Ai, which is beside Beth Aven, on the east side of Bethel, and spoke to them, saying, "Go up and spy out the land." The men went up and spied out Ai. 

###### v3 
They returned to Joshua, and said to him, "Don't let all the people go up, but let about two or three thousand men go up and strike Ai. Don't make all the people to toil there, for there are only a few of them." 

###### v4 
So about three thousand men of the people went up there, and they fled before the men of Ai. 

###### v5 
The men of Ai struck about thirty-six men of them. They chased them from before the gate even to Shebarim, and struck them at the descent. The hearts of the people melted, and became like water. 

###### v6 
Joshua tore his clothes, and fell to the earth on his face before Yahweh's ark until the evening, he and the elders of Israel; and they put dust on their heads. 

###### v7 
Joshua said, "Alas, Lord Yahweh, why have you brought this people over the Jordan at all, to deliver us into the hand of the Amorites, to cause us to perish? I wish that we had been content and lived beyond the Jordan! 

###### v8 
Oh, Lord, what shall I say, after Israel has turned their backs before their enemies? 

###### v9 
For the Canaanites and all the inhabitants of the land will hear of it, and will surround us, and cut off our name from the earth. What will you do for your great name?" 

###### v10 
Yahweh said to Joshua, "Get up! Why have you fallen on your face like that? 

###### v11 
Israel has sinned. Yes, they have even transgressed my covenant which I commanded them. Yes, they have even taken some of the devoted things, and have also stolen, and also deceived. They have even put it among their own stuff. 

###### v12 
Therefore the children of Israel can't stand before their enemies. They turn their backs before their enemies, because they have become devoted for destruction. I will not be with you any more, unless you destroy the devoted things from among you. 

###### v13 
Get up! Sanctify the people, and say, 'Sanctify yourselves for tomorrow, for Yahweh, the God of Israel, says, "There is a devoted thing among you, Israel. You cannot stand before your enemies until you take away the devoted thing from among you." 

###### v14 
In the morning therefore you shall be brought near by your tribes. It shall be that the tribe which Yahweh selects shall come near by families. The family which Yahweh selects shall come near by households. The household which Yahweh selects shall come near man by man. 

###### v15 
It shall be, that he who is taken with the devoted thing shall be burned with fire, he and all that he has, because he has transgressed Yahweh's covenant, and because he has done a disgraceful thing in Israel.'" 

###### v16 
So Joshua rose up early in the morning and brought Israel near by their tribes. The tribe of Judah was selected. 

###### v17 
He brought near the family of Judah, and he selected the family of the Zerahites. He brought near the family of the Zerahites man by man, and Zabdi was selected. 

###### v18 
He brought near his household man by man, and Achan, the son of Carmi, the son of Zabdi, the son of Zerah, of the tribe of Judah, was selected. 

###### v19 
Joshua said to Achan, "My son, please give glory to Yahweh, the God of Israel, and make confession to him. Tell me now what you have done! Don't hide it from me!" 

###### v20 
Achan answered Joshua, and said, "I have truly sinned against Yahweh, the God of Israel, and this is what I have done. 

###### v21 
When I saw among the plunder a beautiful Babylonian robe, two hundred shekels of silver, and a wedge of gold weighing fifty shekels, then I coveted them and took them. Behold, they are hidden in the ground in the middle of my tent, with the silver under it." 

###### v22 
So Joshua sent messengers, and they ran to the tent. Behold, it was hidden in his tent, with the silver under it. 

###### v23 
They took them from the middle of the tent, and brought them to Joshua and to all the children of Israel. They laid them down before Yahweh. 

###### v24 
Joshua, and all Israel with him, took Achan the son of Zerah, the silver, the robe, the wedge of gold, his sons, his daughters, his cattle, his donkeys, his sheep, his tent, and all that he had; and they brought them up to the valley of Achor. 

###### v25 
Joshua said, "Why have you troubled us? Yahweh will trouble you today." All Israel stoned him with stones, and they burned them with fire and stoned them with stones. 

###### v26 
They raised over him a great heap of stones that remains to this day. Yahweh turned from the fierceness of his anger. Therefore the name of that place was called "The valley of Achor" to this day.

***
[[Josh-06|← Joshua 06]] | [[Joshua]] | [[Josh-08|Joshua 08 →]]
