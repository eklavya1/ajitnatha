# Joshua 24

[[Josh-23|← Joshua 23]] | [[Joshua]]
***



###### v1 
Joshua gathered all the tribes of Israel to Shechem, and called for the elders of Israel, for their heads, for their judges, and for their officers; and they presented themselves before God. 

###### v2 
Joshua said to all the people, "Yahweh, the God of Israel, says, 'Your fathers lived of old time beyond the River, even Terah, the father of Abraham, and the father of Nahor. They served other gods. 

###### v3 
I took your father Abraham from beyond the River, and led him throughout all the land of Canaan, and multiplied his offspring, and gave him Isaac. 

###### v4 
I gave to Isaac Jacob and Esau: and I gave to Esau Mount Seir, to possess it. Jacob and his children went down into Egypt. 

###### v5 
"'I sent Moses and Aaron, and I plagued Egypt, according to that which I did among them: and afterward I brought you out. 

###### v6 
I brought your fathers out of Egypt: and you came to the sea. The Egyptians pursued your fathers with chariots and with horsemen to the Red Sea. 

###### v7 
When they cried out to Yahweh, he put darkness between you and the Egyptians, and brought the sea on them, and covered them; and your eyes saw what I did in Egypt. You lived in the wilderness many days. 

###### v8 
"'I brought you into the land of the Amorites, that lived beyond the Jordan. They fought with you, and I gave them into your hand. You possessed their land, and I destroyed them from before you. 

###### v9 
Then Balak the son of Zippor, king of Moab, arose and fought against Israel. He sent and called Balaam the son of Beor to curse you, 

###### v10 
but I would not listen to Balaam; therefore he blessed you still. So I delivered you out of his hand. 

###### v11 
"'You went over the Jordan, and came to Jericho. The men of Jericho fought against you, the Amorite, the Perizzite, the Canaanite, the Hittite, the Girgashite, the Hivite, and the Jebusite; and I delivered them into your hand. 

###### v12 
I sent the hornet before you, which drove them out from before you, even the two kings of the Amorites; not with your sword, nor with your bow. 

###### v13 
I gave you a land on which you had not labored, and cities which you didn't build, and you live in them. You eat of vineyards and olive groves which you didn't plant.' 

###### v14 
"Now therefore fear Yahweh, and serve him in sincerity and in truth. Put away the gods which your fathers served beyond the River, in Egypt; and serve Yahweh. 

###### v15 
If it seems evil to you to serve Yahweh, choose today whom you will serve; whether the gods which your fathers served that were beyond the River, or the gods of the Amorites, in whose land you dwell; but as for me and my house, we will serve Yahweh." 

###### v16 
The people answered, "Far be it from us that we should forsake Yahweh, to serve other gods; 

###### v17 
for it is Yahweh our God who brought us and our fathers up out of the land of Egypt, from the house of bondage, and who did those great signs in our sight, and preserved us in all the way in which we went, and among all the peoples through the middle of whom we passed. 

###### v18 
Yahweh drove out from before us all the peoples, even the Amorites who lived in the land. Therefore we also will serve Yahweh; for he is our God." 

###### v19 
Joshua said to the people, "You can't serve Yahweh, for he is a holy God. He is a jealous God. He will not forgive your disobedience nor your sins. 

###### v20 
If you forsake Yahweh, and serve foreign gods, then he will turn and do you evil, and consume you, after he has done you good." 

###### v21 
The people said to Joshua, "No, but we will serve Yahweh." 

###### v22 
Joshua said to the people, "You are witnesses against yourselves that you have chosen Yahweh yourselves, to serve him." They said, "We are witnesses." 

###### v23 
"Now therefore put away the foreign gods which are among you, and incline your heart to Yahweh, the God of Israel." 

###### v24 
The people said to Joshua, "We will serve Yahweh our God, and we will listen to his voice." 

###### v25 
So Joshua made a covenant with the people that day, and made for them a statute and an ordinance in Shechem. 

###### v26 
Joshua wrote these words in the book of the law of God; and he took a great stone, and set it up there under the oak that was by the sanctuary of Yahweh. 

###### v27 
Joshua said to all the people, "Behold, this stone shall be a witness against us, for it has heard all Yahweh's words which he spoke to us. It shall be therefore a witness against you, lest you deny your God." 

###### v28 
So Joshua sent the people away, each to his own inheritance. 

###### v29 
After these things, Joshua the son of Nun, the servant of Yahweh, died, being one hundred ten years old. 

###### v30 
They buried him in the border of his inheritance in Timnathserah, which is in the hill country of Ephraim, on the north of the mountain of Gaash. 

###### v31 
Israel served Yahweh all the days of Joshua, and all the days of the elders who outlived Joshua, and had known all the work of Yahweh, that he had worked for Israel. 

###### v32 
They buried the bones of Joseph, which the children of Israel brought up out of Egypt, in Shechem, in the parcel of ground which Jacob bought from the sons of Hamor the father of Shechem for a hundred pieces of silver. They became the inheritance of the children of Joseph. 

###### v33 
Eleazar the son of Aaron died. They buried him in the hill of Phinehas his son, which was given him in the hill country of Ephraim.

***
[[Josh-23|← Joshua 23]] | [[Joshua]]
