# Joshua 16

[[Josh-15|← Joshua 15]] | [[Joshua]] | [[Josh-17|Joshua 17 →]]
***



###### v1 
The lot came out for the children of Joseph from the Jordan at Jericho, at the waters of Jericho on the east, even the wilderness, going up from Jericho through the hill country to Bethel. 

###### v2 
It went out from Bethel to Luz, and passed along to the border of the Archites to Ataroth; 

###### v3 
and it went down westward to the border of the Japhletites, to the border of Beth Horon the lower, and on to Gezer; and ended at the sea. 

###### v4 
The children of Joseph, Manasseh and Ephraim, took their inheritance. 

###### v5 
This was the border of the children of Ephraim according to their families. The border of their inheritance eastward was Ataroth Addar, to Beth Horon the upper. 

###### v6 
The border went out westward at Michmethath on the north. The border turned about eastward to Taanath Shiloh, and passed along it on the east of Janoah. 

###### v7 
It went down from Janoah to Ataroth, to Naarah, reached to Jericho, and went out at the Jordan. 

###### v8 
From Tappuah the border went along westward to the brook of Kanah; and ended at the sea. This is the inheritance of the tribe of the children of Ephraim according to their families; 

###### v9 
together with the cities which were set apart for the children of Ephraim in the middle of the inheritance of the children of Manasseh, all the cities with their villages. 

###### v10 
They didn't drive out the Canaanites who lived in Gezer; but the Canaanites dwell in the territory of Ephraim to this day, and have become servants to do forced labor.

***
[[Josh-15|← Joshua 15]] | [[Joshua]] | [[Josh-17|Joshua 17 →]]
