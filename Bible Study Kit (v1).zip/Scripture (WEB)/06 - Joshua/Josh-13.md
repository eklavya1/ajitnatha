# Joshua 13

[[Josh-12|← Joshua 12]] | [[Joshua]] | [[Josh-14|Joshua 14 →]]
***



###### v1 
Now Joshua was old and well advanced in years. Yahweh said to him, "You are old and advanced in years, and there remains yet very much land to be possessed. 

###### v2 
"This is the land that still remains: all the regions of the Philistines, and all the Geshurites; 

###### v3 
from the Shihor, which is before Egypt, even to the border of Ekron northward, which is counted as Canaanite; the five lords of the Philistines; the Gazites, and the Ashdodites, the Ashkelonites, the Gittites, and the Ekronites; also the Avvim, 

###### v4 
on the south; all the land of the Canaanites, and Mearah that belongs to the Sidonians, to Aphek, to the border of the Amorites; 

###### v5 
and the land of the Gebalites, and all Lebanon, toward the sunrise, from Baal Gad under Mount Hermon to the entrance of Hamath; 

###### v6 
all the inhabitants of the hill country from Lebanon to Misrephoth Maim, even all the Sidonians. I will drive them out from before the children of Israel. Just allocate it to Israel for an inheritance, as I have commanded you. 

###### v7 
Now therefore divide this land for an inheritance to the nine tribes and the half-tribe of Manasseh." 

###### v8 
With him the Reubenites and the Gadites received their inheritance, which Moses gave them, beyond the Jordan eastward, even as Moses the servant of Yahweh gave them: 

###### v9 
from Aroer, that is on the edge of the valley of the Arnon, and the city that is in the middle of the valley, and all the plain of Medeba to Dibon; 

###### v10 
and all the cities of Sihon king of the Amorites, who reigned in Heshbon, to the border of the children of Ammon; 

###### v11 
and Gilead, and the border of the Geshurites and Maacathites, and all Mount Hermon, and all Bashan to Salecah; 

###### v12 
all the kingdom of Og in Bashan, who reigned in Ashtaroth and in Edrei (who was left of the remnant of the Rephaim); for Moses attacked these, and drove them out. 

###### v13 
Nevertheless the children of Israel didn't drive out the Geshurites, nor the Maacathites: but Geshur and Maacath live within Israel to this day. 

###### v14 
Only he gave no inheritance to the tribe of Levi. The offerings of Yahweh, the God of Israel, made by fire are his inheritance, as he spoke to him. 

###### v15 
Moses gave to the tribe of the children of Reuben according to their families. 

###### v16 
Their border was from Aroer, that is on the edge of the valley of the Arnon, and the city that is in the middle of the valley, and all the plain by Medeba; 

###### v17 
Heshbon, and all its cities that are in the plain; Dibon, Bamoth Baal, Beth Baal Meon, 

###### v18 
Jahaz, Kedemoth, Mephaath, 

###### v19 
Kiriathaim, Sibmah, Zereth Shahar in the mount of the valley, 

###### v20 
Beth Peor, the slopes of Pisgah, Beth Jeshimoth, 

###### v21 
all the cities of the plain, and all the kingdom of Sihon king of the Amorites, who reigned in Heshbon, whom Moses struck with the chiefs of Midian, Evi, Rekem, Zur, Hur, and Reba, the princes of Sihon, who lived in the land. 

###### v22 
The children of Israel also killed Balaam the son of Beor, the soothsayer, with the sword, among the rest of their slain. 

###### v23 
The border of the children of Reuben was the bank of the Jordan. This was the inheritance of the children of Reuben according to their families, the cities and its villages. 

###### v24 
Moses gave to the tribe of Gad, to the children of Gad, according to their families. 

###### v25 
Their border was Jazer, and all the cities of Gilead, and half the land of the children of Ammon, to Aroer that is near Rabbah; 

###### v26 
and from Heshbon to Ramath Mizpeh, and Betonim; and from Mahanaim to the border of Debir; 

###### v27 
and in the valley, Beth Haram, Beth Nimrah, Succoth, and Zaphon, the rest of the kingdom of Sihon king of Heshbon, the Jordan's bank, to the uttermost part of the sea of Chinnereth beyond the Jordan eastward. 

###### v28 
This is the inheritance of the children of Gad according to their families, the cities and its villages. 

###### v29 
Moses gave an inheritance to the half-tribe of Manasseh. It was for the half-tribe of the children of Manasseh according to their families. 

###### v30 
Their border was from Mahanaim, all Bashan, all the kingdom of Og king of Bashan, and all the villages of Jair, which are in Bashan, sixty cities. 

###### v31 
Half Gilead, Ashtaroth, and Edrei, the cities of the kingdom of Og in Bashan, were for the children of Machir the son of Manasseh, even for the half of the children of Machir according to their families. 

###### v32 
These are the inheritances which Moses distributed in the plains of Moab, beyond the Jordan at Jericho, eastward. 

###### v33 
But Moses gave no inheritance to the tribe of Levi. Yahweh, the God of Israel, is their inheritance, as he spoke to them.

***
[[Josh-12|← Joshua 12]] | [[Joshua]] | [[Josh-14|Joshua 14 →]]
