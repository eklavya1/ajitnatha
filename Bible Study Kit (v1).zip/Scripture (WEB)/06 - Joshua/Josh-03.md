# Joshua 3

[[Josh-02|← Joshua 02]] | [[Joshua]] | [[Josh-04|Joshua 04 →]]
***



###### v1 
Joshua got up early in the morning; and they moved from Shittim and came to the Jordan, he and all the children of Israel. They camped there before they crossed over. 

###### v2 
After three days, the officers went through the middle of the camp; 

###### v3 
and they commanded the people, saying, "When you see the ark of Yahweh your God's covenant, and the Levitical priests bearing it, then leave your place and follow it. 

###### v4 
Yet there shall be a space between you and it of about two thousand cubits by measure--don't come closer to it--that you may know the way by which you must go; for you have not passed this way before." 

###### v5 
Joshua said to the people, "Sanctify yourselves; for tomorrow Yahweh will do wonders among you." 

###### v6 
Joshua spoke to the priests, saying, "Take up the ark of the covenant, and cross over before the people." They took up the ark of the covenant, and went before the people. 

###### v7 
Yahweh said to Joshua, "Today I will begin to magnify you in the sight of all Israel, that they may know that as I was with Moses, so I will be with you. 

###### v8 
You shall command the priests who bear the ark of the covenant, saying, 'When you come to the brink of the waters of the Jordan, you shall stand still in the Jordan.'" 

###### v9 
Joshua said to the children of Israel, "Come here, and hear the words of Yahweh your God." 

###### v10 
Joshua said, "By this you shall know that the living God is among you, and that he will without fail drive the Canaanite, the Hittite, the Hivite, the Perizzite, the Girgashite, the Amorite, and the Jebusite out from before you. 

###### v11 
Behold, the ark of the covenant of the Lord of all the earth passes over before you into the Jordan. 

###### v12 
Now therefore take twelve men out of the tribes of Israel, for every tribe a man. 

###### v13 
It shall be that when the soles of the feet of the priests who bear the ark of Yahweh, the Lord of all the earth, rest in the waters of the Jordan, that the waters of the Jordan will be cut off. The waters that come down from above shall stand in one heap." 

###### v14 
When the people moved from their tents to pass over the Jordan, the priests who bore the ark of the covenant being before the people, 

###### v15 
and when those who bore the ark had come to the Jordan, and the feet of the priests who bore the ark had dipped in the edge of the water (for the Jordan overflows all its banks all the time of harvest), 

###### v16 
the waters which came down from above stood, and rose up in one heap a great way off, at Adam, the city that is beside Zarethan; and those that went down toward the sea of the Arabah, even the Salt Sea, were wholly cut off. Then the people passed over near Jericho. 

###### v17 
The priests who bore the ark of Yahweh's covenant stood firm on dry ground in the middle of the Jordan; and all Israel crossed over on dry ground, until all the nation had passed completely over the Jordan.

***
[[Josh-02|← Joshua 02]] | [[Joshua]] | [[Josh-04|Joshua 04 →]]
