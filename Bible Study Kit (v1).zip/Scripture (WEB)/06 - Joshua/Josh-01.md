# Joshua 1

[[Joshua]] | [[Josh-02|Joshua 02 →]]
***



###### v1 
Now after the death of Moses the servant of Yahweh, Yahweh spoke to Joshua the son of Nun, Moses' servant, saying, 

###### v2 
"Moses my servant is dead. Now therefore arise, go across this Jordan, you and all these people, to the land which I am giving to them, even to the children of Israel. 

###### v3 
I have given you every place that the sole of your foot will tread on, as I told Moses. 

###### v4 
From the wilderness and this Lebanon even to the great river, the river Euphrates, all the land of the Hittites, and to the great sea toward the going down of the sun, shall be your border. 

###### v5 
No man will be able to stand before you all the days of your life. As I was with Moses, so I will be with you. I will not fail you nor forsake you. 

###### v6 
"Be strong and courageous; for you shall cause this people to inherit the land which I swore to their fathers to give them. 

###### v7 
Only be strong and very courageous. Be careful to observe to do according to all the law which Moses my servant commanded you. Don't turn from it to the right hand or to the left, that you may have good success wherever you go. 

###### v8 
This book of the law shall not depart from your mouth, but you shall meditate on it day and night, that you may observe to do according to all that is written in it; for then you shall make your way prosperous, and then you shall have good success. 

###### v9 
Haven't I commanded you? Be strong and courageous. Don't be afraid. Don't be dismayed, for Yahweh your God is with you wherever you go." 

###### v10 
Then Joshua commanded the officers of the people, saying, 

###### v11 
"Pass through the middle of the camp, and command the people, saying, 'Prepare food; for within three days you are to pass over this Jordan, to go in to possess the land which Yahweh your God gives you to possess.'" 

###### v12 
Joshua spoke to the Reubenites, and to the Gadites, and to the half-tribe of Manasseh, saying, 

###### v13 
"Remember the word which Moses the servant of Yahweh commanded you, saying, 'Yahweh your God gives you rest, and will give you this land. 

###### v14 
Your wives, your little ones, and your livestock shall live in the land which Moses gave you beyond the Jordan; but you shall pass over before your brothers armed, all the mighty men of valor, and shall help them 

###### v15 
until Yahweh has given your brothers rest, as he has given you, and they have also possessed the land which Yahweh your God gives them. Then you shall return to the land of your possession and possess it, which Moses the servant of Yahweh gave you beyond the Jordan toward the sunrise.'" 

###### v16 
They answered Joshua, saying, "All that you have commanded us we will do, and wherever you send us we will go. 

###### v17 
Just as we listened to Moses in all things, so will we listen to you. Only may Yahweh your God be with you, as he was with Moses. 

###### v18 
Whoever rebels against your commandment, and doesn't listen to your words in all that you command him shall himself be put to death. Only be strong and courageous."

***
[[Joshua]] | [[Josh-02|Joshua 02 →]]
