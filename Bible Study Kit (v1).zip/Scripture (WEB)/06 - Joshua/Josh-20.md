# Joshua 20

[[Josh-19|← Joshua 19]] | [[Joshua]] | [[Josh-21|Joshua 21 →]]
***



###### v1 
Yahweh spoke to Joshua, saying, 

###### v2 
"Speak to the children of Israel, saying, 'Assign the cities of refuge, of which I spoke to you by Moses, 

###### v3 
that the man slayer who kills any person accidentally or unintentionally may flee there. They shall be to you for a refuge from the avenger of blood. 

###### v4 
He shall flee to one of those cities, and shall stand at the entrance of the gate of the city, and declare his case in the ears of the elders of that city. They shall take him into the city with them, and give him a place, that he may live among them. 

###### v5 
If the avenger of blood pursues him, then they shall not deliver up the man slayer into his hand; because he struck his neighbor unintentionally, and didn't hate him before. 

###### v6 
He shall dwell in that city until he stands before the congregation for judgment, until the death of the high priest that shall be in those days. Then the man slayer shall return, and come to his own city, and to his own house, to the city he fled from.'" 

###### v7 
They set apart Kedesh in Galilee in the hill country of Naphtali, Shechem in the hill country of Ephraim, and Kiriath Arba (also called Hebron) in the hill country of Judah. 

###### v8 
Beyond the Jordan at Jericho eastward, they assigned Bezer in the wilderness in the plain out of the tribe of Reuben, Ramoth in Gilead out of the tribe of Gad, and Golan in Bashan out of the tribe of Manasseh. 

###### v9 
These were the appointed cities for all the children of Israel, and for the alien who lives among them, that whoever kills any person unintentionally might flee there, and not die by the hand of the avenger of blood, until he stands trial before the congregation.

***
[[Josh-19|← Joshua 19]] | [[Joshua]] | [[Josh-21|Joshua 21 →]]
