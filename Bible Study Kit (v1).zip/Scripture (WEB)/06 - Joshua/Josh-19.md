# Joshua 19

[[Josh-18|← Joshua 18]] | [[Joshua]] | [[Josh-20|Joshua 20 →]]
***



###### v1 
The second lot came out for Simeon, even for the tribe of the children of Simeon according to their families. Their inheritance was in the middle of the inheritance of the children of Judah. 

###### v2 
They had for their inheritance Beersheba (or Sheba), Moladah, 

###### v3 
Hazar Shual, Balah, Ezem, 

###### v4 
Eltolad, Bethul, Hormah, 

###### v5 
Ziklag, Beth Marcaboth, Hazar Susah, 

###### v6 
Beth Lebaoth, and Sharuhen; thirteen cities with their villages; 

###### v7 
Ain, Rimmon, Ether, and Ashan; four cities with their villages; 

###### v8 
and all the villages that were around these cities to Baalath Beer, Ramah of the South. This is the inheritance of the tribe of the children of Simeon according to their families. 

###### v9 
Out of the part of the children of Judah was the inheritance of the children of Simeon; for the portion of the children of Judah was too much for them. Therefore the children of Simeon had inheritance in the middle of their inheritance. 

###### v10 
The third lot came up for the children of Zebulun according to their families. The border of their inheritance was to Sarid. 

###### v11 
Their border went up westward, even to Maralah, and reached to Dabbesheth. It reached to the brook that is before Jokneam. 

###### v12 
It turned from Sarid eastward toward the sunrise to the border of Chisloth Tabor. It went out to Daberath, and went up to Japhia. 

###### v13 
From there it passed along eastward to Gath Hepher, to Ethkazin; and it went out at Rimmon which stretches to Neah. 

###### v14 
The border turned around it on the north to Hannathon; and it ended at the valley of Iphtah El; 

###### v15 
Kattath, Nahalal, Shimron, Idalah, and Bethlehem: twelve cities with their villages. 

###### v16 
This is the inheritance of the children of Zebulun according to their families, these cities with their villages. 

###### v17 
The fourth lot came out for Issachar, even for the children of Issachar according to their families. 

###### v18 
Their border was to Jezreel, Chesulloth, Shunem, 

###### v19 
Hapharaim, Shion, Anaharath, 

###### v20 
Rabbith, Kishion, Ebez, 

###### v21 
Remeth, Engannim, En Haddah, and Beth Pazzez. 

###### v22 
The border reached to Tabor, Shahazumah, and Beth Shemesh. Their border ended at the Jordan: sixteen cities with their villages. 

###### v23 
This is the inheritance of the tribe of the children of Issachar according to their families, the cities with their villages. 

###### v24 
The fifth lot came out for the tribe of the children of Asher according to their families. 

###### v25 
Their border was Helkath, Hali, Beten, Achshaph, 

###### v26 
Allammelech, Amad, Mishal. It reached to Carmel westward, and to Shihorlibnath. 

###### v27 
It turned toward the sunrise to Beth Dagon, and reached to Zebulun, and to the valley of Iphtah El northward to Beth Emek and Neiel. It went out to Cabul on the left hand, 

###### v28 
and Ebron, Rehob, Hammon, and Kanah, even to great Sidon. 

###### v29 
The border turned to Ramah, to the fortified city of Tyre; and the border turned to Hosah. It ended at the sea by the region of Achzib; 

###### v30 
Ummah also, and Aphek, and Rehob: twenty-two cities with their villages. 

###### v31 
This is the inheritance of the tribe of the children of Asher according to their families, these cities with their villages. 

###### v32 
The sixth lot came out for the children of Naphtali, even for the children of Naphtali according to their families. 

###### v33 
Their border was from Heleph, from the oak in Zaanannim, Adami-nekeb, and Jabneel, to Lakkum. It ended at the Jordan. 

###### v34 
The border turned westward to Aznoth Tabor, and went out from there to Hukkok. It reached to Zebulun on the south, and reached to Asher on the west, and to Judah at the Jordan toward the sunrise. 

###### v35 
The fortified cities were Ziddim, Zer, Hammath, Rakkath, Chinnereth, 

###### v36 
Adamah, Ramah, Hazor, 

###### v37 
Kedesh, Edrei, En Hazor, 

###### v38 
Iron, Migdal El, Horem, Beth Anath, and Beth Shemesh; nineteen cities with their villages. 

###### v39 
This is the inheritance of the tribe of the children of Naphtali according to their families, the cities with their villages. 

###### v40 
The seventh lot came out for the tribe of the children of Dan according to their families. 

###### v41 
The border of their inheritance was Zorah, Eshtaol, Irshemesh, 

###### v42 
Shaalabbin, Aijalon, Ithlah, 

###### v43 
Elon, Timnah, Ekron, 

###### v44 
Eltekeh, Gibbethon, Baalath, 

###### v45 
Jehud, Bene Berak, Gath Rimmon, 

###### v46 
Me Jarkon, and Rakkon, with the border opposite Joppa. 

###### v47 
The border of the children of Dan went out beyond them; for the children of Dan went up and fought against Leshem, and took it, and struck it with the edge of the sword, and possessed it, and lived therein, and called Leshem, Dan, after the name of Dan their forefather. 

###### v48 
This is the inheritance of the tribe of the children of Dan according to their families, these cities with their villages. 

###### v49 
So they finished distributing the land for inheritance by its borders. The children of Israel gave an inheritance to Joshua the son of Nun among them. 

###### v50 
According to Yahweh's commandment, they gave him the city which he asked, even Timnathserah in the hill country of Ephraim; and he built the city, and lived there. 

###### v51 
These are the inheritances, which Eleazar the priest, Joshua the son of Nun, and the heads of the fathers' houses of the tribes of the children of Israel, distributed for inheritance by lot in Shiloh before Yahweh, at the door of the Tent of Meeting. So they finished dividing the land.

***
[[Josh-18|← Joshua 18]] | [[Joshua]] | [[Josh-20|Joshua 20 →]]
