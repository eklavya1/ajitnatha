# Joshua 22

[[Josh-21|← Joshua 21]] | [[Joshua]] | [[Josh-23|Joshua 23 →]]
***



###### v1 
Then Joshua called the Reubenites, the Gadites, and the half-tribe of Manasseh, 

###### v2 
and said to them, "You have kept all that Moses the servant of Yahweh commanded you, and have listened to my voice in all that I commanded you. 

###### v3 
You have not left your brothers these many days to this day, but have performed the duty of the commandment of Yahweh your God. 

###### v4 
Now Yahweh your God has given rest to your brothers, as he spoke to them. Therefore now return and go to your tents, to the land of your possession, which Moses the servant of Yahweh gave you beyond the Jordan. 

###### v5 
Only take diligent heed to do the commandment and the law which Moses the servant of Yahweh commanded you, to love Yahweh your God, to walk in all his ways, to keep his commandments, to hold fast to him, and to serve him with all your heart and with all your soul." 

###### v6 
So Joshua blessed them, and sent them away; and they went to their tents. 

###### v7 
Now to the one half-tribe of Manasseh Moses had given inheritance in Bashan; but Joshua gave to the other half among their brothers beyond the Jordan westward. Moreover when Joshua sent them away to their tents, he blessed them, 

###### v8 
and spoke to them, saying, "Return with much wealth to your tents, with very much livestock, with silver, with gold, with bronze, with iron, and with very much clothing. Divide the plunder of your enemies with your brothers." 

###### v9 
The children of Reuben and the children of Gad and the half-tribe of Manasseh returned, and departed from the children of Israel out of Shiloh, which is in the land of Canaan, to go to the land of Gilead, to the land of their possession, which they owned, according to the commandment of Yahweh by Moses. 

###### v10 
When they came to the region near the Jordan, that is in the land of Canaan, the children of Reuben and the children of Gad and the half-tribe of Manasseh built an altar there by the Jordan, a great altar to look at. 

###### v11 
The children of Israel heard this, "Behold, the children of Reuben and the children of Gad and the half-tribe of Manasseh have built an altar along the border of the land of Canaan, in the region around the Jordan, on the side that belongs to the children of Israel." 

###### v12 
When the children of Israel heard of it, the whole congregation of the children of Israel gathered themselves together at Shiloh, to go up against them to war. 

###### v13 
The children of Israel sent to the children of Reuben, and to the children of Gad, and to the half-tribe of Manasseh, into the land of Gilead, Phinehas the son of Eleazar the priest. 

###### v14 
With him were ten princes, one prince of a fathers' house for each of the tribes of Israel; and they were each head of their fathers' houses among the thousands of Israel. 

###### v15 
They came to the children of Reuben, and to the children of Gad, and to the half-tribe of Manasseh, to the land of Gilead, and they spoke with them, saying, 

###### v16 
"The whole congregation of Yahweh says, 'What trespass is this that you have committed against the God of Israel, to turn away today from following Yahweh, in that you have built yourselves an altar, to rebel today against Yahweh? 

###### v17 
Is the iniquity of Peor too little for us, from which we have not cleansed ourselves to this day, although there came a plague on the congregation of Yahweh, 

###### v18 
that you must turn away today from following Yahweh? It will be, since you rebel today against Yahweh, that tomorrow he will be angry with the whole congregation of Israel. 

###### v19 
However, if the land of your possession is unclean, then pass over to the land of the possession of Yahweh, in which Yahweh's tabernacle dwells, and take possession among us; but don't rebel against Yahweh, nor rebel against us, in building an altar other than Yahweh our God's altar. 

###### v20 
Didn't Achan the son of Zerah commit a trespass in the devoted thing, and wrath fell on all the congregation of Israel? That man didn't perish alone in his iniquity.'" 

###### v21 
Then the children of Reuben and the children of Gad and the half-tribe of Manasseh answered, and spoke to the heads of the thousands of Israel, 

###### v22 
"The Mighty One, God, Yahweh, the Mighty One, God, Yahweh, he knows; and Israel shall know: if it was in rebellion, or if in trespass against Yahweh (don't save us today), 

###### v23 
that we have built us an altar to turn away from following Yahweh; or if to offer burnt offering or meal offering, or if to offer sacrifices of peace offerings, let Yahweh himself require it. 

###### v24 
"If we have not out of concern done this, and for a reason, saying, 'In time to come your children might speak to our children, saying, "What have you to do with Yahweh, the God of Israel? 

###### v25 
For Yahweh has made the Jordan a border between us and you, you children of Reuben and children of Gad. You have no portion in Yahweh."' So your children might make our children cease from fearing Yahweh. 

###### v26 
"Therefore we said, 'Let's now prepare to build ourselves an altar, not for burnt offering, nor for sacrifice; 

###### v27 
but it will be a witness between us and you, and between our generations after us, that we may perform the service of Yahweh before him with our burnt offerings, with our sacrifices, and with our peace offerings;' that your children may not tell our children in time to come, 'You have no portion in Yahweh.' 

###### v28 
"Therefore we said, 'It shall be, when they tell us or our generations this in time to come, that we shall say, "Behold the pattern of Yahweh's altar, which our fathers made, not for burnt offering, nor for sacrifice; but it is a witness between us and you."' 

###### v29 
"Far be it from us that we should rebel against Yahweh, and turn away today from following Yahweh, to build an altar for burnt offering, for meal offering, or for sacrifice, besides Yahweh our God's altar that is before his tabernacle!" 

###### v30 
When Phinehas the priest, and the princes of the congregation, even the heads of the thousands of Israel that were with him, heard the words that the children of Reuben and the children of Gad and the children of Manasseh spoke, it pleased them well. 

###### v31 
Phinehas the son of Eleazar the priest said to the children of Reuben, to the children of Gad, and to the children of Manasseh, "Today we know that Yahweh is among us, because you have not committed this trespass against Yahweh. Now you have delivered the children of Israel out of Yahweh's hand." 

###### v32 
Phinehas the son of Eleazar the priest, and the princes, returned from the children of Reuben, and from the children of Gad, out of the land of Gilead, to the land of Canaan, to the children of Israel, and brought them word again. 

###### v33 
The thing pleased the children of Israel; and the children of Israel blessed God, and spoke no more of going up against them to war, to destroy the land in which the children of Reuben and the children of Gad lived. 

###### v34 
The children of Reuben and the children of Gad named the altar "A Witness Between Us that Yahweh is God."

***
[[Josh-21|← Joshua 21]] | [[Joshua]] | [[Josh-23|Joshua 23 →]]
