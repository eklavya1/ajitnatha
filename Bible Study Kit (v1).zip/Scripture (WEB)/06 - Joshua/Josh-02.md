# Joshua 2

[[Josh-01|← Joshua 01]] | [[Joshua]] | [[Josh-03|Joshua 03 →]]
***



###### v1 
Joshua the son of Nun secretly sent two men out of Shittim as spies, saying, "Go, view the land, including Jericho." They went and came into the house of a prostitute whose name was Rahab, and slept there. 

###### v2 
The king of Jericho was told, "Behold, men of the children of Israel came in here tonight to spy out the land." 

###### v3 
Jericho's king sent to Rahab, saying, "Bring out the men who have come to you, who have entered into your house; for they have come to spy out all the land." 

###### v4 
The woman took the two men and hid them. Then she said, "Yes, the men came to me, but I didn't know where they came from. 

###### v5 
About the time of the shutting of the gate, when it was dark, the men went out. Where the men went, I don't know. Pursue them quickly. You may catch up with them." 

###### v6 
But she had brought them up to the roof, and hidden them under the stalks of flax which she had laid in order on the roof. 

###### v7 
The men pursued them along the way to the fords of the Jordan River. As soon as those who pursued them had gone out, they shut the gate. 

###### v8 
Before they had lain down, she came up to them on the roof. 

###### v9 
She said to the men, "I know that Yahweh has given you the land, and that the fear of you has fallen upon us, and that all the inhabitants of the land melt away before you. 

###### v10 
For we have heard how Yahweh dried up the water of the Red Sea before you, when you came out of Egypt; and what you did to the two kings of the Amorites, who were beyond the Jordan, to Sihon and to Og, whom you utterly destroyed. 

###### v11 
As soon as we had heard it, our hearts melted, and there wasn't any more spirit in any man, because of you: for Yahweh your God, he is God in heaven above, and on earth beneath. 

###### v12 
Now therefore, please swear to me by Yahweh, since I have dealt kindly with you, that you also will deal kindly with my father's house, and give me a true sign; 

###### v13 
and that you will save alive my father, my mother, my brothers, and my sisters, and all that they have, and will deliver our lives from death." 

###### v14 
The men said to her, "Our life for yours, if you don't talk about this business of ours; and it shall be, when Yahweh gives us the land, that we will deal kindly and truly with you." 

###### v15 
Then she let them down by a cord through the window; for her house was on the side of the wall, and she lived on the wall. 

###### v16 
She said to them, "Go to the mountain, lest the pursuers find you. Hide yourselves there three days, until the pursuers have returned. Afterward, you may go your way." 

###### v17 
The men said to her, "We will be guiltless of this your oath which you've made us to swear. 

###### v18 
Behold, when we come into the land, tie this line of scarlet thread in the window which you used to let us down. Gather to yourself into the house your father, your mother, your brothers, and all your father's household. 

###### v19 
It shall be that whoever goes out of the doors of your house into the street, his blood will be on his head, and we will be guiltless. Whoever is with you in the house, his blood shall be on our head, if any hand is on him. 

###### v20 
But if you talk about this business of ours, then we shall be guiltless of your oath which you've made us to swear." 

###### v21 
She said, "Let it be as you have said." She sent them away, and they departed. Then she tied the scarlet line in the window. 

###### v22 
They went and came to the mountain, and stayed there three days, until the pursuers had returned. The pursuers sought them all along the way, but didn't find them. 

###### v23 
Then the two men returned, descended from the mountain, crossed the river, and came to Joshua the son of Nun. They told him all that had happened to them. 

###### v24 
They said to Joshua, "Truly Yahweh has delivered all the land into our hands. Moreover, all the inhabitants of the land melt away before us."

***
[[Josh-01|← Joshua 01]] | [[Joshua]] | [[Josh-03|Joshua 03 →]]
