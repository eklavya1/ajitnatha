# Joshua 9

[[Josh-08|← Joshua 08]] | [[Joshua]] | [[Josh-10|Joshua 10 →]]
***



###### v1 
When all the kings who were beyond the Jordan, in the hill country, and in the lowland, and on all the shore of the great sea in front of Lebanon, the Hittite, the Amorite, the Canaanite, the Perizzite, the Hivite, and the Jebusite, heard of it 

###### v2 
they gathered themselves together to fight with Joshua and with Israel, with one accord. 

###### v3 
But when the inhabitants of Gibeon heard what Joshua had done to Jericho and to Ai, 

###### v4 
they also resorted to a ruse, and went and made as if they had been ambassadors, and took old sacks on their donkeys, and old, torn-up and bound up wine skins, 

###### v5 
and old and patched sandals on their feet, and wore old garments. All the bread of their food supply was dry and moldy. 

###### v6 
They went to Joshua at the camp at Gilgal, and said to him and to the men of Israel, "We have come from a far country. Now therefore make a covenant with us." 

###### v7 
The men of Israel said to the Hivites, "What if you live among us? How could we make a covenant with you?" 

###### v8 
They said to Joshua, "We are your servants." Joshua said to them, "Who are you? Where do you come from?" 

###### v9 
They said to him, "Your servants have come from a very far country because of the name of Yahweh your God; for we have heard of his fame, all that he did in Egypt, 

###### v10 
and all that he did to the two kings of the Amorites who were beyond the Jordan, to Sihon king of Heshbon and to Og king of Bashan, who was at Ashtaroth. 

###### v11 
Our elders and all the inhabitants of our country spoke to us, saying, 'Take supplies in your hand for the journey, and go to meet them. Tell them, "We are your servants. Now make a covenant with us."' 

###### v12 
This our bread we took hot for our supplies out of our houses on the day we went out to go to you; but now, behold, it is dry, and has become moldy. 

###### v13 
These wine skins, which we filled, were new; and behold, they are torn. These our garments and our sandals have become old because of the very long journey." 

###### v14 
The men sampled their provisions, and didn't ask counsel from Yahweh's mouth. 

###### v15 
Joshua made peace with them, and made a covenant with them, to let them live. The princes of the congregation swore to them. 

###### v16 
At the end of three days after they had made a covenant with them, they heard that they were their neighbors, and that they lived among them. 

###### v17 
The children of Israel traveled and came to their cities on the third day. Now their cities were Gibeon, Chephirah, Beeroth, and Kiriath Jearim. 

###### v18 
The children of Israel didn't strike them, because the princes of the congregation had sworn to them by Yahweh, the God of Israel. All the congregation murmured against the princes. 

###### v19 
But all the princes said to all the congregation, "We have sworn to them by Yahweh, the God of Israel. Now therefore we may not touch them. 

###### v20 
We will do this to them, and let them live; lest wrath be on us, because of the oath which we swore to them." 

###### v21 
The princes said to them, "Let them live." So they became wood cutters and drawers of water for all the congregation, as the princes had spoken to them. 

###### v22 
Joshua called for them, and he spoke to them, saying, "Why have you deceived us, saying, 'We are very far from you,' when you live among us? 

###### v23 
Now therefore you are cursed, and some of you will never fail to be slaves, both wood cutters and drawers of water for the house of my God." 

###### v24 
They answered Joshua, and said, "Because your servants were certainly told how Yahweh your God commanded his servant Moses to give you all the land, and to destroy all the inhabitants of the land from before you. Therefore we were very afraid for our lives because of you, and have done this thing. 

###### v25 
Now, behold, we are in your hand. Do to us as it seems good and right to you to do." 

###### v26 
He did so to them, and delivered them out of the hand of the children of Israel, so that they didn't kill them. 

###### v27 
That day Joshua made them wood cutters and drawers of water for the congregation and for Yahweh's altar to this day, in the place which he should choose.

***
[[Josh-08|← Joshua 08]] | [[Joshua]] | [[Josh-10|Joshua 10 →]]
