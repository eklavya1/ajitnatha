# Joshua 14

[[Josh-13|← Joshua 13]] | [[Joshua]] | [[Josh-15|Joshua 15 →]]
***



###### v1 
These are the inheritances which the children of Israel took in the land of Canaan, which Eleazar the priest, Joshua the son of Nun, and the heads of the fathers' houses of the tribes of the children of Israel, distributed to them, 

###### v2 
by the lot of their inheritance, as Yahweh commanded by Moses, for the nine tribes, and for the half-tribe. 

###### v3 
For Moses had given the inheritance of the two tribes and the half-tribe beyond the Jordan; but to the Levites he gave no inheritance among them. 

###### v4 
For the children of Joseph were two tribes, Manasseh and Ephraim. They gave no portion to the Levites in the land, except cities to dwell in, with their pasture lands for their livestock and for their property. 

###### v5 
The children of Israel did as Yahweh commanded Moses, and they divided the land. 

###### v6 
Then the children of Judah came near to Joshua in Gilgal. Caleb the son of Jephunneh the Kenizzite said to him, "You know the thing that Yahweh spoke to Moses the man of God concerning me and concerning you in Kadesh Barnea. 

###### v7 
I was forty years old when Moses the servant of Yahweh sent me from Kadesh Barnea to spy out the land. I brought him word again as it was in my heart. 

###### v8 
Nevertheless, my brothers who went up with me made the heart of the people melt; but I wholly followed Yahweh my God. 

###### v9 
Moses swore on that day, saying, 'Surely the land where you walked shall be an inheritance to you and to your children forever, because you have wholly followed Yahweh my God.' 

###### v10 
"Now, behold, Yahweh has kept me alive, as he spoke, these forty-five years, from the time that Yahweh spoke this word to Moses, while Israel walked in the wilderness. Now, behold, I am eighty-five years old, today. 

###### v11 
As yet I am as strong today as I was in the day that Moses sent me. As my strength was then, even so is my strength now for war, to go out and to come in. 

###### v12 
Now therefore give me this hill country, of which Yahweh spoke in that day; for you heard in that day how the Anakim were there, and great and fortified cities. It may be that Yahweh will be with me, and I shall drive them out, as Yahweh said." 

###### v13 
Joshua blessed him; and he gave Hebron to Caleb the son of Jephunneh for an inheritance. 

###### v14 
Therefore Hebron became the inheritance of Caleb the son of Jephunneh the Kenizzite to this day, because he followed Yahweh, the God of Israel wholeheartedly. 

###### v15 
Now the name of Hebron before was Kiriath Arba, after the greatest man among the Anakim. Then the land had rest from war.

***
[[Josh-13|← Joshua 13]] | [[Joshua]] | [[Josh-15|Joshua 15 →]]
