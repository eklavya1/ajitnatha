# Joshua 18

[[Josh-17|← Joshua 17]] | [[Joshua]] | [[Josh-19|Joshua 19 →]]
***



###### v1 
The whole congregation of the children of Israel assembled themselves together at Shiloh, and set up the Tent of Meeting there. The land was subdued before them. 

###### v2 
Seven tribes remained among the children of Israel, which had not yet divided their inheritance. 

###### v3 
Joshua said to the children of Israel, "How long will you neglect to go in to possess the land, which Yahweh, the God of your fathers, has given you? 

###### v4 
Appoint for yourselves three men from each tribe. I will send them, and they shall arise, walk through the land, and describe it according to their inheritance; then they shall come to me. 

###### v5 
They shall divide it into seven portions. Judah shall live in his borders on the south, and the house of Joseph shall live in their borders on the north. 

###### v6 
You shall survey the land into seven parts, and bring the description here to me; and I will cast lots for you here before Yahweh our God. 

###### v7 
However, the Levites have no portion among you; for the priesthood of Yahweh is their inheritance. Gad, Reuben, and the half-tribe of Manasseh have received their inheritance east of the Jordan, which Moses the servant of Yahweh gave them." 

###### v8 
The men arose and went. Joshua commanded those who went to survey the land, saying, "Go walk through the land, survey it, and come again to me. I will cast lots for you here before Yahweh in Shiloh." 

###### v9 
The men went and passed through the land, and surveyed it by cities into seven portions in a book. They came to Joshua to the camp at Shiloh. 

###### v10 
Joshua cast lots for them in Shiloh before Yahweh. There Joshua divided the land to the children of Israel according to their divisions. 

###### v11 
The lot of the tribe of the children of Benjamin came up according to their families. The border of their lot went out between the children of Judah and the children of Joseph. 

###### v12 
Their border on the north quarter was from the Jordan. The border went up to the side of Jericho on the north, and went up through the hill country westward. It ended at the wilderness of Beth Aven. 

###### v13 
The border passed along from there to Luz, to the side of Luz (also called Bethel), southward. The border went down to Ataroth Addar, by the mountain that lies on the south of Beth Horon the lower. 

###### v14 
The border extended, and turned around on the west quarter southward, from the mountain that lies before Beth Horon southward; and ended at Kiriath Baal (also called Kiriath Jearim), a city of the children of Judah. This was the west quarter. 

###### v15 
The south quarter was from the farthest part of Kiriath Jearim. The border went out westward, and went out to the spring of the waters of Nephtoah. 

###### v16 
The border went down to the farthest part of the mountain that lies before the valley of the son of Hinnom, which is in the valley of Rephaim northward. It went down to the valley of Hinnom, to the side of the Jebusite southward, and went down to En Rogel. 

###### v17 
It extended northward, went out at En Shemesh, and went out to Geliloth, which is opposite the ascent of Adummim. It went down to the stone of Bohan the son of Reuben. 

###### v18 
It passed along to the side opposite the Arabah northward, and went down to the Arabah. 

###### v19 
The border passed along to the side of Beth Hoglah northward; and the border ended at the north bay of the Salt Sea, at the south end of the Jordan. This was the south border. 

###### v20 
The Jordan was its border on the east quarter. This was the inheritance of the children of Benjamin, by the borders around it, according to their families. 

###### v21 
Now the cities of the tribe of the children of Benjamin according to their families were Jericho, Beth Hoglah, Emek Keziz, 

###### v22 
Beth Arabah, Zemaraim, Bethel, 

###### v23 
Avvim, Parah, Ophrah, 

###### v24 
Chephar Ammoni, Ophni, and Geba; twelve cities with their villages. 

###### v25 
Gibeon, Ramah, Beeroth, 

###### v26 
Mizpeh, Chephirah, Mozah, 

###### v27 
Rekem, Irpeel, Taralah, 

###### v28 
Zelah, Eleph, the Jebusite (also called Jerusalem), Gibeath, and Kiriath; fourteen cities with their villages. This is the inheritance of the children of Benjamin according to their families.

***
[[Josh-17|← Joshua 17]] | [[Joshua]] | [[Josh-19|Joshua 19 →]]
