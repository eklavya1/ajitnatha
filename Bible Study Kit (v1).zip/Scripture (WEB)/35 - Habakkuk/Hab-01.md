# Habakkuk 1

[[Habakkuk]] | [[Hab-02|Habakkuk 02 →]]
***



###### v1 
The revelation which Habakkuk the prophet saw. 

###### v2 
Yahweh, how long will I cry, and you will not hear? I cry out to you "Violence!" and will you not save? 

###### v3 
Why do you show me iniquity, and look at perversity? For destruction and violence are before me. There is strife, and contention rises up. 

###### v4 
Therefore the law is paralyzed, and justice never prevails; for the wicked surround the righteous; therefore justice comes out perverted. 

###### v5 
"Look among the nations, watch, and wonder marvelously; for I am working a work in your days, which you will not believe though it is told you. 

###### v6 
For, behold, I raise up the Chaldeans, that bitter and hasty nation, that march through the width of the earth, to possess dwelling places that are not theirs. 

###### v7 
They are feared and dreaded. Their judgment and their dignity proceed from themselves. 

###### v8 
Their horses also are swifter than leopards, and are more fierce than the evening wolves. Their horsemen press proudly on. Yes, their horsemen come from afar. They fly as an eagle that hurries to devour. 

###### v9 
All of them come for violence. Their hordes face the desert. He gathers prisoners like sand. 

###### v10 
Yes, he scoffs at kings, and princes are a derision to him. He laughs at every stronghold, for he builds up an earthen ramp, and takes it. 

###### v11 
Then he sweeps by like the wind, and goes on. He is indeed guilty, whose strength is his god." 

###### v12 
Aren't you from everlasting, Yahweh my God, my Holy One? We will not die. Yahweh, you have appointed him for judgment. You, Rock, have established him to punish. 

###### v13 
You who have purer eyes than to see evil, and who cannot look on perversity, why do you tolerate those who deal treacherously, and keep silent when the wicked swallows up the man who is more righteous than he, 

###### v14 
and make men like the fish of the sea, like the creeping things, that have no ruler over them? 

###### v15 
He takes up all of them with the hook. He catches them in his net, and gathers them in his dragnet. Therefore he rejoices and is glad. 

###### v16 
Therefore he sacrifices to his net, and burns incense to his dragnet, because by them his life is luxurious, and his food is good. 

###### v17 
Will he therefore continually empty his net, and kill the nations without mercy?

***
[[Habakkuk]] | [[Hab-02|Habakkuk 02 →]]
