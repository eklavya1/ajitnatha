# Habakkuk 3

[[Hab-02|← Habakkuk 02]] | [[Habakkuk]]
***



###### v1 
A prayer of Habakkuk, the prophet, set to victorious music. 

###### v2 
Yahweh, I have heard of your fame. I stand in awe of your deeds, Yahweh. Renew your work in the middle of the years. In the middle of the years make it known. In wrath, you remember mercy. 

###### v3 
God came from Teman, the Holy One from Mount Paran. Selah. His glory covered the heavens, and his praise filled the earth. 

###### v4 
His splendor is like the sunrise. Rays shine from his hand, where his power is hidden. 

###### v5 
Plague went before him, and pestilence followed his feet. 

###### v6 
He stood, and shook the earth. He looked, and made the nations tremble. The ancient mountains were crumbled. The age-old hills collapsed. His ways are eternal. 

###### v7 
I saw the tents of Cushan in affliction. The dwellings of the land of Midian trembled. 

###### v8 
Was Yahweh displeased with the rivers? Was your anger against the rivers, or your wrath against the sea, that you rode on your horses, on your chariots of salvation? 

###### v9 
You uncovered your bow. You called for your sworn arrows. Selah. You split the earth with rivers. 

###### v10 
The mountains saw you, and were afraid. The storm of waters passed by. The deep roared and lifted up its hands on high. 

###### v11 
The sun and moon stood still in the sky, at the light of your arrows as they went, at the shining of your glittering spear. 

###### v12 
You marched through the land in wrath. You threshed the nations in anger. 

###### v13 
You went out for the salvation of your people, for the salvation of your anointed. You crushed the head of the land of wickedness. You stripped them head to foot. Selah. 

###### v14 
You pierced the heads of his warriors with their own spears. They came as a whirlwind to scatter me, gloating as if to devour the wretched in secret. 

###### v15 
You trampled the sea with your horses, churning mighty waters. 

###### v16 
I heard, and my body trembled. My lips quivered at the voice. Rottenness enters into my bones, and I tremble in my place, because I must wait quietly for the day of trouble, for the coming up of the people who invade us. 

###### v17 
For though the fig tree doesn't flourish, nor fruit be in the vines; the labor of the olive fails, the fields yield no food; the flocks are cut off from the fold, and there is no herd in the stalls: 

###### v18 
yet I will rejoice in Yahweh. I will be joyful in the God of my salvation! 

###### v19 
Yahweh, the Lord, is my strength. He makes my feet like deer's feet, and enables me to go in high places. For the music director, on my stringed instruments.

***
[[Hab-02|← Habakkuk 02]] | [[Habakkuk]]
