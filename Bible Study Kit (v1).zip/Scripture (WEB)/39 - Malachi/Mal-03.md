# Malachi 3

[[Mal-02|← Malachi 02]] | [[Malachi]] | [[Mal-04|Malachi 04 →]]
***



###### v1 
"Behold, I send my messenger, and he will prepare the way before me; and the Lord, whom you seek, will suddenly come to his temple; and the messenger of the covenant, whom you desire, behold, he comes!" says Yahweh of Armies. 

###### v2 
"But who can endure the day of his coming? And who will stand when he appears? For he is like a refiner's fire, and like launderers' soap; 

###### v3 
and he will sit as a refiner and purifier of silver, and he will purify the sons of Levi, and refine them as gold and silver; and they shall offer to Yahweh offerings in righteousness. 

###### v4 
Then the offering of Judah and Jerusalem will be pleasant to Yahweh, as in the days of old, and as in ancient years. 

###### v5 
I will come near to you to judgment; and I will be a swift witness against the sorcerers, and against the adulterers, and against the perjurers, and against those who oppress the hireling in his wages, the widow, and the fatherless, and who deprive the foreigner of justice, and don't fear me," says Yahweh of Armies. 

###### v6 
"For I, Yahweh, don't change; therefore you, sons of Jacob, are not consumed. 

###### v7 
From the days of your fathers you have turned away from my ordinances, and have not kept them. Return to me, and I will return to you," says Yahweh of Armies. "But you say, 'How shall we return?' 

###### v8 
Will a man rob God? Yet you rob me! But you say, 'How have we robbed you?' In tithes and offerings. 

###### v9 
You are cursed with the curse; for you rob me, even this whole nation. 

###### v10 
Bring the whole tithe into the storehouse, that there may be food in my house, and test me now in this," says Yahweh of Armies, "if I will not open you the windows of heaven, and pour you out a blessing, that there will not be room enough for. 

###### v11 
I will rebuke the devourer for your sakes, and he shall not destroy the fruits of your ground; neither shall your vine cast its fruit before its time in the field," says Yahweh of Armies. 

###### v12 
"All nations shall call you blessed, for you will be a delightful land," says Yahweh of Armies. 

###### v13 
"Your words have been stout against me," says Yahweh. "Yet you say, 'What have we spoken against you?' 

###### v14 
You have said, 'It is vain to serve God;' and 'What profit is it that we have followed his instructions, and that we have walked mournfully before Yahweh of Armies? 

###### v15 
Now we call the proud happy; yes, those who work wickedness are built up; yes, they tempt God, and escape.' 

###### v16 
Then those who feared Yahweh spoke one with another; and Yahweh listened, and heard, and a book of memory was written before him, for those who feared Yahweh, and who honored his name. 

###### v17 
They shall be mine," says Yahweh of Armies, "my own possession in the day that I make, and I will spare them, as a man spares his own son who serves him. 

###### v18 
Then you shall return and discern between the righteous and the wicked, between him who serves God and him who doesn't serve him.

***
[[Mal-02|← Malachi 02]] | [[Malachi]] | [[Mal-04|Malachi 04 →]]
