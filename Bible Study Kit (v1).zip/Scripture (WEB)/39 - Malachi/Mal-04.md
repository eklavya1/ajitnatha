# Malachi 4

[[Mal-03|← Malachi 03]] | [[Malachi]]
***



###### v1 
"For, behold, the day comes, it burns as a furnace; and all the proud, and all who work wickedness, will be stubble; and the day that comes will burn them up," says Yahweh of Armies, "that it shall leave them neither root nor branch. 

###### v2 
But to you who fear my name shall the sun of righteousness arise with healing in its wings. You will go out, and leap like calves of the stall. 

###### v3 
You shall tread down the wicked; for they will be ashes under the soles of your feet in the day that I make," says Yahweh of Armies. 

###### v4 
"Remember the law of Moses my servant, which I commanded to him in Horeb for all Israel, even statutes and ordinances. 

###### v5 
Behold, I will send you Elijah the prophet before the great and terrible day of Yahweh comes. 

###### v6 
He will turn the hearts of the fathers to the children, and the hearts of the children to their fathers, lest I come and strike the earth with a curse."

***
[[Mal-03|← Malachi 03]] | [[Malachi]]
