# Malachi 2

[[Mal-01|← Malachi 01]] | [[Malachi]] | [[Mal-03|Malachi 03 →]]
***



###### v1 
"Now, you priests, this commandment is for you. 

###### v2 
If you will not listen, and if you will not take it to heart, to give glory to my name," says Yahweh of Armies, "then I will send the curse on you, and I will curse your blessings. Indeed, I have cursed them already, because you do not take it to heart. 

###### v3 
Behold, I will rebuke your offspring, and will spread dung on your faces, even the dung of your feasts; and you will be taken away with it. 

###### v4 
You will know that I have sent this commandment to you, that my covenant may be with Levi," says Yahweh of Armies. 

###### v5 
"My covenant was with him of life and peace; and I gave them to him that he might be reverent toward me; and he was reverent toward me, and stood in awe of my name. 

###### v6 
The law of truth was in his mouth, and unrighteousness was not found in his lips. He walked with me in peace and uprightness, and turned many away from iniquity. 

###### v7 
For the priest's lips should keep knowledge, and they should seek the law at his mouth; for he is the messenger of Yahweh of Armies. 

###### v8 
But you have turned away from the path. You have caused many to stumble in the law. You have corrupted the covenant of Levi," says Yahweh of Armies. 

###### v9 
"Therefore I have also made you contemptible and wicked before all the people, according to the way you have not kept my ways, but have had respect for persons in the law. 

###### v10 
Don't we all have one father? Hasn't one God created us? Why do we deal treacherously every man against his brother, profaning the covenant of our fathers? 

###### v11 
Judah has dealt treacherously, and an abomination is committed in Israel and in Jerusalem; for Judah has profaned the holiness of Yahweh which he loves, and has married the daughter of a foreign god. 

###### v12 
Yahweh will cut off, to the man who does this, him who wakes and him who answers, out of the tents of Jacob, and him who offers an offering to Yahweh of Armies. 

###### v13 
This again you do: you cover Yahweh's altar with tears, with weeping, and with sighing, because he doesn't regard the offering any more, neither receives it with good will at your hand. 

###### v14 
Yet you say, 'Why?' Because Yahweh has been witness between you and the wife of your youth, against whom you have dealt treacherously, though she is your companion, and the wife of your covenant. 

###### v15 
Did he not make you one, although he had the residue of the Spirit? Why one? He sought godly offspring. Therefore take heed to your spirit, and let no one deal treacherously against the wife of his youth. 

###### v16 
One who hates and divorces", says Yahweh, the God of Israel, "covers his garment with violence!" says Yahweh of Armies. "Therefore pay attention to your spirit, that you don't be unfaithful. 

###### v17 
You have wearied Yahweh with your words. Yet you say, 'How have we wearied him?' In that you say, 'Everyone who does evil is good in Yahweh's sight, and he delights in them;' or 'Where is the God of justice?'

***
[[Mal-01|← Malachi 01]] | [[Malachi]] | [[Mal-03|Malachi 03 →]]
