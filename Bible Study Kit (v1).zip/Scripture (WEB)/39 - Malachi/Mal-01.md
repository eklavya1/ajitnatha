# Malachi 1

[[Malachi]] | [[Mal-02|Malachi 02 →]]
***



###### v1 
A revelation, Yahweh's word to Israel by Malachi. 

###### v2 
"I have loved you," says Yahweh. Yet you say, "How have you loved us?" "Wasn't Esau Jacob's brother?" says Yahweh, "Yet I loved Jacob; 

###### v3 
but Esau I hated, and made his mountains a desolation, and gave his heritage to the jackals of the wilderness." 

###### v4 
Whereas Edom says, "We are beaten down, but we will return and build the waste places;" Yahweh of Armies says, "They shall build, but I will throw down; and men will call them 'The Wicked Land,' even the people against whom Yahweh shows wrath forever." 

###### v5 
Your eyes will see, and you will say, "Yahweh is great--even beyond the border of Israel!" 

###### v6 
"A son honors his father, and a servant his master. If I am a father, then where is my honor? And if I am a master, where is the respect due me? Says Yahweh of Armies to you, priests, who despise my name. You say, 'How have we despised your name?' 

###### v7 
You offer polluted bread on my altar. You say, 'How have we polluted you?' In that you say, 'Yahweh's table is contemptible.' 

###### v8 
When you offer the blind for sacrifice, isn't that evil? And when you offer the lame and sick, isn't that evil? Present it now to your governor! Will he be pleased with you? Or will he accept your person?" says Yahweh of Armies. 

###### v9 
"Now, please entreat the favor of God, that he may be gracious to us. With this, will he accept any of you?" says Yahweh of Armies. 

###### v10 
"Oh that there were one among you who would shut the doors, that you might not kindle fire on my altar in vain! I have no pleasure in you," says Yahweh of Armies, "neither will I accept an offering at your hand. 

###### v11 
For from the rising of the sun even to its going down, my name is great among the nations, and in every place incense will be offered to my name, and a pure offering: for my name is great among the nations," says Yahweh of Armies. 

###### v12 
"But you profane it, in that you say, 'Yahweh's table is polluted, and its fruit, even its food, is contemptible.' 

###### v13 
You say also, 'Behold, what a weariness it is!' and you have sniffed at it", says Yahweh of Armies; "and you have brought that which was taken by violence, the lame, and the sick; thus you bring the offering. Should I accept this at your hand?" says Yahweh. 

###### v14 
"But the deceiver is cursed, who has in his flock a male, and vows, and sacrifices to the Lord a defective thing; for I am a great King," says Yahweh of Armies, "and my name is awesome among the nations."

***
[[Malachi]] | [[Mal-02|Malachi 02 →]]
