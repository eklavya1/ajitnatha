# Ecclesiastes 4

[[Eccles-03|← Ecclesiastes 03]] | [[Ecclesiastes]] | [[Eccles-05|Ecclesiastes 05 →]]
***



###### v1 
Then I returned and saw all the oppressions that are done under the sun: and behold, the tears of those who were oppressed, and they had no comforter; and on the side of their oppressors there was power; but they had no comforter. 

###### v2 
Therefore I praised the dead who have been long dead more than the living who are yet alive. 

###### v3 
Yes, better than them both is him who has not yet been, who has not seen the evil work that is done under the sun. 

###### v4 
Then I saw all the labor and achievement that is the envy of a man's neighbor. This also is vanity and a striving after wind. 

###### v5 
The fool folds his hands together and ruins himself. 

###### v6 
Better is a handful, with quietness, than two handfuls with labor and chasing after wind. 

###### v7 
Then I returned and saw vanity under the sun. 

###### v8 
There is one who is alone, and he has neither son nor brother. There is no end to all of his labor, neither are his eyes satisfied with wealth. "For whom then, do I labor and deprive my soul of enjoyment?" This also is vanity. Yes, it is a miserable business. 

###### v9 
Two are better than one, because they have a good reward for their labor. 

###### v10 
For if they fall, the one will lift up his fellow; but woe to him who is alone when he falls, and doesn't have another to lift him up. 

###### v11 
Again, if two lie together, then they have warmth; but how can one keep warm alone? 

###### v12 
If a man prevails against one who is alone, two shall withstand him; and a threefold cord is not quickly broken. 

###### v13 
Better is a poor and wise youth than an old and foolish king who doesn't know how to receive admonition any more. 

###### v14 
For out of prison he came out to be king; yes, even in his kingdom he was born poor. 

###### v15 
I saw all the living who walk under the sun, that they were with the youth, the other, who succeeded him. 

###### v16 
There was no end of all the people, even of all them over whom he was--yet those who come after shall not rejoice in him. Surely this also is vanity and a chasing after wind.

***
[[Eccles-03|← Ecclesiastes 03]] | [[Ecclesiastes]] | [[Eccles-05|Ecclesiastes 05 →]]
