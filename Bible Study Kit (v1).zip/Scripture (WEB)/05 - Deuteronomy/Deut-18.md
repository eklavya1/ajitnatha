# Deuteronomy 18

[[Deut-17|← Deuteronomy 17]] | [[Deuteronomy]] | [[Deut-19|Deuteronomy 19 →]]
***



###### v1 
The priests and the Levites--all the tribe of Levi--shall have no portion nor inheritance with Israel. They shall eat the offerings of Yahweh made by fire and his portion. 

###### v2 
They shall have no inheritance among their brothers. Yahweh is their inheritance, as he has spoken to them. 

###### v3 
This shall be the priests' due from the people, from those who offer a sacrifice, whether it be ox or sheep, that they shall give to the priest: the shoulder, the two cheeks, and the inner parts. 

###### v4 
You shall give him the first fruits of your grain, of your new wine, and of your oil, and the first of the fleece of your sheep. 

###### v5 
For Yahweh your God has chosen him out of all your tribes to stand to minister in Yahweh's name, him and his sons forever. 

###### v6 
If a Levite comes from any of your gates out of all Israel where he lives, and comes with all the desire of his soul to the place which Yahweh shall choose, 

###### v7 
then he shall minister in the name of Yahweh his God, as all his brothers the Levites do, who stand there before Yahweh. 

###### v8 
They shall have like portions to eat, in addition to that which comes from the sale of his family possessions. 

###### v9 
When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations. 

###### v10 
There shall not be found with you anyone who makes his son or his daughter to pass through the fire, one who uses divination, one who tells fortunes, or an enchanter, or a sorcerer, 

###### v11 
or a charmer, or someone who consults with a familiar spirit, or a wizard, or a necromancer. 

###### v12 
For whoever does these things is an abomination to Yahweh. Because of these abominations, Yahweh your God drives them out from before you. 

###### v13 
You shall be blameless with Yahweh your God. 

###### v14 
For these nations that you shall dispossess listen to those who practice sorcery and to diviners; but as for you, Yahweh your God has not allowed you so to do. 

###### v15 
Yahweh your God will raise up to you a prophet from among you, of your brothers, like me. You shall listen to him. 

###### v16 
This is according to all that you desired of Yahweh your God in Horeb in the day of the assembly, saying, "Let me not hear again Yahweh my God's voice, neither let me see this great fire any more, that I not die." 

###### v17 
Yahweh said to me, "They have well said that which they have spoken. 

###### v18 
I will raise them up a prophet from among their brothers, like you. I will put my words in his mouth, and he shall speak to them all that I shall command him. 

###### v19 
It shall happen, that whoever will not listen to my words which he shall speak in my name, I will require it of him. 

###### v20 
But the prophet who speaks a word presumptuously in my name, which I have not commanded him to speak, or who speaks in the name of other gods, that same prophet shall die." 

###### v21 
You may say in your heart, "How shall we know the word which Yahweh has not spoken?" 

###### v22 
When a prophet speaks in Yahweh's name, if the thing doesn't follow, nor happen, that is the thing which Yahweh has not spoken. The prophet has spoken it presumptuously. You shall not be afraid of him.

***
[[Deut-17|← Deuteronomy 17]] | [[Deuteronomy]] | [[Deut-19|Deuteronomy 19 →]]
