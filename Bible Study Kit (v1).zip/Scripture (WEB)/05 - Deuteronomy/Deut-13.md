# Deuteronomy 13

[[Deut-12|← Deuteronomy 12]] | [[Deuteronomy]] | [[Deut-14|Deuteronomy 14 →]]
***



###### v1 
If a prophet or a dreamer of dreams arises among you, and he gives you a sign or a wonder, 

###### v2 
and the sign or the wonder comes to pass, of which he spoke to you, saying, "Let's go after other gods" (which you have not known) "and let's serve them," 

###### v3 
you shall not listen to the words of that prophet, or to that dreamer of dreams; for Yahweh your God is testing you, to know whether you love Yahweh your God with all your heart and with all your soul. 

###### v4 
You shall walk after Yahweh your God, fear him, keep his commandments, and obey his voice. You shall serve him, and cling to him. 

###### v5 
That prophet, or that dreamer of dreams, shall be put to death, because he has spoken rebellion against Yahweh your God, who brought you out of the land of Egypt and redeemed you out of the house of bondage, to draw you aside out of the way which Yahweh your God commanded you to walk in. So you shall remove the evil from among you. 

###### v6 
If your brother, the son of your mother, or your son, or your daughter, or the wife of your bosom, or your friend who is as your own soul, entices you secretly, saying, "Let's go and serve other gods"--which you have not known, you, nor your fathers; 

###### v7 
of the gods of the peoples who are around you, near to you, or far off from you, from the one end of the earth even to the other end of the earth-- 

###### v8 
you shall not consent to him nor listen to him; neither shall your eye pity him, neither shall you spare, neither shall you conceal him; 

###### v9 
but you shall surely kill him. Your hand shall be first on him to put him to death, and afterwards the hands of all the people. 

###### v10 
You shall stone him to death with stones, because he has sought to draw you away from Yahweh your God, who brought you out of the land of Egypt, out of the house of bondage. 

###### v11 
All Israel shall hear, and fear, and shall not do any more wickedness like this among you. 

###### v12 
If you hear about one of your cities, which Yahweh your God gives you to dwell there, that 

###### v13 
certain wicked fellows have gone out from among you and have drawn away the inhabitants of their city, saying, "Let's go and serve other gods," which you have not known, 

###### v14 
then you shall inquire, investigate, and ask diligently. Behold, if it is true, and the thing certain, that such abomination was done among you, 

###### v15 
you shall surely strike the inhabitants of that city with the edge of the sword, destroying it utterly, with all that is therein and its livestock, with the edge of the sword. 

###### v16 
You shall gather all its plunder into the middle of its street, and shall burn with fire the city, with all of its plunder, to Yahweh your God. It shall be a heap forever. It shall not be built again. 

###### v17 
Nothing of the devoted thing shall cling to your hand, that Yahweh may turn from the fierceness of his anger and show you mercy, and have compassion on you and multiply you, as he has sworn to your fathers, 

###### v18 
when you listen to Yahweh your God's voice, to keep all his commandments which I command you today, to do that which is right in Yahweh your God's eyes.

***
[[Deut-12|← Deuteronomy 12]] | [[Deuteronomy]] | [[Deut-14|Deuteronomy 14 →]]
