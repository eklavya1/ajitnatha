# Deuteronomy 9

[[Deut-08|← Deuteronomy 08]] | [[Deuteronomy]] | [[Deut-10|Deuteronomy 10 →]]
***



###### v1 
Hear, Israel! You are to pass over the Jordan today, to go in to dispossess nations greater and mightier than yourself, cities great and fortified up to the sky, 

###### v2 
a people great and tall, the sons of the Anakim, whom you know, and of whom you have heard say, "Who can stand before the sons of Anak?" 

###### v3 
Know therefore today that Yahweh your God is he who goes over before you as a devouring fire. He will destroy them and he will bring them down before you. So you shall drive them out and make them perish quickly, as Yahweh has spoken to you. 

###### v4 
Don't say in your heart, after Yahweh your God has thrust them out from before you, "For my righteousness Yahweh has brought me in to possess this land;" because Yahweh drives them out before you because of the wickedness of these nations. 

###### v5 
Not for your righteousness or for the uprightness of your heart do you go in to possess their land; but for the wickedness of these nations Yahweh your God does drive them out from before you, and that he may establish the word which Yahweh swore to your fathers, to Abraham, to Isaac, and to Jacob. 

###### v6 
Know therefore that Yahweh your God doesn't give you this good land to possess for your righteousness, for you are a stiff-necked people. 

###### v7 
Remember, and don't forget, how you provoked Yahweh your God to wrath in the wilderness. From the day that you left the land of Egypt until you came to this place, you have been rebellious against Yahweh. 

###### v8 
Also in Horeb you provoked Yahweh to wrath, and Yahweh was angry with you to destroy you. 

###### v9 
When I had gone up onto the mountain to receive the stone tablets, even the tablets of the covenant which Yahweh made with you, then I stayed on the mountain forty days and forty nights. I neither ate bread nor drank water. 

###### v10 
Yahweh delivered to me the two stone tablets written with God's finger. On them were all the words which Yahweh spoke with you on the mountain out of the middle of the fire in the day of the assembly. 

###### v11 
It came to pass at the end of forty days and forty nights that Yahweh gave me the two stone tablets, even the tablets of the covenant. 

###### v12 
Yahweh said to me, "Arise, get down quickly from here; for your people whom you have brought out of Egypt have corrupted themselves. They have quickly turned away from the way which I commanded them. They have made a molten image for themselves!" 

###### v13 
Furthermore Yahweh spoke to me, saying, "I have seen these people, and behold, they are a stiff-necked people. 

###### v14 
Leave me alone, that I may destroy them, and blot out their name from under the sky; and I will make of you a nation mightier and greater than they." 

###### v15 
So I turned and came down from the mountain, and the mountain was burning with fire. The two tablets of the covenant were in my two hands. 

###### v16 
I looked, and behold, you had sinned against Yahweh your God. You had made yourselves a molded calf. You had quickly turned away from the way which Yahweh had commanded you. 

###### v17 
I took hold of the two tablets, and threw them out of my two hands, and broke them before your eyes. 

###### v18 
I fell down before Yahweh, as at the first, forty days and forty nights. I neither ate bread nor drank water, because of all your sin which you sinned, in doing that which was evil in Yahweh's sight, to provoke him to anger. 

###### v19 
For I was afraid of the anger and hot displeasure with which Yahweh was angry against you to destroy you. But Yahweh listened to me that time also. 

###### v20 
Yahweh was angry enough with Aaron to destroy him. I prayed for Aaron also at the same time. 

###### v21 
I took your sin, the calf which you had made, and burned it with fire, and crushed it, grinding it very small, until it was as fine as dust. I threw its dust into the brook that descended out of the mountain. 

###### v22 
At Taberah, at Massah, and at Kibroth Hattaavah you provoked Yahweh to wrath. 

###### v23 
When Yahweh sent you from Kadesh Barnea, saying, "Go up and possess the land which I have given you," you rebelled against the commandment of Yahweh your God, and you didn't believe him or listen to his voice. 

###### v24 
You have been rebellious against Yahweh from the day that I knew you. 

###### v25 
So I fell down before Yahweh the forty days and forty nights that I fell down, because Yahweh had said he would destroy you. 

###### v26 
I prayed to Yahweh, and said, "Lord Yahweh, don't destroy your people and your inheritance that you have redeemed through your greatness, that you have brought out of Egypt with a mighty hand. 

###### v27 
Remember your servants, Abraham, Isaac, and Jacob. Don't look at the stubbornness of this people, nor at their wickedness, nor at their sin, 

###### v28 
lest the land you brought us out from say, 'Because Yahweh was not able to bring them into the land which he promised to them, and because he hated them, he has brought them out to kill them in the wilderness.' 

###### v29 
Yet they are your people and your inheritance, which you brought out by your great power and by your outstretched arm."

***
[[Deut-08|← Deuteronomy 08]] | [[Deuteronomy]] | [[Deut-10|Deuteronomy 10 →]]
