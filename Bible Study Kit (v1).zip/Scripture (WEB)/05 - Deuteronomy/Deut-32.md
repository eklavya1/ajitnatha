# Deuteronomy 32

[[Deut-31|← Deuteronomy 31]] | [[Deuteronomy]] | [[Deut-33|Deuteronomy 33 →]]
***



###### v1 
Give ear, you heavens, and I will speak. Let the earth hear the words of my mouth. 

###### v2 
My doctrine will drop as the rain. My speech will condense as the dew, as the misty rain on the tender grass, as the showers on the herb. 

###### v3 
For I will proclaim Yahweh's name. Ascribe greatness to our God! 

###### v4 
The Rock: his work is perfect, for all his ways are just. A God of faithfulness who does no wrong, just and right is he. 

###### v5 
They have dealt corruptly with him. They are not his children, because of their defect. They are a perverse and crooked generation. 

###### v6 
Is this the way you repay Yahweh, foolish and unwise people? Isn't he your father who has bought you? He has made you and established you. 

###### v7 
Remember the days of old. Consider the years of many generations. Ask your father, and he will show you; your elders, and they will tell you. 

###### v8 
When the Most High gave to the nations their inheritance, when he separated the children of men, he set the bounds of the peoples according to the number of the children of Israel. 

###### v9 
For Yahweh's portion is his people. Jacob is the lot of his inheritance. 

###### v10 
He found him in a desert land, in the waste howling wilderness. He surrounded him. He cared for him. He kept him as the apple of his eye. 

###### v11 
As an eagle that stirs up her nest, that flutters over her young, he spread abroad his wings, he took them, he bore them on his feathers. 

###### v12 
Yahweh alone led him. There was no foreign god with him. 

###### v13 
He made him ride on the high places of the earth. He ate the increase of the field. He caused him to suck honey out of the rock, oil out of the flinty rock; 

###### v14 
butter from the herd, and milk from the flock, with fat of lambs, rams of the breed of Bashan, and goats, with the finest of the wheat. From the blood of the grape, you drank wine. 

###### v15 
But Jeshurun grew fat, and kicked. You have grown fat. You have grown thick. You have become sleek. Then he abandoned God who made him, and rejected the Rock of his salvation. 

###### v16 
They moved him to jealousy with strange gods. They provoked him to anger with abominations. 

###### v17 
They sacrificed to demons, not God, to gods that they didn't know, to new gods that came up recently, which your fathers didn't dread. 

###### v18 
Of the Rock who became your father, you are unmindful, and have forgotten God who gave you birth. 

###### v19 
Yahweh saw and abhorred, because of the provocation of his sons and his daughters. 

###### v20 
He said, "I will hide my face from them. I will see what their end will be; for they are a very perverse generation, children in whom is no faithfulness. 

###### v21 
They have moved me to jealousy with that which is not God. They have provoked me to anger with their vanities. I will move them to jealousy with those who are not a people. I will provoke them to anger with a foolish nation. 

###### v22 
For a fire is kindled in my anger, that burns to the lowest Sheol, devours the earth with its increase, and sets the foundations of the mountains on fire. 

###### v23 
"I will heap evils on them. I will spend my arrows on them. 

###### v24 
They shall be wasted with hunger, and devoured with burning heat and bitter destruction. I will send the teeth of animals on them, with the venom of vipers that glide in the dust. 

###### v25 
Outside the sword will bereave, and in the rooms, terror on both young man and virgin, the nursing infant with the gray-haired man. 

###### v26 
I said that I would scatter them afar. I would make their memory to cease from among men; 

###### v27 
were it not that I feared the provocation of the enemy, lest their adversaries should judge wrongly, lest they should say, 'Our hand is exalted, Yahweh has not done all this.'" 

###### v28 
For they are a nation void of counsel. There is no understanding in them. 

###### v29 
Oh that they were wise, that they understood this, that they would consider their latter end! 

###### v30 
How could one chase a thousand, and two put ten thousand to flight, unless their Rock had sold them, and Yahweh had delivered them up? 

###### v31 
For their rock is not as our Rock, even our enemies themselves concede. 

###### v32 
For their vine is of the vine of Sodom, of the fields of Gomorrah. Their grapes are poison grapes. Their clusters are bitter. 

###### v33 
Their wine is the poison of serpents, the cruel venom of asps. 

###### v34 
"Isn't this laid up in store with me, sealed up among my treasures? 

###### v35 
Vengeance is mine, and recompense, at the time when their foot slides; for the day of their calamity is at hand. Their doom rushes at them." 

###### v36 
For Yahweh will judge his people, and have compassion on his servants, when he sees that their power is gone; that there is no one remaining, shut up or left at large. 

###### v37 
He will say, "Where are their gods, the rock in which they took refuge; 

###### v38 
which ate the fat of their sacrifices, and drank the wine of their drink offering? Let them rise up and help you! Let them be your protection. 

###### v39 
"See now that I myself am he. There is no god with me. I kill and I make alive. I wound and I heal. There is no one who can deliver out of my hand. 

###### v40 
For I lift up my hand to heaven and declare, as I live forever, 

###### v41 
if I sharpen my glittering sword, my hand grasps it in judgment; I will take vengeance on my adversaries, and will repay those who hate me. 

###### v42 
I will make my arrows drunk with blood. My sword shall devour flesh with the blood of the slain and the captives, from the head of the leaders of the enemy." 

###### v43 
Rejoice, you nations, with his people, for he will avenge the blood of his servants. He will take vengeance on his adversaries, and will make atonement for his land and for his people. 

###### v44 
Moses came and spoke all the words of this song in the ears of the people, he and Joshua the son of Nun. 

###### v45 
Moses finished reciting all these words to all Israel. 

###### v46 
He said to them, "Set your heart to all the words which I testify to you today, which you shall command your children to observe to do, all the words of this law. 

###### v47 
For it is no vain thing for you, because it is your life, and through this thing you shall prolong your days in the land, where you go over the Jordan to possess it." 

###### v48 
Yahweh spoke to Moses that same day, saying, 

###### v49 
"Go up into this mountain of Abarim, to Mount Nebo, which is in the land of Moab, that is across from Jericho; and see the land of Canaan, which I give to the children of Israel for a possession. 

###### v50 
Die on the mountain where you go up, and be gathered to your people, as Aaron your brother died on Mount Hor, and was gathered to his people; 

###### v51 
because you trespassed against me among the children of Israel at the waters of Meribah of Kadesh, in the wilderness of Zin; because you didn't uphold my holiness among the children of Israel. 

###### v52 
For you shall see the land from a distance; but you shall not go there into the land which I give the children of Israel."

***
[[Deut-31|← Deuteronomy 31]] | [[Deuteronomy]] | [[Deut-33|Deuteronomy 33 →]]
