# Deuteronomy 6

[[Deut-05|← Deuteronomy 05]] | [[Deuteronomy]] | [[Deut-07|Deuteronomy 07 →]]
***



###### v1 
Now these are the commandments, the statutes, and the ordinances, which Yahweh your God commanded to teach you, that you might do them in the land that you go over to possess; 

###### v2 
that you might fear Yahweh your God, to keep all his statutes and his commandments, which I command you--you, your son, and your son's son, all the days of your life; and that your days may be prolonged. 

###### v3 
Hear therefore, Israel, and observe to do it, that it may be well with you, and that you may increase mightily, as Yahweh, the God of your fathers, has promised to you, in a land flowing with milk and honey. 

###### v4 
Hear, Israel: Yahweh is our God. Yahweh is one. 

###### v5 
You shall love Yahweh your God with all your heart, with all your soul, and with all your might. 

###### v6 
These words, which I command you today, shall be on your heart; 

###### v7 
and you shall teach them diligently to your children, and shall talk of them when you sit in your house, and when you walk by the way, and when you lie down, and when you rise up. 

###### v8 
You shall bind them for a sign on your hand, and they shall be for frontlets between your eyes. 

###### v9 
You shall write them on the door posts of your house and on your gates. 

###### v10 
It shall be, when Yahweh your God brings you into the land which he swore to your fathers, to Abraham, to Isaac, and to Jacob, to give you, great and goodly cities which you didn't build, 

###### v11 
and houses full of all good things which you didn't fill, and cisterns dug out which you didn't dig, vineyards and olive trees which you didn't plant, and you shall eat and be full; 

###### v12 
then beware lest you forget Yahweh, who brought you out of the land of Egypt, out of the house of bondage. 

###### v13 
You shall fear Yahweh your God; and you shall serve him, and shall swear by his name. 

###### v14 
You shall not go after other gods, of the gods of the peoples who are around you, 

###### v15 
for Yahweh your God among you is a jealous God, lest the anger of Yahweh your God be kindled against you, and he destroy you from off the face of the earth. 

###### v16 
You shall not tempt Yahweh your God, as you tempted him in Massah. 

###### v17 
You shall diligently keep the commandments of Yahweh your God, and his testimonies, and his statutes, which he has commanded you. 

###### v18 
You shall do that which is right and good in Yahweh's sight, that it may be well with you and that you may go in and possess the good land which Yahweh swore to your fathers, 

###### v19 
to thrust out all your enemies from before you, as Yahweh has spoken. 

###### v20 
When your son asks you in time to come, saying, "What do the testimonies, the statutes, and the ordinances, which Yahweh our God has commanded you mean?" 

###### v21 
then you shall tell your son, "We were Pharaoh's slaves in Egypt. Yahweh brought us out of Egypt with a mighty hand; 

###### v22 
and Yahweh showed great and awesome signs and wonders on Egypt, on Pharaoh, and on all his house, before our eyes; 

###### v23 
and he brought us out from there, that he might bring us in, to give us the land which he swore to our fathers. 

###### v24 
Yahweh commanded us to do all these statutes, to fear Yahweh our God, for our good always, that he might preserve us alive, as we are today. 

###### v25 
It shall be righteousness to us, if we observe to do all these commandments before Yahweh our God, as he has commanded us."

***
[[Deut-05|← Deuteronomy 05]] | [[Deuteronomy]] | [[Deut-07|Deuteronomy 07 →]]
