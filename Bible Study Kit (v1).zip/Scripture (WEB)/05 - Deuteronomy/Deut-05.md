# Deuteronomy 5

[[Deut-04|← Deuteronomy 04]] | [[Deuteronomy]] | [[Deut-06|Deuteronomy 06 →]]
***



###### v1 
Moses called to all Israel, and said to them, "Hear, Israel, the statutes and the ordinances which I speak in your ears today, that you may learn them, and observe to do them." 

###### v2 
Yahweh our God made a covenant with us in Horeb. 

###### v3 
Yahweh didn't make this covenant with our fathers, but with us, even us, who are all of us here alive today. 

###### v4 
Yahweh spoke with you face to face on the mountain out of the middle of the fire, 

###### v5 
(I stood between Yahweh and you at that time, to show you Yahweh's word; for you were afraid because of the fire, and didn't go up onto the mountain) saying, 

###### v6 
"I am Yahweh your God, who brought you out of the land of Egypt, out of the house of bondage. 

###### v7 
"You shall have no other gods before me. 

###### v8 
"You shall not make a carved image for yourself--any likeness of what is in heaven above, or what is in the earth beneath, or that is in the water under the earth. 

###### v9 
You shall not bow yourself down to them, nor serve them; for I, Yahweh your God, am a jealous God, visiting the iniquity of the fathers on the children and on the third and on the fourth generation of those who hate me; 

###### v10 
and showing loving kindness to thousands of those who love me and keep my commandments. 

###### v11 
"You shall not misuse the name of Yahweh your God; for Yahweh will not hold him guiltless who misuses his name. 

###### v12 
"Observe the Sabbath day, to keep it holy, as Yahweh your God commanded you. 

###### v13 
You shall labor six days, and do all your work; 

###### v14 
but the seventh day is a Sabbath to Yahweh your God, in which you shall not do any work-- neither you, nor your son, nor your daughter, nor your male servant, nor your female servant, nor your ox, nor your donkey, nor any of your livestock, nor your stranger who is within your gates; that your male servant and your female servant may rest as well as you. 

###### v15 
You shall remember that you were a servant in the land of Egypt, and Yahweh your God brought you out of there by a mighty hand and by an outstretched arm. Therefore Yahweh your God commanded you to keep the Sabbath day. 

###### v16 
"Honor your father and your mother, as Yahweh your God commanded you; that your days may be long, and that it may go well with you in the land which Yahweh your God gives you. 

###### v17 
"You shall not murder. 

###### v18 
"You shall not commit adultery. 

###### v19 
"You shall not steal. 

###### v20 
"You shall not give false testimony against your neighbor. 

###### v21 
"You shall not covet your neighbor's wife. Neither shall you desire your neighbor's house, his field, or his male servant, or his female servant, his ox, or his donkey, or anything that is your neighbor's." 

###### v22 
Yahweh spoke these words to all your assembly on the mountain out of the middle of the fire, of the cloud, and of the thick darkness, with a great voice. He added no more. He wrote them on two stone tablets, and gave them to me. 

###### v23 
When you heard the voice out of the middle of the darkness, while the mountain was burning with fire, you came near to me, even all the heads of your tribes, and your elders; 

###### v24 
and you said, "Behold, Yahweh our God has shown us his glory and his greatness, and we have heard his voice out of the middle of the fire. We have seen today that God does speak with man, and he lives. 

###### v25 
Now therefore, why should we die? For this great fire will consume us. If we hear Yahweh our God's voice any more, then we shall die. 

###### v26 
For who is there of all flesh who has heard the voice of the living God speaking out of the middle of the fire, as we have, and lived? 

###### v27 
Go near, and hear all that Yahweh our God shall say, and tell us all that Yahweh our God tells you; and we will hear it, and do it." 

###### v28 
Yahweh heard the voice of your words when you spoke to me; and Yahweh said to me, "I have heard the voice of the words of this people which they have spoken to you. They have well said all that they have spoken. 

###### v29 
Oh that there were such a heart in them that they would fear me and keep all my commandments always, that it might be well with them and with their children forever! 

###### v30 
"Go tell them, 'Return to your tents.' 

###### v31 
But as for you, stand here by me, and I will tell you all the commandments, and the statutes, and the ordinances, which you shall teach them, that they may do them in the land which I give them to possess." 

###### v32 
You shall observe to do therefore as Yahweh your God has commanded you. You shall not turn away to the right hand or to the left. 

###### v33 
You shall walk in all the way which Yahweh your God has commanded you, that you may live and that it may be well with you, and that you may prolong your days in the land which you shall possess.

***
[[Deut-04|← Deuteronomy 04]] | [[Deuteronomy]] | [[Deut-06|Deuteronomy 06 →]]
