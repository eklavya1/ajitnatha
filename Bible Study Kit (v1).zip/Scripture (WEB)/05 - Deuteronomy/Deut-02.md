# Deuteronomy 2

[[Deut-01|← Deuteronomy 01]] | [[Deuteronomy]] | [[Deut-03|Deuteronomy 03 →]]
***



###### v1 
Then we turned, and took our journey into the wilderness by the way to the Red Sea, as Yahweh spoke to me; and we encircled Mount Seir many days. 

###### v2 
Yahweh spoke to me, saying, 

###### v3 
"You have encircled this mountain long enough. Turn northward. 

###### v4 
Command the people, saying, 'You are to pass through the border of your brothers, the children of Esau, who dwell in Seir; and they will be afraid of you. Therefore be careful. 

###### v5 
Don't contend with them; for I will not give you any of their land, no, not so much as for the sole of the foot to tread on, because I have given Mount Seir to Esau for a possession. 

###### v6 
You shall purchase food from them for money, that you may eat. You shall also buy water from them for money, that you may drink.'" 

###### v7 
For Yahweh your God has blessed you in all the work of your hands. He has known your walking through this great wilderness. These forty years, Yahweh your God has been with you. You have lacked nothing. 

###### v8 
So we passed by from our brothers, the children of Esau, who dwell in Seir, from the way of the Arabah from Elath and from Ezion Geber. We turned and passed by the way of the wilderness of Moab. 

###### v9 
Yahweh said to me, "Don't bother Moab, neither contend with them in battle; for I will not give you any of his land for a possession, because I have given Ar to the children of Lot for a possession." 

###### v10 
(The Emim lived there before, a great and numerous people, and tall as the Anakim. 

###### v11 
These also are considered to be Rephaim, as the Anakim; but the Moabites call them Emim. 

###### v12 
The Horites also lived in Seir in the past, but the children of Esau succeeded them. They destroyed them from before them, and lived in their place, as Israel did to the land of his possession, which Yahweh gave to them.) 

###### v13 
"Now rise up, and cross over the brook Zered." We went over the brook Zered. 

###### v14 
The days in which we came from Kadesh Barnea until we had come over the brook Zered were thirty-eight years: until all the generation of the men of war were consumed from the middle of the camp, as Yahweh swore to them. 

###### v15 
Moreover Yahweh's hand was against them, to destroy them from the middle of the camp, until they were consumed. 

###### v16 
So, when all the men of war were consumed and dead from among the people, 

###### v17 
Yahweh spoke to me, saying, 

###### v18 
"You are to pass over Ar, the border of Moab, today. 

###### v19 
When you come near the border of the children of Ammon, don't bother them, nor contend with them; for I will not give you any of the land of the children of Ammon for a possession, because I have given it to the children of Lot for a possession." 

###### v20 
(That also is considered a land of Rephaim. Rephaim lived there in the past, but the Ammonites call them Zamzummim, 

###### v21 
a great people, many, and tall, as the Anakim; but Yahweh destroyed them from before Israel, and they succeeded them, and lived in their place; 

###### v22 
as he did for the children of Esau who dwell in Seir, when he destroyed the Horites from before them; and they succeeded them, and lived in their place even to this day. 

###### v23 
Then the Avvim, who lived in villages as far as Gaza: the Caphtorim, who came out of Caphtor, destroyed them and lived in their place.) 

###### v24 
"Rise up, take your journey, and pass over the valley of the Arnon. Behold, I have given into your hand Sihon the Amorite, king of Heshbon, and his land; begin to possess it, and contend with him in battle. 

###### v25 
Today I will begin to put the dread of you and the fear of you on the peoples who are under the whole sky, who shall hear the report of you, and shall tremble and be in anguish because of you." 

###### v26 
I sent messengers out of the wilderness of Kedemoth to Sihon king of Heshbon with words of peace, saying, 

###### v27 
"Let me pass through your land. I will go along by the highway. I will turn neither to the right hand nor to the left. 

###### v28 
You shall sell me food for money, that I may eat; and give me water for money, that I may drink. Just let me pass through on my feet, 

###### v29 
as the children of Esau who dwell in Seir, and the Moabites who dwell in Ar, did to me; until I pass over the Jordan into the land which Yahweh our God gives us." 

###### v30 
But Sihon king of Heshbon would not let us pass by him; for Yahweh your God hardened his spirit and made his heart obstinate, that he might deliver him into your hand, as it is today. 

###### v31 
Yahweh said to me, "Behold, I have begun to deliver up Sihon and his land before you. Begin to possess, that you may inherit his land." 

###### v32 
Then Sihon came out against us, he and all his people, to battle at Jahaz. 

###### v33 
Yahweh our God delivered him up before us; and we struck him, his sons, and all his people. 

###### v34 
We took all his cities at that time, and utterly destroyed every inhabited city, with the women and the little ones. We left no one remaining. 

###### v35 
Only the livestock we took for plunder for ourselves, with the plunder of the cities which we had taken. 

###### v36 
From Aroer, which is on the edge of the valley of the Arnon, and the city that is in the valley, even to Gilead, there was not a city too high for us. Yahweh our God delivered up all before us. 

###### v37 
Only to the land of the children of Ammon you didn't come near: all the banks of the river Jabbok, and the cities of the hill country, and wherever Yahweh our God forbade us.

***
[[Deut-01|← Deuteronomy 01]] | [[Deuteronomy]] | [[Deut-03|Deuteronomy 03 →]]
