# Deuteronomy 30

[[Deut-29|← Deuteronomy 29]] | [[Deuteronomy]] | [[Deut-31|Deuteronomy 31 →]]
***



###### v1 
It shall happen, when all these things have come on you, the blessing and the curse, which I have set before you, and you shall call them to mind among all the nations where Yahweh your God has driven you, 

###### v2 
and return to Yahweh your God and obey his voice according to all that I command you today, you and your children, with all your heart and with all your soul, 

###### v3 
that then Yahweh your God will release you from captivity, have compassion on you, and will return and gather you from all the peoples where Yahweh your God has scattered you. 

###### v4 
If your outcasts are in the uttermost parts of the heavens, from there Yahweh your God will gather you, and from there he will bring you back. 

###### v5 
Yahweh your God will bring you into the land which your fathers possessed, and you will possess it. He will do you good, and increase your numbers more than your fathers. 

###### v6 
Yahweh your God will circumcise your heart, and the heart of your offspring, to love Yahweh your God with all your heart and with all your soul, that you may live. 

###### v7 
Yahweh your God will put all these curses on your enemies and on those who hate you, who persecuted you. 

###### v8 
You shall return and obey Yahweh's voice, and do all his commandments which I command you today. 

###### v9 
Yahweh your God will make you prosperous in all the work of your hand, in the fruit of your body, in the fruit of your livestock, and in the fruit of your ground, for good; for Yahweh will again rejoice over you for good, as he rejoiced over your fathers, 

###### v10 
if you will obey Yahweh your God's voice, to keep his commandments and his statutes which are written in this book of the law; if you turn to Yahweh your God with all your heart and with all your soul. 

###### v11 
For this commandment which I command you today is not too hard for you or too distant. 

###### v12 
It is not in heaven, that you should say, "Who will go up for us to heaven, bring it to us, and proclaim it to us, that we may do it?" 

###### v13 
Neither is it beyond the sea, that you should say, "Who will go over the sea for us, bring it to us, and proclaim it to us, that we may do it?" 

###### v14 
But the word is very near to you, in your mouth and in your heart, that you may do it. 

###### v15 
Behold, I have set before you today life and prosperity, and death and evil. 

###### v16 
For I command you today to love Yahweh your God, to walk in his ways and to keep his commandments, his statutes, and his ordinances, that you may live and multiply, and that Yahweh your God may bless you in the land where you go in to possess it. 

###### v17 
But if your heart turns away, and you will not hear, but are drawn away and worship other gods, and serve them, 

###### v18 
I declare to you today that you will surely perish. You will not prolong your days in the land where you pass over the Jordan to go in to possess it. 

###### v19 
I call heaven and earth to witness against you today that I have set before you life and death, the blessing and the curse. Therefore choose life, that you may live, you and your descendants, 

###### v20 
to love Yahweh your God, to obey his voice, and to cling to him; for he is your life, and the length of your days, that you may dwell in the land which Yahweh swore to your fathers, to Abraham, to Isaac, and to Jacob, to give them.

***
[[Deut-29|← Deuteronomy 29]] | [[Deuteronomy]] | [[Deut-31|Deuteronomy 31 →]]
