# Deuteronomy 11

[[Deut-10|← Deuteronomy 10]] | [[Deuteronomy]] | [[Deut-12|Deuteronomy 12 →]]
***



###### v1 
Therefore you shall love Yahweh your God, and keep his instructions, his statutes, his ordinances, and his commandments, always. 

###### v2 
Know this day--for I don't speak with your children who have not known, and who have not seen the chastisement of Yahweh your God, his greatness, his mighty hand, his outstretched arm, 

###### v3 
his signs, and his works, which he did in the middle of Egypt to Pharaoh the king of Egypt, and to all his land; 

###### v4 
and what he did to the army of Egypt, to their horses, and to their chariots; how he made the water of the Red Sea to overflow them as they pursued you, and how Yahweh has destroyed them to this day; 

###### v5 
and what he did to you in the wilderness until you came to this place; 

###### v6 
and what he did to Dathan and Abiram, the sons of Eliab, the son of Reuben--how the earth opened its mouth and swallowed them up, with their households, their tents, and every living thing that followed them, in the middle of all Israel; 

###### v7 
but your eyes have seen all of Yahweh's great work which he did. 

###### v8 
Therefore you shall keep the entire commandment which I command you today, that you may be strong, and go in and possess the land that you go over to possess; 

###### v9 
and that you may prolong your days in the land which Yahweh swore to your fathers to give to them and to their offspring, a land flowing with milk and honey. 

###### v10 
For the land, where you go in to possess isn't like the land of Egypt that you came out of, where you sowed your seed and watered it with your foot, as a garden of herbs; 

###### v11 
but the land that you go over to possess is a land of hills and valleys which drinks water from the rain of the sky, 

###### v12 
a land which Yahweh your God cares for. Yahweh your God's eyes are always on it, from the beginning of the year even to the end of the year. 

###### v13 
It shall happen, if you shall listen diligently to my commandments which I command you today, to love Yahweh your God, and to serve him with all your heart and with all your soul, 

###### v14 
that I will give the rain for your land in its season, the early rain and the latter rain, that you may gather in your grain, your new wine, and your oil. 

###### v15 
I will give grass in your fields for your livestock, and you shall eat and be full. 

###### v16 
Be careful, lest your heart be deceived, and you turn away to serve other gods and worship them; 

###### v17 
and Yahweh's anger be kindled against you, and he shut up the sky so that there is no rain, and the land doesn't yield its fruit; and you perish quickly from off the good land which Yahweh gives you. 

###### v18 
Therefore you shall lay up these words of mine in your heart and in your soul. You shall bind them for a sign on your hand, and they shall be for frontlets between your eyes. 

###### v19 
You shall teach them to your children, talking of them when you sit in your house, when you walk by the way, when you lie down, and when you rise up. 

###### v20 
You shall write them on the door posts of your house and on your gates; 

###### v21 
that your days and your children's days may be multiplied in the land which Yahweh swore to your fathers to give them, as the days of the heavens above the earth. 

###### v22 
For if you shall diligently keep all these commandments which I command you--to do them, to love Yahweh your God, to walk in all his ways, and to cling to him-- 

###### v23 
then Yahweh will drive out all these nations from before you, and you shall dispossess nations greater and mightier than yourselves. 

###### v24 
Every place on which the sole of your foot treads shall be yours: from the wilderness and Lebanon, from the river, the river Euphrates, even to the western sea shall be your border. 

###### v25 
No man will be able to stand before you. Yahweh your God will lay the fear of you and the dread of you on all the land that you tread on, as he has spoken to you. 

###### v26 
Behold, I set before you today a blessing and a curse: 

###### v27 
the blessing, if you listen to the commandments of Yahweh your God, which I command you today; 

###### v28 
and the curse, if you do not listen to the commandments of Yahweh your God, but turn away out of the way which I command you today, to go after other gods which you have not known. 

###### v29 
It shall happen, when Yahweh your God brings you into the land that you go to possess, that you shall set the blessing on Mount Gerizim, and the curse on Mount Ebal. 

###### v30 
Aren't they beyond the Jordan, behind the way of the going down of the sun, in the land of the Canaanites who dwell in the Arabah near Gilgal, beside the oaks of Moreh? 

###### v31 
For you are to pass over the Jordan to go in to possess the land which Yahweh your God gives you, and you shall possess it and dwell in it. 

###### v32 
You shall observe to do all the statutes and the ordinances which I set before you today.

***
[[Deut-10|← Deuteronomy 10]] | [[Deuteronomy]] | [[Deut-12|Deuteronomy 12 →]]
