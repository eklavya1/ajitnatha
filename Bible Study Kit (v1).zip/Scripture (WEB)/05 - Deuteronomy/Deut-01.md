# Deuteronomy 1

[[Deuteronomy]] | [[Deut-02|Deuteronomy 02 →]]
***



###### v1 
These are the words which Moses spoke to all Israel beyond the Jordan in the wilderness, in the Arabah opposite Suf, between Paran, Tophel, Laban, Hazeroth, and Dizahab. 

###### v2 
It is eleven days' journey from Horeb by the way of Mount Seir to Kadesh Barnea. 

###### v3 
In the fortieth year, in the eleventh month, on the first day of the month, Moses spoke to the children of Israel according to all that Yahweh had given him in commandment to them, 

###### v4 
after he had struck Sihon the king of the Amorites who lived in Heshbon, and Og the king of Bashan who lived in Ashtaroth, at Edrei. 

###### v5 
Beyond the Jordan, in the land of Moab, Moses began to declare this law, saying, 

###### v6 
"Yahweh our God spoke to us in Horeb, saying, 'You have lived long enough at this mountain. 

###### v7 
Turn, and take your journey, and go to the hill country of the Amorites and to all the places near there: in the Arabah, in the hill country, in the lowland, in the South, by the seashore, in the land of the Canaanites, and in Lebanon as far as the great river, the river Euphrates. 

###### v8 
Behold, I have set the land before you. Go in and possess the land which Yahweh swore to your fathers--to Abraham, to Isaac, and to Jacob--to give to them and to their offspring after them.'" 

###### v9 
I spoke to you at that time, saying, "I am not able to bear you myself alone. 

###### v10 
Yahweh your God has multiplied you, and behold, you are today as the stars of the sky for multitude. 

###### v11 
Yahweh, the God of your fathers, make you a thousand times as many as you are and bless you, as he has promised you! 

###### v12 
How can I myself alone bear your problems, your burdens, and your strife? 

###### v13 
Take wise men of understanding who are respected among your tribes, and I will make them heads over you." 

###### v14 
You answered me, and said, "The thing which you have spoken is good to do." 

###### v15 
So I took the heads of your tribes, wise and respected men, and made them heads over you, captains of thousands, captains of hundreds, captains of fifties, captains of tens, and officers, according to your tribes. 

###### v16 
I commanded your judges at that time, saying, "Hear cases between your brothers and judge righteously between a man and his brother, and the foreigner who is living with him. 

###### v17 
You shall not show partiality in judgment; you shall hear the small and the great alike. You shall not be afraid of the face of man, for the judgment is God's. The case that is too hard for you, you shall bring to me, and I will hear it." 

###### v18 
I commanded you at that time all the things which you should do. 

###### v19 
We traveled from Horeb and went through all that great and terrible wilderness which you saw, by the way to the hill country of the Amorites, as Yahweh our God commanded us; and we came to Kadesh Barnea. 

###### v20 
I said to you, "You have come to the hill country of the Amorites, which Yahweh our God gives to us. 

###### v21 
Behold, Yahweh your God has set the land before you. Go up, take possession, as Yahweh the God of your fathers has spoken to you. Don't be afraid, neither be dismayed." 

###### v22 
You came near to me, everyone of you, and said, "Let's send men before us, that they may search the land for us, and bring back to us word of the way by which we must go up, and the cities to which we shall come." 

###### v23 
The thing pleased me well. I took twelve of your men, one man for every tribe. 

###### v24 
They turned and went up into the hill country, and came to the valley of Eshcol, and spied it out. 

###### v25 
They took some of the fruit of the land in their hands and brought it down to us, and brought us word again, and said, "It is a good land which Yahweh our God gives to us." 

###### v26 
Yet you wouldn't go up, but rebelled against the commandment of Yahweh your God. 

###### v27 
You murmured in your tents, and said, "Because Yahweh hated us, he has brought us out of the land of Egypt, to deliver us into the hand of the Amorites to destroy us. 

###### v28 
Where are we going up? Our brothers have made our heart melt, saying, 'The people are greater and taller than we. The cities are great and fortified up to the sky. Moreover we have seen the sons of the Anakim there!'" 

###### v29 
Then I said to you, "Don't be terrified. Don't be afraid of them. 

###### v30 
Yahweh your God, who goes before you, he will fight for you, according to all that he did for you in Egypt before your eyes, 

###### v31 
and in the wilderness where you have seen how that Yahweh your God carried you, as a man carries his son, in all the way that you went, until you came to this place." 

###### v32 
Yet in this thing you didn't believe Yahweh your God, 

###### v33 
who went before you on the way, to seek out a place for you to pitch your tents in: in fire by night, to show you by what way you should go, and in the cloud by day. 

###### v34 
Yahweh heard the voice of your words and was angry, and swore, saying, 

###### v35 
"Surely not one of these men of this evil generation shall see the good land which I swore to give to your fathers, 

###### v36 
except Caleb the son of Jephunneh. He shall see it. I will give the land that he has trodden on to him and to his children, because he has wholly followed Yahweh." 

###### v37 
Also Yahweh was angry with me for your sakes, saying, "You also shall not go in there. 

###### v38 
Joshua the son of Nun, who stands before you, shall go in there. Encourage him, for he shall cause Israel to inherit it. 

###### v39 
Moreover your little ones, whom you said would be captured or killed, your children, who today have no knowledge of good or evil, shall go in there. I will give it to them, and they shall possess it. 

###### v40 
But as for you, turn, and take your journey into the wilderness by the way to the Red Sea." 

###### v41 
Then you answered and said to me, "We have sinned against Yahweh. We will go up and fight, according to all that Yahweh our God commanded us." Every man of you put on his weapons of war, and presumed to go up into the hill country. 

###### v42 
Yahweh said to me, "Tell them, 'Don't go up and don't fight; for I am not among you, lest you be struck before your enemies.'" 

###### v43 
So I spoke to you, and you didn't listen; but you rebelled against the commandment of Yahweh, and were presumptuous, and went up into the hill country. 

###### v44 
The Amorites, who lived in that hill country, came out against you and chased you as bees do, and beat you down in Seir, even to Hormah. 

###### v45 
You returned and wept before Yahweh; but Yahweh didn't listen to your voice, nor turn his ear to you. 

###### v46 
So you stayed in Kadesh many days, according to the days that you remained.

***
[[Deuteronomy]] | [[Deut-02|Deuteronomy 02 →]]
