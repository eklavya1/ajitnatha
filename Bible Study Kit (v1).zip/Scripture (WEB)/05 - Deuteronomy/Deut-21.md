# Deuteronomy 21

[[Deut-20|← Deuteronomy 20]] | [[Deuteronomy]] | [[Deut-22|Deuteronomy 22 →]]
***



###### v1 
If someone is found slain in the land which Yahweh your God gives you to possess, lying in the field, and it isn't known who has struck him, 

###### v2 
then your elders and your judges shall come out, and they shall measure to the cities which are around him who is slain. 

###### v3 
It shall be that the elders of the city which is nearest to the slain man shall take a heifer of the herd, which hasn't been worked with and which has not drawn in the yoke. 

###### v4 
The elders of that city shall bring the heifer down to a valley with running water, which is neither plowed nor sown, and shall break the heifer's neck there in the valley. 

###### v5 
The priests the sons of Levi shall come near, for them Yahweh your God has chosen to minister to him, and to bless in Yahweh's name; and according to their word shall every controversy and every assault be decided. 

###### v6 
All the elders of that city which is nearest to the slain man shall wash their hands over the heifer whose neck was broken in the valley. 

###### v7 
They shall answer and say, "Our hands have not shed this blood, neither have our eyes seen it. 

###### v8 
Forgive, Yahweh, your people Israel, whom you have redeemed, and don't allow innocent blood among your people Israel." The blood shall be forgiven them. 

###### v9 
So you shall put away the innocent blood from among you, when you shall do that which is right in Yahweh's eyes. 

###### v10 
When you go out to battle against your enemies, and Yahweh your God delivers them into your hands and you carry them away captive, 

###### v11 
and see among the captives a beautiful woman, and you are attracted to her, and desire to take her as your wife, 

###### v12 
then you shall bring her home to your house. She shall shave her head and trim her nails. 

###### v13 
She shall take off the clothing of her captivity, and shall remain in your house, and bewail her father and her mother a full month. After that you shall go in to her and be her husband, and she shall be your wife. 

###### v14 
It shall be, if you have no delight in her, then you shall let her go where she desires; but you shall not sell her at all for money. You shall not deal with her as a slave, because you have humbled her. 

###### v15 
If a man has two wives, the one beloved and the other hated, and they have borne him children, both the beloved and the hated, and if the firstborn son is hers who was hated, 

###### v16 
then it shall be, in the day that he causes his sons to inherit that which he has, that he may not give the son of the beloved the rights of the firstborn before the son of the hated, who is the firstborn; 

###### v17 
but he shall acknowledge the firstborn, the son of the hated, by giving him a double portion of all that he has; for he is the beginning of his strength. The right of the firstborn is his. 

###### v18 
If a man has a stubborn and rebellious son who will not obey the voice of his father or the voice of his mother, and though they chasten him, will not listen to them, 

###### v19 
then his father and his mother shall take hold of him and bring him out to the elders of his city and to the gate of his place. 

###### v20 
They shall tell the elders of his city, "This our son is stubborn and rebellious. He will not obey our voice. He is a glutton and a drunkard." 

###### v21 
All the men of his city shall stone him to death with stones. So you shall remove the evil from among you. All Israel shall hear, and fear. 

###### v22 
If a man has committed a sin worthy of death, and he is put to death, and you hang him on a tree, 

###### v23 
his body shall not remain all night on the tree, but you shall surely bury him the same day; for he who is hanged is accursed of God. Don't defile your land which Yahweh your God gives you for an inheritance.

***
[[Deut-20|← Deuteronomy 20]] | [[Deuteronomy]] | [[Deut-22|Deuteronomy 22 →]]
