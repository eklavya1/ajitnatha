# Deuteronomy 33

[[Deut-32|← Deuteronomy 32]] | [[Deuteronomy]] | [[Deut-34|Deuteronomy 34 →]]
***



###### v1 
This is the blessing with which Moses the man of God blessed the children of Israel before his death. 

###### v2 
He said, "Yahweh came from Sinai, and rose from Seir to them. He shone from Mount Paran. He came from the ten thousands of holy ones. At his right hand was a fiery law for them. 

###### v3 
Yes, he loves the people. All his saints are in your hand. They sat down at your feet. Each receives your words. 

###### v4 
Moses commanded us a law, an inheritance for the assembly of Jacob. 

###### v5 
He was king in Jeshurun, when the heads of the people were gathered, all the tribes of Israel together. 

###### v6 
"Let Reuben live, and not die; Nor let his men be few." 

###### v7 
This is for Judah. He said, "Hear, Yahweh, the voice of Judah. Bring him in to his people. With his hands he contended for himself. You shall be a help against his adversaries." 

###### v8 
About Levi he said, "Your Thummim and your Urim are with your godly one, whom you proved at Massah, with whom you contended at the waters of Meribah. 

###### v9 
He said of his father, and of his mother, 'I have not seen him.' He didn't acknowledge his brothers, nor did he know his own children; for they have observed your word, and keep your covenant. 

###### v10 
They shall teach Jacob your ordinances, and Israel your law. They shall put incense before you, and whole burnt offering on your altar. 

###### v11 
Yahweh, bless his skills. Accept the work of his hands. Strike through the hips of those who rise up against him, of those who hate him, that they not rise again." 

###### v12 
About Benjamin he said, "The beloved of Yahweh will dwell in safety by him. He covers him all day long. He dwells between his shoulders." 

###### v13 
About Joseph he said, "His land is blessed by Yahweh, for the precious things of the heavens, for the dew, for the deep that couches beneath, 

###### v14 
for the precious things of the fruits of the sun, for the precious things that the moon can yield, 

###### v15 
for the best things of the ancient mountains, for the precious things of the everlasting hills, 

###### v16 
for the precious things of the earth and its fullness, the good will of him who lived in the bush. Let this come on the head of Joseph, on the crown of the head of him who was separated from his brothers. 

###### v17 
Majesty belongs to the firstborn of his herd. His horns are the horns of the wild ox. With them he will push all the peoples to the ends of the earth. They are the ten thousands of Ephraim. They are the thousands of Manasseh." 

###### v18 
About Zebulun he said, "Rejoice, Zebulun, in your going out; and Issachar, in your tents. 

###### v19 
They will call the peoples to the mountain. There they will offer sacrifices of righteousness, for they will draw out the abundance of the seas, the hidden treasures of the sand." 

###### v20 
About Gad he said, "He who enlarges Gad is blessed. He dwells as a lioness, and tears the arm and the crown of the head. 

###### v21 
He provided the first part for himself, for the lawgiver's portion reserved was reserved for him. He came with the heads of the people. He executed the righteousness of Yahweh, His ordinances with Israel." 

###### v22 
About Dan he said, "Dan is a lion's cub that leaps out of Bashan." 

###### v23 
About Naphtali he said, "Naphtali, satisfied with favor, full of Yahweh's blessing, Possess the west and the south." 

###### v24 
About Asher he said, "Asher is blessed with children. Let him be acceptable to his brothers. Let him dip his foot in oil. 

###### v25 
Your bars will be iron and bronze. As your days, so your strength will be. 

###### v26 
"There is no one like God, Jeshurun, who rides on the heavens for your help, in his excellency on the skies. 

###### v27 
The eternal God is your dwelling place. Underneath are the everlasting arms. He thrust out the enemy from before you, and said, 'Destroy!' 

###### v28 
Israel dwells in safety, the fountain of Jacob alone, In a land of grain and new wine. Yes, his heavens drop down dew. 

###### v29 
You are happy, Israel! Who is like you, a people saved by Yahweh, the shield of your help, the sword of your excellency? Your enemies will submit themselves to you. You will tread on their high places."

***
[[Deut-32|← Deuteronomy 32]] | [[Deuteronomy]] | [[Deut-34|Deuteronomy 34 →]]
