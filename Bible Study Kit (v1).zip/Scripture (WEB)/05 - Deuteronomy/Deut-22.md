# Deuteronomy 22

[[Deut-21|← Deuteronomy 21]] | [[Deuteronomy]] | [[Deut-23|Deuteronomy 23 →]]
***



###### v1 
You shall not see your brother's ox or his sheep go astray and hide yourself from them. You shall surely bring them again to your brother. 

###### v2 
If your brother isn't near to you, or if you don't know him, then you shall bring it home to your house, and it shall be with you until your brother comes looking for it, and you shall restore it to him. 

###### v3 
So you shall do with his donkey. So you shall do with his garment. So you shall do with every lost thing of your brother's, which he has lost and you have found. You may not hide yourself. 

###### v4 
You shall not see your brother's donkey or his ox fallen down by the way, and hide yourself from them. You shall surely help him to lift them up again. 

###### v5 
A woman shall not wear men's clothing, neither shall a man put on women's clothing; for whoever does these things is an abomination to Yahweh your God. 

###### v6 
If you come across a bird's nest on the way, in any tree or on the ground, with young ones or eggs, and the hen sitting on the young, or on the eggs, you shall not take the hen with the young. 

###### v7 
You shall surely let the hen go, but the young you may take for yourself, that it may be well with you, and that you may prolong your days. 

###### v8 
When you build a new house, then you shall make a railing around your roof, so that you don't bring blood on your house if anyone falls from there. 

###### v9 
You shall not sow your vineyard with two kinds of seed, lest all the fruit be defiled, the seed which you have sown, and the increase of the vineyard. 

###### v10 
You shall not plow with an ox and a donkey together. 

###### v11 
You shall not wear clothes of wool and linen woven together. 

###### v12 
You shall make yourselves fringes on the four corners of your cloak with which you cover yourself. 

###### v13 
If any man takes a wife, and goes in to her, hates her, 

###### v14 
accuses her of shameful things, gives her a bad name, and says, "I took this woman, and when I came near to her, I didn't find in her the tokens of virginity;" 

###### v15 
then the young lady's father and mother shall take and bring the tokens of the young lady's virginity to the elders of the city in the gate. 

###### v16 
The young lady's father shall tell the elders, "I gave my daughter to this man as his wife, and he hates her. 

###### v17 
Behold, he has accused her of shameful things, saying, 'I didn't find in your daughter the tokens of virginity;' and yet these are the tokens of my daughter's virginity." They shall spread the cloth before the elders of the city. 

###### v18 
The elders of that city shall take the man and chastise him. 

###### v19 
They shall fine him one hundred shekels of silver, and give them to the father of the young lady, because he has given a bad name to a virgin of Israel. She shall be his wife. He may not put her away all his days. 

###### v20 
But if this thing is true, that the tokens of virginity were not found in the young lady, 

###### v21 
then they shall bring out the young lady to the door of her father's house, and the men of her city shall stone her to death with stones, because she has done folly in Israel, to play the prostitute in her father's house. So you shall remove the evil from among you. 

###### v22 
If a man is found lying with a woman married to a husband, then they shall both die, the man who lay with the woman and the woman. So you shall remove the evil from Israel. 

###### v23 
If there is a young lady who is a virgin pledged to be married to a husband, and a man finds her in the city, and lies with her, 

###### v24 
then you shall bring them both out to the gate of that city, and you shall stone them to death with stones; the lady, because she didn't cry, being in the city; and the man, because he has humbled his neighbor's wife. So you shall remove the evil from among you. 

###### v25 
But if the man finds the lady who is pledged to be married in the field, and the man forces her and lies with her, then only the man who lay with her shall die; 

###### v26 
but to the lady you shall do nothing. There is in the lady no sin worthy of death; for as when a man rises against his neighbor and kills him, even so is this matter; 

###### v27 
for he found her in the field, the pledged to be married lady cried, and there was no one to save her. 

###### v28 
If a man finds a lady who is a virgin, who is not pledged to be married, grabs her and lies with her, and they are found, 

###### v29 
then the man who lay with her shall give to the lady's father fifty shekels of silver. She shall be his wife, because he has humbled her. He may not put her away all his days. 

###### v30 
A man shall not take his father's wife, and shall not uncover his father's skirt.

***
[[Deut-21|← Deuteronomy 21]] | [[Deuteronomy]] | [[Deut-23|Deuteronomy 23 →]]
