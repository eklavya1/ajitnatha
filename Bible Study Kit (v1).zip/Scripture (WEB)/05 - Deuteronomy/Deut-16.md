# Deuteronomy 16

[[Deut-15|← Deuteronomy 15]] | [[Deuteronomy]] | [[Deut-17|Deuteronomy 17 →]]
***



###### v1 
Observe the month of Abib, and keep the Passover to Yahweh your God; for in the month of Abib Yahweh your God brought you out of Egypt by night. 

###### v2 
You shall sacrifice the Passover to Yahweh your God, of the flock and the herd, in the place which Yahweh shall choose to cause his name to dwell there. 

###### v3 
You shall eat no leavened bread with it. You shall eat unleavened bread with it seven days, even the bread of affliction (for you came out of the land of Egypt in haste) that you may remember the day when you came out of the land of Egypt all the days of your life. 

###### v4 
No yeast shall be seen with you in all your borders seven days; neither shall any of the meat, which you sacrifice the first day at evening, remain all night until the morning. 

###### v5 
You may not sacrifice the Passover within any of your gates which Yahweh your God gives you; 

###### v6 
but at the place which Yahweh your God shall choose to cause his name to dwell in, there you shall sacrifice the Passover at evening, at the going down of the sun, at the season that you came out of Egypt. 

###### v7 
You shall roast and eat it in the place which Yahweh your God chooses. In the morning you shall return to your tents. 

###### v8 
Six days you shall eat unleavened bread. On the seventh day shall be a solemn assembly to Yahweh your God. You shall do no work. 

###### v9 
You shall count for yourselves seven weeks. From the time you begin to put the sickle to the standing grain you shall begin to count seven weeks. 

###### v10 
You shall keep the feast of weeks to Yahweh your God with a tribute of a free will offering of your hand, which you shall give according to how Yahweh your God blesses you. 

###### v11 
You shall rejoice before Yahweh your God: you, your son, your daughter, your male servant, your female servant, the Levite who is within your gates, the foreigner, the fatherless, and the widow who are among you, in the place which Yahweh your God shall choose to cause his name to dwell there. 

###### v12 
You shall remember that you were a slave in Egypt. You shall observe and do these statutes. 

###### v13 
You shall keep the feast of booths seven days, after you have gathered in from your threshing floor and from your wine press. 

###### v14 
You shall rejoice in your feast, you, your son, your daughter, your male servant, your female servant, the Levite, the foreigner, the fatherless, and the widow who are within your gates. 

###### v15 
You shall keep a feast to Yahweh your God seven days in the place which Yahweh chooses, because Yahweh your God will bless you in all your increase and in all the work of your hands, and you shall be altogether joyful. 

###### v16 
Three times in a year all of your males shall appear before Yahweh your God in the place which he chooses: in the feast of unleavened bread, in the feast of weeks, and in the feast of booths. They shall not appear before Yahweh empty. 

###### v17 
Every man shall give as he is able, according to Yahweh your God's blessing which he has given you. 

###### v18 
You shall make judges and officers in all your gates, which Yahweh your God gives you, according to your tribes; and they shall judge the people with righteous judgment. 

###### v19 
You shall not pervert justice. You shall not show partiality. You shall not take a bribe, for a bribe blinds the eyes of the wise and perverts the words of the righteous. 

###### v20 
You shall follow that which is altogether just, that you may live and inherit the land which Yahweh your God gives you. 

###### v21 
You shall not plant for yourselves an Asherah of any kind of tree beside Yahweh your God's altar, which you shall make for yourselves. 

###### v22 
Neither shall you set yourself up a sacred stone which Yahweh your God hates.

***
[[Deut-15|← Deuteronomy 15]] | [[Deuteronomy]] | [[Deut-17|Deuteronomy 17 →]]
