# Deuteronomy 31

[[Deut-30|← Deuteronomy 30]] | [[Deuteronomy]] | [[Deut-32|Deuteronomy 32 →]]
***



###### v1 
Moses went and spoke these words to all Israel. 

###### v2 
He said to them, "I am one hundred twenty years old today. I can no more go out and come in. Yahweh has said to me, 'You shall not go over this Jordan.' 

###### v3 
Yahweh your God himself will go over before you. He will destroy these nations from before you, and you shall dispossess them. Joshua will go over before you, as Yahweh has spoken. 

###### v4 
Yahweh will do to them as he did to Sihon and to Og, the kings of the Amorites, and to their land, when he destroyed them. 

###### v5 
Yahweh will deliver them up before you, and you shall do to them according to all the commandment which I have commanded you. 

###### v6 
Be strong and courageous. Don't be afraid or scared of them; for Yahweh your God himself is who goes with you. He will not fail you nor forsake you." 

###### v7 
Moses called to Joshua, and said to him in the sight of all Israel, "Be strong and courageous, for you shall go with this people into the land which Yahweh has sworn to their fathers to give them; and you shall cause them to inherit it. 

###### v8 
Yahweh himself is who goes before you. He will be with you. He will not fail you nor forsake you. Don't be afraid. Don't be discouraged." 

###### v9 
Moses wrote this law and delivered it to the priests the sons of Levi, who bore the ark of Yahweh's covenant, and to all the elders of Israel. 

###### v10 
Moses commanded them, saying, "At the end of every seven years, in the set time of the year of release, in the feast of booths, 

###### v11 
when all Israel has come to appear before Yahweh your God in the place which he will choose, you shall read this law before all Israel in their hearing. 

###### v12 
Assemble the people, the men and the women and the little ones, and the foreigners who are within your gates, that they may hear, learn, fear Yahweh your God, and observe to do all the words of this law, 

###### v13 
and that their children, who have not known, may hear and learn to fear Yahweh your God, as long as you live in the land where you go over the Jordan to possess it." 

###### v14 
Yahweh said to Moses, "Behold, your days approach that you must die. Call Joshua, and present yourselves in the Tent of Meeting, that I may commission him." Moses and Joshua went, and presented themselves in the Tent of Meeting. 

###### v15 
Yahweh appeared in the Tent in a pillar of cloud, and the pillar of cloud stood over the Tent's door. 

###### v16 
Yahweh said to Moses, "Behold, you shall sleep with your fathers. This people will rise up and play the prostitute after the strange gods of the land where they go to be among them, and will forsake me and break my covenant which I have made with them. 

###### v17 
Then my anger shall be kindled against them in that day, and I will forsake them, and I will hide my face from them, and they shall be devoured, and many evils and troubles shall come on them; so that they will say in that day, 'Haven't these evils come on us because our God is not among us?' 

###### v18 
I will surely hide my face in that day for all the evil which they have done, in that they have turned to other gods. 

###### v19 
"Now therefore write this song for yourselves, and teach it to the children of Israel. Put it in their mouths, that this song may be a witness for me against the children of Israel. 

###### v20 
For when I have brought them into the land which I swore to their fathers, flowing with milk and honey, and they have eaten and filled themselves, and grown fat, then they will turn to other gods, and serve them, and despise me, and break my covenant. 

###### v21 
It will happen, when many evils and troubles have come on them, that this song will testify before them as a witness; for it will not be forgotten out of the mouths of their descendants; for I know their ways and what they are doing today, before I have brought them into the land which I promised them." 

###### v22 
So Moses wrote this song the same day, and taught it to the children of Israel. 

###### v23 
He commissioned Joshua the son of Nun, and said, "Be strong and courageous; for you shall bring the children of Israel into the land which I swore to them. I will be with you." 

###### v24 
When Moses had finished writing the words of this law in a book, until they were finished, 

###### v25 
Moses commanded the Levites, who bore the ark of Yahweh's covenant, saying, 

###### v26 
"Take this book of the law, and put it by the side of the ark of Yahweh your God's covenant, that it may be there for a witness against you. 

###### v27 
For I know your rebellion and your stiff neck. Behold, while I am yet alive with you today, you have been rebellious against Yahweh. How much more after my death? 

###### v28 
Assemble to me all the elders of your tribes and your officers, that I may speak these words in their ears, and call heaven and earth to witness against them. 

###### v29 
For I know that after my death you will utterly corrupt yourselves, and turn away from the way which I have commanded you; and evil will happen to you in the latter days, because you will do that which is evil in Yahweh's sight, to provoke him to anger through the work of your hands." 

###### v30 
Moses spoke in the ears of all the assembly of Israel the words of this song, until they were finished.

***
[[Deut-30|← Deuteronomy 30]] | [[Deuteronomy]] | [[Deut-32|Deuteronomy 32 →]]
