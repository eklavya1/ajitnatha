# Deuteronomy 15

[[Deut-14|← Deuteronomy 14]] | [[Deuteronomy]] | [[Deut-16|Deuteronomy 16 →]]
***



###### v1 
At the end of every seven years, you shall cancel debts. 

###### v2 
This is the way it shall be done: every creditor shall release that which he has lent to his neighbor. He shall not require payment from his neighbor and his brother, because Yahweh's release has been proclaimed. 

###### v3 
Of a foreigner you may require it; but whatever of yours is with your brother, your hand shall release. 

###### v4 
However there will be no poor with you (for Yahweh will surely bless you in the land which Yahweh your God gives you for an inheritance to possess) 

###### v5 
if only you diligently listen to Yahweh your God's voice, to observe to do all this commandment which I command you today. 

###### v6 
For Yahweh your God will bless you, as he promised you. You will lend to many nations, but you will not borrow. You will rule over many nations, but they will not rule over you. 

###### v7 
If a poor man, one of your brothers, is with you within any of your gates in your land which Yahweh your God gives you, you shall not harden your heart, nor shut your hand from your poor brother; 

###### v8 
but you shall surely open your hand to him, and shall surely lend him sufficient for his need, which he lacks. 

###### v9 
Beware that there not be a wicked thought in your heart, saying, "The seventh year, the year of release, is at hand," and your eye be evil against your poor brother and you give him nothing; and he cry to Yahweh against you, and it be sin to you. 

###### v10 
You shall surely give, and your heart shall not be grieved when you give to him, because it is for this thing Yahweh your God will bless you in all your work and in all that you put your hand to. 

###### v11 
For the poor will never cease out of the land. Therefore I command you to surely open your hand to your brother, to your needy, and to your poor, in your land. 

###### v12 
If your brother, a Hebrew man, or a Hebrew woman, is sold to you and serves you six years, then in the seventh year you shall let him go free from you. 

###### v13 
When you let him go free from you, you shall not let him go empty. 

###### v14 
You shall furnish him liberally out of your flock, out of your threshing floor, and out of your wine press. As Yahweh your God has blessed you, you shall give to him. 

###### v15 
You shall remember that you were a slave in the land of Egypt, and Yahweh your God redeemed you. Therefore I command you this thing today. 

###### v16 
It shall be, if he tells you, "I will not go out from you," because he loves you and your house, because he is well with you, 

###### v17 
then you shall take an awl, and thrust it through his ear to the door, and he shall be your servant forever. Also to your female servant you shall do likewise. 

###### v18 
It shall not seem hard to you when you let him go free from you, for he has been double the value of a hired hand as he served you six years. Yahweh your God will bless you in all that you do. 

###### v19 
You shall dedicate all the firstborn males that are born of your herd and of your flock to Yahweh your God. You shall do no work with the firstborn of your herd, nor shear the firstborn of your flock. 

###### v20 
You shall eat it before Yahweh your God year by year in the place which Yahweh shall choose, you and your household. 

###### v21 
If it has any defect--is lame or blind, or has any defect whatever, you shall not sacrifice it to Yahweh your God. 

###### v22 
You shall eat it within your gates. The unclean and the clean shall eat it alike, as the gazelle and as the deer. 

###### v23 
Only you shall not eat its blood. You shall pour it out on the ground like water.

***
[[Deut-14|← Deuteronomy 14]] | [[Deuteronomy]] | [[Deut-16|Deuteronomy 16 →]]
