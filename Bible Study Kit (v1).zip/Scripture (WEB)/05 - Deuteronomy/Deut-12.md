# Deuteronomy 12

[[Deut-11|← Deuteronomy 11]] | [[Deuteronomy]] | [[Deut-13|Deuteronomy 13 →]]
***



###### v1 
These are the statutes and the ordinances which you shall observe to do in the land which Yahweh, the God of your fathers, has given you to possess all the days that you live on the earth. 

###### v2 
You shall surely destroy all the places in which the nations that you shall dispossess served their gods: on the high mountains, and on the hills, and under every green tree. 

###### v3 
You shall break down their altars, dash their pillars in pieces, and burn their Asherah poles with fire. You shall cut down the engraved images of their gods. You shall destroy their name out of that place. 

###### v4 
You shall not do so to Yahweh your God. 

###### v5 
But to the place which Yahweh your God shall choose out of all your tribes, to put his name there, you shall seek his habitation, and you shall come there. 

###### v6 
You shall bring your burnt offerings, your sacrifices, your tithes, the wave offering of your hand, your vows, your free will offerings, and the firstborn of your herd and of your flock there. 

###### v7 
There you shall eat before Yahweh your God, and you shall rejoice in all that you put your hand to, you and your households, in which Yahweh your God has blessed you. 

###### v8 
You shall not do all the things that we do here today, every man whatever is right in his own eyes; 

###### v9 
for you haven't yet come to the rest and to the inheritance which Yahweh your God gives you. 

###### v10 
But when you go over the Jordan and dwell in the land which Yahweh your God causes you to inherit, and he gives you rest from all your enemies around you, so that you dwell in safety, 

###### v11 
then it shall happen that to the place which Yahweh your God shall choose, to cause his name to dwell there, there you shall bring all that I command you: your burnt offerings, your sacrifices, your tithes, the wave offering of your hand, and all your choice vows which you vow to Yahweh. 

###### v12 
You shall rejoice before Yahweh your God--you, and your sons, your daughters, your male servants, your female servants, and the Levite who is within your gates, because he has no portion nor inheritance with you. 

###### v13 
Be careful that you don't offer your burnt offerings in every place that you see; 

###### v14 
but in the place which Yahweh chooses in one of your tribes, there you shall offer your burnt offerings, and there you shall do all that I command you. 

###### v15 
Yet you may kill and eat meat within all your gates, after all the desire of your soul, according to Yahweh your God's blessing which he has given you. The unclean and the clean may eat of it, as of the gazelle and the deer. 

###### v16 
Only you shall not eat the blood. You shall pour it out on the earth like water. 

###### v17 
You may not eat within your gates the tithe of your grain, or of your new wine, or of your oil, or the firstborn of your herd or of your flock, nor any of your vows which you vow, nor your free will offerings, nor the wave offering of your hand; 

###### v18 
but you shall eat them before Yahweh your God in the place which Yahweh your God shall choose: you, your son, your daughter, your male servant, your female servant, and the Levite who is within your gates. You shall rejoice before Yahweh your God in all that you put your hand to. 

###### v19 
Be careful that you don't forsake the Levite as long as you live in your land. 

###### v20 
When Yahweh your God enlarges your border, as he has promised you, and you say, "I want to eat meat," because your soul desires to eat meat, you may eat meat, after all the desire of your soul. 

###### v21 
If the place which Yahweh your God shall choose to put his name is too far from you, then you shall kill of your herd and of your flock, which Yahweh has given you, as I have commanded you; and you may eat within your gates, after all the desire of your soul. 

###### v22 
Even as the gazelle and as the deer is eaten, so you shall eat of it. The unclean and the clean may eat of it alike. 

###### v23 
Only be sure that you don't eat the blood; for the blood is the life. You shall not eat the life with the meat. 

###### v24 
You shall not eat it. You shall pour it out on the earth like water. 

###### v25 
You shall not eat it, that it may go well with you and with your children after you, when you do that which is right in Yahweh's eyes. 

###### v26 
Only your holy things which you have, and your vows, you shall take and go to the place which Yahweh shall choose. 

###### v27 
You shall offer your burnt offerings, the meat and the blood, on Yahweh your God's altar. The blood of your sacrifices shall be poured out on Yahweh your God's altar, and you shall eat the meat. 

###### v28 
Observe and hear all these words which I command you, that it may go well with you and with your children after you forever, when you do that which is good and right in Yahweh your God's eyes. 

###### v29 
When Yahweh your God cuts off the nations from before you where you go in to dispossess them, and you dispossess them and dwell in their land, 

###### v30 
be careful that you are not ensnared to follow them after they are destroyed from before you, and that you not inquire after their gods, saying, "How do these nations serve their gods? I will do likewise." 

###### v31 
You shall not do so to Yahweh your God; for every abomination to Yahweh, which he hates, they have done to their gods; for they even burn their sons and their daughters in the fire to their gods. 

###### v32 
Whatever thing I command you, that you shall observe to do. You shall not add to it, nor take away from it.

***
[[Deut-11|← Deuteronomy 11]] | [[Deuteronomy]] | [[Deut-13|Deuteronomy 13 →]]
