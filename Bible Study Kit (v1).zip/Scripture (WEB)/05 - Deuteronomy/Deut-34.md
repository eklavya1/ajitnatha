# Deuteronomy 34

[[Deut-33|← Deuteronomy 33]] | [[Deuteronomy]]
***



###### v1 
Moses went up from the plains of Moab to Mount Nebo, to the top of Pisgah, that is opposite Jericho. Yahweh showed him all the land of Gilead to Dan, 

###### v2 
and all Naphtali, and the land of Ephraim and Manasseh, and all the land of Judah, to the Western Sea, 

###### v3 
and the south, and the Plain of the valley of Jericho the city of palm trees, to Zoar. 

###### v4 
Yahweh said to him, "This is the land which I swore to Abraham, to Isaac, and to Jacob, saying, 'I will give it to your offspring.' I have caused you to see it with your eyes, but you shall not go over there." 

###### v5 
So Moses the servant of Yahweh died there in the land of Moab, according to Yahweh's word. 

###### v6 
He buried him in the valley in the land of Moab opposite Beth Peor, but no man knows where his tomb is to this day. 

###### v7 
Moses was one hundred twenty years old when he died. His eye was not dim, nor his strength gone. 

###### v8 
The children of Israel wept for Moses in the plains of Moab thirty days, until the days of weeping in the mourning for Moses were ended. 

###### v9 
Joshua the son of Nun was full of the spirit of wisdom, for Moses had laid his hands on him. The children of Israel listened to him, and did as Yahweh commanded Moses. 

###### v10 
Since then, there has not arisen a prophet in Israel like Moses, whom Yahweh knew face to face, 

###### v11 
in all the signs and the wonders which Yahweh sent him to do in the land of Egypt, to Pharaoh, and to all his servants, and to all his land, 

###### v12 
and in all the mighty hand, and in all the awesome deeds, which Moses did in the sight of all Israel.

***
[[Deut-33|← Deuteronomy 33]] | [[Deuteronomy]]
