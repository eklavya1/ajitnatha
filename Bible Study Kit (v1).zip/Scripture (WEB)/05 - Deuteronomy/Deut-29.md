# Deuteronomy 29

[[Deut-28|← Deuteronomy 28]] | [[Deuteronomy]] | [[Deut-30|Deuteronomy 30 →]]
***



###### v1 
These are the words of the covenant which Yahweh commanded Moses to make with the children of Israel in the land of Moab, in addition to the covenant which he made with them in Horeb. 

###### v2 
Moses called to all Israel, and said to them: Your eyes have seen all that Yahweh did in the land of Egypt to Pharaoh, and to all his servants, and to all his land; 

###### v3 
the great trials which your eyes saw, the signs, and those great wonders. 

###### v4 
But Yahweh has not given you a heart to know, eyes to see, and ears to hear, to this day. 

###### v5 
I have led you forty years in the wilderness. Your clothes have not grown old on you, and your sandals have not grown old on your feet. 

###### v6 
You have not eaten bread, neither have you drunk wine or strong drink, that you may know that I am Yahweh your God. 

###### v7 
When you came to this place, Sihon the king of Heshbon and Og the king of Bashan came out against us to battle, and we struck them. 

###### v8 
We took their land, and gave it for an inheritance to the Reubenites, and to the Gadites, and to the half-tribe of the Manassites. 

###### v9 
Therefore keep the words of this covenant and do them, that you may prosper in all that you do. 

###### v10 
All of you stand today in the presence of Yahweh your God: your heads, your tribes, your elders, and your officers, even all the men of Israel, 

###### v11 
your little ones, your wives, and the foreigners who are in the middle of your camps, from the one who cuts your wood to the one who draws your water, 

###### v12 
that you may enter into the covenant of Yahweh your God, and into his oath, which Yahweh your God makes with you today, 

###### v13 
that he may establish you today as his people, and that he may be your God, as he spoke to you and as he swore to your fathers, to Abraham, to Isaac, and to Jacob. 

###### v14 
Neither do I make this covenant and this oath with you only, 

###### v15 
but with those who stand here with us today before Yahweh our God, and also with those who are not here with us today 

###### v16 
(for you know how we lived in the land of Egypt, and how we came through the middle of the nations through which you passed; 

###### v17 
and you have seen their abominations and their idols of wood, stone, silver, and gold, which were among them); 

###### v18 
lest there should be among you man, woman, family, or tribe whose heart turns away today from Yahweh our God, to go to serve the gods of those nations; lest there should be among you a root that produces bitter poison; 

###### v19 
and it happen, when he hears the words of this curse, that he bless himself in his heart, saying, "I shall have peace, though I walk in the stubbornness of my heart," to destroy the moist with the dry. 

###### v20 
Yahweh will not pardon him, but then Yahweh's anger and his jealousy will smoke against that man, and all the curse that is written in this book will fall on him, and Yahweh will blot out his name from under the sky. 

###### v21 
Yahweh will set him apart for evil out of all the tribes of Israel, according to all the curses of the covenant written in this book of the law. 

###### v22 
The generation to come--your children who will rise up after you, and the foreigner who will come from a far land--will say, when they see the plagues of that land, and the sicknesses with which Yahweh has made it sick, 

###### v23 
that all of its land is sulfur, salt, and burning, that it is not sown, doesn't produce, nor does any grass grow in it, like the overthrow of Sodom, Gomorrah, Admah, and Zeboiim, which Yahweh overthrew in his anger, and in his wrath. 

###### v24 
Even all the nations will say, "Why has Yahweh done this to this land? What does the heat of this great anger mean?" 

###### v25 
Then men will say, "Because they abandoned the covenant of Yahweh, the God of their fathers, which he made with them when he brought them out of the land of Egypt, 

###### v26 
and went and served other gods and worshiped them, gods that they didn't know and that he had not given to them. 

###### v27 
Therefore Yahweh's anger burned against this land, to bring on it all the curses that are written in this book. 

###### v28 
Yahweh rooted them out of their land in anger, in wrath, and in great indignation, and thrust them into another land, as it is today." 

###### v29 
The secret things belong to Yahweh our God; but the things that are revealed belong to us and to our children forever, that we may do all the words of this law.

***
[[Deut-28|← Deuteronomy 28]] | [[Deuteronomy]] | [[Deut-30|Deuteronomy 30 →]]
