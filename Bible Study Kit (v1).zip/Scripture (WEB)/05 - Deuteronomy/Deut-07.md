# Deuteronomy 7

[[Deut-06|← Deuteronomy 06]] | [[Deuteronomy]] | [[Deut-08|Deuteronomy 08 →]]
***



###### v1 
When Yahweh your God brings you into the land where you go to possess it, and casts out many nations before you--the Hittite, the Girgashite, the Amorite, the Canaanite, the Perizzite, the Hivite, and the Jebusite--seven nations greater and mightier than you; 

###### v2 
and when Yahweh your God delivers them up before you, and you strike them, then you shall utterly destroy them. You shall make no covenant with them, nor show mercy to them. 

###### v3 
You shall not make marriages with them. You shall not give your daughter to his son, nor shall you take his daughter for your son. 

###### v4 
For that would turn away your sons from following me, that they may serve other gods. So Yahweh's anger would be kindled against you, and he would destroy you quickly. 

###### v5 
But you shall deal with them like this: you shall break down their altars, dash their pillars in pieces, cut down their Asherah poles, and burn their engraved images with fire. 

###### v6 
For you are a holy people to Yahweh your God. Yahweh your God has chosen you to be a people for his own possession, above all peoples who are on the face of the earth. 

###### v7 
Yahweh didn't set his love on you nor choose you, because you were more in number than any people; for you were the fewest of all peoples; 

###### v8 
but because Yahweh loves you, and because he desires to keep the oath which he swore to your fathers, Yahweh has brought you out with a mighty hand and redeemed you out of the house of bondage, from the hand of Pharaoh king of Egypt. 

###### v9 
Know therefore that Yahweh your God himself is God, the faithful God, who keeps covenant and loving kindness to a thousand generations with those who love him and keep his commandments, 

###### v10 
and repays those who hate him to their face, to destroy them. He will not be slack to him who hates him. He will repay him to his face. 

###### v11 
You shall therefore keep the commandments, the statutes, and the ordinances which I command you today, to do them. 

###### v12 
It shall happen, because you listen to these ordinances and keep and do them, that Yahweh your God will keep with you the covenant and the loving kindness which he swore to your fathers. 

###### v13 
He will love you, bless you, and multiply you. He will also bless the fruit of your body and the fruit of your ground, your grain and your new wine and your oil, the increase of your livestock and the young of your flock, in the land which he swore to your fathers to give you. 

###### v14 
You will be blessed above all peoples. There won't be male or female barren among you, or among your livestock. 

###### v15 
Yahweh will take away from you all sickness; and he will put none of the evil diseases of Egypt, which you know, on you, but will lay them on all those who hate you. 

###### v16 
You shall consume all the peoples whom Yahweh your God shall deliver to you. Your eye shall not pity them. You shall not serve their gods; for that would be a snare to you. 

###### v17 
If you shall say in your heart, "These nations are more than I; how can I dispossess them?" 

###### v18 
you shall not be afraid of them. You shall remember well what Yahweh your God did to Pharaoh and to all Egypt: 

###### v19 
the great trials which your eyes saw, the signs, the wonders, the mighty hand, and the outstretched arm, by which Yahweh your God brought you out. So shall Yahweh your God do to all the peoples of whom you are afraid. 

###### v20 
Moreover Yahweh your God will send the hornet among them, until those who are left, and hide themselves, perish from before you. 

###### v21 
You shall not be scared of them; for Yahweh your God is among you, a great and awesome God. 

###### v22 
Yahweh your God will cast out those nations before you little by little. You may not consume them at once, lest the animals of the field increase on you. 

###### v23 
But Yahweh your God will deliver them up before you, and will confuse them with a great confusion, until they are destroyed. 

###### v24 
He will deliver their kings into your hand, and you shall make their name perish from under the sky. No one will be able to stand before you until you have destroyed them. 

###### v25 
You shall burn the engraved images of their gods with fire. You shall not covet the silver or the gold that is on them, nor take it for yourself, lest you be snared in it; for it is an abomination to Yahweh your God. 

###### v26 
You shall not bring an abomination into your house and become a devoted thing like it. You shall utterly detest it. You shall utterly abhor it; for it is a devoted thing.

***
[[Deut-06|← Deuteronomy 06]] | [[Deuteronomy]] | [[Deut-08|Deuteronomy 08 →]]
