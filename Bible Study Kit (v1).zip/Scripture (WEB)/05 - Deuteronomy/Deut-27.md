# Deuteronomy 27

[[Deut-26|← Deuteronomy 26]] | [[Deuteronomy]] | [[Deut-28|Deuteronomy 28 →]]
***



###### v1 
Moses and the elders of Israel commanded the people, saying, "Keep all the commandment which I command you today. 

###### v2 
It shall be on the day when you shall pass over the Jordan to the land which Yahweh your God gives you, that you shall set yourself up great stones, and coat them with plaster. 

###### v3 
You shall write on them all the words of this law, when you have passed over, that you may go in to the land which Yahweh your God gives you, a land flowing with milk and honey, as Yahweh, the God of your fathers, has promised you. 

###### v4 
It shall be, when you have crossed over the Jordan, that you shall set up these stones, which I command you today, on Mount Ebal, and you shall coat them with plaster. 

###### v5 
There you shall build an altar to Yahweh your God, an altar of stones. You shall not use any iron tool on them. 

###### v6 
You shall build Yahweh your God's altar of uncut stones. You shall offer burnt offerings on it to Yahweh your God. 

###### v7 
You shall sacrifice peace offerings, and shall eat there. You shall rejoice before Yahweh your God. 

###### v8 
You shall write on the stones all the words of this law very plainly." 

###### v9 
Moses and the Levitical priests spoke to all Israel, saying, "Be silent and listen, Israel! Today you have become the people of Yahweh your God. 

###### v10 
You shall therefore obey Yahweh your God's voice, and do his commandments and his statutes, which I command you today." 

###### v11 
Moses commanded the people the same day, saying, 

###### v12 
"These shall stand on Mount Gerizim to bless the people, when you have crossed over the Jordan: Simeon, Levi, Judah, Issachar, Joseph, and Benjamin. 

###### v13 
These shall stand on Mount Ebal for the curse: Reuben, Gad, Asher, Zebulun, Dan, and Naphtali. 

###### v14 
With a loud voice, the Levites shall say to all the men of Israel, 

###### v15 
'Cursed is the man who makes an engraved or molten image, an abomination to Yahweh, the work of the hands of the craftsman, and sets it up in secret.' All the people shall answer and say, 'Amen.' 

###### v16 
'Cursed is he who dishonors his father or his mother.' All the people shall say, 'Amen.' 

###### v17 
'Cursed is he who removes his neighbor's landmark.' All the people shall say, 'Amen.' 

###### v18 
'Cursed is he who leads the blind astray on the road.' All the people shall say, 'Amen.' 

###### v19 
'Cursed is he who withholds justice from the foreigner, fatherless, and widow.' All the people shall say, 'Amen.' 

###### v20 
'Cursed is he who lies with his father's wife, because he dishonors his father's bed.' All the people shall say, 'Amen.' 

###### v21 
'Cursed is he who lies with any kind of animal.' All the people shall say, 'Amen.' 

###### v22 
'Cursed is he who lies with his sister, his father's daughter or his mother's daughter.' All the people shall say, 'Amen.' 

###### v23 
'Cursed is he who lies with his mother-in-law.' All the people shall say, 'Amen.' 

###### v24 
'Cursed is he who secretly kills his neighbor.' All the people shall say, 'Amen.' 

###### v25 
'Cursed is he who takes a bribe to kill an innocent person.' All the people shall say, 'Amen.' 

###### v26 
'Cursed is he who doesn't uphold the words of this law by doing them.' All the people shall say, 'Amen.'"

***
[[Deut-26|← Deuteronomy 26]] | [[Deuteronomy]] | [[Deut-28|Deuteronomy 28 →]]
