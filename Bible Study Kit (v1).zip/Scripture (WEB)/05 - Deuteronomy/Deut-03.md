# Deuteronomy 3

[[Deut-02|← Deuteronomy 02]] | [[Deuteronomy]] | [[Deut-04|Deuteronomy 04 →]]
***



###### v1 
Then we turned, and went up the way to Bashan. Og the king of Bashan came out against us, he and all his people, to battle at Edrei. 

###### v2 
Yahweh said to me, "Don't fear him; for I have delivered him, with all his people and his land, into your hand. You shall do to him as you did to Sihon king of the Amorites, who lived at Heshbon." 

###### v3 
So Yahweh our God also delivered into our hand Og, the king of Bashan, and all his people. We struck him until no one was left to him remaining. 

###### v4 
We took all his cities at that time. There was not a city which we didn't take from them: sixty cities, all the region of Argob, the kingdom of Og in Bashan. 

###### v5 
All these were cities fortified with high walls, gates, and bars, in addition to a great many villages without walls. 

###### v6 
We utterly destroyed them, as we did to Sihon king of Heshbon, utterly destroying every inhabited city, with the women and the little ones. 

###### v7 
But all the livestock, and the plunder of the cities, we took for plunder for ourselves. 

###### v8 
We took the land at that time out of the hand of the two kings of the Amorites who were beyond the Jordan, from the valley of the Arnon to Mount Hermon. 

###### v9 
(The Sidonians call Hermon Sirion, and the Amorites call it Senir.) 

###### v10 
We took all the cities of the plain, and all Gilead, and all Bashan, to Salecah and Edrei, cities of the kingdom of Og in Bashan. 

###### v11 
(For only Og king of Bashan remained of the remnant of the Rephaim. Behold, his bedstead was a bedstead of iron. Isn't it in Rabbah of the children of Ammon? Nine cubits was its length, and four cubits its width, after the cubit of a man.) 

###### v12 
This land we took in possession at that time: from Aroer, which is by the valley of the Arnon, and half the hill country of Gilead with its cities, I gave to the Reubenites and to the Gadites; 

###### v13 
and the rest of Gilead, and all Bashan, the kingdom of Og, I gave to the half-tribe of Manasseh--all the region of Argob, even all Bashan. (The same is called the land of Rephaim. 

###### v14 
Jair the son of Manasseh took all the region of Argob, to the border of the Geshurites and the Maacathites, and called them, even Bashan, after his own name, Havvoth Jair, to this day.) 

###### v15 
I gave Gilead to Machir. 

###### v16 
To the Reubenites and to the Gadites I gave from Gilead even to the valley of the Arnon, the middle of the valley, and its border, even to the river Jabbok, which is the border of the children of Ammon; 

###### v17 
the Arabah also, and the Jordan and its border, from Chinnereth even to the sea of the Arabah, the Salt Sea, under the slopes of Pisgah eastward. 

###### v18 
I commanded you at that time, saying, "Yahweh your God has given you this land to possess it. All of you men of valor shall pass over armed before your brothers, the children of Israel. 

###### v19 
But your wives, and your little ones, and your livestock, (I know that you have much livestock), shall live in your cities which I have given you, 

###### v20 
until Yahweh gives rest to your brothers, as to you, and they also possess the land which Yahweh your God gives them beyond the Jordan. Then you shall each return to his own possession, which I have given you." 

###### v21 
I commanded Joshua at that time, saying, "Your eyes have seen all that Yahweh your God has done to these two kings. So shall Yahweh do to all the kingdoms where you go over. 

###### v22 
You shall not fear them; for Yahweh your God himself fights for you." 

###### v23 
I begged Yahweh at that time, saying, 

###### v24 
"Lord Yahweh, you have begun to show your servant your greatness, and your strong hand. For what god is there in heaven or in earth that can do works like yours, and mighty acts like yours? 

###### v25 
Please let me go over and see the good land that is beyond the Jordan, that fine mountain, and Lebanon." 

###### v26 
But Yahweh was angry with me because of you, and didn't listen to me. Yahweh said to me, "That is enough! Speak no more to me of this matter. 

###### v27 
Go up to the top of Pisgah, and lift up your eyes westward, and northward, and southward, and eastward, and see with your eyes; for you shall not go over this Jordan. 

###### v28 
But commission Joshua, and encourage him, and strengthen him; for he shall go over before this people, and he shall cause them to inherit the land which you shall see." 

###### v29 
So we stayed in the valley near Beth Peor.

***
[[Deut-02|← Deuteronomy 02]] | [[Deuteronomy]] | [[Deut-04|Deuteronomy 04 →]]
