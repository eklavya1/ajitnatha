# Deuteronomy 4

[[Deut-03|← Deuteronomy 03]] | [[Deuteronomy]] | [[Deut-05|Deuteronomy 05 →]]
***



###### v1 
Now, Israel, listen to the statutes and to the ordinances which I teach you, to do them; that you may live, and go in and possess the land which Yahweh, the God of your fathers, gives you. 

###### v2 
You shall not add to the word which I command you, neither shall you take away from it, that you may keep the commandments of Yahweh your God which I command you. 

###### v3 
Your eyes have seen what Yahweh did because of Baal Peor; for Yahweh your God has destroyed all the men who followed Baal Peor from among you. 

###### v4 
But you who were faithful to Yahweh your God are all alive today. 

###### v5 
Behold, I have taught you statutes and ordinances, even as Yahweh my God commanded me, that you should do so in the middle of the land where you go in to possess it. 

###### v6 
Keep therefore and do them; for this is your wisdom and your understanding in the sight of the peoples who shall hear all these statutes and say, "Surely this great nation is a wise and understanding people." 

###### v7 
For what great nation is there that has a god so near to them as Yahweh our God is whenever we call on him? 

###### v8 
What great nation is there that has statutes and ordinances so righteous as all this law which I set before you today? 

###### v9 
Only be careful, and keep your soul diligently, lest you forget the things which your eyes saw, and lest they depart from your heart all the days of your life; but make them known to your children and your children's children-- 

###### v10 
the day that you stood before Yahweh your God in Horeb, when Yahweh said to me, "Assemble the people to me, and I will make them hear my words, that they may learn to fear me all the days that they live on the earth, and that they may teach their children." 

###### v11 
You came near and stood under the mountain. The mountain burned with fire to the heart of the sky, with darkness, cloud, and thick darkness. 

###### v12 
Yahweh spoke to you out of the middle of the fire: you heard the voice of words, but you saw no form; you only heard a voice. 

###### v13 
He declared to you his covenant, which he commanded you to perform, even the ten commandments. He wrote them on two stone tablets. 

###### v14 
Yahweh commanded me at that time to teach you statutes and ordinances, that you might do them in the land where you go over to possess it. 

###### v15 
Be very careful, for you saw no kind of form on the day that Yahweh spoke to you in Horeb out of the middle of the fire, 

###### v16 
lest you corrupt yourselves, and make yourself a carved image in the form of any figure, the likeness of male or female, 

###### v17 
the likeness of any animal that is on the earth, the likeness of any winged bird that flies in the sky, 

###### v18 
the likeness of anything that creeps on the ground, the likeness of any fish that is in the water under the earth; 

###### v19 
and lest you lift up your eyes to the sky, and when you see the sun and the moon and the stars, even all the army of the sky, you are drawn away and worship them, and serve them, which Yahweh your God has allotted to all the peoples under the whole sky. 

###### v20 
But Yahweh has taken you, and brought you out of the iron furnace, out of Egypt, to be to him a people of inheritance, as it is today. 

###### v21 
Furthermore Yahweh was angry with me for your sakes, and swore that I should not go over the Jordan, and that I should not go in to that good land which Yahweh your God gives you for an inheritance; 

###### v22 
but I must die in this land. I must not go over the Jordan, but you shall go over and possess that good land. 

###### v23 
Be careful, lest you forget the covenant of Yahweh your God, which he made with you, and make yourselves a carved image in the form of anything which Yahweh your God has forbidden you. 

###### v24 
For Yahweh your God is a devouring fire, a jealous God. 

###### v25 
When you father children and children's children, and you have been long in the land, and then corrupt yourselves, and make a carved image in the form of anything, and do that which is evil in Yahweh your God's sight to provoke him to anger, 

###### v26 
I call heaven and earth to witness against you today, that you will soon utterly perish from off the land which you go over the Jordan to possess it. You will not prolong your days on it, but will utterly be destroyed. 

###### v27 
Yahweh will scatter you among the peoples, and you will be left few in number among the nations where Yahweh will lead you away. 

###### v28 
There you will serve gods, the work of men's hands, wood and stone, which neither see, nor hear, nor eat, nor smell. 

###### v29 
But from there you shall seek Yahweh your God, and you will find him when you search after him with all your heart and with all your soul. 

###### v30 
When you are in oppression, and all these things have come on you, in the latter days you shall return to Yahweh your God and listen to his voice. 

###### v31 
For Yahweh your God is a merciful God. He will not fail you nor destroy you, nor forget the covenant of your fathers which he swore to them. 

###### v32 
For ask now of the days that are past, which were before you, since the day that God created man on the earth, and from the one end of the sky to the other, whether there has been anything as great as this thing is, or has been heard like it? 

###### v33 
Did a people ever hear the voice of God speaking out of the middle of the fire, as you have heard, and live? 

###### v34 
Or has God tried to go and take a nation for himself from among another nation, by trials, by signs, by wonders, by war, by a mighty hand, by an outstretched arm, and by great terrors, according to all that Yahweh your God did for you in Egypt before your eyes? 

###### v35 
It was shown to you so that you might know that Yahweh is God. There is no one else besides him. 

###### v36 
Out of heaven he made you to hear his voice, that he might instruct you. On earth he made you to see his great fire; and you heard his words out of the middle of the fire. 

###### v37 
Because he loved your fathers, therefore he chose their offspring after them, and brought you out with his presence, with his great power, out of Egypt; 

###### v38 
to drive out nations from before you greater and mightier than you, to bring you in, to give you their land for an inheritance, as it is today. 

###### v39 
Know therefore today, and take it to heart, that Yahweh himself is God in heaven above and on the earth beneath. There is no one else. 

###### v40 
You shall keep his statutes and his commandments which I command you today, that it may go well with you and with your children after you, and that you may prolong your days in the land which Yahweh your God gives you for all time. 

###### v41 
Then Moses set apart three cities beyond the Jordan toward the sunrise, 

###### v42 
that the man slayer might flee there, who kills his neighbor unintentionally and didn't hate him in time past, and that fleeing to one of these cities he might live: 

###### v43 
Bezer in the wilderness, in the plain country, for the Reubenites; and Ramoth in Gilead for the Gadites; and Golan in Bashan for the Manassites. 

###### v44 
This is the law which Moses set before the children of Israel. 

###### v45 
These are the testimonies, and the statutes, and the ordinances which Moses spoke to the children of Israel when they came out of Egypt, 

###### v46 
beyond the Jordan, in the valley opposite Beth Peor, in the land of Sihon king of the Amorites, who lived at Heshbon, whom Moses and the children of Israel struck when they came out of Egypt. 

###### v47 
They took possession of his land and the land of Og king of Bashan, the two kings of the Amorites, who were beyond the Jordan toward the sunrise; 

###### v48 
from Aroer, which is on the edge of the valley of the Arnon, even to Mount Sion (also called Hermon), 

###### v49 
and all the Arabah beyond the Jordan eastward, even to the sea of the Arabah, under the slopes of Pisgah.

***
[[Deut-03|← Deuteronomy 03]] | [[Deuteronomy]] | [[Deut-05|Deuteronomy 05 →]]
