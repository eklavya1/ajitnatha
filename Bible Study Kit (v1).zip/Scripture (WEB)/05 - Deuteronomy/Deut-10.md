# Deuteronomy 10

[[Deut-09|← Deuteronomy 09]] | [[Deuteronomy]] | [[Deut-11|Deuteronomy 11 →]]
***



###### v1 
At that time Yahweh said to me, "Cut two stone tablets like the first, and come up to me onto the mountain, and make an ark of wood. 

###### v2 
I will write on the tablets the words that were on the first tablets which you broke, and you shall put them in the ark." 

###### v3 
So I made an ark of acacia wood, and cut two stone tablets like the first, and went up onto the mountain, having the two tablets in my hand. 

###### v4 
He wrote on the tablets, according to the first writing, the ten commandments, which Yahweh spoke to you on the mountain out of the middle of the fire in the day of the assembly; and Yahweh gave them to me. 

###### v5 
I turned and came down from the mountain, and put the tablets in the ark which I had made; and there they are as Yahweh commanded me. 

###### v6 
(The children of Israel traveled from Beeroth Bene Jaakan to Moserah. There Aaron died, and there he was buried; and Eleazar his son ministered in the priest's office in his place. 

###### v7 
From there they traveled to Gudgodah; and from Gudgodah to Jotbathah, a land of brooks of water. 

###### v8 
At that time Yahweh set apart the tribe of Levi to bear the ark of Yahweh's covenant, to stand before Yahweh to minister to him, and to bless in his name, to this day. 

###### v9 
Therefore Levi has no portion nor inheritance with his brothers; Yahweh is his inheritance, according as Yahweh your God spoke to him.) 

###### v10 
I stayed on the mountain, as at the first time, forty days and forty nights; and Yahweh listened to me that time also. Yahweh would not destroy you. 

###### v11 
Yahweh said to me, "Arise, take your journey before the people; and they shall go in and possess the land which I swore to their fathers to give to them." 

###### v12 
Now, Israel, what does Yahweh your God require of you, but to fear Yahweh your God, to walk in all his ways, to love him, and to serve Yahweh your God with all your heart and with all your soul, 

###### v13 
to keep Yahweh's commandments and statutes, which I command you today for your good? 

###### v14 
Behold, to Yahweh your God belongs heaven, the heaven of heavens, and the earth, with all that is therein. 

###### v15 
Only Yahweh had a delight in your fathers to love them, and he chose their offspring after them, even you above all peoples, as it is today. 

###### v16 
Circumcise therefore the foreskin of your heart, and be no more stiff-necked. 

###### v17 
For Yahweh your God, he is God of gods and Lord of lords, the great God, the mighty, and the awesome, who doesn't respect persons or take bribes. 

###### v18 
He executes justice for the fatherless and widow and loves the foreigner in giving him food and clothing. 

###### v19 
Therefore love the foreigner, for you were foreigners in the land of Egypt. 

###### v20 
You shall fear Yahweh your God. You shall serve him. You shall cling to him, and you shall swear by his name. 

###### v21 
He is your praise, and he is your God, who has done for you these great and awesome things which your eyes have seen. 

###### v22 
Your fathers went down into Egypt with seventy persons; and now Yahweh your God has made you as the stars of the sky for multitude.

***
[[Deut-09|← Deuteronomy 09]] | [[Deuteronomy]] | [[Deut-11|Deuteronomy 11 →]]
