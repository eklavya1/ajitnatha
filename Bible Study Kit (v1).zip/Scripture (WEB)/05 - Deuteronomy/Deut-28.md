# Deuteronomy 28

[[Deut-27|← Deuteronomy 27]] | [[Deuteronomy]] | [[Deut-29|Deuteronomy 29 →]]
***



###### v1 
It shall happen, if you shall listen diligently to Yahweh your God's voice, to observe to do all his commandments which I command you today, that Yahweh your God will set you high above all the nations of the earth. 

###### v2 
All these blessings will come upon you, and overtake you, if you listen to Yahweh your God's voice. 

###### v3 
You shall be blessed in the city, and you shall be blessed in the field. 

###### v4 
You shall be blessed in the fruit of your body, the fruit of your ground, the fruit of your animals, the increase of your livestock, and the young of your flock. 

###### v5 
Your basket and your kneading trough shall be blessed. 

###### v6 
You shall be blessed when you come in, and you shall be blessed when you go out. 

###### v7 
Yahweh will cause your enemies who rise up against you to be struck before you. They will come out against you one way, and will flee before you seven ways. 

###### v8 
Yahweh will command the blessing on you in your barns, and in all that you put your hand to. He will bless you in the land which Yahweh your God gives you. 

###### v9 
Yahweh will establish you for a holy people to himself, as he has sworn to you, if you shall keep the commandments of Yahweh your God, and walk in his ways. 

###### v10 
All the peoples of the earth shall see that you are called by Yahweh's name, and they will be afraid of you. 

###### v11 
Yahweh will grant you abundant prosperity in the fruit of your body, in the fruit of your livestock, and in the fruit of your ground, in the land which Yahweh swore to your fathers to give you. 

###### v12 
Yahweh will open to you his good treasure in the sky, to give the rain of your land in its season, and to bless all the work of your hand. You will lend to many nations, and you will not borrow. 

###### v13 
Yahweh will make you the head, and not the tail. You will be above only, and you will not be beneath, if you listen to the commandments of Yahweh your God which I command you today, to observe and to do, 

###### v14 
and shall not turn away from any of the words which I command you today, to the right hand or to the left, to go after other gods to serve them. 

###### v15 
But it shall come to pass, if you will not listen to Yahweh your God's voice, to observe to do all his commandments and his statutes which I command you today, that all these curses will come on you and overtake you. 

###### v16 
You will be cursed in the city, and you will be cursed in the field. 

###### v17 
Your basket and your kneading trough will be cursed. 

###### v18 
The fruit of your body, the fruit of your ground, the increase of your livestock, and the young of your flock will be cursed. 

###### v19 
You will be cursed when you come in, and you will be cursed when you go out. 

###### v20 
Yahweh will send on you cursing, confusion, and rebuke in all that you put your hand to do, until you are destroyed and until you perish quickly, because of the evil of your doings, by which you have forsaken me. 

###### v21 
Yahweh will make the pestilence cling to you, until he has consumed you from off the land where you go in to possess it. 

###### v22 
Yahweh will strike you with consumption, with fever, with inflammation, with fiery heat, with the sword, with blight, and with mildew. They will pursue you until you perish. 

###### v23 
Your sky that is over your head will be bronze, and the earth that is under you will be iron. 

###### v24 
Yahweh will make the rain of your land powder and dust. It will come down on you from the sky, until you are destroyed. 

###### v25 
Yahweh will cause you to be struck before your enemies. You will go out one way against them, and will flee seven ways before them. You will be tossed back and forth among all the kingdoms of the earth. 

###### v26 
Your dead bodies will be food to all birds of the sky, and to the animals of the earth; and there will be no one to frighten them away. 

###### v27 
Yahweh will strike you with the boils of Egypt, with the tumors, with the scurvy, and with the itch, of which you can not be healed. 

###### v28 
Yahweh will strike you with madness, with blindness, and with astonishment of heart. 

###### v29 
You will grope at noonday, as the blind gropes in darkness, and you shall not prosper in your ways. You will only be oppressed and robbed always, and there will be no one to save you. 

###### v30 
You will betroth a wife, and another man shall lie with her. You will build a house, and you won't dwell in it. You will plant a vineyard, and not use its fruit. 

###### v31 
Your ox will be slain before your eyes, and you will not eat any of it. Your donkey will be violently taken away from before your face, and will not be restored to you. Your sheep will be given to your enemies, and you will have no one to save you. 

###### v32 
Your sons and your daughters will be given to another people. Your eyes will look, and fail with longing for them all day long. There will be no power in your hand. 

###### v33 
A nation which you don't know will eat the fruit of your ground and all of your work. You will only be oppressed and crushed always, 

###### v34 
so that the sights that you see with your eyes will drive you mad. 

###### v35 
Yahweh will strike you in the knees and in the legs with a sore boil, of which you cannot be healed, from the sole of your foot to the crown of your head. 

###### v36 
Yahweh will bring you, and your king whom you will set over yourselves, to a nation that you have not known, you nor your fathers. There you will serve other gods of wood and stone. 

###### v37 
You will become an astonishment, a proverb, and a byword among all the peoples where Yahweh will lead you away. 

###### v38 
You will carry much seed out into the field, and will gather little in, for the locust will consume it. 

###### v39 
You will plant vineyards and dress them, but you will neither drink of the wine, nor harvest, because worms will eat them. 

###### v40 
You will have olive trees throughout all your borders, but you won't anoint yourself with the oil, for your olives will drop off. 

###### v41 
You will father sons and daughters, but they will not be yours, for they will go into captivity. 

###### v42 
Locusts will consume all of your trees and the fruit of your ground. 

###### v43 
The foreigner who is among you will mount up above you higher and higher, and you will come down lower and lower. 

###### v44 
He will lend to you, and you won't lend to him. He will be the head, and you will be the tail. 

###### v45 
All these curses will come on you, and will pursue you and overtake you, until you are destroyed, because you didn't listen to Yahweh your God's voice, to keep his commandments and his statutes which he commanded you. 

###### v46 
They will be for a sign and for a wonder to you and to your offspring forever. 

###### v47 
Because you didn't serve Yahweh your God with joyfulness and with gladness of heart, by reason of the abundance of all things; 

###### v48 
therefore you will serve your enemies whom Yahweh sends against you, in hunger, in thirst, in nakedness, and in lack of all things. He will put an iron yoke on your neck until he has destroyed you. 

###### v49 
Yahweh will bring a nation against you from far, from the end of the earth, as the eagle flies: a nation whose language you will not understand, 

###### v50 
a nation of fierce facial expressions, that doesn't respect the elderly, nor show favor to the young. 

###### v51 
They will eat the fruit of your livestock and the fruit of your ground, until you are destroyed. They also won't leave you grain, new wine, oil, the increase of your livestock, or the young of your flock, until they have caused you to perish. 

###### v52 
They will besiege you in all your gates until your high and fortified walls in which you trusted come down throughout all your land. They will besiege you in all your gates throughout all your land which Yahweh your God has given you. 

###### v53 
You will eat the fruit of your own body, the flesh of your sons and of your daughters, whom Yahweh your God has given you, in the siege and in the distress with which your enemies will distress you. 

###### v54 
The man who is tender among you, and very delicate, his eye will be evil toward his brother, toward the wife whom he loves, and toward the remnant of his children whom he has remaining, 

###### v55 
so that he will not give to any of them of the flesh of his children whom he will eat, because he has nothing left to him, in the siege and in the distress with which your enemy will distress you in all your gates. 

###### v56 
The tender and delicate woman among you, who would not venture to set the sole of her foot on the ground for delicateness and tenderness, her eye will be evil toward the husband that she loves, toward her son, toward her daughter, 

###### v57 
toward her young one who comes out from between her feet, and toward her children whom she bears; for she will eat them secretly for lack of all things in the siege and in the distress with which your enemy will distress you in your gates. 

###### v58 
If you will not observe to do all the words of this law that are written in this book, that you may fear this glorious and fearful name, YAHWEH your God, 

###### v59 
then Yahweh will make your plagues and the plagues of your offspring fearful, even great plagues, and of long duration, and severe sicknesses, and of long duration. 

###### v60 
He will bring on you again all the diseases of Egypt, which you were afraid of; and they will cling to you. 

###### v61 
Also every sickness and every plague which is not written in the book of this law, Yahweh will bring them on you until you are destroyed. 

###### v62 
You will be left few in number, even though you were as the stars of the sky for multitude, because you didn't listen to Yahweh your God's voice. 

###### v63 
It will happen that as Yahweh rejoiced over you to do you good, and to multiply you, so Yahweh will rejoice over you to cause you to perish and to destroy you. You will be plucked from the land that you are going in to possess. 

###### v64 
Yahweh will scatter you among all peoples, from one end of the earth to the other end of the earth. There you will serve other gods which you have not known, you nor your fathers, even wood and stone. 

###### v65 
Among these nations you will find no ease, and there will be no rest for the sole of your foot; but Yahweh will give you there a trembling heart, failing of eyes, and pining of soul. 

###### v66 
Your life will hang in doubt before you. You will be afraid night and day, and will have no assurance of your life. 

###### v67 
In the morning you will say, "I wish it were evening!" and at evening you will say, "I wish it were morning!" for the fear of your heart which you will fear, and for the sights which your eyes will see. 

###### v68 
Yahweh will bring you into Egypt again with ships, by the way of which I told to you that you would never see it again. There you will offer yourselves to your enemies for male and female slaves, and nobody will buy you.

***
[[Deut-27|← Deuteronomy 27]] | [[Deuteronomy]] | [[Deut-29|Deuteronomy 29 →]]
