# Zephaniah 3

[[Zeph-02|← Zephaniah 02]] | [[Zephaniah]]
***



###### v1 
Woe to her who is rebellious and polluted, the oppressing city! 

###### v2 
She didn't obey the voice. She didn't receive correction. She didn't trust in Yahweh. She didn't draw near to her God. 

###### v3 
Her princes within her are roaring lions. Her judges are evening wolves. They leave nothing until the next day. 

###### v4 
Her prophets are arrogant and treacherous people. Her priests have profaned the sanctuary. They have done violence to the law. 

###### v5 
Yahweh, within her, is righteous. He will do no wrong. Every morning he brings his justice to light. He doesn't fail, but the unjust know no shame. 

###### v6 
I have cut off nations. Their battlements are desolate. I have made their streets waste, so that no one passes by. Their cities are destroyed, so that there is no man, so that there is no inhabitant. 

###### v7 
I said, "Just fear me. Receive correction, so that her dwelling won't be cut off, according to all that I have appointed concerning her." But they rose early and corrupted all their doings. 

###### v8 
"Therefore wait for me", says Yahweh, "until the day that I rise up to the prey, for my determination is to gather the nations, that I may assemble the kingdoms, to pour on them my indignation, even all my fierce anger, for all the earth will be devoured with the fire of my jealousy. 

###### v9 
For then I will purify the lips of the peoples, that they may all call on Yahweh's name, to serve him shoulder to shoulder. 

###### v10 
From beyond the rivers of Cush, my worshipers, even the daughter of my dispersed people, will bring my offering. 

###### v11 
In that day you will not be disappointed for all your doings, in which you have transgressed against me; for then I will take away out from among you your proudly exulting ones, and you will no more be arrogant in my holy mountain. 

###### v12 
But I will leave among you an afflicted and poor people, and they will take refuge in Yahweh's name. 

###### v13 
The remnant of Israel will not do iniquity, nor speak lies, neither will a deceitful tongue be found in their mouth, for they will feed and lie down, and no one will make them afraid." 

###### v14 
Sing, daughter of Zion! Shout, Israel! Be glad and rejoice with all your heart, daughter of Jerusalem. 

###### v15 
Yahweh has taken away your judgments. He has thrown out your enemy. The King of Israel, Yahweh, is among you. You will not be afraid of evil any more. 

###### v16 
In that day, it will be said to Jerusalem, "Don't be afraid, Zion. Don't let your hands be weak." 

###### v17 
Yahweh, your God, is among you, a mighty one who will save. He will rejoice over you with joy. He will calm you in his love. He will rejoice over you with singing. 

###### v18 
I will remove those who grieve about the appointed feasts from you. They are a burden and a reproach to you. 

###### v19 
Behold, at that time I will deal with all those who afflict you, and I will save those who are lame, and gather those who were driven away. I will give them praise and honor, whose shame has been in all the earth. 

###### v20 
At that time I will bring you in, and at that time I will gather you; for I will give you honor and praise among all the peoples of the earth, when I restore your fortunes before your eyes, says Yahweh.

***
[[Zeph-02|← Zephaniah 02]] | [[Zephaniah]]
