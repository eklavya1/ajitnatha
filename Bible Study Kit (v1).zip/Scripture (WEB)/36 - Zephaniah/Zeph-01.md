# Zephaniah 1

[[Zephaniah]] | [[Zeph-02|Zephaniah 02 →]]
***



###### v1 
Yahweh's word which came to Zephaniah, the son of Cushi, the son of Gedaliah, the son of Amariah, the son of Hezekiah, in the days of Josiah, the son of Amon, king of Judah. 

###### v2 
I will utterly sweep away everything from the surface of the earth, says Yahweh. 

###### v3 
I will sweep away man and animal. I will sweep away the birds of the sky, the fish of the sea, and the heaps of rubble with the wicked. I will cut off man from the surface of the earth, says Yahweh. 

###### v4 
I will stretch out my hand against Judah, and against all the inhabitants of Jerusalem. I will cut off the remnant of Baal from this place: the name of the idolatrous and pagan priests, 

###### v5 
those who worship the army of the sky on the housetops, those who worship and swear by Yahweh and also swear by Malcam, 

###### v6 
those who have turned back from following Yahweh, and those who haven't sought Yahweh nor inquired after him. 

###### v7 
Be silent at the presence of the Lord Yahweh, for the day of Yahweh is at hand. For Yahweh has prepared a sacrifice. He has consecrated his guests. 

###### v8 
It will happen in the day of Yahweh's sacrifice, that I will punish the princes, the king's sons, and all those who are clothed with foreign clothing. 

###### v9 
In that day, I will punish all those who leap over the threshold, who fill their master's house with violence and deceit. 

###### v10 
In that day, says Yahweh, there will be the noise of a cry from the fish gate, a wailing from the second quarter, and a great crashing from the hills. 

###### v11 
Wail, you inhabitants of Maktesh, for all the people of Canaan are undone! All those who were loaded with silver are cut off. 

###### v12 
It will happen at that time, that I will search Jerusalem with lamps, and I will punish the men who are settled on their dregs, who say in their heart, "Yahweh will not do good, neither will he do evil." 

###### v13 
Their wealth will become a plunder, and their houses a desolation. Yes, they will build houses, but won't inhabit them. They will plant vineyards, but won't drink their wine. 

###### v14 
The great day of Yahweh is near. It is near, and hurries greatly, the voice of the day of Yahweh. The mighty man cries there bitterly. 

###### v15 
That day is a day of wrath, a day of distress and anguish, a day of trouble and ruin, a day of darkness and gloom, a day of clouds and blackness, 

###### v16 
a day of the trumpet and alarm, against the fortified cities, and against the high battlements. 

###### v17 
I will bring distress on men, that they will walk like blind men, because they have sinned against Yahweh, and their blood will be poured out like dust, and their flesh like dung. 

###### v18 
Neither their silver nor their gold will be able to deliver them in the day of Yahweh's wrath, but the whole land will be devoured by the fire of his jealousy; for he will make an end, yes, a terrible end, of all those who dwell in the land.

***
[[Zephaniah]] | [[Zeph-02|Zephaniah 02 →]]
