# Zephaniah 2

[[Zeph-01|← Zephaniah 01]] | [[Zephaniah]] | [[Zeph-03|Zephaniah 03 →]]
***



###### v1 
Gather yourselves together, yes, gather together, you nation that has no shame, 

###### v2 
before the appointed time when the day passes as the chaff, before the fierce anger of Yahweh comes on you, before the day of Yahweh's anger comes on you. 

###### v3 
Seek Yahweh, all you humble of the land, who have kept his ordinances. Seek righteousness. Seek humility. It may be that you will be hidden in the day of Yahweh's anger. 

###### v4 
For Gaza will be forsaken, and Ashkelon a desolation. They will drive out Ashdod at noonday, and Ekron will be rooted up. 

###### v5 
Woe to the inhabitants of the sea coast, the nation of the Cherethites! Yahweh's word is against you, Canaan, the land of the Philistines. I will destroy you, that there will be no inhabitant. 

###### v6 
The sea coast will be pastures, with cottages for shepherds and folds for flocks. 

###### v7 
The coast will be for the remnant of the house of Judah. They will find pasture. In the houses of Ashkelon, they will lie down in the evening, for Yahweh, their God, will visit them, and restore them. 

###### v8 
I have heard the reproach of Moab, and the insults of the children of Ammon, with which they have reproached my people, and magnified themselves against their border. 

###### v9 
Therefore as I live, says Yahweh of Armies, the God of Israel, surely Moab will be as Sodom, and the children of Ammon as Gomorrah, a possession of nettles, and salt pits, and a perpetual desolation. The remnant of my people will plunder them, and the survivors of my nation will inherit them. 

###### v10 
This they will have for their pride, because they have reproached and magnified themselves against the people of Yahweh of Armies. 

###### v11 
Yahweh will be awesome to them, for he will famish all the gods of the land. Men will worship him, everyone from his place, even all the shores of the nations. 

###### v12 
You Cushites also, you will be killed by my sword. 

###### v13 
He will stretch out his hand against the north, destroy Assyria, and will make Nineveh a desolation, as dry as the wilderness. 

###### v14 
Herds will lie down in the middle of her, all the animals of the nations. Both the pelican and the porcupine will lodge in its capitals. Their calls will echo through the windows. Desolation will be in the thresholds, for he has laid bare the cedar beams. 

###### v15 
This is the joyous city that lived carelessly, that said in her heart, "I am, and there is no one besides me." How she has become a desolation, a place for animals to lie down in! Everyone who passes by her will hiss, and shake their fists.

***
[[Zeph-01|← Zephaniah 01]] | [[Zephaniah]] | [[Zeph-03|Zephaniah 03 →]]
