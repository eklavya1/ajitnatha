# James 5

[[James-04|← James 04]] | [[James]]
***



###### v1 
Come now, you rich, weep and howl for your miseries that are coming on you. 

###### v2 
Your riches are corrupted and your garments are moth-eaten. 

###### v3 
Your gold and your silver are corroded, and their corrosion will be for a testimony against you and will eat your flesh like fire. You have laid up your treasure in the last days. 

###### v4 
Behold, the wages of the laborers who mowed your fields, which you have kept back by fraud, cry out, and the cries of those who reaped have entered into the ears of the Lord of Armies. 

###### v5 
You have lived in luxury on the earth, and taken your pleasure. You have nourished your hearts as in a day of slaughter. 

###### v6 
You have condemned and you have murdered the righteous one. He doesn't resist you. 

###### v7 
Be patient therefore, brothers, until the coming of the Lord. Behold, the farmer waits for the precious fruit of the earth, being patient over it, until it receives the early and late rain. 

###### v8 
You also be patient. Establish your hearts, for the coming of the Lord is at hand. 

###### v9 
Don't grumble, brothers, against one another, so that you won't be judged. Behold, the judge stands at the door. 

###### v10 
Take, brothers, for an example of suffering and of perseverance, the prophets who spoke in the name of the Lord. 

###### v11 
Behold, we call them blessed who endured. You have heard of the perseverance of Job, and have seen the Lord in the outcome, and how the Lord is full of compassion and mercy. 

###### v12 
But above all things, my brothers, don't swear-- not by heaven, or by the earth, or by any other oath; but let your "yes" be "yes", and your "no", "no", so that you don't fall into hypocrisy. 

###### v13 
Is any among you suffering? Let him pray. Is any cheerful? Let him sing praises. 

###### v14 
Is any among you sick? Let him call for the elders of the assembly, and let them pray over him, anointing him with oil in the name of the Lord, 

###### v15 
and the prayer of faith will heal him who is sick, and the Lord will raise him up. If he has committed sins, he will be forgiven. 

###### v16 
Confess your offenses to one another, and pray for one another, that you may be healed. The insistent prayer of a righteous person is powerfully effective. 

###### v17 
Elijah was a man with a nature like ours, and he prayed earnestly that it might not rain, and it didn't rain on the earth for three years and six months. 

###### v18 
He prayed again, and the sky gave rain, and the earth produced its fruit. 

###### v19 
Brothers, if any among you wanders from the truth and someone turns him back, 

###### v20 
let him know that he who turns a sinner from the error of his way will save a soul from death and will cover a multitude of sins.

***
[[James-04|← James 04]] | [[James]]
