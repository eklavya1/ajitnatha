# James 1

[[James]] | [[James-02|James 02 →]]
***



###### v1 
James, a servant of God and of the Lord Jesus Christ, to the twelve tribes which are in the Dispersion: Greetings. 

###### v2 
Count it all joy, my brothers, when you fall into various temptations, 

###### v3 
knowing that the testing of your faith produces endurance. 

###### v4 
Let endurance have its perfect work, that you may be perfect and complete, lacking in nothing. 

###### v5 
But if any of you lacks wisdom, let him ask of God, who gives to all liberally and without reproach, and it will be given to him. 

###### v6 
But let him ask in faith, without any doubting, for he who doubts is like a wave of the sea, driven by the wind and tossed. 

###### v7 
For that man shouldn't think that he will receive anything from the Lord. 

###### v8 
He is a double-minded man, unstable in all his ways. 

###### v9 
But let the brother in humble circumstances glory in his high position; 

###### v10 
and the rich, in that he is made humble, because like the flower in the grass, he will pass away. 

###### v11 
For the sun arises with the scorching wind and withers the grass, and the flower in it falls, and the beauty of its appearance perishes. So the rich man will also fade away in his pursuits. 

###### v12 
Blessed is a person who endures temptation, for when he has been approved, he will receive the crown of life, which the Lord promised to those who love him. 

###### v13 
Let no man say when he is tempted, "I am tempted by God," for God can't be tempted by evil, and he himself tempts no one. 

###### v14 
But each one is tempted when he is drawn away by his own lust and enticed. 

###### v15 
Then the lust, when it has conceived, bears sin. The sin, when it is full grown, produces death. 

###### v16 
Don't be deceived, my beloved brothers. 

###### v17 
Every good gift and every perfect gift is from above, coming down from the Father of lights, with whom can be no variation, nor turning shadow. 

###### v18 
Of his own will he gave birth to us by the word of truth, that we should be a kind of first fruits of his creatures. 

###### v19 
So, then, my beloved brothers, let every man be swift to hear, slow to speak, and slow to anger; 

###### v20 
for the anger of man doesn't produce the righteousness of God. 

###### v21 
Therefore, putting away all filthiness and overflowing of wickedness, receive with humility the implanted word, which is able to save your souls. 

###### v22 
But be doers of the word, and not only hearers, deluding your own selves. 

###### v23 
For if anyone is a hearer of the word and not a doer, he is like a man looking at his natural face in a mirror; 

###### v24 
for he sees himself, and goes away, and immediately forgets what kind of man he was. 

###### v25 
But he who looks into the perfect law of freedom and continues, not being a hearer who forgets, but a doer of the work, this man will be blessed in what he does. 

###### v26 
If anyone among you thinks himself to be religious while he doesn't bridle his tongue, but deceives his heart, this man's religion is worthless. 

###### v27 
Pure religion and undefiled before our God and Father is this: to visit the fatherless and widows in their affliction, and to keep oneself unstained by the world.

***
[[James]] | [[James-02|James 02 →]]
