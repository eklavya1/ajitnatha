# James 2

[[James-01|← James 01]] | [[James]] | [[James-03|James 03 →]]
***



###### v1 
My brothers, don't hold the faith of our Lord Jesus Christ of glory with partiality. 

###### v2 
For if a man with a gold ring, in fine clothing, comes into your synagogue, and a poor man in filthy clothing also comes in, 

###### v3 
and you pay special attention to him who wears the fine clothing and say, "Sit here in a good place;" and you tell the poor man, "Stand there," or "Sit by my footstool" 

###### v4 
haven't you shown partiality among yourselves, and become judges with evil thoughts? 

###### v5 
Listen, my beloved brothers. Didn't God choose those who are poor in this world to be rich in faith, and heirs of the Kingdom which he promised to those who love him? 

###### v6 
But you have dishonored the poor man. Don't the rich oppress you, and personally drag you before the courts? 

###### v7 
Don't they blaspheme the honorable name by which you are called? 

###### v8 
However, if you fulfill the royal law according to the Scripture, "You shall love your neighbor as yourself," you do well. 

###### v9 
But if you show partiality, you commit sin, being convicted by the law as transgressors. 

###### v10 
For whoever keeps the whole law, and yet stumbles in one point, he has become guilty of all. 

###### v11 
For he who said, "Do not commit adultery," Now if you do not commit adultery, but murder, you have become a transgressor of the law. 

###### v12 
So speak and so do, as men who are to be judged by a law of freedom. 

###### v13 
For judgment is without mercy to him who has shown no mercy. Mercy triumphs over judgment. 

###### v14 
What good is it, my brothers, if a man says he has faith, but has no works? Can faith save him? 

###### v15 
And if a brother or sister is naked and in lack of daily food, 

###### v16 
and one of you tells them, "Go in peace. Be warmed and filled;" yet you didn't give them the things the body needs, what good is it? 

###### v17 
Even so faith, if it has no works, is dead in itself. 

###### v18 
Yes, a man will say, "You have faith, and I have works." Show me your faith without works, and I will show you my faith by my works. 

###### v19 
You believe that God is one. You do well. The demons also believe, and shudder. 

###### v20 
But do you want to know, vain man, that faith apart from works is dead? 

###### v21 
Wasn't Abraham our father justified by works, in that he offered up Isaac his son on the altar? 

###### v22 
You see that faith worked with his works, and by works faith was perfected. 

###### v23 
So the Scripture was fulfilled which says, "Abraham believed God, and it was accounted to him as righteousness," and he was called the friend of God. 

###### v24 
You see then that by works, a man is justified, and not only by faith. 

###### v25 
In the same way, wasn't Rahab the prostitute also justified by works, in that she received the messengers and sent them out another way? 

###### v26 
For as the body apart from the spirit is dead, even so faith apart from works is dead.

***
[[James-01|← James 01]] | [[James]] | [[James-03|James 03 →]]
