# James 3

[[James-02|← James 02]] | [[James]] | [[James-04|James 04 →]]
***



###### v1 
Let not many of you be teachers, my brothers, knowing that we will receive heavier judgment. 

###### v2 
For we all stumble in many things. Anyone who doesn't stumble in word is a perfect person, able to bridle the whole body also. 

###### v3 
Indeed, we put bits into the horses' mouths so that they may obey us, and we guide their whole body. 

###### v4 
Behold, the ships also, though they are so big and are driven by fierce winds, are yet guided by a very small rudder, wherever the pilot desires. 

###### v5 
So the tongue is also a little member, and boasts great things. See how a small fire can spread to a large forest! 

###### v6 
And the tongue is a fire. The world of iniquity among our members is the tongue, which defiles the whole body, and sets on fire the course of nature, and is set on fire by Gehenna. 

###### v7 
For every kind of animal, bird, creeping thing, and sea creature, is tamed, and has been tamed by mankind; 

###### v8 
but nobody can tame the tongue. It is a restless evil, full of deadly poison. 

###### v9 
With it we bless our God and Father, and with it we curse men who are made in the image of God. 

###### v10 
Out of the same mouth comes blessing and cursing. My brothers, these things ought not to be so. 

###### v11 
Does a spring send out from the same opening fresh and bitter water? 

###### v12 
Can a fig tree, my brothers, yield olives, or a vine figs? Thus no spring yields both salt water and fresh water. 

###### v13 
Who is wise and understanding among you? Let him show by his good conduct that his deeds are done in gentleness of wisdom. 

###### v14 
But if you have bitter jealousy and selfish ambition in your heart, don't boast and don't lie against the truth. 

###### v15 
This wisdom is not that which comes down from above, but is earthly, sensual, and demonic. 

###### v16 
For where jealousy and selfish ambition are, there is confusion and every evil deed. 

###### v17 
But the wisdom that is from above is first pure, then peaceful, gentle, reasonable, full of mercy and good fruits, without partiality, and without hypocrisy. 

###### v18 
Now the fruit of righteousness is sown in peace by those who make peace.

***
[[James-02|← James 02]] | [[James]] | [[James-04|James 04 →]]
