# James 4

[[James-03|← James 03]] | [[James]] | [[James-05|James 05 →]]
***



###### v1 
Where do wars and fightings among you come from? Don't they come from your pleasures that war in your members? 

###### v2 
You lust, and don't have. You murder and covet, and can't obtain. You fight and make war. You don't have, because you don't ask. 

###### v3 
You ask, and don't receive, because you ask with wrong motives, so that you may spend it on your pleasures. 

###### v4 
You adulterers and adulteresses, don't you know that friendship with the world is hostility toward God? Whoever therefore wants to be a friend of the world makes himself an enemy of God. 

###### v5 
Or do you think that the Scripture says in vain, "The Spirit who lives in us yearns jealously"? 

###### v6 
But he gives more grace. Therefore it says, "God resists the proud, but gives grace to the humble." 

###### v7 
Be subject therefore to God. Resist the devil, and he will flee from you. 

###### v8 
Draw near to God, and he will draw near to you. Cleanse your hands, you sinners. Purify your hearts, you double-minded. 

###### v9 
Lament, mourn, and weep. Let your laughter be turned to mourning, and your joy to gloom. 

###### v10 
Humble yourselves in the sight of the Lord, and he will exalt you. 

###### v11 
Don't speak against one another, brothers. He who speaks against a brother and judges his brother, speaks against the law and judges the law. But if you judge the law, you are not a doer of the law, but a judge. 

###### v12 
Only one is the lawgiver, who is able to save and to destroy. But who are you to judge another? 

###### v13 
Come now, you who say, "Today or tomorrow let's go into this city, and spend a year there, trade, and make a profit." 

###### v14 
Whereas you don't know what your life will be like tomorrow. For what is your life? For you are a vapor that appears for a little time, and then vanishes away. 

###### v15 
For you ought to say, "If the Lord wills, we will both live, and do this or that." 

###### v16 
But now you glory in your boasting. All such boasting is evil. 

###### v17 
To him therefore who knows to do good, and doesn't do it, to him it is sin.

***
[[James-03|← James 03]] | [[James]] | [[James-05|James 05 →]]
