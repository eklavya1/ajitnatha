# 2 Chronicles 25

[[2 Chron-24|← 2 Chronicles 24]] | [[2 Chronicles]] | [[2 Chron-26|2 Chronicles 26 →]]
***



###### v1 
Amaziah was twenty-five years old when he began to reign, and he reigned twenty-nine years in Jerusalem. His mother's name was Jehoaddan, of Jerusalem. 

###### v2 
He did that which was right in Yahweh's eyes, but not with a perfect heart. 

###### v3 
Now when the kingdom was established to him, he killed his servants who had killed his father the king. 

###### v4 
But he didn't put their children to death, but did according to that which is written in the law in the book of Moses, as Yahweh commanded, saying, "The fathers shall not die for the children, neither shall the children die for the fathers; but every man shall die for his own sin." 

###### v5 
Moreover Amaziah gathered Judah together, and ordered them according to their fathers' houses, under captains of thousands and captains of hundreds, even all Judah and Benjamin. He counted them from twenty years old and upward, and found that there were three hundred thousand chosen men, able to go out to war, who could handle spear and shield. 

###### v6 
He also hired one hundred thousand mighty men of valor out of Israel for one hundred talents of silver. 

###### v7 
A man of God came to him, saying, "O king, don't let the army of Israel go with you, for Yahweh is not with Israel, with all the children of Ephraim. 

###### v8 
But if you will go, take action, and be strong for the battle. God will overthrow you before the enemy; for God has power to help, and to overthrow." 

###### v9 
Amaziah said to the man of God, "But what shall we do for the hundred talents which I have given to the army of Israel?" The man of God answered, "Yahweh is able to give you much more than this." 

###### v10 
Then Amaziah separated them, the army that had come to him out of Ephraim, to go home again. Therefore their anger was greatly kindled against Judah, and they returned home in fierce anger. 

###### v11 
Amaziah took courage, and led his people out, and went to the Valley of Salt, and struck ten thousand of the children of Seir. 

###### v12 
The children of Judah carried away ten thousand alive, and brought them to the top of the rock, and threw them down from the top of the rock, so that they all were broken in pieces. 

###### v13 
But the men of the army whom Amaziah sent back, that they should not go with him to battle, fell on the cities of Judah, from Samaria even to Beth Horon, and struck of them three thousand, and took much plunder. 

###### v14 
Now after Amaziah had come from the slaughter of the Edomites, he brought the gods of the children of Seir, and set them up to be his gods, and bowed down himself before them, and burned incense to them. 

###### v15 
Therefore Yahweh's anger burned against Amaziah, and he sent to him a prophet, who said to him, "Why have you sought after the gods of the people, which have not delivered their own people out of your hand?" 

###### v16 
As he talked with him, the king said to him, "Have we made you one of the king's counselors? Stop! Why should you be struck down?" Then the prophet stopped, and said, "I know that God has determined to destroy you, because you have done this, and have not listened to my counsel." 

###### v17 
Then Amaziah king of Judah consulted his advisers, and sent to Joash, the son of Jehoahaz the son of Jehu, king of Israel, saying, "Come! Let's look one another in the face." 

###### v18 
Joash king of Israel sent to Amaziah king of Judah, saying, "The thistle that was in Lebanon sent to the cedar that was in Lebanon, saying, 'Give your daughter to my son as his wife. Then a wild animal that was in Lebanon passed by, and trampled down the thistle. 

###### v19 
You say to yourself that you have struck Edom; and your heart lifts you up to boast. Now stay at home. Why should you meddle with trouble, that you should fall, even you, and Judah with you?'" 

###### v20 
But Amaziah would not listen; for it was of God, that he might deliver them into the hand of their enemies, because they had sought after the gods of Edom. 

###### v21 
So Joash king of Israel went up, and he and Amaziah king of Judah looked one another in the face at Beth Shemesh, which belongs to Judah. 

###### v22 
Judah was defeated by Israel; so every man fled to his tent. 

###### v23 
Joash king of Israel took Amaziah king of Judah, the son of Joash the son of Jehoahaz, at Beth Shemesh, and brought him to Jerusalem, and broke down the wall of Jerusalem from the gate of Ephraim to the corner gate, four hundred cubits. 

###### v24 
He took all the gold and silver, and all the vessels that were found in God's house with Obed-Edom, and the treasures of the king's house, the hostages also, and returned to Samaria. 

###### v25 
Amaziah the son of Joash king of Judah lived for fifteen years after the death of Joash son of Jehoahaz king of Israel. 

###### v26 
Now the rest of the acts of Amaziah, first and last, behold, aren't they written in the book of the kings of Judah and Israel? 

###### v27 
Now from the time that Amaziah turned away from following Yahweh, they made a conspiracy against him in Jerusalem. He fled to Lachish, but they sent after him to Lachish, and killed him there. 

###### v28 
They brought him on horses, and buried him with his fathers in the City of Judah.

***
[[2 Chron-24|← 2 Chronicles 24]] | [[2 Chronicles]] | [[2 Chron-26|2 Chronicles 26 →]]
