# 2 Chronicles 29

[[2 Chron-28|← 2 Chronicles 28]] | [[2 Chronicles]] | [[2 Chron-30|2 Chronicles 30 →]]
***



###### v1 
Hezekiah began to reign when he was twenty-five years old, and he reigned twenty-nine years in Jerusalem. His mother's name was Abijah, the daughter of Zechariah. 

###### v2 
He did that which was right in Yahweh's eyes, according to all that David his father had done. 

###### v3 
In the first year of his reign, in the first month, he opened the doors of Yahweh's house, and repaired them. 

###### v4 
He brought in the priests and the Levites, and gathered them together into the wide place on the east, 

###### v5 
and said to them, "Listen to me, you Levites! Now sanctify yourselves, and sanctify the house of Yahweh, the God of your fathers, and carry the filthiness out of the holy place. 

###### v6 
For our fathers were unfaithful, and have done that which was evil in Yahweh our God's sight, and have forsaken him, and have turned away their faces from the habitation of Yahweh, and turned their backs. 

###### v7 
Also they have shut up the doors of the porch, and put out the lamps, and have not burned incense nor offered burnt offerings in the holy place to the God of Israel. 

###### v8 
Therefore Yahweh's wrath was on Judah and Jerusalem, and he has delivered them to be tossed back and forth, to be an astonishment, and a hissing, as you see with your eyes. 

###### v9 
For, behold, our fathers have fallen by the sword, and our sons and our daughters and our wives are in captivity for this. 

###### v10 
Now it is in my heart to make a covenant with Yahweh, the God of Israel, that his fierce anger may turn away from us. 

###### v11 
My sons, don't be negligent now; for Yahweh has chosen you to stand before him, to minister to him, and that you should be his ministers, and burn incense." 

###### v12 
Then the Levites arose, Mahath, the son of Amasai, and Joel the son of Azariah, of the sons of the Kohathites; and of the sons of Merari, Kish the son of Abdi, and Azariah the son of Jehallelel; and of the Gershonites, Joah the son of Zimmah, and Eden the son of Joah; 

###### v13 
and of the sons of Elizaphan, Shimri and Jeuel; and of the sons of Asaph, Zechariah and Mattaniah; 

###### v14 
and of the sons of Heman, Jehuel and Shimei; and of the sons of Jeduthun, Shemaiah and Uzziel. 

###### v15 
They gathered their brothers, sanctified themselves, and went in, according to the commandment of the king by Yahweh's words, to cleanse Yahweh's house. 

###### v16 
The priests went into the inner part of Yahweh's house to cleanse it, and brought out all the uncleanness that they found in Yahweh's temple into the court of Yahweh's house. The Levites took it from there to carry it out to the brook Kidron. 

###### v17 
Now they began on the first day of the first month to sanctify, and on the eighth day of the month they came to Yahweh's porch. They sanctified Yahweh's house in eight days, and on the sixteenth day of the first month they finished. 

###### v18 
Then they went in to Hezekiah the king within the palace, and said, "We have cleansed all Yahweh's house, including the altar of burnt offering with all its vessels, and the table of show bread with all its vessels. 

###### v19 
Moreover, we have prepared and sanctified all the vessels which king Ahaz threw away in his reign, when he was unfaithful. Behold, they are before Yahweh's altar." 

###### v20 
Then Hezekiah the king arose early, gathered the princes of the city, and went up to Yahweh's house. 

###### v21 
They brought seven bulls, seven rams, seven lambs, and seven male goats, for a sin offering for the kingdom, for the sanctuary, and for Judah. He commanded the priests the sons of Aaron to offer them on Yahweh's altar. 

###### v22 
So they killed the bulls, and the priests received the blood, and sprinkled it on the altar. They killed the rams, and sprinkled the blood on the altar. They also killed the lambs, and sprinkled the blood on the altar. 

###### v23 
They brought near the male goats for the sin offering before the king and the assembly; and they laid their hands on them. 

###### v24 
Then the priests killed them, and they made a sin offering with their blood on the altar, to make atonement for all Israel; for the king commanded that the burnt offering and the sin offering should be made for all Israel. 

###### v25 
He set the Levites in Yahweh's house with cymbals, with stringed instruments, and with harps, according to the commandment of David, of Gad the king's seer, and Nathan the prophet; for the commandment was from Yahweh by his prophets. 

###### v26 
The Levites stood with David's instruments, and the priests with the trumpets. 

###### v27 
Hezekiah commanded them to offer the burnt offering on the altar. When the burnt offering began, Yahweh's song also began, along with the trumpets and instruments of David king of Israel. 

###### v28 
All the assembly worshiped, the singers sang, and the trumpeters sounded. All this continued until the burnt offering was finished. 

###### v29 
When they had finished offering, the king and all who were present with him bowed themselves and worshiped. 

###### v30 
Moreover Hezekiah the king and the princes commanded the Levites to sing praises to Yahweh with the words of David, and of Asaph the seer. They sang praises with gladness, and they bowed their heads and worshiped. 

###### v31 
Then Hezekiah answered, "Now you have consecrated yourselves to Yahweh. Come near and bring sacrifices and thank offerings into Yahweh's house." The assembly brought in sacrifices and thank offerings, and as many as were of a willing heart brought burnt offerings. 

###### v32 
The number of the burnt offerings which the assembly brought was seventy bulls, one hundred rams, and two hundred lambs. All these were for a burnt offering to Yahweh. 

###### v33 
The consecrated things were six hundred head of cattle and three thousand sheep. 

###### v34 
But the priests were too few, so that they could not skin all the burnt offerings. Therefore their brothers the Levites helped them, until the work was ended, and until the priests had sanctified themselves; for the Levites were more upright in heart to sanctify themselves than the priests. 

###### v35 
Also the burnt offerings were in abundance, with the fat of the peace offerings, and with the drink offerings for every burnt offering. So the service of Yahweh's house was set in order. 

###### v36 
Hezekiah and all the people rejoiced, because of that which God had prepared for the people; for the thing was done suddenly.

***
[[2 Chron-28|← 2 Chronicles 28]] | [[2 Chronicles]] | [[2 Chron-30|2 Chronicles 30 →]]
