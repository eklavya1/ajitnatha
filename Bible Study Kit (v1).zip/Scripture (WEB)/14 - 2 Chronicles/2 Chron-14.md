# 2 Chronicles 14

[[2 Chron-13|← 2 Chronicles 13]] | [[2 Chronicles]] | [[2 Chron-15|2 Chronicles 15 →]]
***



###### v1 
So Abijah slept with his fathers, and they buried him in David's city; and Asa his son reigned in his place. In his days, the land was quiet ten years. 

###### v2 
Asa did that which was good and right in Yahweh his God's eyes; 

###### v3 
for he took away the foreign altars and the high places, broke down the pillars, cut down the Asherah poles, 

###### v4 
and commanded Judah to seek Yahweh, the God of their fathers, and to obey his law and command. 

###### v5 
Also he took away out of all the cities of Judah the high places and the sun images; and the kingdom was quiet before him. 

###### v6 
He built fortified cities in Judah; for the land was quiet, and he had no war in those years, because Yahweh had given him rest. 

###### v7 
For he said to Judah, "Let's build these cities, and make walls around them, with towers, gates, and bars. The land is yet before us, because we have sought Yahweh our God. We have sought him, and he has given us rest on every side." So they built and prospered. 

###### v8 
Asa had an army of three hundred thousand out of Judah who bore bucklers and spears, and two hundred eighty thousand out of Benjamin who bore shields and drew bows. All these were mighty men of valor. 

###### v9 
Zerah the Ethiopian came out against them with an army of a million troops and three hundred chariots, and he came to Mareshah. 

###### v10 
Then Asa went out to meet him, and they set the battle in array in the valley of Zephathah at Mareshah. 

###### v11 
Asa cried to Yahweh his God, and said, "Yahweh, there is no one besides you to help, between the mighty and him who has no strength. Help us, Yahweh our God; for we rely on you, and in your name are we come against this multitude. Yahweh, you are our God. Don't let man prevail against you." 

###### v12 
So Yahweh struck the Ethiopians before Asa and before Judah; and the Ethiopians fled. 

###### v13 
Asa and the people who were with him pursued them to Gerar: and so many of the Ethiopians fell that they could not recover themselves; for they were destroyed before Yahweh and before his army; and they carried away very much booty. 

###### v14 
They struck all the cities around Gerar; for the fear of Yahweh came on them, and they plundered all the cities; for there was much plunder in them. 

###### v15 
They also struck the tents of livestock, and carried away sheep in abundance, and camels, and returned to Jerusalem.

***
[[2 Chron-13|← 2 Chronicles 13]] | [[2 Chronicles]] | [[2 Chron-15|2 Chronicles 15 →]]
