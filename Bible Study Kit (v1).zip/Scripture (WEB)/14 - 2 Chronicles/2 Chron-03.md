# 2 Chronicles 3

[[2 Chron-02|← 2 Chronicles 02]] | [[2 Chronicles]] | [[2 Chron-04|2 Chronicles 04 →]]
***



###### v1 
Then Solomon began to build Yahweh's house at Jerusalem on Mount Moriah, where Yahweh appeared to David his father, which he prepared in the place that David had appointed, on the threshing floor of Ornan the Jebusite. 

###### v2 
He began to build in the second day of the second month, in the fourth year of his reign. 

###### v3 
Now these are the foundations which Solomon laid for the building of God's house. The length by cubits after the first measure was sixty cubits, and the width twenty cubits. 

###### v4 
The porch that was in front, its length, according to the width of the house, was twenty cubits, and the height one hundred twenty; and he overlaid it within with pure gold. 

###### v5 
He made the larger room with a ceiling of cypress wood, which he overlaid with fine gold, and ornamented it with palm trees and chains. 

###### v6 
He decorated the house with precious stones for beauty. The gold was gold from Parvaim. 

###### v7 
He also overlaid the house, the beams, the thresholds, its walls, and its doors with gold; and engraved cherubim on the walls. 

###### v8 
He made the most holy place. Its length, according to the width of the house, was twenty cubits, and its width twenty cubits; and he overlaid it with fine gold, amounting to six hundred talents. 

###### v9 
The weight of the nails was fifty shekels of gold. He overlaid the upper rooms with gold. 

###### v10 
In the most holy place he made two cherubim by carving; and they overlaid them with gold. 

###### v11 
The wings of the cherubim were twenty cubits long: the wing of the one was five cubits, reaching to the wall of the house; and the other wing was five cubits, reaching to the wing of the other cherub. 

###### v12 
The wing of the other cherub was five cubits, reaching to the wall of the house; and the other wing was five cubits, joining to the wing of the other cherub. 

###### v13 
The wings of these cherubim spread themselves out twenty cubits. They stood on their feet, and their faces were toward the house. 

###### v14 
He made the veil of blue, purple, crimson, and fine linen, and ornamented it with cherubim. 

###### v15 
Also he made before the house two pillars of thirty-five cubits height, and the capital that was on the top of each of them was five cubits. 

###### v16 
He made chains in the inner sanctuary, and put them on the tops of the pillars; and he made one hundred pomegranates, and put them on the chains. 

###### v17 
He set up the pillars before the temple, one on the right hand, and the other on the left; and called the name of that on the right hand Jachin, and the name of that on the left Boaz.

***
[[2 Chron-02|← 2 Chronicles 02]] | [[2 Chronicles]] | [[2 Chron-04|2 Chronicles 04 →]]
