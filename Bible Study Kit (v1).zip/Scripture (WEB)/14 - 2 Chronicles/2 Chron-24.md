# 2 Chronicles 24

[[2 Chron-23|← 2 Chronicles 23]] | [[2 Chronicles]] | [[2 Chron-25|2 Chronicles 25 →]]
***



###### v1 
Joash was seven years old when he began to reign, and he reigned forty years in Jerusalem. His mother's name was Zibiah, of Beersheba. 

###### v2 
Joash did that which was right in Yahweh's eyes all the days of Jehoiada the priest. 

###### v3 
Jehoiada took for him two wives, and he became the father of sons and daughters. 

###### v4 
After this, Joash intended to restore Yahweh's house. 

###### v5 
He gathered together the priests and the Levites, and said to them, "Go out to the cities of Judah, and gather money to repair the house of your God from all Israel from year to year. See that you expedite this matter." However the Levites didn't do it right away. 

###### v6 
The king called for Jehoiada the chief, and said to him, "Why haven't you required of the Levites to bring in the tax of Moses the servant of Yahweh, and of the assembly of Israel, out of Judah and out of Jerusalem, for the Tent of the Testimony?" 

###### v7 
For the sons of Athaliah, that wicked woman, had broken up God's house; and they also gave all the dedicated things of Yahweh's house to the Baals. 

###### v8 
So the king commanded, and they made a chest, and set it outside at the gate of Yahweh's house. 

###### v9 
They made a proclamation through Judah and Jerusalem, to bring in for Yahweh the tax that Moses the servant of God laid on Israel in the wilderness. 

###### v10 
All the princes and all the people rejoiced, and brought in, and cast into the chest, until they had filled it. 

###### v11 
Whenever the chest was brought to the king's officers by the hand of the Levites, and when they saw that there was much money, the king's scribe and the chief priest's officer came and emptied the chest, and took it, and carried it to its place again. Thus they did day by day, and gathered money in abundance. 

###### v12 
The king and Jehoiada gave it to those who did the work of the service of Yahweh's house. They hired masons and carpenters to restore Yahweh's house, and also those who worked iron and bronze to repair Yahweh's house. 

###### v13 
So the workmen worked, and the work of repairing went forward in their hands. They set up God's house as it was designed, and strengthened it. 

###### v14 
When they had finished, they brought the rest of the money before the king and Jehoiada, from which were made vessels for Yahweh's house, even vessels with which to minister and to offer, including spoons and vessels of gold and silver. They offered burnt offerings in Yahweh's house continually all the days of Jehoiada. 

###### v15 
But Jehoiada grew old and was full of days, and he died. He was one hundred thirty years old when he died. 

###### v16 
They buried him in David's city among the kings, because he had done good in Israel, and toward God and his house. 

###### v17 
Now after the death of Jehoiada, the princes of Judah came, and bowed down to the king. Then the king listened to them. 

###### v18 
They abandoned the house of Yahweh, the God of their fathers, and served the Asherah poles and the idols, so wrath came on Judah and Jerusalem for this their guiltiness. 

###### v19 
Yet he sent prophets to them, to bring them again to Yahweh, and they testified against them; but they would not listen. 

###### v20 
The Spirit of God came on Zechariah the son of Jehoiada the priest; and he stood above the people, and said to them, "God says, 'Why do you disobey Yahweh's commandments, so that you can't prosper? Because you have forsaken Yahweh, he has also forsaken you.'" 

###### v21 
They conspired against him, and stoned him with stones at the commandment of the king in the court of Yahweh's house. 

###### v22 
Thus Joash the king didn't remember the kindness which Jehoiada his father had done to him, but killed his son. When he died, he said, "May Yahweh look at it, and repay it." 

###### v23 
At the end of the year, the army of the Syrians came up against him: and they came to Judah and Jerusalem, and destroyed all the princes of the people from among the people, and sent all their plunder to the king of Damascus. 

###### v24 
For the army of the Syrians came with a small company of men; and Yahweh delivered a very great army into their hand, because they had forsaken Yahweh, the God of their fathers. So they executed judgment on Joash. 

###### v25 
When they had departed from him (for they left him very sick), his own servants conspired against him for the blood of the sons of Jehoiada the priest, and killed him on his bed, and he died. They buried him in David's city, but they didn't bury him in the tombs of the kings. 

###### v26 
These are those who conspired against him: Zabad the son of Shimeath the Ammonitess and Jehozabad the son of Shimrith the Moabitess. 

###### v27 
Now concerning his sons, the greatness of the burdens laid on him, and the rebuilding of God's house, behold, they are written in the commentary of the book of the kings. Amaziah his son reigned in his place.

***
[[2 Chron-23|← 2 Chronicles 23]] | [[2 Chronicles]] | [[2 Chron-25|2 Chronicles 25 →]]
