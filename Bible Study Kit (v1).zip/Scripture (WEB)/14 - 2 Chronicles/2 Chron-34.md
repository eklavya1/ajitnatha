# 2 Chronicles 34

[[2 Chron-33|← 2 Chronicles 33]] | [[2 Chronicles]] | [[2 Chron-35|2 Chronicles 35 →]]
***



###### v1 
Josiah was eight years old when he began to reign, and he reigned thirty-one years in Jerusalem. 

###### v2 
He did that which was right in Yahweh's eyes, and walked in the ways of David his father, and didn't turn away to the right hand or to the left. 

###### v3 
For in the eighth year of his reign, while he was yet young, he began to seek after the God of David his father; and in the twelfth year he began to purge Judah and Jerusalem from the high places, the Asherah poles, the engraved images, and the molten images. 

###### v4 
They broke down the altars of the Baals in his presence; and he cut down the incense altars that were on high above them. He broke the Asherah poles, the engraved images, and the molten images in pieces, made dust of them, and scattered it on the graves of those who had sacrificed to them. 

###### v5 
He burned the bones of the priests on their altars, and purged Judah and Jerusalem. 

###### v6 
He did this in the cities of Manasseh, Ephraim, and Simeon, even to Naphtali, around in their ruins. 

###### v7 
He broke down the altars, and beat the Asherah poles and the engraved images into powder, and cut down all the incense altars throughout all the land of Israel, then returned to Jerusalem. 

###### v8 
Now in the eighteenth year of his reign, when he had purged the land and the house, he sent Shaphan the son of Azaliah, and Maaseiah the governor of the city, and Joah the son of Joahaz the recorder, to repair the house of Yahweh his God. 

###### v9 
They came to Hilkiah the high priest, and delivered the money that was brought into God's house, which the Levites, the keepers of the threshold, had gathered from the hands of Manasseh, Ephraim, of all the remnant of Israel, of all Judah and Benjamin, and of the inhabitants of Jerusalem. 

###### v10 
They delivered it into the hands of the workmen who had the oversight of Yahweh's house; and the workmen who labored in Yahweh's house gave it to mend and repair the house. 

###### v11 
They gave it to the carpenters and to the builders, to buy cut stone and timber for couplings, and to make beams for the houses which the kings of Judah had destroyed. 

###### v12 
The men did the work faithfully. Their overseers were Jahath and Obadiah, the Levites, of the sons of Merari; and Zechariah and Meshullam, of the sons of the Kohathites, to give direction; and others of the Levites, who were all skillful with musical instruments. 

###### v13 
Also they were over the bearers of burdens, and directed all who did the work in every kind of service. Of the Levites, there were scribes, officials, and gatekeepers. 

###### v14 
When they brought out the money that was brought into Yahweh's house, Hilkiah the priest found the book of Yahweh's law given by Moses. 

###### v15 
Hilkiah answered Shaphan the scribe, "I have found the book of the law in Yahweh's house." So Hilkiah delivered the book to Shaphan. 

###### v16 
Shaphan carried the book to the king, and moreover brought back word to the king, saying, "All that was committed to your servants, they are doing. 

###### v17 
They have emptied out the money that was found in Yahweh's house, and have delivered it into the hand of the overseers, and into the hand of the workmen." 

###### v18 
Shaphan the scribe told the king, saying, "Hilkiah the priest has delivered me a book." Shaphan read from it to the king. 

###### v19 
When the king had heard the words of the law, he tore his clothes. 

###### v20 
The king commanded Hilkiah, Ahikam the son of Shaphan, Abdon the son of Micah, Shaphan the scribe, and Asaiah the king's servant, saying, 

###### v21 
"Go inquire of Yahweh for me, and for those who are left in Israel and in Judah, concerning the words of the book that is found; for great is Yahweh's wrath that is poured out on us, because our fathers have not kept Yahweh's word, to do according to all that is written in this book." 

###### v22 
So Hilkiah, and they whom the king had commanded, went to Huldah the prophetess, the wife of Shallum the son of Tokhath, the son of Hasrah, keeper of the wardrobe (now she lived in Jerusalem in the second quarter), and they spoke to her to that effect. 

###### v23 
She said to them, "Yahweh, the God of Israel says: 'Tell the man who sent you to me, 

###### v24 
"Yahweh says, 'Behold, I will bring evil on this place, and on its inhabitants, even all the curses that are written in the book which they have read before the king of Judah. 

###### v25 
Because they have forsaken me, and have burned incense to other gods, that they might provoke me to anger with all the works of their hands; therefore my wrath is poured out on this place, and it will not be quenched.'"' 

###### v26 
But to the king of Judah, who sent you to inquire of Yahweh, you shall tell him this, 'Yahweh, the God of Israel says: "About the words which you have heard, 

###### v27 
because your heart was tender, and you humbled yourself before God, when you heard his words against this place, and against its inhabitants, and have humbled yourself before me, and have torn your clothes, and wept before me, I also have heard you," says Yahweh. 

###### v28 
"Behold, I will gather you to your fathers, and you will be gathered to your grave in peace. Your eyes won't see all the evil that I will bring on this place and on its inhabitants."'" They brought back word to the king. 

###### v29 
Then the king sent and gathered together all the elders of Judah and Jerusalem. 

###### v30 
The king went up to Yahweh's house, with all the men of Judah and the inhabitants of Jerusalem, the priests, the Levites, and all the people, both great and small; and he read in their hearing all the words of the book of the covenant that was found in Yahweh's house. 

###### v31 
The king stood in his place, and made a covenant before Yahweh, to walk after Yahweh, and to keep his commandments, and his testimonies, and his statutes, with all his heart, and with all his soul, to perform the words of the covenant that were written in this book. 

###### v32 
He caused all who were found in Jerusalem and Benjamin to stand. The inhabitants of Jerusalem did according to the covenant of God, the God of their fathers. 

###### v33 
Josiah took away all the abominations out of all the countries that belonged to the children of Israel, and made all who were found in Israel to serve, even to serve Yahweh their God. All his days they didn't depart from following Yahweh, the God of their fathers.

***
[[2 Chron-33|← 2 Chronicles 33]] | [[2 Chronicles]] | [[2 Chron-35|2 Chronicles 35 →]]
