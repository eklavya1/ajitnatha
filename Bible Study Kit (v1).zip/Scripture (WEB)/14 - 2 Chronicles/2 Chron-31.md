# 2 Chronicles 31

[[2 Chron-30|← 2 Chronicles 30]] | [[2 Chronicles]] | [[2 Chron-32|2 Chronicles 32 →]]
***



###### v1 
Now when all this was finished, all Israel who were present went out to the cities of Judah, and broke the pillars in pieces, cut down the Asherah poles, and broke down the high places and the altars out of all Judah and Benjamin, also in Ephraim and Manasseh, until they had destroyed them all. Then all the children of Israel returned, every man to his possession, into their own cities. 

###### v2 
Hezekiah appointed the divisions of the priests and the Levites after their divisions, every man according to his service, both the priests and the Levites, for burnt offerings and for peace offerings, to minister, to give thanks, and to praise in the gates of Yahweh's camp. 

###### v3 
He also appointed the king's portion of his possessions for the burnt offerings, for the morning and evening burnt offerings, and the burnt offerings for the Sabbaths, for the new moons, and for the set feasts, as it is written in Yahweh's law. 

###### v4 
Moreover he commanded the people who lived in Jerusalem to give the portion of the priests and the Levites, that they might give themselves to Yahweh's law. 

###### v5 
As soon as the commandment went out, the children of Israel gave in abundance the first fruits of grain, new wine, oil, honey, and of all the increase of the field; and they brought in the tithe of all things abundantly. 

###### v6 
The children of Israel and Judah, who lived in the cities of Judah, also brought in the tithe of cattle and sheep, and the tithe of dedicated things which were consecrated to Yahweh their God, and laid them in heaps. 

###### v7 
In the third month they began to lay the foundation of the heaps, and finished them in the seventh month. 

###### v8 
When Hezekiah and the princes came and saw the heaps, they blessed Yahweh and his people Israel. 

###### v9 
Then Hezekiah questioned the priests and the Levites about the heaps. 

###### v10 
Azariah the chief priest, of the house of Zadok, answered him and said, "Since people began to bring the offerings into Yahweh's house, we have eaten and had enough, and have plenty left over, for Yahweh has blessed his people; and that which is left is this great store." 

###### v11 
Then Hezekiah commanded them to prepare rooms in Yahweh's house, and they prepared them. 

###### v12 
They brought in the offerings, the tithes, and the dedicated things faithfully. Conaniah the Levite was ruler over them, and Shimei his brother was second. 

###### v13 
Jehiel, Azaziah, Nahath, Asahel, Jerimoth, Jozabad, Eliel, Ismachiah, Mahath, and Benaiah were overseers under the hand of Conaniah and Shimei his brother, by the appointment of Hezekiah the king and Azariah the ruler of God's house. 

###### v14 
Kore the son of Imnah the Levite, the gatekeeper at the east gate, was over the free will offerings of God, to distribute Yahweh's offerings and the most holy things. 

###### v15 
Under him were Eden, Miniamin, Jeshua, Shemaiah, Amariah, and Shecaniah, in the cities of the priests, in their office of trust, to give to their brothers by divisions, to the great as well as to the small; 

###### v16 
in addition to those who were listed by genealogy of males, from three years old and upward, even everyone who entered into Yahweh's house, as the duty of every day required, for their service in their offices according to their divisions; 

###### v17 
and those who were listed by genealogy of the priests by their fathers' houses, and the Levites from twenty years old and upward, in their offices by their divisions; 

###### v18 
and those who were listed by genealogy of all their little ones, their wives, their sons, and their daughters, through all the congregation; for in their office of trust they sanctified themselves in holiness. 

###### v19 
Also for the sons of Aaron the priests, who were in the fields of the pasture lands of their cities, in every city, there were men who were mentioned by name, to give portions to all the males among the priests, and to all who were listed by genealogy among the Levites. 

###### v20 
Hezekiah did so throughout all Judah; and he did that which was good, right, and faithful before Yahweh his God. 

###### v21 
In every work that he began in the service of God's house, in the law, and in the commandments, to seek his God, he did it with all his heart, and prospered.

***
[[2 Chron-30|← 2 Chronicles 30]] | [[2 Chronicles]] | [[2 Chron-32|2 Chronicles 32 →]]
