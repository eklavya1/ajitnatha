# 2 Chronicles 16

[[2 Chron-15|← 2 Chronicles 15]] | [[2 Chronicles]] | [[2 Chron-17|2 Chronicles 17 →]]
***



###### v1 
In the thirty-sixth year of Asa's reign, Baasha king of Israel went up against Judah, and built Ramah, that he might not allow anyone to go out or come in to Asa king of Judah. 

###### v2 
Then Asa brought out silver and gold out of the treasures of Yahweh's house and of the king's house, and sent to Ben Hadad king of Syria, who lived at Damascus, saying, 

###### v3 
"Let there be a treaty between me and you, as there was between my father and your father. Behold, I have sent you silver and gold. Go, break your treaty with Baasha king of Israel, that he may depart from me." 

###### v4 
Ben Hadad listened to king Asa, and sent the captains of his armies against the cities of Israel; and they struck Ijon, Dan, Abel Maim, and all the storage cities of Naphtali. 

###### v5 
When Baasha heard of it, he stopped building Ramah, and let his work cease. 

###### v6 
Then Asa the king took all Judah, and they carried away the stones of Rama, and its timber, with which Baasha had built; and he built Geba and Mizpah with them. 

###### v7 
At that time Hanani the seer came to Asa king of Judah, and said to him, "Because you have relied on the king of Syria, and have not relied on Yahweh your God, therefore the army of the king of Syria has escaped out of your hand. 

###### v8 
Weren't the Ethiopians and the Lubim a huge army, with chariots and exceedingly many horsemen? Yet, because you relied on Yahweh, he delivered them into your hand. 

###### v9 
For Yahweh's eyes run back and forth throughout the whole earth, to show himself strong in the behalf of them whose heart is perfect toward him. You have done foolishly in this; for from now on you will have wars." 

###### v10 
Then Asa was angry with the seer, and put him in the prison; for he was in a rage with him because of this thing. Asa oppressed some of the people at the same time. 

###### v11 
Behold, the acts of Asa, first and last, behold, they are written in the book of the kings of Judah and Israel. 

###### v12 
In the thirty-ninth year of his reign, Asa was diseased in his feet. His disease was exceedingly great: yet in his disease he didn't seek Yahweh, but just the physicians. 

###### v13 
Asa slept with his fathers, and died in the forty-first year of his reign. 

###### v14 
They buried him in his own tomb, which he had dug out for himself in David's city, and laid him in the bed which was filled with sweet odors and various kinds of spices prepared by the perfumers' art; and they made a very great fire for him.

***
[[2 Chron-15|← 2 Chronicles 15]] | [[2 Chronicles]] | [[2 Chron-17|2 Chronicles 17 →]]
