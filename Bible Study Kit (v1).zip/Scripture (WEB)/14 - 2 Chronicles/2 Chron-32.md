# 2 Chronicles 32

[[2 Chron-31|← 2 Chronicles 31]] | [[2 Chronicles]] | [[2 Chron-33|2 Chronicles 33 →]]
***



###### v1 
After these things and this faithfulness, Sennacherib king of Assyria came, entered into Judah, and encamped against the fortified cities, and intended to win them for himself. 

###### v2 
When Hezekiah saw that Sennacherib had come, and that he was planning to fight against Jerusalem, 

###### v3 
he took counsel with his princes and his mighty men to stop the waters of the springs which were outside of the city, and they helped him. 

###### v4 
So, many people gathered together and they stopped all the springs and the brook that flowed through the middle of the land, saying, "Why should the kings of Assyria come, and find abundant water?" 

###### v5 
He took courage, built up all the wall that was broken down, and raised it up to the towers, with the other wall outside, and strengthened Millo in David's city, and made weapons and shields in abundance. 

###### v6 
He set captains of war over the people, and gathered them together to him in the wide place at the gate of the city, and spoke encouragingly to them, saying, 

###### v7 
"Be strong and courageous. Don't be afraid or dismayed because of the king of Assyria, nor for all the multitude who is with him; for there is a greater one with us than with him. 

###### v8 
An arm of flesh is with him, but Yahweh our God is with us to help us and to fight our battles." The people rested themselves on the words of Hezekiah king of Judah. 

###### v9 
After this, Sennacherib king of Assyria sent his servants to Jerusalem, (now he was before Lachish, and all his power with him), to Hezekiah king of Judah, and to all Judah who were at Jerusalem, saying, 

###### v10 
Sennacherib king of Assyria says, "In whom do you trust, that you remain under siege in Jerusalem? 

###### v11 
Doesn't Hezekiah persuade you, to give you over to die by famine and by thirst, saying, 'Yahweh our God will deliver us out of the hand of the king of Assyria?' 

###### v12 
Hasn't the same Hezekiah taken away his high places and his altars, and commanded Judah and Jerusalem, saying, 'You shall worship before one altar, and you shall burn incense on it?' 

###### v13 
Don't you know what I and my fathers have done to all the peoples of the lands? Were the gods of the nations of the lands in any way able to deliver their land out of my hand? 

###### v14 
Who was there among all the gods of those nations which my fathers utterly destroyed, that could deliver his people out of my hand, that your God should be able to deliver you out of my hand? 

###### v15 
Now therefore don't let Hezekiah deceive you, nor persuade you in this way. Don't believe him, for no god of any nation or kingdom was able to deliver his people out of my hand, and out of the hand of my fathers. How much less will your God deliver you out of my hand?" 

###### v16 
His servants spoke yet more against Yahweh God, and against his servant Hezekiah. 

###### v17 
He also wrote letters insulting Yahweh, the God of Israel, and speaking against him, saying, "As the gods of the nations of the lands, which have not delivered their people out of my hand, so shall the God of Hezekiah not deliver his people out of my hand." 

###### v18 
They called out with a loud voice in the Jews' language to the people of Jerusalem who were on the wall, to frighten them, and to trouble them; that they might take the city. 

###### v19 
They spoke of the God of Jerusalem as of the gods of the peoples of the earth, which are the work of men's hands. 

###### v20 
Hezekiah the king and Isaiah the prophet the son of Amoz, prayed because of this, and cried to heaven. 

###### v21 
Yahweh sent an angel, who cut off all the mighty men of valor, and the leaders and captains, in the camp of the king of Assyria. So he returned with shame of face to his own land. When he had come into the house of his god, those who came out of his own body killed him there with the sword. 

###### v22 
Thus Yahweh saved Hezekiah and the inhabitants of Jerusalem from the hand of Sennacherib the king of Assyria and from the hand of all others, and guided them on every side. 

###### v23 
Many brought gifts to Yahweh to Jerusalem, and precious things to Hezekiah king of Judah; so that he was exalted in the sight of all nations from then on. 

###### v24 
In those days Hezekiah was terminally ill, and he prayed to Yahweh; and he spoke to him, and gave him a sign. 

###### v25 
But Hezekiah didn't reciprocate appropriate to the benefit done for him, because his heart was lifted up. Therefore there was wrath on him, and on Judah and Jerusalem. 

###### v26 
Notwithstanding Hezekiah humbled himself for the pride of his heart, both he and the inhabitants of Jerusalem, so that Yahweh's wrath didn't come on them in the days of Hezekiah. 

###### v27 
Hezekiah had exceedingly much riches and honor. He provided himself with treasuries for silver, for gold, for precious stones, for spices, for shields, and for all kinds of valuable vessels; 

###### v28 
also storehouses for the increase of grain, new wine, and oil; and stalls for all kinds of animals, and flocks in folds. 

###### v29 
Moreover he provided for himself cities, and possessions of flocks and herds in abundance; for God had given him abundant possessions. 

###### v30 
This same Hezekiah also stopped the upper spring of the waters of Gihon, and brought them straight down on the west side of David's city. Hezekiah prospered in all his works. 

###### v31 
However concerning the ambassadors of the princes of Babylon, who sent to him to inquire of the wonder that was done in the land, God left him, to try him, that he might know all that was in his heart. 

###### v32 
Now the rest of the acts of Hezekiah, and his good deeds, behold, they are written in the vision of Isaiah the prophet the son of Amoz, in the book of the kings of Judah and Israel. 

###### v33 
Hezekiah slept with his fathers, and they buried him in the ascent of the tombs of the sons of David. All Judah and the inhabitants of Jerusalem honored him at his death. Manasseh his son reigned in his place.

***
[[2 Chron-31|← 2 Chronicles 31]] | [[2 Chronicles]] | [[2 Chron-33|2 Chronicles 33 →]]
