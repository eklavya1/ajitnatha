# 2 Chronicles 19

[[2 Chron-18|← 2 Chronicles 18]] | [[2 Chronicles]] | [[2 Chron-20|2 Chronicles 20 →]]
***



###### v1 
Jehoshaphat the king of Judah returned to his house in peace to Jerusalem. 

###### v2 
Jehu the son of Hanani the seer went out to meet him, and said to king Jehoshaphat, "Should you help the wicked, and love those who hate Yahweh? Because of this, wrath is on you from before Yahweh. 

###### v3 
Nevertheless there are good things found in you, in that you have put away the Asheroth out of the land, and have set your heart to seek God." 

###### v4 
Jehoshaphat lived at Jerusalem; and he went out again among the people from Beersheba to the hill country of Ephraim, and brought them back to Yahweh, the God of their fathers. 

###### v5 
He set judges in the land throughout all the fortified cities of Judah, city by city, 

###### v6 
and said to the judges, "Consider what you do, for you don't judge for man, but for Yahweh; and he is with you in the judgment. 

###### v7 
Now therefore let the fear of Yahweh be on you. Take heed and do it; for there is no iniquity with Yahweh our God, nor respect of persons, nor taking of bribes." 

###### v8 
Moreover in Jerusalem Jehoshaphat appointed Levites and priests, and of the heads of the fathers' households of Israel, for the judgment of Yahweh, and for controversies. They returned to Jerusalem. 

###### v9 
He commanded them, saying, "You shall do this in the fear of Yahweh, faithfully, and with a perfect heart. 

###### v10 
Whenever any controversy comes to you from your brothers who dwell in their cities, between blood and blood, between law and commandment, statutes and ordinances, you must warn them, that they not be guilty toward Yahweh, and so wrath come on you and on your brothers. Do this, and you will not be guilty. 

###### v11 
Behold, Amariah the chief priest is over you in all matters of Yahweh; and Zebadiah the son of Ishmael, the ruler of the house of Judah, in all the king's matters. Also the Levites shall be officers before you. Deal courageously, and may Yahweh be with the good."

***
[[2 Chron-18|← 2 Chronicles 18]] | [[2 Chronicles]] | [[2 Chron-20|2 Chronicles 20 →]]
