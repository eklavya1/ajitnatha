# 2 Chronicles 15

[[2 Chron-14|← 2 Chronicles 14]] | [[2 Chronicles]] | [[2 Chron-16|2 Chronicles 16 →]]
***



###### v1 
The Spirit of God came on Azariah the son of Oded: 

###### v2 
and he went out to meet Asa, and said to him, "Hear me, Asa, and all Judah and Benjamin! Yahweh is with you, while you are with him; and if you seek him, he will be found by you; but if you forsake him, he will forsake you. 

###### v3 
Now for a long time Israel was without the true God, without a teaching priest, and without law. 

###### v4 
But when in their distress they turned to Yahweh, the God of Israel, and sought him, he was found by them. 

###### v5 
In those times there was no peace to him who went out, nor to him who came in; but great troubles were on all the inhabitants of the lands. 

###### v6 
They were broken in pieces, nation against nation, and city against city; for God troubled them with all adversity. 

###### v7 
But you be strong, and don't let your hands be slack; for your work will be rewarded." 

###### v8 
When Asa heard these words, and the prophecy of Oded the prophet, he took courage, and put away the abominations out of all the land of Judah and Benjamin, and out of the cities which he had taken from the hill country of Ephraim; and he renewed Yahweh's altar that was before Yahweh's porch. 

###### v9 
He gathered all Judah and Benjamin, and those who lived with them out of Ephraim, Manasseh, and Simeon; for they came to him out of Israel in abundance when they saw that Yahweh his God was with him. 

###### v10 
So they gathered themselves together at Jerusalem in the third month, in the fifteenth year of Asa's reign. 

###### v11 
They sacrificed to Yahweh in that day, of the plunder which they had brought, seven hundred head of cattle and seven thousand sheep. 

###### v12 
They entered into the covenant to seek Yahweh, the God of their fathers, with all their heart and with all their soul; 

###### v13 
and that whoever would not seek Yahweh, the God of Israel, should be put to death, whether small or great, whether man or woman. 

###### v14 
They swore to Yahweh with a loud voice, with shouting, with trumpets, and with cornets. 

###### v15 
All Judah rejoiced at the oath, for they had sworn with all their heart, and sought him with their whole desire; and he was found by them. Then Yahweh gave them rest all around. 

###### v16 
Also Maacah, the mother of Asa the king, he removed from being queen, because she had made an abominable image for an Asherah; so Asa cut down her image, ground it into dust, and burned it at the brook Kidron. 

###### v17 
But the high places were not taken away out of Israel; nevertheless the heart of Asa was perfect all his days. 

###### v18 
He brought the things that his father had dedicated, and that he himself had dedicated, silver, gold, and vessels into God's house. 

###### v19 
There was no more war to the thirty-fifth year of Asa's reign.

***
[[2 Chron-14|← 2 Chronicles 14]] | [[2 Chronicles]] | [[2 Chron-16|2 Chronicles 16 →]]
