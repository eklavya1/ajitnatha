# 2 Chronicles 1

[[2 Chronicles]] | [[2 Chron-02|2 Chronicles 02 →]]
***



###### v1 
Solomon the son of David was firmly established in his kingdom, and Yahweh his God was with him, and made him exceedingly great. 

###### v2 
Solomon spoke to all Israel, to the captains of thousands and of hundreds, to the judges, and to every prince in all Israel, the heads of the fathers' households. 

###### v3 
So Solomon, and all the assembly with him, went to the high place that was at Gibeon; for God's Tent of Meeting was there, which Yahweh's servant Moses had made in the wilderness. 

###### v4 
But David had brought God's ark up from Kiriath Jearim to the place that David had prepared for it; for he had pitched a tent for it at Jerusalem. 

###### v5 
Moreover the bronze altar that Bezalel the son of Uri, the son of Hur, had made was there before Yahweh's tabernacle; and Solomon and the assembly were seeking counsel there. 

###### v6 
Solomon went up there to the bronze altar before Yahweh, which was at the Tent of Meeting, and offered one thousand burnt offerings on it. 

###### v7 
That night, God appeared to Solomon and said to him, "Ask for what you want me to give you." 

###### v8 
Solomon said to God, "You have shown great loving kindness to David my father, and have made me king in his place. 

###### v9 
Now, Yahweh God, let your promise to David my father be established; for you have made me king over a people like the dust of the earth in multitude. 

###### v10 
Now give me wisdom and knowledge, that I may go out and come in before this people; for who can judge this great people of yours?" 

###### v11 
God said to Solomon, "Because this was in your heart, and you have not asked riches, wealth, honor, or the life of those who hate you, nor yet have you asked for long life; but have asked for wisdom and knowledge for yourself, that you may judge my people, over whom I have made you king, 

###### v12 
therefore wisdom and knowledge is granted to you. I will give you riches, wealth, and honor, such as none of the kings have had who have been before you, and none after you will have." 

###### v13 
So Solomon came from the high place that was at Gibeon, from before the Tent of Meeting, to Jerusalem; and he reigned over Israel. 

###### v14 
Solomon gathered chariots and horsemen. He had one thousand four hundred chariots and twelve thousand horsemen that he placed in the chariot cities, and with the king at Jerusalem. 

###### v15 
The king made silver and gold to be as common as stones in Jerusalem, and he made cedars to be as common as the sycamore trees that are in the lowland. 

###### v16 
The horses which Solomon had were brought out of Egypt and from Kue. The king's merchants purchased them from Kue. 

###### v17 
They brought up and brought out of Egypt a chariot for six hundred pieces of silver, and a horse for one hundred fifty. They also exported them to the Hittite kings and the Syrian kings.

***
[[2 Chronicles]] | [[2 Chron-02|2 Chronicles 02 →]]
