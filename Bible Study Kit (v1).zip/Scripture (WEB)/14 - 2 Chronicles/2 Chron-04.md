# 2 Chronicles 4

[[2 Chron-03|← 2 Chronicles 03]] | [[2 Chronicles]] | [[2 Chron-05|2 Chronicles 05 →]]
***



###### v1 
Then he made an altar of bronze, twenty cubits long, twenty cubits wide, and ten cubits high. 

###### v2 
Also he made the molten sea of ten cubits from brim to brim. It was round, five cubits high, and thirty cubits in circumference. 

###### v3 
Under it was the likeness of oxen, which encircled it, for ten cubits, encircling the sea. The oxen were in two rows, cast when it was cast. 

###### v4 
It stood on twelve oxen, three looking toward the north, and three looking toward the west, and three looking toward the south, and three looking toward the east; and the sea was set on them above, and all their hindquarters were inward. 

###### v5 
It was a handbreadth thick; and its brim was made like the brim of a cup, like the flower of a lily. It received and held three thousand baths. 

###### v6 
He also made ten basins, and put five on the right hand, and five on the left, to wash in them. The things that belonged to the burnt offering were washed in them; but the sea was for the priests to wash in. 

###### v7 
He made the ten lamp stands of gold according to the ordinance concerning them; and he set them in the temple, five on the right hand, and five on the left. 

###### v8 
He made also ten tables, and placed them in the temple, five on the right side, and five on the left. He made one hundred basins of gold. 

###### v9 
Furthermore he made the court of the priests, the great court, and doors for the court, and overlaid their doors with bronze. 

###### v10 
He set the sea on the right side of the house eastward, toward the south. 

###### v11 
Huram made the pots, the shovels, and the basins. So Huram finished doing the work that he did for king Solomon in God's house: 

###### v12 
the two pillars, the bowls, the two capitals which were on the top of the pillars, the two networks to cover the two bowls of the capitals that were on the top of the pillars, 

###### v13 
and the four hundred pomegranates for the two networks; two rows of pomegranates for each network, to cover the two bowls of the capitals that were on the pillars. 

###### v14 
He also made the bases, and he made the basins on the bases; 

###### v15 
one sea, and the twelve oxen under it. 

###### v16 
Huram his father also made the pots, the shovels, the forks, and all its vessels for king Solomon, for Yahweh's house, of bright bronze. 

###### v17 
The king cast them in the plain of the Jordan, in the clay ground between Succoth and Zeredah. 

###### v18 
Thus Solomon made all these vessels in great abundance; for the weight of the bronze could not be determined. 

###### v19 
Solomon made all the vessels that were in God's house, the golden altar also, and the tables with the show bread on them; 

###### v20 
and the lamp stands with their lamps, to burn according to the ordinance before the inner sanctuary, of pure gold; 

###### v21 
and the flowers, the lamps, and the tongs of gold that was perfect gold; 

###### v22 
and the snuffers, the basins, the spoons, and the fire pans of pure gold. As for the entry of the house, its inner doors for the most holy place and the doors of the main hall of the temple were of gold.

***
[[2 Chron-03|← 2 Chronicles 03]] | [[2 Chronicles]] | [[2 Chron-05|2 Chronicles 05 →]]
