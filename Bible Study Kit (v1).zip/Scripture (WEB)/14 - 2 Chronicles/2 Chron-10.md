# 2 Chronicles 10

[[2 Chron-09|← 2 Chronicles 09]] | [[2 Chronicles]] | [[2 Chron-11|2 Chronicles 11 →]]
***



###### v1 
Rehoboam went to Shechem; for all Israel had come to Shechem to make him king. 

###### v2 
When Jeroboam the son of Nebat heard of it (for he was in Egypt, where he had fled from the presence of king Solomon), Jeroboam returned out of Egypt. 

###### v3 
They sent and called him; and Jeroboam and all Israel came, and they spoke to Rehoboam, saying, 

###### v4 
"Your father made our yoke grievous: now therefore make the grievous service of your father, and his heavy yoke which he put on us, lighter, and we will serve you." 

###### v5 
He said to them, "Come again to me after three days." So the people departed. 

###### v6 
King Rehoboam took counsel with the old men, who had stood before Solomon his father while he yet lived, saying, "What counsel do you give me about how to answer these people?" 

###### v7 
They spoke to him, saying, "If you are kind to these people, please them, and speak good words to them, then they will be your servants forever." 

###### v8 
But he abandoned the counsel of the old men which they had given him, and took counsel with the young men who had grown up with him, who stood before him. 

###### v9 
He said to them, "What counsel do you give, that we may give an answer to these people, who have spoken to me, saying, 'Make the yoke that your father put on us lighter?'" 

###### v10 
The young men who had grown up with him spoke to him, saying, "Thus you shall tell the people who spoke to you, saying, 'Your father made our yoke heavy, but make it lighter on us;' thus you shall say to them, 'My little finger is thicker than my father's waist. 

###### v11 
Now whereas my father burdened you with a heavy yoke, I will add to your yoke. My father chastised you with whips, but I will chastise you with scorpions.'" 

###### v12 
So Jeroboam and all the people came to Rehoboam the third day, as the king asked, saying, "Come to me again the third day." 

###### v13 
The king answered them roughly; and king Rehoboam abandoned the counsel of the old men, 

###### v14 
and spoke to them after the counsel of the young men, saying, "My father made your yoke heavy, but I will add to it. My father chastised you with whips, but I will chastise you with scorpions." 

###### v15 
So the king didn't listen to the people; for it was brought about by God, that Yahweh might establish his word, which he spoke by Ahijah the Shilonite to Jeroboam the son of Nebat. 

###### v16 
When all Israel saw that the king didn't listen to them, the people answered the king, saying, "What portion do we have in David? We don't have an inheritance in the son of Jesse! Every man to your tents, Israel! Now see to your own house, David." So all Israel departed to their tents. 

###### v17 
But as for the children of Israel who lived in the cities of Judah, Rehoboam reigned over them. 

###### v18 
Then king Rehoboam sent Hadoram, who was over the men subject to forced labor; and the children of Israel stoned him to death with stones. King Rehoboam hurried to get himself up to his chariot, to flee to Jerusalem. 

###### v19 
So Israel rebelled against David's house to this day.

***
[[2 Chron-09|← 2 Chronicles 09]] | [[2 Chronicles]] | [[2 Chron-11|2 Chronicles 11 →]]
