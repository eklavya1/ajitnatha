# 2 Chronicles 20

[[2 Chron-19|← 2 Chronicles 19]] | [[2 Chronicles]] | [[2 Chron-21|2 Chronicles 21 →]]
***



###### v1 
After this, the children of Moab, the children of Ammon, and with them some of the Ammonites, came against Jehoshaphat to battle. 

###### v2 
Then some came who told Jehoshaphat, saying, "A great multitude is coming against you from beyond the sea from Syria. Behold, they are in Hazazon Tamar" (that is, En Gedi). 

###### v3 
Jehoshaphat was alarmed, and set himself to seek to Yahweh. He proclaimed a fast throughout all Judah. 

###### v4 
Judah gathered themselves together to seek help from Yahweh. They came out of all the cities of Judah to seek Yahweh. 

###### v5 
Jehoshaphat stood in the assembly of Judah and Jerusalem, in Yahweh's house, before the new court; 

###### v6 
and he said, "Yahweh, the God of our fathers, aren't you God in heaven? Aren't you ruler over all the kingdoms of the nations? Power and might are in your hand, so that no one is able to withstand you. 

###### v7 
Didn't you, our God, drive out the inhabitants of this land before your people Israel, and give it to the offspring of Abraham your friend forever? 

###### v8 
They lived in it, and have built you a sanctuary in it for your name, saying, 

###### v9 
'If evil comes on us--the sword, judgment, pestilence, or famine--we will stand before this house, and before you (for your name is in this house), and cry to you in our affliction, and you will hear and save.' 

###### v10 
Now, behold, the children of Ammon and Moab and Mount Seir, whom you would not let Israel invade when they came out of the land of Egypt, but they turned away from them, and didn't destroy them; 

###### v11 
behold, how they reward us, to come to cast us out of your possession, which you have given us to inherit. 

###### v12 
Our God, will you not judge them? For we have no might against this great company that comes against us. We don't know what to do, but our eyes are on you." 

###### v13 
All Judah stood before Yahweh, with their little ones, their wives, and their children. 

###### v14 
Then Yahweh's Spirit came on Jahaziel the son of Zechariah, the son of Benaiah, the son of Jeiel, the son of Mattaniah, the Levite, of the sons of Asaph, in the middle of the assembly; 

###### v15 
and he said, "Listen, all Judah, and you inhabitants of Jerusalem, and you, king Jehoshaphat. Yahweh says to you, 'Don't be afraid, and don't be dismayed because of this great multitude; for the battle is not yours, but God's. 

###### v16 
Tomorrow, go down against them. Behold, they are coming up by the ascent of Ziz. You will find them at the end of the valley, before the wilderness of Jeruel. 

###### v17 
You will not need to fight this battle. Set yourselves, stand still, and see the salvation of Yahweh with you, O Judah and Jerusalem. Don't be afraid, nor be dismayed. Go out against them tomorrow, for Yahweh is with you.'" 

###### v18 
Jehoshaphat bowed his head with his face to the ground; and all Judah and the inhabitants of Jerusalem fell down before Yahweh, worshiping Yahweh. 

###### v19 
The Levites, of the children of the Kohathites and of the children of the Korahites, stood up to praise Yahweh, the God of Israel, with an exceedingly loud voice. 

###### v20 
They rose early in the morning, and went out into the wilderness of Tekoa. As they went out, Jehoshaphat stood and said, "Listen to me, Judah, and you inhabitants of Jerusalem! Believe in Yahweh your God, so you will be established! Believe his prophets, so you will prosper." 

###### v21 
When he had taken counsel with the people, he appointed those who were to sing to Yahweh, and give praise in holy array, as they go out before the army, and say, "Give thanks to Yahweh; for his loving kindness endures forever." 

###### v22 
When they began to sing and to praise, Yahweh set ambushers against the children of Ammon, Moab, and Mount Seir, who had come against Judah; and they were struck. 

###### v23 
For the children of Ammon and Moab stood up against the inhabitants of Mount Seir to utterly kill and destroy them. When they had finished the inhabitants of Seir, everyone helped to destroy each other. 

###### v24 
When Judah came to the place overlooking the wilderness, they looked at the multitude; and behold, they were dead bodies fallen to the earth, and there were none who escaped. 

###### v25 
When Jehoshaphat and his people came to take their plunder, they found among them in abundance both riches and dead bodies, and precious jewels, which they stripped off for themselves, more than they could carry away. They took plunder for three days, it was so much. 

###### v26 
On the fourth day, they assembled themselves in Beracah Valley, for there they blessed Yahweh. Therefore the name of that place was called "Beracah Valley" to this day. 

###### v27 
Then they returned, every man of Judah and Jerusalem, with Jehoshaphat in front of them, to go again to Jerusalem with joy; for Yahweh had made them to rejoice over their enemies. 

###### v28 
They came to Jerusalem with stringed instruments, harps, and trumpets to Yahweh's house. 

###### v29 
The fear of God was on all the kingdoms of the countries, when they heard that Yahweh fought against the enemies of Israel. 

###### v30 
So the realm of Jehoshaphat was quiet, for his God gave him rest all around. 

###### v31 
Jehoshaphat reigned over Judah. He was thirty-five years old when he began to reign; and he reigned twenty-five years in Jerusalem. His mother's name was Azubah the daughter of Shilhi. 

###### v32 
He walked in the way of Asa his father, and didn't turn away from it, doing that which was right in Yahweh's eyes. 

###### v33 
However the high places were not taken away, and the people had still not set their hearts on the God of their fathers. 

###### v34 
Now the rest of the acts of Jehoshaphat, first and last, behold, they are written in the history of Jehu the son of Hanani, which is included in the book of the kings of Israel. 

###### v35 
After this, Jehoshaphat king of Judah joined himself with Ahaziah king of Israel. The same did very wickedly. 

###### v36 
He joined himself with him to make ships to go to Tarshish. They made the ships in Ezion Geber. 

###### v37 
Then Eliezer the son of Dodavahu of Mareshah prophesied against Jehoshaphat, saying, "Because you have joined yourself with Ahaziah, Yahweh has destroyed your works." The ships were wrecked, so that they were not able to go to Tarshish.

***
[[2 Chron-19|← 2 Chronicles 19]] | [[2 Chronicles]] | [[2 Chron-21|2 Chronicles 21 →]]
