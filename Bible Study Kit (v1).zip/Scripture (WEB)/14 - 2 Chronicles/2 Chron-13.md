# 2 Chronicles 13

[[2 Chron-12|← 2 Chronicles 12]] | [[2 Chronicles]] | [[2 Chron-14|2 Chronicles 14 →]]
***



###### v1 
In the eighteenth year of king Jeroboam, Abijah began to reign over Judah. 

###### v2 
He reigned three years in Jerusalem. His mother's name was Micaiah the daughter of Uriel of Gibeah. There was war between Abijah and Jeroboam. 

###### v3 
Abijah joined battle with an army of valiant men of war, even four hundred thousand chosen men; and Jeroboam set the battle in array against him with eight hundred thousand chosen men, who were mighty men of valor. 

###### v4 
Abijah stood up on Mount Zemaraim, which is in the hill country of Ephraim, and said, "Hear me, Jeroboam and all Israel: 

###### v5 
Ought you not to know that Yahweh, the God of Israel, gave the kingdom over Israel to David forever, even to him and to his sons by a covenant of salt? 

###### v6 
Yet Jeroboam the son of Nebat, the servant of Solomon the son of David, rose up, and rebelled against his lord. 

###### v7 
Worthless men were gathered to him, wicked fellows who strengthened themselves against Rehoboam the son of Solomon, when Rehoboam was young and tender hearted, and could not withstand them. 

###### v8 
"Now you intend to withstand the kingdom of Yahweh in the hand of the sons of David. You are a great multitude, and the golden calves which Jeroboam made you for gods are with you. 

###### v9 
Haven't you driven out the priests of Yahweh, the sons of Aaron, and the Levites, and made priests for yourselves according to the ways of the peoples of other lands? Whoever comes to consecrate himself with a young bull and seven rams may be a priest of those who are no gods. 

###### v10 
"But as for us, Yahweh is our God, and we have not forsaken him. We have priests serving Yahweh, the sons of Aaron, and the Levites in their work; 

###### v11 
and they burn to Yahweh every morning and every evening burnt offerings and sweet incense. They also set the show bread in order on the pure table; and the lamp stand of gold with its lamps, to burn every evening; for we keep the instruction of Yahweh our God, but you have forsaken him. 

###### v12 
Behold, God is with us at our head, and his priests with the trumpets of alarm to sound an alarm against you. Children of Israel, don't fight against Yahweh, the God of your fathers; for you will not prosper." 

###### v13 
But Jeroboam caused an ambush to come about behind them; so they were before Judah, and the ambush was behind them. 

###### v14 
When Judah looked back, behold, the battle was before and behind them; and they cried to Yahweh, and the priests sounded with the trumpets. 

###### v15 
Then the men of Judah gave a shout. As the men of Judah shouted, God struck Jeroboam and all Israel before Abijah and Judah. 

###### v16 
The children of Israel fled before Judah, and God delivered them into their hand. 

###### v17 
Abijah and his people killed them with a great slaughter, so five hundred thousand chosen men of Israel fell down slain. 

###### v18 
Thus the children of Israel were brought under at that time, and the children of Judah prevailed, because they relied on Yahweh, the God of their fathers. 

###### v19 
Abijah pursued Jeroboam, and took cities from him, Bethel with its villages, Jeshanah with its villages, and Ephron with its villages. 

###### v20 
Jeroboam didn't recover strength again in the days of Abijah. Yahweh struck him, and he died. 

###### v21 
But Abijah grew mighty, and took for himself fourteen wives, and became the father of twenty-two sons and sixteen daughters. 

###### v22 
The rest of the acts of Abijah, his ways, and his sayings are written in the commentary of the prophet Iddo.

***
[[2 Chron-12|← 2 Chronicles 12]] | [[2 Chronicles]] | [[2 Chron-14|2 Chronicles 14 →]]
