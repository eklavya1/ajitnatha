# 2 Chronicles 28

[[2 Chron-27|← 2 Chronicles 27]] | [[2 Chronicles]] | [[2 Chron-29|2 Chronicles 29 →]]
***



###### v1 
Ahaz was twenty years old when he began to reign, and he reigned sixteen years in Jerusalem. He didn't do that which was right in Yahweh's eyes, like David his father, 

###### v2 
but he walked in the ways of the kings of Israel, and also made molten images for the Baals. 

###### v3 
Moreover he burned incense in the valley of the son of Hinnom, and burned his children in the fire, according to the abominations of the nations whom Yahweh cast out before the children of Israel. 

###### v4 
He sacrificed and burned incense in the high places, and on the hills, and under every green tree. 

###### v5 
Therefore Yahweh his God delivered him into the hand of the king of Syria. They struck him, and carried away from him a great multitude of captives, and brought them to Damascus. He was also delivered into the hand of the king of Israel, who struck him with a great slaughter. 

###### v6 
For Pekah the son of Remaliah killed in Judah one hundred twenty thousand in one day, all of them valiant men, because they had forsaken Yahweh, the God of their fathers. 

###### v7 
Zichri, a mighty man of Ephraim, killed Maaseiah the king's son, Azrikam the ruler of the house, and Elkanah who was next to the king. 

###### v8 
The children of Israel carried away captive of their brothers two hundred thousand women, sons, and daughters, and also took away much plunder from them, and brought the plunder to Samaria. 

###### v9 
But a prophet of Yahweh was there, whose name was Oded; and he went out to meet the army that came to Samaria, and said to them, "Behold, because Yahweh, the God of your fathers, was angry with Judah, he has delivered them into your hand, and you have slain them in a rage which has reached up to heaven. 

###### v10 
Now you intend to degrade the children of Judah and Jerusalem as male and female slaves for yourselves. Aren't there even with you trespasses of your own against Yahweh your God? 

###### v11 
Now hear me therefore, and send back the captives that you have taken captive from your brothers, for the fierce wrath of Yahweh is on you." 

###### v12 
Then some of the heads of the children of Ephraim, Azariah the son of Johanan, Berechiah the son of Meshillemoth, Jehizkiah the son of Shallum, and Amasa the son of Hadlai, stood up against those who came from the war, 

###### v13 
and said to them, "You must not bring in the captives here, for you intend that which will bring on us a trespass against Yahweh, to add to our sins and to our guilt; for our guilt is great, and there is fierce wrath against Israel." 

###### v14 
So the armed men left the captives and the plunder before the princes and all the assembly. 

###### v15 
The men who have been mentioned by name rose up and took the captives, and with the plunder clothed all who were naked among them, dressed them, gave them sandals, and gave them something to eat and to drink, anointed them, carried all the feeble of them on donkeys, and brought them to Jericho, the city of palm trees, to their brothers. Then they returned to Samaria. 

###### v16 
At that time king Ahaz sent to the kings of Assyria to help him. 

###### v17 
For again the Edomites had come and struck Judah, and carried away captives. 

###### v18 
The Philistines also had invaded the cities of the lowland, and of the South of Judah, and had taken Beth Shemesh, Aijalon, Gederoth, Soco with its villages, Timnah with its villages, and also Gimzo and its villages; and they lived there. 

###### v19 
For Yahweh brought Judah low because of Ahaz king of Israel, because he acted without restraint in Judah and trespassed severely against Yahweh. 

###### v20 
Tilgath Pilneser king of Assyria came to him, and gave him trouble, but didn't strengthen him. 

###### v21 
For Ahaz took away a portion out of Yahweh's house, and out of the house of the king and of the princes, and gave it to the king of Assyria; but it didn't help him. 

###### v22 
In the time of his distress, he trespassed yet more against Yahweh, this same king Ahaz. 

###### v23 
For he sacrificed to the gods of Damascus, which struck him. He said, "Because the gods of the kings of Syria helped them, so I will sacrifice to them, that they may help me." But they were the ruin of him, and of all Israel. 

###### v24 
Ahaz gathered together the vessels of God's house, and cut the vessels of God's house in pieces, and shut up the doors of Yahweh's house; and he made himself altars in every corner of Jerusalem. 

###### v25 
In every city of Judah he made high places to burn incense to other gods, and provoked Yahweh, the God of his fathers, to anger. 

###### v26 
Now the rest of his acts, and all his ways, first and last, behold, they are written in the book of the kings of Judah and Israel. 

###### v27 
Ahaz slept with his fathers, and they buried him in the city, even in Jerusalem, because they didn't bring him into the tombs of the kings of Israel; and Hezekiah his son reigned in his place.

***
[[2 Chron-27|← 2 Chronicles 27]] | [[2 Chronicles]] | [[2 Chron-29|2 Chronicles 29 →]]
