# 2 Chronicles 27

[[2 Chron-26|← 2 Chronicles 26]] | [[2 Chronicles]] | [[2 Chron-28|2 Chronicles 28 →]]
***



###### v1 
Jotham was twenty-five years old when he began to reign, and he reigned sixteen years in Jerusalem. His mother's name was Jerushah the daughter of Zadok. 

###### v2 
He did that which was right in Yahweh's eyes, according to all that his father Uzziah had done. However he didn't enter into Yahweh's temple. The people still acted corruptly. 

###### v3 
He built the upper gate of Yahweh's house, and he built much on the wall of Ophel. 

###### v4 
Moreover he built cities in the hill country of Judah, and in the forests he built fortresses and towers. 

###### v5 
He also fought with the king of the children of Ammon, and prevailed against them. The children of Ammon gave him the same year one hundred talents of silver, ten thousand cors of wheat, and ten thousand cors of barley. The children of Ammon also gave that much to him in the second year, and in the third. 

###### v6 
So Jotham became mighty, because he ordered his ways before Yahweh his God. 

###### v7 
Now the rest of the acts of Jotham, and all his wars, and his ways, behold, they are written in the book of the kings of Israel and Judah. 

###### v8 
He was twenty-five years old when he began to reign, and reigned sixteen years in Jerusalem. 

###### v9 
Jotham slept with his fathers, and they buried him in David's city; and Ahaz his son reigned in his place.

***
[[2 Chron-26|← 2 Chronicles 26]] | [[2 Chronicles]] | [[2 Chron-28|2 Chronicles 28 →]]
