# 2 Chronicles 26

[[2 Chron-25|← 2 Chronicles 25]] | [[2 Chronicles]] | [[2 Chron-27|2 Chronicles 27 →]]
***



###### v1 
All the people of Judah took Uzziah, who was sixteen years old, and made him king in the place of his father Amaziah. 

###### v2 
He built Eloth and restored it to Judah. After that the king slept with his fathers. 

###### v3 
Uzziah was sixteen years old when he began to reign; and he reigned fifty-two years in Jerusalem. His mother's name was Jechiliah, of Jerusalem. 

###### v4 
He did that which was right in Yahweh's eyes, according to all that his father Amaziah had done. 

###### v5 
He set himself to seek God in the days of Zechariah, who had understanding in the vision of God; and as long as he sought Yahweh, God made him prosper. 

###### v6 
He went out and fought against the Philistines, and broke down the wall of Gath, the wall of Jabneh, and the wall of Ashdod; and he built cities in the country of Ashdod, and among the Philistines. 

###### v7 
God helped him against the Philistines, and against the Arabians who lived in Gur Baal, and the Meunim. 

###### v8 
The Ammonites gave tribute to Uzziah. His name spread abroad even to the entrance of Egypt; for he grew exceedingly strong. 

###### v9 
Moreover Uzziah built towers in Jerusalem at the corner gate, at the valley gate, and at the turning of the wall, and fortified them. 

###### v10 
He built towers in the wilderness, and dug out many cisterns, for he had much livestock; in the lowland also, and in the plain. He had farmers and vineyard keepers in the mountains and in the fruitful fields, for he loved farming. 

###### v11 
Moreover Uzziah had an army of fighting men, who went out to war by bands, according to the number of their reckoning made by Jeiel the scribe and Maaseiah the officer, under the hand of Hananiah, one of the king's captains. 

###### v12 
The whole number of the heads of fathers' households, even the mighty men of valor, was two thousand six hundred. 

###### v13 
Under their hand was an army, three hundred seven thousand five hundred, who made war with mighty power, to help the king against the enemy. 

###### v14 
Uzziah prepared for them, even for all the army, shields, spears, helmets, coats of mail, bows, and stones for slinging. 

###### v15 
In Jerusalem, he made devices, invented by skillful men, to be on the towers and on the battlements, with which to shoot arrows and great stones. His name spread far abroad, because he was marvelously helped until he was strong. 

###### v16 
But when he was strong, his heart was lifted up, so that he did corruptly, and he trespassed against Yahweh his God; for he went into Yahweh's temple to burn incense on the altar of incense. 

###### v17 
Azariah the priest went in after him, and with him eighty priests of Yahweh, who were valiant men. 

###### v18 
They resisted Uzziah the king, and said to him, "It isn't for you, Uzziah, to burn incense to Yahweh, but for the priests the sons of Aaron, who are consecrated to burn incense. Go out of the sanctuary, for you have trespassed. It will not be for your honor from Yahweh God." 

###### v19 
Then Uzziah was angry. He had a censer in his hand to burn incense, and while he was angry with the priests, the leprosy broke out on his forehead before the priests in Yahweh's house, beside the altar of incense. 

###### v20 
Azariah the chief priest, and all the priests, looked at him, and behold, he was leprous in his forehead, and they thrust him out quickly from there. Yes, he himself also hurried to go out, because Yahweh had struck him. 

###### v21 
Uzziah the king was a leper to the day of his death, and lived in a separate house, being a leper; for he was cut off from Yahweh's house. Jotham his son was over the king's house, judging the people of the land. 

###### v22 
Now the rest of the acts of Uzziah, first and last, Isaiah the prophet, the son of Amoz, wrote. 

###### v23 
So Uzziah slept with his fathers; and they buried him with his fathers in the field of burial which belonged to the kings, for they said, "He is a leper." Jotham his son reigned in his place.

***
[[2 Chron-25|← 2 Chronicles 25]] | [[2 Chronicles]] | [[2 Chron-27|2 Chronicles 27 →]]
