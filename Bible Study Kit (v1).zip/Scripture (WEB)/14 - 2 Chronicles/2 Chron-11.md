# 2 Chronicles 11

[[2 Chron-10|← 2 Chronicles 10]] | [[2 Chronicles]] | [[2 Chron-12|2 Chronicles 12 →]]
***



###### v1 
When Rehoboam had come to Jerusalem, he assembled the house of Judah and Benjamin, one hundred eighty thousand chosen men who were warriors, to fight against Israel, to bring the kingdom again to Rehoboam. 

###### v2 
But Yahweh's word came to Shemaiah the man of God, saying, 

###### v3 
"Speak to Rehoboam the son of Solomon, king of Judah, and to all Israel in Judah and Benjamin, saying, 

###### v4 
'Yahweh says, "You shall not go up, nor fight against your brothers! Every man return to his house; for this thing is of me."'" So they listened to Yahweh's words, and returned from going against Jeroboam. 

###### v5 
Rehoboam lived in Jerusalem, and built cities for defense in Judah. 

###### v6 
He built Bethlehem, Etam, Tekoa, 

###### v7 
Beth Zur, Soco, Adullam, 

###### v8 
Gath, Mareshah, Ziph, 

###### v9 
Adoraim, Lachish, Azekah, 

###### v10 
Zorah, Aijalon, and Hebron, which are fortified cities in Judah and in Benjamin. 

###### v11 
He fortified the strongholds, and put captains in them, and stores of food, oil and wine. 

###### v12 
He put shields and spears in every city, and made them exceedingly strong. Judah and Benjamin belonged to him. 

###### v13 
The priests and the Levites who were in all Israel stood with him out of all their territory. 

###### v14 
For the Levites left their pasture lands and their possession, and came to Judah and Jerusalem; for Jeroboam and his sons cast them off, that they should not execute the priest's office to Yahweh. 

###### v15 
He himself appointed priests for the high places, for the male goats, and for the calves which he had made. 

###### v16 
After them, out of all the tribes of Israel, those who set their hearts to seek Yahweh, the God of Israel, came to Jerusalem to sacrifice to Yahweh, the God of their fathers. 

###### v17 
So they strengthened the kingdom of Judah, and made Rehoboam the son of Solomon strong for three years; for they walked three years in the way of David and Solomon. 

###### v18 
Rehoboam took a wife for himself, Mahalath the daughter of Jerimoth the son of David and of Abihail the daughter of Eliab the son of Jesse. 

###### v19 
She bore him sons: Jeush, Shemariah, and Zaham. 

###### v20 
After her, he took Maacah the daughter of Absalom; and she bore him Abijah, Attai, Ziza, and Shelomith. 

###### v21 
Rehoboam loved Maacah the daughter of Absalom above all his wives and his concubines; for he took eighteen wives and sixty concubines, and became the father of twenty-eight sons and sixty daughters. 

###### v22 
Rehoboam appointed Abijah the son of Maacah to be chief, the prince among his brothers; for he intended to make him king. 

###### v23 
He dealt wisely, and dispersed of all his sons throughout all the lands of Judah and Benjamin, to every fortified city. He gave them food in abundance and he sought many wives for them.

***
[[2 Chron-10|← 2 Chronicles 10]] | [[2 Chronicles]] | [[2 Chron-12|2 Chronicles 12 →]]
