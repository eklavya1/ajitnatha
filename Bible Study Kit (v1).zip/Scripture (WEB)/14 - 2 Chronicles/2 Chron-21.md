# 2 Chronicles 21

[[2 Chron-20|← 2 Chronicles 20]] | [[2 Chronicles]] | [[2 Chron-22|2 Chronicles 22 →]]
***



###### v1 
Jehoshaphat slept with his fathers, and was buried with his fathers in David's city, and Jehoram his son reigned in his place. 

###### v2 
He had brothers, the sons of Jehoshaphat: Azariah, Jehiel, Zechariah, Azariah, Michael, and Shephatiah. All these were the sons of Jehoshaphat king of Israel. 

###### v3 
Their father gave them great gifts of silver, of gold, and of precious things, with fortified cities in Judah; but he gave the kingdom to Jehoram, because he was the firstborn. 

###### v4 
Now when Jehoram had risen up over the kingdom of his father, and had strengthened himself, he killed all his brothers with the sword, and also some of the princes of Israel. 

###### v5 
Jehoram was thirty-two years old when he began to reign, and he reigned eight years in Jerusalem. 

###### v6 
He walked in the way of the kings of Israel, as did Ahab's house; for he had Ahab's daughter as his wife. He did that which was evil in Yahweh's sight. 

###### v7 
However Yahweh would not destroy David's house, because of the covenant that he had made with David, and as he promised to give a lamp to him and to his children always. 

###### v8 
In his days Edom revolted from under the hand of Judah, and made a king over themselves. 

###### v9 
Then Jehoram went there with his captains and all his chariots with him. He rose up by night and struck the Edomites who surrounded him, along with the captains of the chariots. 

###### v10 
So Edom revolted from under the hand of Judah to this day. Then Libnah revolted at the same time from under his hand, because he had forsaken Yahweh, the God of his fathers. 

###### v11 
Moreover he made high places in the mountains of Judah, and made the inhabitants of Jerusalem play the prostitute, and led Judah astray. 

###### v12 
A letter came to him from Elijah the prophet, saying, "Yahweh, the God of David your father, says, 'Because you have not walked in the ways of Jehoshaphat your father, nor in the ways of Asa king of Judah, 

###### v13 
but have walked in the way of the kings of Israel, and have made Judah and the inhabitants of Jerusalem to play the prostitute like Ahab's house did, and also have slain your brothers of your father's house, who were better than yourself, 

###### v14 
behold, Yahweh will strike your people with a great plague, including your children, your wives, and all your possessions; 

###### v15 
and you will have great sickness with a disease of your bowels, until your bowels fall out by reason of the sickness, day by day.'" 

###### v16 
Yahweh stirred up against Jehoram the spirit of the Philistines, and of the Arabians who are beside the Ethiopians; 

###### v17 
and they came up against Judah, broke into it, and carried away all the possessions that were found in the king's house, including his sons and his wives; so that there was no son left him, except Jehoahaz, the youngest of his sons. 

###### v18 
After all this Yahweh struck him in his bowels with an incurable disease. 

###### v19 
In process of time, at the end of two years, his bowels fell out by reason of his sickness, and he died of severe diseases. His people made no burning for him, like the burning of his fathers. 

###### v20 
He was thirty-two years old when he began to reign, and he reigned in Jerusalem eight years. He departed without being missed; and they buried him in David's city, but not in the tombs of the kings.

***
[[2 Chron-20|← 2 Chronicles 20]] | [[2 Chronicles]] | [[2 Chron-22|2 Chronicles 22 →]]
