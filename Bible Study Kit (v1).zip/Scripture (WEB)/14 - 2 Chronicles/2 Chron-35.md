# 2 Chronicles 35

[[2 Chron-34|← 2 Chronicles 34]] | [[2 Chronicles]] | [[2 Chron-36|2 Chronicles 36 →]]
***



###### v1 
Josiah kept a Passover to Yahweh in Jerusalem. They killed the Passover on the fourteenth day of the first month. 

###### v2 
He set the priests in their offices, and encouraged them in the service of Yahweh's house. 

###### v3 
He said to the Levites who taught all Israel, who were holy to Yahweh, "Put the holy ark in the house which Solomon the son of David king of Israel built. It will no longer be a burden on your shoulders. Now serve Yahweh your God, and his people Israel. 

###### v4 
Prepare yourselves after your fathers' houses by your divisions, according to the writing of David king of Israel, and according to the writing of Solomon his son. 

###### v5 
Stand in the holy place according to the divisions of the fathers' houses of your brothers the children of the people, and let there be for each a portion of a fathers' house of the Levites. 

###### v6 
Kill the Passover, sanctify yourselves, and prepare for your brothers, to do according to Yahweh's word by Moses." 

###### v7 
Josiah gave to the children of the people, of the flock, lambs and young goats, all of them for the Passover offerings, to all who were present, to the number of thirty thousand, and three thousand bulls. These were of the king's substance. 

###### v8 
His princes gave a free will offering to the people, to the priests, and to the Levites. Hilkiah, Zechariah, and Jehiel, the rulers of God's house, gave to the priests for the Passover offerings two thousand six hundred small livestock, and three hundred head of cattle. 

###### v9 
Conaniah also, and Shemaiah and Nethanel, his brothers, and Hashabiah, Jeiel, and Jozabad, the chiefs of the Levites, gave to the Levites for the Passover offerings five thousand small livestock and five hundred head of cattle. 

###### v10 
So the service was prepared, and the priests stood in their place, and the Levites by their divisions, according to the king's commandment. 

###### v11 
They killed the Passover, and the priests sprinkled the blood which they received of their hand, and the Levites skinned them. 

###### v12 
They removed the burnt offerings, that they might give them according to the divisions of the fathers' houses of the children of the people, to offer to Yahweh, as it is written in the book of Moses. They did the same with the cattle. 

###### v13 
They roasted the Passover with fire according to the ordinance. They boiled the holy offerings in pots, in cauldrons, and in pans, and carried them quickly to all the children of the people. 

###### v14 
Afterward they prepared for themselves and for the priests, because the priests the sons of Aaron were busy with offering the burnt offerings and the fat until night. Therefore the Levites prepared for themselves and for the priests the sons of Aaron. 

###### v15 
The singers the sons of Asaph were in their place, according to the commandment of David, Asaph, Heman, and Jeduthun the king's seer; and the gatekeepers were at every gate. They didn't need to depart from their service, because their brothers the Levites prepared for them. 

###### v16 
So all the service of Yahweh was prepared the same day, to keep the Passover, and to offer burnt offerings on Yahweh's altar, according to the commandment of king Josiah. 

###### v17 
The children of Israel who were present kept the Passover at that time, and the feast of unleavened bread seven days. 

###### v18 
There was no Passover like that kept in Israel from the days of Samuel the prophet, nor did any of the kings of Israel keep such a Passover as Josiah kept, with the priests, the Levites, and all Judah and Israel who were present, and the inhabitants of Jerusalem. 

###### v19 
This Passover was kept in the eighteenth year of the reign of Josiah. 

###### v20 
After all this, when Josiah had prepared the temple, Neco king of Egypt went up to fight against Carchemish by the Euphrates, and Josiah went out against him. 

###### v21 
But he sent ambassadors to him, saying, "What have I to do with you, you king of Judah? I come not against you today, but against the house with which I have war. God has commanded me to make haste. Beware that it is God who is with me, that he not destroy you." 

###### v22 
Nevertheless Josiah would not turn his face from him, but disguised himself, that he might fight with him, and didn't listen to the words of Neco from the mouth of God, and came to fight in the valley of Megiddo. 

###### v23 
The archers shot at king Josiah; and the king said to his servants, "Take me away, because I am seriously wounded!" 

###### v24 
So his servants took him out of the chariot, and put him in the second chariot that he had, and brought him to Jerusalem; and he died, and was buried in the tombs of his fathers. All Judah and Jerusalem mourned for Josiah. 

###### v25 
Jeremiah lamented for Josiah, and all the singing men and singing women spoke of Josiah in their lamentations to this day; and they made them an ordinance in Israel. Behold, they are written in the lamentations. 

###### v26 
Now the rest of the acts of Josiah, and his good deeds, according to that which is written in Yahweh's law, 

###### v27 
and his acts, first and last, behold, they are written in the book of the kings of Israel and Judah.

***
[[2 Chron-34|← 2 Chronicles 34]] | [[2 Chronicles]] | [[2 Chron-36|2 Chronicles 36 →]]
