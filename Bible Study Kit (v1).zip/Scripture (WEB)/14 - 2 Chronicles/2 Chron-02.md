# 2 Chronicles 2

[[2 Chron-01|← 2 Chronicles 01]] | [[2 Chronicles]] | [[2 Chron-03|2 Chronicles 03 →]]
***



###### v1 
Now Solomon decided to build a house for Yahweh's name, and a house for his kingdom. 

###### v2 
Solomon counted out seventy thousand men to bear burdens, eighty thousand men who were stone cutters in the mountains, and three thousand six hundred to oversee them. 

###### v3 
Solomon sent to Huram the king of Tyre, saying, "As you dealt with David my father, and sent him cedars to build him a house in which to dwell, so deal with me. 

###### v4 
Behold, I am about to build a house for the name of Yahweh my God, to dedicate it to him, to burn before him incense of sweet spices, for the continual show bread, and for the burnt offerings morning and evening, on the Sabbaths, on the new moons, and on the set feasts of Yahweh our God. This is an ordinance forever to Israel. 

###### v5 
"The house which I am building will be great; for our God is greater than all gods. 

###### v6 
But who is able to build him a house, since heaven and the heaven of heavens can't contain him? Who am I then, that I should build him a house, except just to burn incense before him? 

###### v7 
"Now therefore send me a man skillful to work in gold, in silver, in bronze, in iron, and in purple, crimson, and blue, and who knows how to engrave engravings, to be with the skillful men who are with me in Judah and in Jerusalem, whom David my father provided. 

###### v8 
"Send me also cedar trees, cypress trees, and algum trees out of Lebanon; for I know that your servants know how to cut timber in Lebanon. Behold, my servants will be with your servants, 

###### v9 
even to prepare me timber in abundance; for the house which I am about to build will be great and wonderful. 

###### v10 
Behold, I will give to your servants, the cutters who cut timber, twenty thousand cors of beaten wheat, twenty thousand baths of barley, twenty thousand baths of wine, and twenty thousand baths of oil." 

###### v11 
Then Huram the king of Tyre answered in writing, which he sent to Solomon, "Because Yahweh loves his people, he has made you king over them." 

###### v12 
Huram continued, "Blessed be Yahweh, the God of Israel, who made heaven and earth, who has given to David the king a wise son, endowed with discretion and understanding, who would build a house for Yahweh, and a house for his kingdom. 

###### v13 
Now I have sent a skillful man, endowed with understanding, Huram-abi, 

###### v14 
the son of a woman of the daughters of Dan; and his father was a man of Tyre, skillful to work in gold, in silver, in bronze, in iron, in stone, in timber, and in purple, in blue, in fine linen, and in crimson, also to engrave any kind of engraving and to devise any device; that there may be a place appointed to him with your skillful men, and with the skillful men of my lord David your father. 

###### v15 
"Now therefore the wheat, the barley, the oil, and the wine, which my lord has spoken of, let him send to his servants; 

###### v16 
and we will cut wood out of Lebanon, as much as you need. We will bring it to you in rafts by sea to Joppa; then you shall carry it up to Jerusalem." 

###### v17 
Solomon counted all the foreigners who were in the land of Israel, after the census with which David his father had counted them; and they found one hundred fifty-three thousand six hundred. 

###### v18 
He set seventy thousand of them to bear burdens, eighty thousand who were stone cutters in the mountains, and three thousand six hundred overseers to assign the people their work.

***
[[2 Chron-01|← 2 Chronicles 01]] | [[2 Chronicles]] | [[2 Chron-03|2 Chronicles 03 →]]
