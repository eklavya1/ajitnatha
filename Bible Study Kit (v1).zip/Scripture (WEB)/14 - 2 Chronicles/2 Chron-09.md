# 2 Chronicles 9

[[2 Chron-08|← 2 Chronicles 08]] | [[2 Chronicles]] | [[2 Chron-10|2 Chronicles 10 →]]
***



###### v1 
When the queen of Sheba heard of the fame of Solomon, she came to test Solomon with hard questions at Jerusalem, with a very great caravan, including camels that bore spices, gold in abundance, and precious stones. When she had come to Solomon, she talked with him about all that was in her heart. 

###### v2 
Solomon answered all her questions. There wasn't anything hidden from Solomon which he didn't tell her. 

###### v3 
When the queen of Sheba had seen the wisdom of Solomon, the house that he had built, 

###### v4 
the food of his table, the seating of his servants, the attendance of his ministers, their clothing, his cup bearers also, their clothing, and his ascent by which he went up to Yahweh's house; there was no more spirit in her. 

###### v5 
She said to the king, "It was a true report that I heard in my own land of your acts and of your wisdom. 

###### v6 
However I didn't believe their words until I came, and my eyes had seen it; and behold half of the greatness of your wisdom wasn't told me. You exceed the fame that I heard! 

###### v7 
Happy are your men, and happy are these your servants, who stand continually before you, and hear your wisdom. 

###### v8 
Blessed be Yahweh your God, who delighted in you, to set you on his throne, to be king for Yahweh your God; because your God loved Israel, to establish them forever. Therefore he made you king over them, to do justice and righteousness." 

###### v9 
She gave the king one hundred and twenty talents of gold, spices in great abundance, and precious stones. There was never before such spice as the queen of Sheba gave to king Solomon. 

###### v10 
The servants of Huram and the servants of Solomon, who brought gold from Ophir, also brought algum trees and precious stones. 

###### v11 
The king used algum tree wood to make terraces for Yahweh's house and for the king's house, and harps and stringed instruments for the singers. There were none like these seen before in the land of Judah. 

###### v12 
King Solomon gave to the queen of Sheba all her desire, whatever she asked, in addition to that which she had brought to the king. So she turned, and went to her own land, she and her servants. 

###### v13 
Now the weight of gold that came to Solomon in one year was six hundred sixty-six talents of gold, 

###### v14 
in addition to that which the traders and merchants brought. All the kings of Arabia and the governors of the country brought gold and silver to Solomon. 

###### v15 
King Solomon made two hundred bucklers of beaten gold. Six hundred shekels of beaten gold went to one buckler. 

###### v16 
He made three hundred shields of beaten gold. Three hundred shekels of gold went to one shield. The king put them in the House of the Forest of Lebanon. 

###### v17 
Moreover the king made a great throne of ivory, and overlaid it with pure gold. 

###### v18 
There were six steps to the throne, with a footstool of gold, which were fastened to the throne, and armrests on either side by the place of the seat, and two lions standing beside the armrests. 

###### v19 
Twelve lions stood there on the one side and on the other on the six steps. There was nothing like it made in any other kingdom. 

###### v20 
All king Solomon's drinking vessels were of gold, and all the vessels of the House of the Forest of Lebanon were of pure gold. Silver was not considered valuable in the days of Solomon. 

###### v21 
For the king had ships that went to Tarshish with Huram's servants. Once every three years, the ships of Tarshish came bringing gold, silver, ivory, apes, and peacocks. 

###### v22 
So king Solomon exceeded all the kings of the earth in riches and wisdom. 

###### v23 
All the kings of the earth sought the presence of Solomon, to hear his wisdom, which God had put in his heart. 

###### v24 
They each brought tribute, vessels of silver, vessels of gold, clothing, armor, spices, horses, and mules every year. 

###### v25 
Solomon had four thousand stalls for horses and chariots, and twelve thousand horsemen, that he stationed in the chariot cities, and with the king at Jerusalem. 

###### v26 
He ruled over all the kings from the River even to the land of the Philistines, and to the border of Egypt. 

###### v27 
The king made silver as common in Jerusalem as stones, and he made cedars to be as abundant as the sycamore trees that are in the lowland. 

###### v28 
They brought horses for Solomon out of Egypt and out of all lands. 

###### v29 
Now the rest of the acts of Solomon, first and last, aren't they written in the history of Nathan the prophet, and in the prophecy of Ahijah the Shilonite, and in the visions of Iddo the seer concerning Jeroboam the son of Nebat? 

###### v30 
Solomon reigned in Jerusalem over all Israel forty years. 

###### v31 
Solomon slept with his fathers, and he was buried in his father David's city: and Rehoboam his son reigned in his place.

***
[[2 Chron-08|← 2 Chronicles 08]] | [[2 Chronicles]] | [[2 Chron-10|2 Chronicles 10 →]]
