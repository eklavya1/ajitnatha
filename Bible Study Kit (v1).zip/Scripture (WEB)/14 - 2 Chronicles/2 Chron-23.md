# 2 Chronicles 23

[[2 Chron-22|← 2 Chronicles 22]] | [[2 Chronicles]] | [[2 Chron-24|2 Chronicles 24 →]]
***



###### v1 
In the seventh year, Jehoiada strengthened himself, and took the captains of hundreds, Azariah the son of Jeroham, Ishmael the son of Jehohanan, Azariah the son of Obed, Maaseiah the son of Adaiah, and Elishaphat the son of Zichri, into a covenant with him. 

###### v2 
They went around in Judah, and gathered the Levites out of all the cities of Judah, and the heads of fathers' households of Israel, and they came to Jerusalem. 

###### v3 
All the assembly made a covenant with the king in God's house. He said to them, "Behold, the king's son must reign, as Yahweh has spoken concerning the sons of David. 

###### v4 
This is the thing that you must do. A third part of you, who come in on the Sabbath, of the priests and of the Levites, shall be gatekeepers of the thresholds. 

###### v5 
A third part shall be at the king's house; and a third part at the gate of the foundation. All the people will be in the courts of Yahweh's house. 

###### v6 
But let no one come into Yahweh's house, except the priests and those who minister of the Levites. They shall come in, for they are holy, but all the people shall follow Yahweh's instructions. 

###### v7 
The Levites shall surround the king, every man with his weapons in his hand. Whoever comes into the house, let him be slain. Be with the king when he comes in, and when he goes out." 

###### v8 
So the Levites and all Judah did according to all that Jehoiada the priest commanded: and they each took his men, those who were to come in on the Sabbath; with those who were to go out on the Sabbath; for Jehoiada the priest didn't dismiss the shift. 

###### v9 
Jehoiada the priest delivered to the captains of hundreds the spears, and bucklers, and shields, that had been king David's, which were in God's house. 

###### v10 
He set all the people, every man with his weapon in his hand, from the right side of the house to the left side of the house, near the altar and the house, around the king. 

###### v11 
Then they brought out the king's son, and put the crown on him, and gave him the covenant, and made him king. Jehoiada and his sons anointed him, and they said, "Long live the king!" 

###### v12 
When Athaliah heard the noise of the people running and praising the king, she came to the people into Yahweh's house. 

###### v13 
Then she looked, and, behold, the king stood by his pillar at the entrance, and the captains and the trumpets by the king. All the people of the land rejoiced, and blew trumpets. The singers also played musical instruments, and led the singing of praise. Then Athaliah tore her clothes, and said, "Treason! treason!" 

###### v14 
Jehoiada the priest brought out the captains of hundreds who were set over the army, and said to them, "Bring her out between the ranks; and whoever follows her, let him be slain with the sword." For the priest said, "Don't kill her in Yahweh's house." 

###### v15 
So they made way for her. She went to the entrance of the horse gate to the king's house; and they killed her there. 

###### v16 
Jehoiada made a covenant between himself, all the people, and the king, that they should be Yahweh's people. 

###### v17 
All the people went to the house of Baal, broke it down, broke his altars and his images in pieces, and killed Mattan the priest of Baal before the altars. 

###### v18 
Jehoiada appointed the officers of Yahweh's house under the hand of the Levitical priests, whom David had distributed in Yahweh's house, to offer the burnt offerings of Yahweh, as it is written in the law of Moses, with rejoicing and with singing, as David had ordered. 

###### v19 
He set the gatekeepers at the gates of Yahweh's house, that no one who was unclean in anything should enter in. 

###### v20 
He took the captains of hundreds, the nobles, the governors of the people, and all the people of the land, and brought the king down from Yahweh's house. They came through the upper gate to the king's house, and set the king on the throne of the kingdom. 

###### v21 
So all the people of the land rejoiced, and the city was quiet. They had slain Athaliah with the sword.

***
[[2 Chron-22|← 2 Chronicles 22]] | [[2 Chronicles]] | [[2 Chron-24|2 Chronicles 24 →]]
