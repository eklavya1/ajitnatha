# 2 Chronicles 33

[[2 Chron-32|← 2 Chronicles 32]] | [[2 Chronicles]] | [[2 Chron-34|2 Chronicles 34 →]]
***



###### v1 
Manasseh was twelve years old when he began to reign, and he reigned fifty-five years in Jerusalem. 

###### v2 
He did that which was evil in Yahweh's sight, after the abominations of the nations whom Yahweh cast out before the children of Israel. 

###### v3 
For he built again the high places which Hezekiah his father had broken down; and he raised up altars for the Baals, made Asheroth, and worshiped all the army of the sky, and served them. 

###### v4 
He built altars in Yahweh's house, of which Yahweh said, "My name shall be in Jerusalem forever." 

###### v5 
He built altars for all the army of the sky in the two courts of Yahweh's house. 

###### v6 
He also made his children to pass through the fire in the valley of the son of Hinnom. He practiced sorcery, divination, and witchcraft, and dealt with those who had familiar spirits and with wizards. He did much evil in Yahweh's sight, to provoke him to anger. 

###### v7 
He set the engraved image of the idol, which he had made, in God's house, of which God said to David and to Solomon his son, "In this house, and in Jerusalem, which I have chosen out of all the tribes of Israel, I will put my name forever. 

###### v8 
I will not any more remove the foot of Israel from off the land which I have appointed for your fathers, if only they will observe to do all that I have commanded them, even all the law, the statutes, and the ordinances given by Moses." 

###### v9 
Manasseh seduced Judah and the inhabitants of Jerusalem, so that they did more evil than did the nations whom Yahweh destroyed before the children of Israel. 

###### v10 
Yahweh spoke to Manasseh, and to his people; but they didn't listen. 

###### v11 
Therefore Yahweh brought on them the captains of the army of the king of Assyria, who took Manasseh in chains, bound him with fetters, and carried him to Babylon. 

###### v12 
When he was in distress, he begged Yahweh his God, and humbled himself greatly before the God of his fathers. 

###### v13 
He prayed to him; and he was entreated by him, and heard his supplication, and brought him again to Jerusalem into his kingdom. Then Manasseh knew that Yahweh was God. 

###### v14 
Now after this, he built an outer wall to David's city, on the west side of Gihon, in the valley, even to the entrance at the fish gate. He encircled Ophel with it, and raised it up to a very great height; and he put valiant captains in all the fortified cities of Judah. 

###### v15 
He took away the foreign gods, and the idol out of Yahweh's house, and all the altars that he had built in the mountain of Yahweh's house, and in Jerusalem, and cast them out of the city. 

###### v16 
He built up Yahweh's altar, and offered sacrifices of peace offerings and of thanksgiving on it, and commanded Judah to serve Yahweh, the God of Israel. 

###### v17 
Nevertheless the people sacrificed still in the high places, but only to Yahweh their God. 

###### v18 
Now the rest of the acts of Manasseh, and his prayer to his God, and the words of the seers who spoke to him in the name of Yahweh, the God of Israel, behold, they are written among the acts of the kings of Israel. 

###### v19 
His prayer also, and how God was entreated of him, and all his sin and his trespass, and the places in which he built high places, and set up the Asherah poles and the engraved images, before he humbled himself: behold, they are written in the history of Hozai. 

###### v20 
So Manasseh slept with his fathers, and they buried him in his own house; and Amon his son reigned in his place. 

###### v21 
Amon was twenty-two years old when he began to reign; and he reigned two years in Jerusalem. 

###### v22 
He did that which was evil in Yahweh's sight, as did Manasseh his father; and Amon sacrificed to all the engraved images which Manasseh his father had made, and served them. 

###### v23 
He didn't humble himself before Yahweh, as Manasseh his father had humbled himself; but this same Amon trespassed more and more. 

###### v24 
His servants conspired against him, and put him to death in his own house. 

###### v25 
But the people of the land killed all those who had conspired against king Amon; and the people of the land made Josiah his son king in his place.

***
[[2 Chron-32|← 2 Chronicles 32]] | [[2 Chronicles]] | [[2 Chron-34|2 Chronicles 34 →]]
