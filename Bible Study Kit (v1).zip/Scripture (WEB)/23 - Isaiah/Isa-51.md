# Isaiah 51

[[Isa-50|← Isaiah 50]] | [[Isaiah]] | [[Isa-52|Isaiah 52 →]]
***



###### v1 
"Listen to me, you who follow after righteousness, you who seek Yahweh. Look to the rock you were cut from, and to the quarry you were dug from. 

###### v2 
Look to Abraham your father, and to Sarah who bore you; for when he was but one I called him, I blessed him, and made him many. 

###### v3 
For Yahweh has comforted Zion. He has comforted all her waste places, and has made her wilderness like Eden, and her desert like the garden of Yahweh. Joy and gladness will be found in them, thanksgiving, and the voice of melody. 

###### v4 
"Listen to me, my people; and hear me, my nation, for a law will go out from me, and I will establish my justice for a light to the peoples. 

###### v5 
My righteousness is near. My salvation has gone out, and my arms will judge the peoples. The islands will wait for me, and they will trust my arm. 

###### v6 
Lift up your eyes to the heavens, and look at the earth beneath; for the heavens will vanish away like smoke, and the earth will wear out like a garment. Its inhabitants will die in the same way, but my salvation will be forever, and my righteousness will not be abolished. 

###### v7 
"Listen to me, you who know righteousness, the people in whose heart is my law. Don't fear the reproach of men, and don't be dismayed at their insults. 

###### v8 
For the moth will eat them up like a garment, and the worm will eat them like wool; but my righteousness will be forever, and my salvation to all generations." 

###### v9 
Awake, awake, put on strength, arm of Yahweh! Awake, as in the days of old, the generations of ancient times. Isn't it you who cut Rahab in pieces, who pierced the monster? 

###### v10 
Isn't it you who dried up the sea, the waters of the great deep; who made the depths of the sea a way for the redeemed to pass over? 

###### v11 
Those ransomed by Yahweh will return, and come with singing to Zion. Everlasting joy shall be on their heads. They will obtain gladness and joy. Sorrow and sighing shall flee away. 

###### v12 
"I, even I, am he who comforts you. Who are you, that you are afraid of man who shall die, and of the son of man who will be made as grass? 

###### v13 
Have you forgotten Yahweh your Maker, who stretched out the heavens, and laid the foundations of the earth? Do you live in fear continually all day because of the fury of the oppressor, when he prepares to destroy? Where is the fury of the oppressor? 

###### v14 
The captive exile will speedily be freed. He will not die and go down into the pit. His bread won't fail. 

###### v15 
For I am Yahweh your God, who stirs up the sea so that its waves roar. Yahweh of Armies is his name. 

###### v16 
I have put my words in your mouth and have covered you in the shadow of my hand, that I may plant the heavens, and lay the foundations of the earth, and tell Zion, 'You are my people.'" 

###### v17 
Awake, awake! Stand up, Jerusalem, you who have drunk from Yahweh's hand the cup of his wrath. You have drunken the bowl of the cup of staggering, and drained it. 

###### v18 
There is no one to guide her among all the sons to whom she has given birth; and there is no one who takes her by the hand among all the sons whom she has brought up. 

###### v19 
These two things have happened to you-- who will grieve with you?-- desolation and destruction, and famine and the sword. How can I comfort you? 

###### v20 
Your sons have fainted. They lie at the head of all the streets, like an antelope in a net. They are full of Yahweh's wrath, the rebuke of your God. 

###### v21 
Therefore now hear this, you afflicted, and drunken, but not with wine: 

###### v22 
Your Lord Yahweh, your God who pleads the cause of his people, says, "Behold, I have taken out of your hand the cup of staggering, even the bowl of the cup of my wrath. You will not drink it any more. 

###### v23 
I will put it into the hand of those who afflict you, who have said to your soul, 'Bow down, that we may walk over you;' and you have laid your back as the ground, like a street to those who walk over."

***
[[Isa-50|← Isaiah 50]] | [[Isaiah]] | [[Isa-52|Isaiah 52 →]]
