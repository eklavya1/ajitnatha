# Isaiah 56

[[Isa-55|← Isaiah 55]] | [[Isaiah]] | [[Isa-57|Isaiah 57 →]]
***



###### v1 
Yahweh says, "Maintain justice and do what is right, for my salvation is near and my righteousness will soon be revealed. 

###### v2 
Blessed is the man who does this, and the son of man who holds it fast; who keeps the Sabbath without profaning it and keeps his hand from doing any evil." 

###### v3 
Let no foreigner who has joined himself to Yahweh speak, saying, "Yahweh will surely separate me from his people." Do not let the eunuch say, "Behold, I am a dry tree." 

###### v4 
For Yahweh says, "To the eunuchs who keep my Sabbaths, choose the things that please me, and hold fast to my covenant, 

###### v5 
I will give them in my house and within my walls a memorial and a name better than of sons and of daughters. I will give them an everlasting name that will not be cut off. 

###### v6 
Also the foreigners who join themselves to Yahweh to serve him, and to love Yahweh's name, to be his servants, everyone who keeps the Sabbath from profaning it, and holds fast my covenant, 

###### v7 
I will bring these to my holy mountain, and make them joyful in my house of prayer. Their burnt offerings and their sacrifices will be accepted on my altar; for my house will be called a house of prayer for all peoples." 

###### v8 
The Lord Yahweh, who gathers the outcasts of Israel, says, "I will yet gather others to him, in addition to his own who are gathered." 

###### v9 
All you animals of the field, come to devour, all you animals in the forest. 

###### v10 
His watchmen are blind. They are all without knowledge. They are all mute dogs. They can't bark-- dreaming, lying down, loving to slumber. 

###### v11 
Yes, the dogs are greedy. They can never have enough. They are shepherds who can't understand. They have all turned to their own way, each one to his gain, from every quarter. 

###### v12 
"Come," they say, "I will get wine, and we will fill ourselves with strong drink; and tomorrow will be as today, great beyond measure."

***
[[Isa-55|← Isaiah 55]] | [[Isaiah]] | [[Isa-57|Isaiah 57 →]]
