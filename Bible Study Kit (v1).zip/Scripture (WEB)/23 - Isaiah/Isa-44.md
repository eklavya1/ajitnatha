# Isaiah 44

[[Isa-43|← Isaiah 43]] | [[Isaiah]] | [[Isa-45|Isaiah 45 →]]
***



###### v1 
Yet listen now, Jacob my servant, and Israel, whom I have chosen. 

###### v2 
This is what Yahweh who made you, and formed you from the womb, who will help you says: "Don't be afraid, Jacob my servant; and you, Jeshurun, whom I have chosen. 

###### v3 
For I will pour water on him who is thirsty, and streams on the dry ground. I will pour my Spirit on your descendants, and my blessing on your offspring: 

###### v4 
and they will spring up among the grass, as willows by the watercourses. 

###### v5 
One will say, 'I am Yahweh's;' and another will be called by the name of Jacob; and another will write with his hand 'to Yahweh,' and honor the name of Israel." 

###### v6 
This is what Yahweh, the King of Israel, and his Redeemer, Yahweh of Armies, says: "I am the first, and I am the last; and besides me there is no God. 

###### v7 
Who is like me? Who will call, and will declare it, and set it in order for me, since I established the ancient people? Let them declare the things that are coming, and that will happen. 

###### v8 
Don't fear, neither be afraid. Haven't I declared it to you long ago, and shown it? You are my witnesses. Is there a God besides me? Indeed, there is not. I don't know any other Rock." 

###### v9 
Everyone who makes a carved image is vain. The things that they delight in will not profit. Their own witnesses don't see, nor know, that they may be disappointed. 

###### v10 
Who has fashioned a god, or molds an image that is profitable for nothing? 

###### v11 
Behold, all his fellows will be disappointed; and the workmen are mere men. Let them all be gathered together. Let them stand up. They will fear. They will be put to shame together. 

###### v12 
The blacksmith takes an ax, works in the coals, fashions it with hammers, and works it with his strong arm. He is hungry, and his strength fails; he drinks no water, and is faint. 

###### v13 
The carpenter stretches out a line. He marks it out with a pencil. He shapes it with planes. He marks it out with compasses, and shapes it like the figure of a man, with the beauty of a man, to reside in a house. 

###### v14 
He cuts down cedars for himself, and takes the cypress and the oak, and strengthens for himself one among the trees of the forest. He plants a cypress tree, and the rain nourishes it. 

###### v15 
Then it will be for a man to burn; and he takes some of it, and warms himself. Yes, he burns it, and bakes bread. Yes, he makes a god, and worships it; he makes it a carved image, and falls down to it. 

###### v16 
He burns part of it in the fire. With part of it, he eats meat. He roasts a roast, and is satisfied. Yes, he warms himself, and says, "Aha! I am warm. I have seen the fire." 

###### v17 
The rest of it he makes into a god, even his engraved image. He bows down to it and worships, and prays to it, and says, "Deliver me; for you are my god!" 

###### v18 
They don't know, neither do they consider: for he has shut their eyes, that they can't see; and their hearts, that they can't understand. 

###### v19 
No one thinks, neither is there knowledge nor understanding to say, "I have burned part of it in the fire. Yes, I have also baked bread on its coals. I have roasted meat and eaten it. Shall I make the rest of it into an abomination? Shall I bow down to a tree trunk?" 

###### v20 
He feeds on ashes. A deceived heart has turned him aside; and he can't deliver his soul, nor say, "Isn't there a lie in my right hand?" 

###### v21 
Remember these things, Jacob and Israel; for you are my servant. I have formed you. You are my servant. Israel, you will not be forgotten by me. 

###### v22 
I have blotted out, as a thick cloud, your transgressions, and, as a cloud, your sins. Return to me, for I have redeemed you. 

###### v23 
Sing, you heavens, for Yahweh has done it! Shout, you lower parts of the earth! Break out into singing, you mountains, O forest, all of your trees, for Yahweh has redeemed Jacob, and will glorify himself in Israel. 

###### v24 
Yahweh, your Redeemer, and he who formed you from the womb says: "I am Yahweh, who makes all things; who alone stretches out the heavens; who spreads out the earth by myself; 

###### v25 
who frustrates the signs of the liars, and makes diviners mad; who turns wise men backward, and makes their knowledge foolish; 

###### v26 
who confirms the word of his servant, and performs the counsel of his messengers; who says of Jerusalem, 'She will be inhabited;' and of the cities of Judah, 'They will be built,' and 'I will raise up its waste places;' 

###### v27 
who says to the deep, 'Be dry,' and 'I will dry up your rivers;' 

###### v28 
Who says of Cyrus, 'He is my shepherd, and shall perform all my pleasure,' even saying of Jerusalem, 'She will be built;' and of the temple, 'Your foundation will be laid.'"

***
[[Isa-43|← Isaiah 43]] | [[Isaiah]] | [[Isa-45|Isaiah 45 →]]
