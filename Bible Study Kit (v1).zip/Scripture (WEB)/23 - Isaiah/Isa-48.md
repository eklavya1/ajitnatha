# Isaiah 48

[[Isa-47|← Isaiah 47]] | [[Isaiah]] | [[Isa-49|Isaiah 49 →]]
***



###### v1 
"Hear this, house of Jacob, you who are called by the name of Israel, and have come out of the waters of Judah. You swear by Yahweh's name, and make mention of the God of Israel, but not in truth, nor in righteousness-- 

###### v2 
for they call themselves citizens of the holy city, and rely on the God of Israel; Yahweh of Armies is his name. 

###### v3 
I have declared the former things from of old. Yes, they went out of my mouth, and I revealed them. I did them suddenly, and they happened. 

###### v4 
Because I knew that you are obstinate, and your neck is an iron sinew, and your brow bronze; 

###### v5 
therefore I have declared it to you from of old; before it came to pass I showed it to you; lest you should say, 'My idol has done them. My engraved image and my molten image has commanded them.' 

###### v6 
You have heard it. Now see all this. And you, won't you declare it? "I have shown you new things from this time, even hidden things, which you have not known. 

###### v7 
They are created now, and not from of old. Before today, you didn't hear them, lest you should say, 'Behold, I knew them.' 

###### v8 
Yes, you didn't hear. Yes, you didn't know. Yes, from of old your ear was not opened, for I knew that you dealt very treacherously, and were called a transgressor from the womb. 

###### v9 
For my name's sake, I will defer my anger, and for my praise, I hold it back for you so that I don't cut you off. 

###### v10 
Behold, I have refined you, but not as silver. I have chosen you in the furnace of affliction. 

###### v11 
For my own sake, for my own sake, I will do it; for how would my name be profaned? I will not give my glory to another. 

###### v12 
"Listen to me, O Jacob, and Israel my called: I am he. I am the first. I am also the last. 

###### v13 
Yes, my hand has laid the foundation of the earth, and my right hand has spread out the heavens. when I call to them, they stand up together. 

###### v14 
"Assemble yourselves, all of you, and hear! Who among them has declared these things? He whom Yahweh loves will do what he likes to Babylon, and his arm will be against the Chaldeans. 

###### v15 
I, even I, have spoken. Yes, I have called him. I have brought him and he shall make his way prosperous. 

###### v16 
"Come near to me and hear this: "From the beginning I have not spoken in secret; from the time that it happened, I was there." Now the Lord Yahweh has sent me with his Spirit. 

###### v17 
Yahweh, your Redeemer, the Holy One of Israel says: "I am Yahweh your God, who teaches you to profit, who leads you by the way that you should go. 

###### v18 
Oh that you had listened to my commandments! Then your peace would have been like a river and your righteousness like the waves of the sea. 

###### v19 
Your offspring also would have been as the sand and the descendants of your body like its grains. His name would not be cut off nor destroyed from before me." 

###### v20 
Leave Babylon! Flee from the Chaldeans! With a voice of singing announce this, tell it even to the end of the earth: say, "Yahweh has redeemed his servant Jacob!" 

###### v21 
They didn't thirst when he led them through the deserts. He caused the waters to flow out of the rock for them. He also split the rock and the waters gushed out. 

###### v22 
"There is no peace", says Yahweh, "for the wicked."

***
[[Isa-47|← Isaiah 47]] | [[Isaiah]] | [[Isa-49|Isaiah 49 →]]
