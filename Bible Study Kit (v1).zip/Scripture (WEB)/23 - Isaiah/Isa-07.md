# Isaiah 7

[[Isa-06|← Isaiah 06]] | [[Isaiah]] | [[Isa-08|Isaiah 08 →]]
***



###### v1 
In the days of Ahaz the son of Jotham, the son of Uzziah, king of Judah, Rezin the king of Syria, and Pekah the son of Remaliah, king of Israel, went up to Jerusalem to war against it, but could not prevail against it. 

###### v2 
David's house was told, "Syria is allied with Ephraim." His heart trembled, and the heart of his people, as the trees of the forest tremble with the wind. 

###### v3 
Then Yahweh said to Isaiah, "Go out now to meet Ahaz, you, and Shearjashub your son, at the end of the conduit of the upper pool, on the highway of the fuller's field. 

###### v4 
Tell him, 'Be careful, and keep calm. Don't be afraid, neither let your heart be faint because of these two tails of smoking torches, for the fierce anger of Rezin and Syria, and of the son of Remaliah. 

###### v5 
Because Syria, Ephraim, and the son of Remaliah, have plotted evil against you, saying, 

###### v6 
"Let's go up against Judah, and tear it apart, and let's divide it among ourselves, and set up a king within it, even the son of Tabeel." 

###### v7 
This is what the Lord Yahweh says: "It shall not stand, neither shall it happen." 

###### v8 
For the head of Syria is Damascus, and the head of Damascus is Rezin. Within sixty-five years Ephraim shall be broken in pieces, so that it shall not be a people. 

###### v9 
The head of Ephraim is Samaria, and the head of Samaria is Remaliah's son. If you will not believe, surely you shall not be established.'" 

###### v10 
Yahweh spoke again to Ahaz, saying, 

###### v11 
"Ask a sign of Yahweh your God; ask it either in the depth, or in the height above." 

###### v12 
But Ahaz said, "I won't ask. I won't tempt Yahweh." 

###### v13 
He said, "Listen now, house of David. Is it not enough for you to try the patience of men, that you will try the patience of my God also? 

###### v14 
Therefore the Lord himself will give you a sign. Behold, the virgin will conceive, and bear a son, and shall call his name Immanuel. 

###### v15 
He shall eat butter and honey when he knows to refuse the evil and choose the good. 

###### v16 
For before the child knows to refuse the evil and choose the good, the land whose two kings you abhor shall be forsaken. 

###### v17 
Yahweh will bring on you, on your people, and on your father's house, days that have not come, from the day that Ephraim departed from Judah, even the king of Assyria. 

###### v18 
It will happen in that day that Yahweh will whistle for the fly that is in the uttermost part of the rivers of Egypt, and for the bee that is in the land of Assyria. 

###### v19 
They shall come, and shall all rest in the desolate valleys, in the clefts of the rocks, on all thorn hedges, and on all pastures. 

###### v20 
In that day the Lord will shave with a razor that is hired in the parts beyond the River, even with the king of Assyria, the head and the hair of the feet; and it shall also consume the beard. 

###### v21 
It shall happen in that day that a man shall keep alive a young cow, and two sheep. 

###### v22 
It shall happen, that because of the abundance of milk which they shall give he shall eat butter; for everyone will eat butter and honey that is left within the land. 

###### v23 
It will happen in that day that every place where there were a thousand vines at a thousand silver shekels, shall be for briers and thorns. 

###### v24 
People will go there with arrows and with bow, because all the land will be briers and thorns. 

###### v25 
All the hills that were cultivated with the hoe, you shall not come there for fear of briers and thorns; but it shall be for the sending out of oxen, and for sheep to tread on."

***
[[Isa-06|← Isaiah 06]] | [[Isaiah]] | [[Isa-08|Isaiah 08 →]]
