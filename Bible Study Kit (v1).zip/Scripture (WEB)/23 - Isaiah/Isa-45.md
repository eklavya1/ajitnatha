# Isaiah 45

[[Isa-44|← Isaiah 44]] | [[Isaiah]] | [[Isa-46|Isaiah 46 →]]
***



###### v1 
Yahweh says to his anointed, to Cyrus, whose right hand I have held, to subdue nations before him, and strip kings of their armor; to open the doors before him, and the gates shall not be shut: 

###### v2 
"I will go before you and make the rough places smooth. I will break the doors of bronze in pieces and cut apart the bars of iron. 

###### v3 
I will give you the treasures of darkness and hidden riches of secret places, that you may know that it is I, Yahweh, who calls you by your name, even the God of Israel. 

###### v4 
For Jacob my servant's sake, and Israel my chosen, I have called you by your name. I have given you a title, though you have not known me. 

###### v5 
I am Yahweh, and there is no one else. Besides me, there is no God. I will strengthen you, though you have not known me, 

###### v6 
that they may know from the rising of the sun, and from the west, that there is no one besides me. I am Yahweh, and there is no one else. 

###### v7 
I form the light and create darkness. I make peace and create calamity. I am Yahweh, who does all these things. 

###### v8 
Rain, you heavens, from above, and let the skies pour down righteousness. Let the earth open, that it may produce salvation, and let it cause righteousness to spring up with it. I, Yahweh, have created it. 

###### v9 
Woe to him who strives with his Maker-- a clay pot among the clay pots of the earth! Shall the clay ask him who fashions it, 'What are you making?' or your work, 'He has no hands?' 

###### v10 
Woe to him who says to a father, 'What have you become the father of?' or to a mother, 'What have you given birth to?'" 

###### v11 
Yahweh, the Holy One of Israel and his Maker says: "You ask me about the things that are to come, concerning my sons, and you command me concerning the work of my hands! 

###### v12 
I have made the earth, and created man on it. I, even my hands, have stretched out the heavens. I have commanded all their army. 

###### v13 
I have raised him up in righteousness, and I will make all his ways straight. He shall build my city, and he shall let my exiles go free, not for price nor reward," says Yahweh of Armies. 

###### v14 
Yahweh says: "The labor of Egypt, and the merchandise of Ethiopia, and the Sabeans, men of stature, will come over to you, and they will be yours. They will go after you. They shall come over in chains. They will bow down to you. They will make supplication to you: 'Surely God is in you; and there is no one else. There is no other god. 

###### v15 
Most certainly you are a God who has hidden yourself, God of Israel, the Savior.'" 

###### v16 
They will be disappointed, yes, confounded, all of them. Those who are makers of idols will go into confusion together. 

###### v17 
Israel will be saved by Yahweh with an everlasting salvation. You will not be disappointed nor confounded to ages everlasting. 

###### v18 
For Yahweh who created the heavens, the God who formed the earth and made it, who established it and didn't create it a waste, who formed it to be inhabited says: "I am Yahweh. There is no other. 

###### v19 
I have not spoken in secret, in a place of the land of darkness. I didn't say to the offspring of Jacob, 'Seek me in vain.' I, Yahweh, speak righteousness. I declare things that are right. 

###### v20 
"Assemble yourselves and come. Draw near together, you who have escaped from the nations. Those have no knowledge who carry the wood of their engraved image, and pray to a god that can't save. 

###### v21 
Declare and present it. Yes, let them take counsel together. Who has shown this from ancient time? Who has declared it of old? Haven't I, Yahweh? There is no other God besides me, a just God and a Savior. There is no one besides me. 

###### v22 
"Look to me, and be saved, all the ends of the earth; for I am God, and there is no other. 

###### v23 
I have sworn by myself. The word has gone out of my mouth in righteousness, and will not be revoked, that to me every knee shall bow, every tongue shall take an oath. 

###### v24 
They will say of me, 'There is righteousness and strength only in Yahweh.'" Even to him will men come. All those who raged against him will be disappointed. 

###### v25 
All the offspring of Israel will be justified in Yahweh, and will rejoice!

***
[[Isa-44|← Isaiah 44]] | [[Isaiah]] | [[Isa-46|Isaiah 46 →]]
