# Isaiah 53

[[Isa-52|← Isaiah 52]] | [[Isaiah]] | [[Isa-54|Isaiah 54 →]]
***



###### v1 
Who has believed our message? To whom has Yahweh's arm been revealed? 

###### v2 
For he grew up before him as a tender plant, and as a root out of dry ground. He has no good looks or majesty. When we see him, there is no beauty that we should desire him. 

###### v3 
He was despised and rejected by men, a man of suffering and acquainted with disease. He was despised as one from whom men hide their face; and we didn't respect him. 

###### v4 
Surely he has borne our sickness and carried our suffering; yet we considered him plagued, struck by God, and afflicted. 

###### v5 
But he was pierced for our transgressions. He was crushed for our iniquities. The punishment that brought our peace was on him; and by his wounds we are healed. 

###### v6 
All we like sheep have gone astray. Everyone has turned to his own way; and Yahweh has laid on him the iniquity of us all. 

###### v7 
He was oppressed, yet when he was afflicted he didn't open his mouth. As a lamb that is led to the slaughter, and as a sheep that before its shearers is silent, so he didn't open his mouth. 

###### v8 
He was taken away by oppression and judgment. As for his generation, who considered that he was cut off out of the land of the living and stricken for the disobedience of my people? 

###### v9 
They made his grave with the wicked, and with a rich man in his death, although he had done no violence, nor was any deceit in his mouth. 

###### v10 
Yet it pleased Yahweh to bruise him. He has caused him to suffer. When you make his soul an offering for sin, he will see his offspring. He will prolong his days and Yahweh's pleasure will prosper in his hand. 

###### v11 
After the suffering of his soul, he will see the light and be satisfied. My righteous servant will justify many by the knowledge of himself; and he will bear their iniquities. 

###### v12 
Therefore I will give him a portion with the great. He will divide the plunder with the strong; because he poured out his soul to death and was counted with the transgressors; yet he bore the sins of many and made intercession for the transgressors.

***
[[Isa-52|← Isaiah 52]] | [[Isaiah]] | [[Isa-54|Isaiah 54 →]]
