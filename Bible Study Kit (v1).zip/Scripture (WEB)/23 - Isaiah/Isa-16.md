# Isaiah 16

[[Isa-15|← Isaiah 15]] | [[Isaiah]] | [[Isa-17|Isaiah 17 →]]
***



###### v1 
Send the lambs for the ruler of the land from Selah to the wilderness, to the mountain of the daughter of Zion. 

###### v2 
For it will be that as wandering birds, as a scattered nest, so will the daughters of Moab be at the fords of the Arnon. 

###### v3 
Give counsel! Execute justice! Make your shade like the night in the middle of the noonday! Hide the outcasts! Don't betray the fugitive! 

###### v4 
Let my outcasts dwell with you! As for Moab, be a hiding place for him from the face of the destroyer. For the extortionist is brought to nothing. Destruction ceases. The oppressors are consumed out of the land. 

###### v5 
A throne will be established in loving kindness. One will sit on it in truth, in the tent of David, judging, seeking justice, and swift to do righteousness. 

###### v6 
We have heard of the pride of Moab, that he is very proud; even of his arrogance, his pride, and his wrath. His boastings are nothing. 

###### v7 
Therefore Moab will wail for Moab. Everyone will wail. You will mourn for the raisin cakes of Kir Hareseth, utterly stricken. 

###### v8 
For the fields of Heshbon languish with the vine of Sibmah. The lords of the nations have broken down its choice branches, which reached even to Jazer, which wandered into the wilderness. Its shoots were spread abroad. They passed over the sea. 

###### v9 
Therefore I will weep with the weeping of Jazer for the vine of Sibmah. I will water you with my tears, Heshbon, and Elealeh: for on your summer fruits and on your harvest the battle shout has fallen. 

###### v10 
Gladness is taken away, and joy out of the fruitful field; and in the vineyards there will be no singing, neither joyful noise. Nobody will tread out wine in the presses. I have made the shouting stop. 

###### v11 
Therefore my heart sounds like a harp for Moab, and my inward parts for Kir Heres. 

###### v12 
It will happen that when Moab presents himself, when he wearies himself on the high place, and comes to his sanctuary to pray, that he will not prevail. 

###### v13 
This is the word that Yahweh spoke concerning Moab in time past. 

###### v14 
But now Yahweh has spoken, saying, "Within three years, as a worker bound by contract would count them, the glory of Moab shall be brought into contempt, with all his great multitude; and the remnant will be very small and feeble."

***
[[Isa-15|← Isaiah 15]] | [[Isaiah]] | [[Isa-17|Isaiah 17 →]]
