# Isaiah 36

[[Isa-35|← Isaiah 35]] | [[Isaiah]] | [[Isa-37|Isaiah 37 →]]
***



###### v1 
Now in the fourteenth year of king Hezekiah, Sennacherib king of Assyria attacked all of the fortified cities of Judah and captured them. 

###### v2 
The king of Assyria sent Rabshakeh from Lachish to Jerusalem to king Hezekiah with a large army. He stood by the aqueduct from the upper pool in the fuller's field highway. 

###### v3 
Then Eliakim the son of Hilkiah, who was over the household, and Shebna the scribe, and Joah, the son of Asaph, the recorder came out to him. 

###### v4 
Rabshakeh said to them, "Now tell Hezekiah, 'The great king, the king of Assyria, says, "What confidence is this in which you trust? 

###### v5 
I say that your counsel and strength for the war are only vain words. Now in whom do you trust, that you have rebelled against me? 

###### v6 
Behold, you trust in the staff of this bruised reed, even in Egypt, which if a man leans on it, it will go into his hand and pierce it. So is Pharaoh king of Egypt to all who trust in him. 

###### v7 
But if you tell me, 'We trust in Yahweh our God,' isn't that he whose high places and whose altars Hezekiah has taken away, and has said to Judah and to Jerusalem, 'You shall worship before this altar?'" 

###### v8 
Now therefore, please make a pledge to my master the king of Assyria, and I will give you two thousand horses, if you are able on your part to set riders on them. 

###### v9 
How then can you turn away the face of one captain of the least of my master's servants, and put your trust in Egypt for chariots and for horsemen? 

###### v10 
Have I come up now without Yahweh against this land to destroy it? Yahweh said to me, "Go up against this land, and destroy it."'" 

###### v11 
Then Eliakim, Shebna and Joah said to Rabshakeh, "Please speak to your servants in Aramaic, for we understand it. Don't speak to us in the Jews' language in the hearing of the people who are on the wall." 

###### v12 
But Rabshakeh said, "Has my master sent me only to your master and to you, to speak these words, and not to the men who sit on the wall, who will eat their own dung and drink their own urine with you?" 

###### v13 
Then Rabshakeh stood, and called out with a loud voice in the Jews' language, and said, "Hear the words of the great king, the king of Assyria! 

###### v14 
The king says, 'Don't let Hezekiah deceive you; for he will not be able to deliver you. 

###### v15 
Don't let Hezekiah make you trust in Yahweh, saying, "Yahweh will surely deliver us. This city won't be given into the hand of the king of Assyria."' 

###### v16 
Don't listen to Hezekiah, for the king of Assyria says, 'Make your peace with me, and come out to me; and each of you eat from his vine, and each one from his fig tree, and each one of you drink the waters of his own cistern; 

###### v17 
until I come and take you away to a land like your own land, a land of grain and new wine, a land of bread and vineyards. 

###### v18 
Beware lest Hezekiah persuade you, saying, "Yahweh will deliver us." Have any of the gods of the nations delivered their lands from the hand of the king of Assyria? 

###### v19 
Where are the gods of Hamath and Arpad? Where are the gods of Sepharvaim? Have they delivered Samaria from my hand? 

###### v20 
Who are they among all the gods of these countries that have delivered their country out of my hand, that Yahweh should deliver Jerusalem out of my hand?'" 

###### v21 
But they remained silent, and said nothing in reply, for the king's commandment was, "Don't answer him." 

###### v22 
Then Eliakim the son of Hilkiah, who was over the household, and Shebna the scribe, and Joah, the son of Asaph, the recorder, came to Hezekiah with their clothes torn, and told him the words of Rabshakeh.

***
[[Isa-35|← Isaiah 35]] | [[Isaiah]] | [[Isa-37|Isaiah 37 →]]
