# Isaiah 49

[[Isa-48|← Isaiah 48]] | [[Isaiah]] | [[Isa-50|Isaiah 50 →]]
***



###### v1 
Listen, islands, to me. Listen, you peoples, from afar: Yahweh has called me from the womb; from the inside of my mother, he has mentioned my name. 

###### v2 
He has made my mouth like a sharp sword. He has hidden me in the shadow of his hand. He has made me a polished shaft. He has kept me close in his quiver. 

###### v3 
He said to me, "You are my servant, Israel, in whom I will be glorified." 

###### v4 
But I said, "I have labored in vain. I have spent my strength in vain for nothing; yet surely the justice due to me is with Yahweh, and my reward with my God." 

###### v5 
Now Yahweh, he who formed me from the womb to be his servant, says to bring Jacob again to him, and to gather Israel to him, for I am honorable in Yahweh's eyes, and my God has become my strength. 

###### v6 
Indeed, he says, "It is too light a thing that you should be my servant to raise up the tribes of Jacob, and to restore the preserved of Israel. I will also give you as a light to the nations, that you may be my salvation to the end of the earth." 

###### v7 
Yahweh, the Redeemer of Israel, and his Holy One, says to him whom man despises, to him whom the nation abhors, to a servant of rulers: "Kings shall see and rise up, princes, and they shall worship, because of Yahweh who is faithful, even the Holy One of Israel, who has chosen you." 

###### v8 
Yahweh says, "I have answered you in an acceptable time. I have helped you in a day of salvation. I will preserve you and give you for a covenant of the people, to raise up the land, to make them inherit the desolate heritage, 

###### v9 
saying to those who are bound, 'Come out!'; to those who are in darkness, 'Show yourselves!' "They shall feed along the paths, and their pasture shall be on all treeless heights. 

###### v10 
They shall not hunger nor thirst; neither shall the heat nor sun strike them: for he who has mercy on them will lead them. He will guide them by springs of water. 

###### v11 
I will make all my mountains a road, and my highways shall be exalted. 

###### v12 
Behold, these shall come from afar, and behold, these from the north and from the west; and these from the land of Sinim." 

###### v13 
Sing, heavens, and be joyful, earth! Break out into singing, mountains, for Yahweh has comforted his people, and will have compassion on his afflicted. 

###### v14 
But Zion said, "Yahweh has forsaken me, and the Lord has forgotten me." 

###### v15 
"Can a woman forget her nursing child, that she should not have compassion on the son of her womb? Yes, these may forget, yet I will not forget you! 

###### v16 
Behold, I have engraved you on the palms of my hands. Your walls are continually before me. 

###### v17 
Your children hurry. Your destroyers and those who devastated you will leave you. 

###### v18 
Lift up your eyes all around, and see: all these gather themselves together, and come to you. As I live," says Yahweh, "you shall surely clothe yourself with them all as with an ornament, and dress yourself with them, like a bride. 

###### v19 
"For, as for your waste and your desolate places, and your land that has been destroyed, surely now that land will be too small for the inhabitants, and those who swallowed you up will be far away. 

###### v20 
The children of your bereavement will say in your ears, 'This place is too small for me. Give me a place to live in.' 

###### v21 
Then you will say in your heart, 'Who has conceived these for me, since I have been bereaved of my children and am alone, an exile, and wandering back and forth? Who has brought these up? Behold, I was left alone. Where were these?'" 

###### v22 
The Lord Yahweh says, "Behold, I will lift up my hand to the nations, and lift up my banner to the peoples. They shall bring your sons in their bosom, and your daughters shall be carried on their shoulders. 

###### v23 
Kings shall be your foster fathers, and their queens your nursing mothers. They will bow down to you with their faces to the earth, and lick the dust of your feet. Then you will know that I am Yahweh; and those who wait for me shall not be disappointed." 

###### v24 
Shall the plunder be taken from the mighty, or the lawful captives be delivered? 

###### v25 
But Yahweh says, "Even the captives of the mighty shall be taken away, and the plunder retrieved from the fierce, for I will contend with him who contends with you and I will save your children. 

###### v26 
I will feed those who oppress you with their own flesh; and they will be drunk on their own blood, as with sweet wine. Then all flesh shall know that I, Yahweh, am your Savior and your Redeemer, the Mighty One of Jacob."

***
[[Isa-48|← Isaiah 48]] | [[Isaiah]] | [[Isa-50|Isaiah 50 →]]
