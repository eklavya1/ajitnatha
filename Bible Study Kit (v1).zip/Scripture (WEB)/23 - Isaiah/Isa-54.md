# Isaiah 54

[[Isa-53|← Isaiah 53]] | [[Isaiah]] | [[Isa-55|Isaiah 55 →]]
***



###### v1 
"Sing, barren, you who didn't give birth; break out into singing, and cry aloud, you who didn't travail with child: for more are the children of the desolate than the children of the married wife," says Yahweh. 

###### v2 
"Enlarge the place of your tent, and let them stretch out the curtains of your habitations; don't spare: lengthen your cords, and strengthen your stakes. 

###### v3 
For you will spread out on the right hand and on the left; and your offspring will possess the nations and settle in desolate cities. 

###### v4 
"Don't be afraid, for you will not be ashamed. Don't be confounded, for you will not be disappointed. For you will forget the shame of your youth. You will remember the reproach of your widowhood no more. 

###### v5 
For your Maker is your husband; Yahweh of Armies is his name. The Holy One of Israel is your Redeemer. He will be called the God of the whole earth. 

###### v6 
For Yahweh has called you as a wife forsaken and grieved in spirit, even a wife of youth, when she is cast off," says your God. 

###### v7 
"For a small moment I have forsaken you, but I will gather you with great mercies. 

###### v8 
In overflowing wrath I hid my face from you for a moment, but with everlasting loving kindness I will have mercy on you," says Yahweh your Redeemer. 

###### v9 
"For this is like the waters of Noah to me; for as I have sworn that the waters of Noah will no more go over the earth, so I have sworn that I will not be angry with you, nor rebuke you. 

###### v10 
For the mountains may depart, and the hills be removed; but my loving kindness will not depart from you, and my covenant of peace will not be removed," says Yahweh who has mercy on you. 

###### v11 
"You afflicted, tossed with storms, and not comforted, behold, I will set your stones in beautiful colors, and lay your foundations with sapphires. 

###### v12 
I will make your pinnacles of rubies, your gates of sparkling jewels, and all your walls of precious stones. 

###### v13 
All your children will be taught by Yahweh; and your children's peace will be great. 

###### v14 
You will be established in righteousness. You will be far from oppression, for you will not be afraid, and far from terror, for it shall not come near you. 

###### v15 
Behold, they may gather together, but not by me. Whoever gathers together against you will fall because of you. 

###### v16 
"Behold, I have created the blacksmith who fans the coals into flame, and forges a weapon for his work; and I have created the destroyer to destroy. 

###### v17 
No weapon that is formed against you will prevail; and you will condemn every tongue that rises against you in judgment. This is the heritage of Yahweh's servants, and their righteousness is of me," says Yahweh.

***
[[Isa-53|← Isaiah 53]] | [[Isaiah]] | [[Isa-55|Isaiah 55 →]]
