# Isaiah 57

[[Isa-56|← Isaiah 56]] | [[Isaiah]] | [[Isa-58|Isaiah 58 →]]
***



###### v1 
The righteous perish, and no one lays it to heart. Merciful men are taken away, and no one considers that the righteous is taken away from the evil. 

###### v2 
He enters into peace. They rest in their beds, each one who walks in his uprightness. 

###### v3 
"But draw near here, you sons of a sorceress, you offspring of adulterers and prostitutes. 

###### v4 
Whom do you mock? Against whom do you make a wide mouth and stick out your tongue? Aren't you children of disobedience and offspring of falsehood, 

###### v5 
you who inflame yourselves among the oaks, under every green tree; who kill the children in the valleys, under the clefts of the rocks? 

###### v6 
Among the smooth stones of the valley is your portion. They, they are your lot. You have even poured a drink offering to them. You have offered an offering. Shall I be appeased for these things? 

###### v7 
On a high and lofty mountain you have set your bed. You also went up there to offer sacrifice. 

###### v8 
You have set up your memorial behind the doors and the posts, for you have exposed yourself to someone besides me, and have gone up. You have enlarged your bed and made you a covenant with them. You loved what you saw on their bed. 

###### v9 
You went to the king with oil, increased your perfumes, sent your ambassadors far off, and degraded yourself even to Sheol. 

###### v10 
You were wearied with the length of your ways; yet you didn't say, 'It is in vain.' You found a reviving of your strength; therefore you weren't faint. 

###### v11 
"Whom have you dreaded and feared, so that you lie, and have not remembered me, nor laid it to your heart? Haven't I held my peace for a long time, and you don't fear me? 

###### v12 
I will declare your righteousness; and as for your works, they will not benefit you. 

###### v13 
When you cry, let those whom you have gathered deliver you; but the wind will take them. a breath will carry them all away: but he who takes refuge in me will possess the land, and will inherit my holy mountain." 

###### v14 
He will say, "Build up, build up, prepare the way! Remove the stumbling-block out of the way of my people." 

###### v15 
For the high and lofty One who inhabits eternity, whose name is Holy, says: "I dwell in the high and holy place, with him also who is of a contrite and humble spirit, to revive the spirit of the humble, and to revive the heart of the contrite. 

###### v16 
For I will not contend forever, neither will I always be angry; for the spirit would faint before me, and the souls whom I have made. 

###### v17 
I was angry because of the iniquity of his covetousness and struck him. I hid myself and was angry; and he went on backsliding in the way of his heart. 

###### v18 
I have seen his ways, and will heal him. I will lead him also, and restore comforts to him and to his mourners. 

###### v19 
I create the fruit of the lips: Peace, peace, to him who is far off and to him who is near," says Yahweh; "and I will heal them." 

###### v20 
But the wicked are like the troubled sea; for it can't rest and its waters cast up mire and mud. 

###### v21 
"There is no peace", says my God, "for the wicked."

***
[[Isa-56|← Isaiah 56]] | [[Isaiah]] | [[Isa-58|Isaiah 58 →]]
