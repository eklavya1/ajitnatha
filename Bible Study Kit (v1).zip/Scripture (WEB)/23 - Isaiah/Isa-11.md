# Isaiah 11

[[Isa-10|← Isaiah 10]] | [[Isaiah]] | [[Isa-12|Isaiah 12 →]]
***



###### v1 
A shoot will come out of the stock of Jesse, and a branch out of his roots will bear fruit. 

###### v2 
Yahweh's Spirit will rest on him: the spirit of wisdom and understanding, the spirit of counsel and might, the spirit of knowledge and of the fear of Yahweh. 

###### v3 
His delight will be in the fear of Yahweh. He will not judge by the sight of his eyes, neither decide by the hearing of his ears; 

###### v4 
but he will judge the poor with righteousness, and decide with equity for the humble of the earth. He will strike the earth with the rod of his mouth; and with the breath of his lips he will kill the wicked. 

###### v5 
Righteousness will be the belt of his waist, and faithfulness the belt of his waist. 

###### v6 
The wolf will live with the lamb, and the leopard will lie down with the young goat, the calf, the young lion, and the fattened calf together; and a little child will lead them. 

###### v7 
The cow and the bear will graze. Their young ones will lie down together. The lion will eat straw like the ox. 

###### v8 
The nursing child will play near a cobra's hole, and the weaned child will put his hand on the viper's den. 

###### v9 
They will not hurt nor destroy in all my holy mountain; for the earth will be full of the knowledge of Yahweh, as the waters cover the sea. 

###### v10 
It will happen in that day that the nations will seek the root of Jesse, who stands as a banner of the peoples; and his resting place will be glorious. 

###### v11 
It will happen in that day that the Lord will set his hand again the second time to recover the remnant that is left of his people from Assyria, from Egypt, from Pathros, from Cush, from Elam, from Shinar, from Hamath, and from the islands of the sea. 

###### v12 
He will set up a banner for the nations, and will assemble the outcasts of Israel, and gather together the dispersed of Judah from the four corners of the earth. 

###### v13 
The envy also of Ephraim will depart, and those who persecute Judah will be cut off. Ephraim won't envy Judah, and Judah won't persecute Ephraim. 

###### v14 
They will fly down on the shoulders of the Philistines on the west. Together they will plunder the children of the east. They will extend their power over Edom and Moab, and the children of Ammon will obey them. 

###### v15 
Yahweh will utterly destroy the tongue of the Egyptian sea; and with his scorching wind he will wave his hand over the River, and will split it into seven streams, and cause men to march over in sandals. 

###### v16 
There will be a highway for the remnant that is left of his people from Assyria, like there was for Israel in the day that he came up out of the land of Egypt.

***
[[Isa-10|← Isaiah 10]] | [[Isaiah]] | [[Isa-12|Isaiah 12 →]]
