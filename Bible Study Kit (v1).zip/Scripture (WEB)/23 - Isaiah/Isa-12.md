# Isaiah 12

[[Isa-11|← Isaiah 11]] | [[Isaiah]] | [[Isa-13|Isaiah 13 →]]
***



###### v1 
In that day you will say, "I will give thanks to you, Yahweh; for though you were angry with me, your anger has turned away and you comfort me. 

###### v2 
Behold, God is my salvation. I will trust, and will not be afraid; for Yah, Yahweh, is my strength and song; and he has become my salvation." 

###### v3 
Therefore with joy you will draw water out of the wells of salvation. 

###### v4 
In that day you will say, "Give thanks to Yahweh! Call on his name! Declare his doings among the peoples! Proclaim that his name is exalted! 

###### v5 
Sing to Yahweh, for he has done excellent things! Let this be known in all the earth! 

###### v6 
Cry aloud and shout, you inhabitant of Zion; for the Holy One of Israel is great among you!"

***
[[Isa-11|← Isaiah 11]] | [[Isaiah]] | [[Isa-13|Isaiah 13 →]]
