# Isaiah 41

[[Isa-40|← Isaiah 40]] | [[Isaiah]] | [[Isa-42|Isaiah 42 →]]
***



###### v1 
"Keep silent before me, islands, and let the peoples renew their strength. Let them come near, then let them speak. Let's meet together for judgment. 

###### v2 
Who has raised up one from the east? Who called him to his foot in righteousness? He hands over nations to him and makes him rule over kings. He gives them like the dust to his sword, like the driven stubble to his bow. 

###### v3 
He pursues them and passes by safely, even by a way that he had not gone with his feet. 

###### v4 
Who has worked and done it, calling the generations from the beginning? I, Yahweh, the first, and with the last, I am he." 

###### v5 
The islands have seen, and fear. The ends of the earth tremble. They approach, and come. 

###### v6 
Everyone helps his neighbor. They say to their brothers, "Be strong!" 

###### v7 
So the carpenter encourages the goldsmith. He who smoothes with the hammer encourages him who strikes the anvil, saying of the soldering, "It is good;" and he fastens it with nails, that it might not totter. 

###### v8 
"But you, Israel, my servant, Jacob whom I have chosen, the offspring of Abraham my friend, 

###### v9 
You whom I have taken hold of from the ends of the earth, and called from its corners, and said to you, 'You are my servant, I have chosen you and have not cast you away.' 

###### v10 
Don't you be afraid, for I am with you. Don't be dismayed, for I am your God. I will strengthen you. Yes, I will help you. Yes, I will uphold you with the right hand of my righteousness. 

###### v11 
Behold, all those who are incensed against you will be disappointed and confounded. Those who strive with you will be like nothing, and shall perish. 

###### v12 
You will seek them, and won't find them, even those who contend with you. Those who war against you will be as nothing, as a non-existent thing. 

###### v13 
For I, Yahweh your God, will hold your right hand, saying to you, 'Don't be afraid. I will help you.' 

###### v14 
Don't be afraid, you worm Jacob, and you men of Israel. I will help you," says Yahweh. "Your Redeemer is the Holy One of Israel. 

###### v15 
Behold, I have made you into a new sharp threshing instrument with teeth. You will thresh the mountains, and beat them small, and will make the hills like chaff. 

###### v16 
You will winnow them, and the wind will carry them away, and the whirlwind will scatter them. You will rejoice in Yahweh. You will glory in the Holy One of Israel. 

###### v17 
The poor and needy seek water, and there is none. Their tongue fails for thirst. I, Yahweh, will answer them. I, the God of Israel, will not forsake them. 

###### v18 
I will open rivers on the bare heights, and springs in the middle of the valleys. I will make the wilderness a pool of water, and the dry land springs of water. 

###### v19 
I will put cedar, acacia, myrtle, and oil trees in the wilderness. I will set cypress trees, pine, and box trees together in the desert; 

###### v20 
that they may see, know, consider, and understand together, that Yahweh's hand has done this, and the Holy One of Israel has created it. 

###### v21 
Produce your cause," says Yahweh. "Bring out your strong reasons!" says the King of Jacob. 

###### v22 
"Let them announce and declare to us what will happen! Declare the former things, what they are, that we may consider them, and know the latter end of them; or show us things to come. 

###### v23 
Declare the things that are to come hereafter, that we may know that you are gods. Yes, do good, or do evil, that we may be dismayed, and see it together. 

###### v24 
Behold, you are nothing, and your work is nothing. He who chooses you is an abomination. 

###### v25 
"I have raised up one from the north, and he has come, from the rising of the sun, one who calls on my name, and he shall come on rulers as on mortar, and as the potter treads clay. 

###### v26 
Who has declared it from the beginning, that we may know? and before, that we may say, 'He is right?' Surely, there is no one who declares. Surely, there is no one who shows. Surely, there is no one who hears your words. 

###### v27 
I am the first to say to Zion, 'Behold, look at them;' and I will give one who brings good news to Jerusalem. 

###### v28 
When I look, there is no man, even among them there is no counselor who, when I ask of them, can answer a word. 

###### v29 
Behold, all of their deeds are vanity and nothing. Their molten images are wind and confusion.

***
[[Isa-40|← Isaiah 40]] | [[Isaiah]] | [[Isa-42|Isaiah 42 →]]
