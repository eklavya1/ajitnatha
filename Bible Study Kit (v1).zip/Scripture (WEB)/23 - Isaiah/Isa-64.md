# Isaiah 64

[[Isa-63|← Isaiah 63]] | [[Isaiah]] | [[Isa-65|Isaiah 65 →]]
***



###### v1 
Oh that you would tear the heavens, that you would come down, that the mountains might quake at your presence. 

###### v2 
As when fire kindles the brushwood, and the fire causes the water to boil; Make your name known to your adversaries, that the nations may tremble at your presence! 

###### v3 
When you did awesome things which we didn't look for, you came down, and the mountains quaked at your presence. 

###### v4 
For from of old men have not heard, nor perceived by the ear, nor has the eye seen a God besides you, who works for him who waits for him. 

###### v5 
You meet him who rejoices and does righteousness, those who remember you in your ways. Behold, you were angry, and we sinned. We have been in sin for a long time. Shall we be saved? 

###### v6 
For we have all become like one who is unclean, and all our righteousness is like a polluted garment. We all fade like a leaf; and our iniquities, like the wind, take us away. 

###### v7 
There is no one who calls on your name, who stirs himself up to take hold of you; for you have hidden your face from us, and have consumed us by means of our iniquities. 

###### v8 
But now, Yahweh, you are our Father. We are the clay and you our potter. We all are the work of your hand. 

###### v9 
Don't be furious, Yahweh. Don't remember iniquity forever. Look and see, we beg you, we are all your people. 

###### v10 
Your holy cities have become a wilderness. Zion has become a wilderness, Jerusalem a desolation. 

###### v11 
Our holy and our beautiful house where our fathers praised you is burned with fire. All our pleasant places are laid waste. 

###### v12 
Will you hold yourself back for these things, Yahweh? Will you keep silent and punish us very severely?

***
[[Isa-63|← Isaiah 63]] | [[Isaiah]] | [[Isa-65|Isaiah 65 →]]
