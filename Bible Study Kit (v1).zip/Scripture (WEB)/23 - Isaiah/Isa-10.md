# Isaiah 10

[[Isa-09|← Isaiah 09]] | [[Isaiah]] | [[Isa-11|Isaiah 11 →]]
***



###### v1 
Woe to those who decree unrighteous decrees, and to the writers who write oppressive decrees; 

###### v2 
to deprive the needy of justice, and to rob the poor among my people of their rights, that widows may be their plunder, and that they may make the fatherless their prey! 

###### v3 
What will you do in the day of visitation, and in the desolation which will come from afar? To whom will you flee for help? Where will you leave your wealth? 

###### v4 
They will only bow down under the prisoners, and will fall under the slain. For all this his anger is not turned away, but his hand is stretched out still. 

###### v5 
Alas Assyrian, the rod of my anger, the staff in whose hand is my indignation! 

###### v6 
I will send him against a profane nation, and against the people who anger me I will give him a command to take the plunder and to take the prey, and to tread them down like the mire of the streets. 

###### v7 
However he doesn't mean so, neither does his heart think so; but it is in his heart to destroy, and to cut off not a few nations. 

###### v8 
For he says, "Aren't all of my princes kings? 

###### v9 
Isn't Calno like Carchemish? Isn't Hamath like Arpad? Isn't Samaria like Damascus?" 

###### v10 
As my hand has found the kingdoms of the idols, whose engraved images exceeded those of Jerusalem and of Samaria; 

###### v11 
shall I not, as I have done to Samaria and her idols, so do to Jerusalem and her idols? 

###### v12 
Therefore it will happen that when the Lord has performed his whole work on Mount Zion and on Jerusalem, I will punish the fruit of the willful proud heart of the king of Assyria, and the insolence of his arrogant looks. 

###### v13 
For he has said, "By the strength of my hand I have done it, and by my wisdom; for I have understanding. I have removed the boundaries of the peoples, and have robbed their treasures. Like a valiant man I have brought down their rulers. 

###### v14 
My hand has found the riches of the peoples like a nest, and like one gathers eggs that are abandoned, I have gathered all the earth. There was no one who moved their wing, or that opened their mouth, or chirped." 

###### v15 
Should an ax brag against him who chops with it? Should a saw exalt itself above him who saws with it? As if a rod should lift those who lift it up, or as if a staff should lift up someone who is not wood. 

###### v16 
Therefore the Lord, Yahweh of Armies, will send among his fat ones leanness; and under his glory a burning will be kindled like the burning of fire. 

###### v17 
The light of Israel will be for a fire, and his Holy One for a flame; and it will burn and devour his thorns and his briers in one day. 

###### v18 
He will consume the glory of his forest, and of his fruitful field, both soul and body. It will be as when a standard bearer faints. 

###### v19 
The remnant of the trees of his forest shall be few, so that a child could write their number. 

###### v20 
It will come to pass in that day that the remnant of Israel, and those who have escaped from the house of Jacob will no more again lean on him who struck them, but shall lean on Yahweh, the Holy One of Israel, in truth. 

###### v21 
A remnant will return, even the remnant of Jacob, to the mighty God. 

###### v22 
For though your people, Israel, are like the sand of the sea, only a remnant of them will return. A destruction is determined, overflowing with righteousness. 

###### v23 
For the Lord, Yahweh of Armies, will make a full end, and that determined, throughout all the earth. 

###### v24 
Therefore the Lord, Yahweh of Armies, says "My people who dwell in Zion, don't be afraid of the Assyrian, though he strike you with the rod, and lift up his staff against you, as Egypt did. 

###### v25 
For yet a very little while, and the indignation against you will be accomplished, and my anger will be directed to his destruction." 

###### v26 
Yahweh of Armies will stir up a scourge against him, as in the slaughter of Midian at the rock of Oreb. His rod will be over the sea, and he will lift it up like he did against Egypt. 

###### v27 
It will happen in that day that his burden will depart from off your shoulder, and his yoke from off your neck, and the yoke shall be destroyed because of the anointing oil. 

###### v28 
He has come to Aiath. He has passed through Migron. At Michmash he stores his baggage. 

###### v29 
They have gone over the pass. They have taken up their lodging at Geba. Ramah trembles. Gibeah of Saul has fled. 

###### v30 
Cry aloud with your voice, daughter of Gallim! Listen, Laishah! You poor Anathoth! 

###### v31 
Madmenah is a fugitive. The inhabitants of Gebim flee for safety. 

###### v32 
This very day he will halt at Nob. He shakes his hand at the mountain of the daughter of Zion, the hill of Jerusalem. 

###### v33 
Behold, the Lord, Yahweh of Armies, will lop the boughs with terror. The tall will be cut down, and the lofty will be brought low. 

###### v34 
He will cut down the thickets of the forest with iron, and Lebanon will fall by the Mighty One.

***
[[Isa-09|← Isaiah 09]] | [[Isaiah]] | [[Isa-11|Isaiah 11 →]]
