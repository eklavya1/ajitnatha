# Isaiah 32

[[Isa-31|← Isaiah 31]] | [[Isaiah]] | [[Isa-33|Isaiah 33 →]]
***



###### v1 
Behold, a king shall reign in righteousness, and princes shall rule in justice. 

###### v2 
A man shall be as a hiding place from the wind, and a covert from the storm, as streams of water in a dry place, as the shade of a large rock in a weary land. 

###### v3 
The eyes of those who see will not be dim, and the ears of those who hear will listen. 

###### v4 
The heart of the rash will understand knowledge, and the tongue of the stammerers will be ready to speak plainly. 

###### v5 
The fool will no longer be called noble, nor the scoundrel be highly respected. 

###### v6 
For the fool will speak folly, and his heart will work iniquity, to practice profanity, and to utter error against Yahweh, to make empty the soul of the hungry, and to cause the drink of the thirsty to fail. 

###### v7 
The ways of the scoundrel are evil. He devises wicked plans to destroy the humble with lying words, even when the needy speaks right. 

###### v8 
But the noble devises noble things; and he will continue in noble things. 

###### v9 
Rise up, you women who are at ease! Hear my voice! You careless daughters, give ear to my speech! 

###### v10 
For days beyond a year you will be troubled, you careless women; for the vintage will fail. The harvest won't come. 

###### v11 
Tremble, you women who are at ease! Be troubled, you careless ones! Strip yourselves, make yourselves naked, and put sackcloth on your waist. 

###### v12 
Beat your breasts for the pleasant fields, for the fruitful vine. 

###### v13 
Thorns and briers will come up on my people's land; yes, on all the houses of joy in the joyous city. 

###### v14 
For the palace will be forsaken. The populous city will be deserted. The hill and the watchtower will be for dens forever, a delight for wild donkeys, a pasture of flocks, 

###### v15 
until the Spirit is poured on us from on high, and the wilderness becomes a fruitful field, and the fruitful field is considered a forest. 

###### v16 
Then justice will dwell in the wilderness; and righteousness will remain in the fruitful field. 

###### v17 
The work of righteousness will be peace, and the effect of righteousness, quietness and confidence forever. 

###### v18 
My people will live in a peaceful habitation, in safe dwellings, and in quiet resting places, 

###### v19 
though hail flattens the forest, and the city is leveled completely. 

###### v20 
Blessed are you who sow beside all waters, who send out the feet of the ox and the donkey.

***
[[Isa-31|← Isaiah 31]] | [[Isaiah]] | [[Isa-33|Isaiah 33 →]]
