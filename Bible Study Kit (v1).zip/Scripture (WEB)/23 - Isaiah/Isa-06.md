# Isaiah 6

[[Isa-05|← Isaiah 05]] | [[Isaiah]] | [[Isa-07|Isaiah 07 →]]
***



###### v1 
In the year that king Uzziah died, I saw the Lord sitting on a throne, high and lifted up; and his train filled the temple. 

###### v2 
Above him stood the seraphim. Each one had six wings. With two he covered his face. With two he covered his feet. With two he flew. 

###### v3 
One called to another, and said, "Holy, holy, holy, is Yahweh of Armies! The whole earth is full of his glory!" 

###### v4 
The foundations of the thresholds shook at the voice of him who called, and the house was filled with smoke. 

###### v5 
Then I said, "Woe is me! For I am undone, because I am a man of unclean lips, and I dwell among a people of unclean lips: for my eyes have seen the King, Yahweh of Armies!" 

###### v6 
Then one of the seraphim flew to me, having a live coal in his hand, which he had taken with the tongs from off the altar. 

###### v7 
He touched my mouth with it, and said, "Behold, this has touched your lips; and your iniquity is taken away, and your sin forgiven." 

###### v8 
I heard the Lord's voice, saying, "Whom shall I send, and who will go for us?" Then I said, "Here I am. Send me!" 

###### v9 
He said, "Go, and tell this people, 'You hear indeed, but don't understand. You see indeed, but don't perceive.' 

###### v10 
Make the heart of this people fat. Make their ears heavy, and shut their eyes; lest they see with their eyes, hear with their ears, understand with their heart, and turn again, and be healed." 

###### v11 
Then I said, "Lord, how long?" He answered, "Until cities are waste without inhabitant, houses without man, the land becomes utterly waste, 

###### v12 
and Yahweh has removed men far away, and the forsaken places are many within the land. 

###### v13 
If there is a tenth left in it, that also will in turn be consumed, as a terebinth, and as an oak, whose stump remains when they are cut down; so the holy seed is its stock."

***
[[Isa-05|← Isaiah 05]] | [[Isaiah]] | [[Isa-07|Isaiah 07 →]]
