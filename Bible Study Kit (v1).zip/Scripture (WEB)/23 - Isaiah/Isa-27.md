# Isaiah 27

[[Isa-26|← Isaiah 26]] | [[Isaiah]] | [[Isa-28|Isaiah 28 →]]
***



###### v1 
In that day, Yahweh with his hard and great and strong sword will punish leviathan, the fleeing serpent, and leviathan the twisted serpent; and he will kill the dragon that is in the sea. 

###### v2 
In that day, sing to her, "A pleasant vineyard! 

###### v3 
I, Yahweh, am its keeper. I will water it every moment. Lest anyone damage it, I will keep it night and day. 

###### v4 
Wrath is not in me, but if I should find briers and thorns, I would do battle! I would march on them and I would burn them together. 

###### v5 
Or else let him take hold of my strength, that he may make peace with me. Let him make peace with me." 

###### v6 
In days to come, Jacob will take root. Israel will blossom and bud. They will fill the surface of the world with fruit. 

###### v7 
Has he struck them as he struck those who struck them? Or are they killed like those who killed them were killed? 

###### v8 
In measure, when you send them away, you contend with them. He has removed them with his rough blast in the day of the east wind. 

###### v9 
Therefore by this the iniquity of Jacob will be forgiven, and this is all the fruit of taking away his sin: that he makes all the stones of the altar as chalk stones that are beaten in pieces, so that the Asherah poles and the incense altars shall rise no more. 

###### v10 
For the fortified city is solitary, a habitation deserted and forsaken, like the wilderness. The calf will feed there, and there he will lie down, and consume its branches. 

###### v11 
When its boughs are withered, they will be broken off. The women will come and set them on fire, for they are a people of no understanding. Therefore he who made them will not have compassion on them, and he who formed them will show them no favor. 

###### v12 
It will happen in that day that Yahweh will thresh from the flowing stream of the Euphrates to the brook of Egypt; and you will be gathered one by one, children of Israel. 

###### v13 
It will happen in that day that a great trumpet will be blown; and those who were ready to perish in the land of Assyria, and those who were outcasts in the land of Egypt, shall come; and they will worship Yahweh in the holy mountain at Jerusalem.

***
[[Isa-26|← Isaiah 26]] | [[Isaiah]] | [[Isa-28|Isaiah 28 →]]
