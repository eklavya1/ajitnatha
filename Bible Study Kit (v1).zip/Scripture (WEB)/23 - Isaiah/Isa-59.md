# Isaiah 59

[[Isa-58|← Isaiah 58]] | [[Isaiah]] | [[Isa-60|Isaiah 60 →]]
***



###### v1 
Behold, Yahweh's hand is not shortened, that it can't save; nor his ear dull, that it can't hear. 

###### v2 
But your iniquities have separated you and your God, and your sins have hidden his face from you, so that he will not hear. 

###### v3 
For your hands are defiled with blood, and your fingers with iniquity. Your lips have spoken lies. Your tongue mutters wickedness. 

###### v4 
No one sues in righteousness, and no one pleads in truth. They trust in vanity, and speak lies. They conceive mischief, and give birth to iniquity. 

###### v5 
They hatch adders' eggs, and weave the spider's web. He who eats of their eggs dies; and that which is crushed breaks out into a viper. 

###### v6 
Their webs won't become garments. They won't cover themselves with their works. Their works are works of iniquity, and acts of violence are in their hands. 

###### v7 
Their feet run to evil, and they hurry to shed innocent blood. Their thoughts are thoughts of iniquity. Desolation and destruction are in their paths. 

###### v8 
They don't know the way of peace; and there is no justice in their ways. They have made crooked paths for themselves; whoever goes in them doesn't know peace. 

###### v9 
Therefore justice is far from us, and righteousness doesn't overtake us. We look for light, but see darkness; for brightness, but we walk in obscurity. 

###### v10 
We grope for the wall like the blind. Yes, we grope as those who have no eyes. We stumble at noon as if it were twilight. Among those who are strong, we are like dead men. 

###### v11 
We all roar like bears and moan bitterly like doves. We look for justice, but there is none, for salvation, but it is far off from us. 

###### v12 
For our transgressions are multiplied before you, and our sins testify against us; for our transgressions are with us, and as for our iniquities, we know them: 

###### v13 
transgressing and denying Yahweh, and turning away from following our God, speaking oppression and revolt, conceiving and uttering from the heart words of falsehood. 

###### v14 
Justice is turned away backward, and righteousness stands far away; for truth has fallen in the street, and uprightness can't enter. 

###### v15 
Yes, truth is lacking; and he who departs from evil makes himself a prey. Yahweh saw it, and it displeased him that there was no justice. 

###### v16 
He saw that there was no man, and wondered that there was no intercessor. Therefore his own arm brought salvation to him; and his righteousness sustained him. 

###### v17 
He put on righteousness as a breastplate, and a helmet of salvation on his head. He put on garments of vengeance for clothing, and was clad with zeal as a mantle. 

###### v18 
According to their deeds, he will repay as appropriate, wrath to his adversaries, recompense to his enemies; he will repay the islands their due. 

###### v19 
So they will fear Yahweh's name from the west, and his glory from the rising of the sun; for he will come as a rushing stream, which Yahweh's breath drives. 

###### v20 
"A Redeemer will come to Zion, and to those who turn from disobedience in Jacob," says Yahweh. 

###### v21 
"As for me, this is my covenant with them," says Yahweh. "My Spirit who is on you, and my words which I have put in your mouth shall not depart out of your mouth, nor out of the mouth of your offspring, nor out of the mouth of your offspring's offspring," says Yahweh, "from now on and forever."

***
[[Isa-58|← Isaiah 58]] | [[Isaiah]] | [[Isa-60|Isaiah 60 →]]
