# Isaiah 65

[[Isa-64|← Isaiah 64]] | [[Isaiah]] | [[Isa-66|Isaiah 66 →]]
***



###### v1 
"I am inquired of by those who didn't ask. I am found by those who didn't seek me. I said, 'See me, see me,' to a nation that was not called by my name. 

###### v2 
I have spread out my hands all day to a rebellious people, who walk in a way that is not good, after their own thoughts; 

###### v3 
a people who provoke me to my face continually, sacrificing in gardens, and burning incense on bricks; 

###### v4 
who sit among the graves, and spend nights in secret places; who eat pig's meat, and broth of abominable things is in their vessels; 

###### v5 
who say, 'Stay by yourself, don't come near to me, for I am holier than you.' These are smoke in my nose, a fire that burns all day. 

###### v6 
"Behold, it is written before me: I will not keep silence, but will repay, yes, I will repay into their bosom, 

###### v7 
your own iniquities, and the iniquities of your fathers together", says Yahweh, "who have burned incense on the mountains, and blasphemed me on the hills. Therefore I will first measure their work into their bosom." 

###### v8 
Yahweh says, "As the new wine is found in the cluster, and one says, 'Don't destroy it, for a blessing is in it:' so I will do for my servants' sake, that I may not destroy them all. 

###### v9 
I will bring offspring out of Jacob, and out of Judah an inheritor of my mountains. My chosen will inherit it, and my servants will dwell there. 

###### v10 
Sharon will be a fold of flocks, and the valley of Achor a place for herds to lie down in, for my people who have sought me. 

###### v11 
"But you who forsake Yahweh, who forget my holy mountain, who prepare a table for Fortune, and who fill up mixed wine to Destiny; 

###### v12 
I will destine you to the sword, and you will all bow down to the slaughter; because when I called, you didn't answer. When I spoke, you didn't listen; but you did that which was evil in my eyes, and chose that in which I didn't delight." 

###### v13 
Therefore the Lord Yahweh says, "Behold, my servants will eat, but you will be hungry; behold, my servants will drink, but you will be thirsty. Behold, my servants will rejoice, but you will be disappointed; 

###### v14 
Behold, my servants will sing for joy of heart, but you will cry for sorrow of heart, and will wail for anguish of spirit. 

###### v15 
You will leave your name for a curse to my chosen; and the Lord Yahweh will kill you. He will call his servants by another name, 

###### v16 
so that he who blesses himself in the earth will bless himself in the God of truth; and he who swears in the earth will swear by the God of truth; because the former troubles are forgotten, and because they are hidden from my eyes. 

###### v17 
"For, behold, I create new heavens and a new earth; and the former things will not be remembered, nor come into mind. 

###### v18 
But be glad and rejoice forever in that which I create; for, behold, I create Jerusalem to be a delight, and her people a joy. 

###### v19 
I will rejoice in Jerusalem, and delight in my people; and the voice of weeping and the voice of crying will be heard in her no more. 

###### v20 
"No more will there be an infant who only lives a few days, nor an old man who has not filled his days; for the child will die one hundred years old, and the sinner being one hundred years old will be accursed. 

###### v21 
They will build houses and inhabit them. They will plant vineyards and eat their fruit. 

###### v22 
They will not build and another inhabit. They will not plant and another eat: for the days of my people will be like the days of a tree, and my chosen will long enjoy the work of their hands. 

###### v23 
They will not labor in vain nor give birth for calamity; for they are the offspring of Yahweh's blessed and their descendants with them. 

###### v24 
It will happen that before they call, I will answer; and while they are yet speaking, I will hear. 

###### v25 
The wolf and the lamb will feed together. The lion will eat straw like the ox. Dust will be the serpent's food. They will not hurt nor destroy in all my holy mountain," says Yahweh.

***
[[Isa-64|← Isaiah 64]] | [[Isaiah]] | [[Isa-66|Isaiah 66 →]]
