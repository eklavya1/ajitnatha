# Isaiah 42

[[Isa-41|← Isaiah 41]] | [[Isaiah]] | [[Isa-43|Isaiah 43 →]]
***



###### v1 
"Behold, my servant, whom I uphold, my chosen, in whom my soul delights: I have put my Spirit on him. He will bring justice to the nations. 

###### v2 
He will not shout, nor raise his voice, nor cause it to be heard in the street. 

###### v3 
He won't break a bruised reed. He won't quench a dimly burning wick. He will faithfully bring justice. 

###### v4 
He will not fail nor be discouraged, until he has set justice in the earth, and the islands wait for his law." 

###### v5 
God Yahweh, he who created the heavens and stretched them out, he who spread out the earth and that which comes out of it, he who gives breath to its people and spirit to those who walk in it, says: 

###### v6 
"I, Yahweh, have called you in righteousness. I will hold your hand. I will keep you, and make you a covenant for the people, as a light for the nations, 

###### v7 
to open the blind eyes, to bring the prisoners out of the dungeon, and those who sit in darkness out of the prison. 

###### v8 
"I am Yahweh. That is my name. I will not give my glory to another, nor my praise to engraved images. 

###### v9 
Behold, the former things have happened and I declare new things. I tell you about them before they come up." 

###### v10 
Sing to Yahweh a new song, and his praise from the end of the earth, you who go down to the sea, and all that is therein, the islands and their inhabitants. 

###### v11 
Let the wilderness and its cities raise their voices, with the villages that Kedar inhabits. Let the inhabitants of Sela sing. Let them shout from the top of the mountains! 

###### v12 
Let them give glory to Yahweh, and declare his praise in the islands. 

###### v13 
Yahweh will go out like a mighty man. He will stir up zeal like a man of war. He will raise a war cry. Yes, he will shout aloud. He will triumph over his enemies. 

###### v14 
"I have been silent a long time. I have been quiet and restrained myself. Now I will cry out like a travailing woman. I will both gasp and pant. 

###### v15 
I will destroy mountains and hills, and dry up all their herbs. I will make the rivers islands, and will dry up the pools. 

###### v16 
I will bring the blind by a way that they don't know. I will lead them in paths that they don't know. I will make darkness light before them, and crooked places straight. I will do these things, and I will not forsake them. 

###### v17 
"Those who trust in engraved images, who tell molten images, 'You are our gods,' will be turned back. They will be utterly disappointed. 

###### v18 
"Hear, you deaf, and look, you blind, that you may see. 

###### v19 
Who is blind, but my servant? Or who is as deaf as my messenger whom I send? Who is as blind as he who is at peace, and as blind as Yahweh's servant? 

###### v20 
You see many things, but don't observe. His ears are open, but he doesn't listen. 

###### v21 
It pleased Yahweh, for his righteousness' sake, to magnify the law and make it honorable. 

###### v22 
But this is a robbed and plundered people. All of them are snared in holes, and they are hidden in prisons. They have become captives, and no one delivers, and a plunder, and no one says, 'Restore them!' 

###### v23 
Who is there among you who will give ear to this? Who will listen and hear for the time to come? 

###### v24 
Who gave Jacob as plunder, and Israel to the robbers? Didn't Yahweh, he against whom we have sinned? For they would not walk in his ways, and they disobeyed his law. 

###### v25 
Therefore he poured the fierceness of his anger on him, and the strength of battle. It set him on fire all around, but he didn't know. It burned him, but he didn't take it to heart."

***
[[Isa-41|← Isaiah 41]] | [[Isaiah]] | [[Isa-43|Isaiah 43 →]]
