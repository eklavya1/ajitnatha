# Isaiah 39

[[Isa-38|← Isaiah 38]] | [[Isaiah]] | [[Isa-40|Isaiah 40 →]]
***



###### v1 
At that time, Merodach Baladan the son of Baladan, king of Babylon, sent letters and a present to Hezekiah; for he heard that he had been sick, and had recovered. 

###### v2 
Hezekiah was pleased with them, and showed them the house of his precious things, the silver, the gold, the spices, and the precious oil, and all the house of his armor, and all that was found in his treasures. There was nothing in his house, nor in all his dominion, that Hezekiah didn't show them. 

###### v3 
Then Isaiah the prophet came to king Hezekiah, and asked him, "What did these men say? From where did they come to you?" Hezekiah said, "They have come from a country far from me, even from Babylon." 

###### v4 
Then he asked, "What have they seen in your house?" Hezekiah answered, "They have seen all that is in my house. There is nothing among my treasures that I have not shown them." 

###### v5 
Then Isaiah said to Hezekiah, "Hear the word of Yahweh of Armies: 

###### v6 
'Behold, the days are coming when all that is in your house, and that which your fathers have stored up until today, will be carried to Babylon. Nothing will be left,' says Yahweh. 

###### v7 
'They will take away your sons who will issue from you, whom you shall father, and they will be eunuchs in the king of Babylon's palace.'" 

###### v8 
Then Hezekiah said to Isaiah, "Yahweh's word which you have spoken is good." He said moreover, "For there will be peace and truth in my days."

***
[[Isa-38|← Isaiah 38]] | [[Isaiah]] | [[Isa-40|Isaiah 40 →]]
