# Isaiah 63

[[Isa-62|← Isaiah 62]] | [[Isaiah]] | [[Isa-64|Isaiah 64 →]]
***



###### v1 
Who is this who comes from Edom, with dyed garments from Bozrah? Who is this who is glorious in his clothing, marching in the greatness of his strength? "It is I who speak in righteousness, mighty to save." 

###### v2 
Why is your clothing red, and your garments like him who treads in the wine vat? 

###### v3 
"I have trodden the wine press alone. Of the peoples, no one was with me. Yes, I trod them in my anger and trampled them in my wrath. Their lifeblood is sprinkled on my garments, and I have stained all my clothing. 

###### v4 
For the day of vengeance was in my heart, and the year of my redeemed has come. 

###### v5 
I looked, and there was no one to help; and I wondered that there was no one to uphold. Therefore my own arm brought salvation to me. My own wrath upheld me. 

###### v6 
I trod down the peoples in my anger and made them drunk in my wrath. I poured their lifeblood out on the earth." 

###### v7 
I will tell of the loving kindnesses of Yahweh and the praises of Yahweh, according to all that Yahweh has given to us, and the great goodness toward the house of Israel, which he has given to them according to his mercies, and according to the multitude of his loving kindnesses. 

###### v8 
For he said, "Surely, they are my people, children who will not deal falsely;" so he became their Savior. 

###### v9 
In all their affliction he was afflicted, and the angel of his presence saved them. In his love and in his pity he redeemed them. He bore them, and carried them all the days of old. 

###### v10 
But they rebelled and grieved his Holy Spirit. Therefore he turned and became their enemy, and he himself fought against them. 

###### v11 
Then he remembered the days of old, Moses and his people, saying, "Where is he who brought them up out of the sea with the shepherds of his flock? Where is he who put his Holy Spirit among them?" 

###### v12 
Who caused his glorious arm to be at Moses' right hand? Who divided the waters before them, to make himself an everlasting name? 

###### v13 
Who led them through the depths, like a horse in the wilderness, so that they didn't stumble? 

###### v14 
As the livestock that go down into the valley, Yahweh's Spirit caused them to rest. So you led your people to make yourself a glorious name. 

###### v15 
Look down from heaven, and see from the habitation of your holiness and of your glory. Where are your zeal and your mighty acts? The yearning of your heart and your compassion is restrained toward me. 

###### v16 
For you are our Father, though Abraham doesn't know us, and Israel does not acknowledge us. You, Yahweh, are our Father. Our Redeemer from everlasting is your name. 

###### v17 
O Yahweh, why do you make us wander from your ways, and harden our heart from your fear? Return for your servants' sake, the tribes of your inheritance. 

###### v18 
Your holy people possessed it but a little while. Our adversaries have trodden down your sanctuary. 

###### v19 
We have become like those over whom you never ruled, like those who were not called by your name.

***
[[Isa-62|← Isaiah 62]] | [[Isaiah]] | [[Isa-64|Isaiah 64 →]]
