# Isaiah 15

[[Isa-14|← Isaiah 14]] | [[Isaiah]] | [[Isa-16|Isaiah 16 →]]
***



###### v1 
The burden of Moab. For in a night, Ar of Moab is laid waste, and brought to nothing. For in a night Kir of Moab is laid waste, and brought to nothing. 

###### v2 
They have gone up to Bayith, and to Dibon, to the high places, to weep. Moab wails over Nebo and over Medeba. Baldness is on all of their heads. Every beard is cut off. 

###### v3 
In their streets, they clothe themselves in sackcloth. In their streets and on their housetops, everyone wails, weeping abundantly. 

###### v4 
Heshbon cries out with Elealeh. Their voice is heard even to Jahaz. Therefore the armed men of Moab cry aloud. Their souls tremble within them. 

###### v5 
My heart cries out for Moab! Her nobles flee to Zoar, to Eglath Shelishiyah; for they go up by the ascent of Luhith with weeping; for on the way to Horonaim, they raise up a cry of destruction. 

###### v6 
For the waters of Nimrim will be desolate; for the grass has withered away, the tender grass fails, there is no green thing. 

###### v7 
Therefore they will carry away the abundance they have gotten, and that which they have stored up, over the brook of the willows. 

###### v8 
For the cry has gone around the borders of Moab, its wailing to Eglaim, and its wailing to Beer Elim. 

###### v9 
For the waters of Dimon are full of blood; for I will bring yet more on Dimon, a lion on those of Moab who escape, and on the remnant of the land.

***
[[Isa-14|← Isaiah 14]] | [[Isaiah]] | [[Isa-16|Isaiah 16 →]]
