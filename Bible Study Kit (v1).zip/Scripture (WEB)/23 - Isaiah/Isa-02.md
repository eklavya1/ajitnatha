# Isaiah 2

[[Isa-01|← Isaiah 01]] | [[Isaiah]] | [[Isa-03|Isaiah 03 →]]
***



###### v1 
This is what Isaiah the son of Amoz saw concerning Judah and Jerusalem. 

###### v2 
It shall happen in the latter days, that the mountain of Yahweh's house shall be established on the top of the mountains, and shall be raised above the hills; and all nations shall flow to it. 

###### v3 
Many peoples shall go and say, "Come, let's go up to the mountain of Yahweh, to the house of the God of Jacob; and he will teach us of his ways, and we will walk in his paths." For the law shall go out of Zion, and Yahweh's word from Jerusalem. 

###### v4 
He will judge between the nations, and will decide concerning many peoples. They shall beat their swords into plowshares, and their spears into pruning hooks. Nation shall not lift up sword against nation, neither shall they learn war any more. 

###### v5 
House of Jacob, come, and let's walk in the light of Yahweh. 

###### v6 
For you have forsaken your people, the house of Jacob, because they are filled from the east, with those who practice divination like the Philistines, and they clasp hands with the children of foreigners. 

###### v7 
Their land is full of silver and gold, neither is there any end of their treasures. Their land also is full of horses, neither is there any end of their chariots. 

###### v8 
Their land also is full of idols. They worship the work of their own hands, that which their own fingers have made. 

###### v9 
Man is brought low, and mankind is humbled; therefore don't forgive them. 

###### v10 
Enter into the rock, and hide in the dust, from before the terror of Yahweh, and from the glory of his majesty. 

###### v11 
The lofty looks of man will be brought low, the arrogance of men will be bowed down, and Yahweh alone will be exalted in that day. 

###### v12 
For there will be a day of Yahweh of Armies for all that is proud and arrogant, and for all that is lifted up; and it shall be brought low: 

###### v13 
for all the cedars of Lebanon, that are high and lifted up, for all the oaks of Bashan, 

###### v14 
for all the high mountains, for all the hills that are lifted up, 

###### v15 
for every lofty tower, for every fortified wall, 

###### v16 
for all the ships of Tarshish, and for all pleasant imagery. 

###### v17 
The loftiness of man shall be bowed down, and the arrogance of men shall be brought low; and Yahweh alone shall be exalted in that day. 

###### v18 
The idols shall utterly pass away. 

###### v19 
Men shall go into the caves of the rocks, and into the holes of the earth, from before the terror of Yahweh, and from the glory of his majesty, when he arises to shake the earth mightily. 

###### v20 
In that day, men shall cast away their idols of silver and their idols of gold, which have been made for themselves to worship, to the moles and to the bats, 

###### v21 
to go into the caverns of the rocks, and into the clefts of the ragged rocks, from before the terror of Yahweh, and from the glory of his majesty, when he arises to shake the earth mightily. 

###### v22 
Stop trusting in man, whose breath is in his nostrils; for of what account is he?

***
[[Isa-01|← Isaiah 01]] | [[Isaiah]] | [[Isa-03|Isaiah 03 →]]
