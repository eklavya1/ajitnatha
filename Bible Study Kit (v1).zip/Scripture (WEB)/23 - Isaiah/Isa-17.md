# Isaiah 17

[[Isa-16|← Isaiah 16]] | [[Isaiah]] | [[Isa-18|Isaiah 18 →]]
***



###### v1 
The burden of Damascus. "Behold, Damascus is taken away from being a city, and it will be a ruinous heap. 

###### v2 
The cities of Aroer are forsaken. They will be for flocks, which shall lie down, and no one shall make them afraid. 

###### v3 
The fortress shall cease from Ephraim, and the kingdom from Damascus, and the remnant of Syria. They will be as the glory of the children of Israel," says Yahweh of Armies. 

###### v4 
"It will happen in that day that the glory of Jacob will be made thin, and the fatness of his flesh will become lean. 

###### v5 
It will be like when the harvester gathers the wheat, and his arm reaps the grain. Yes, it will be like when one gleans grain in the valley of Rephaim. 

###### v6 
Yet gleanings will be left there, like the shaking of an olive tree, two or three olives in the top of the uppermost bough, four or five in the outermost branches of a fruitful tree," says Yahweh, the God of Israel. 

###### v7 
In that day, people will look to their Maker, and their eyes will have respect for the Holy One of Israel. 

###### v8 
They will not look to the altars, the work of their hands; neither shall they respect that which their fingers have made, either the Asherah poles, or the incense altars. 

###### v9 
In that day, their strong cities will be like the forsaken places in the woods and on the mountain top, which were forsaken from before the children of Israel; and it will be a desolation. 

###### v10 
For you have forgotten the God of your salvation, and have not remembered the rock of your strength. Therefore you plant pleasant plants, and set out foreign seedlings. 

###### v11 
In the day of your planting, you hedge it in. In the morning, you make your seed blossom, but the harvest flees away in the day of grief and of desperate sorrow. 

###### v12 
Ah, the uproar of many peoples, who roar like the roaring of the seas; and the rushing of nations, that rush like the rushing of mighty waters! 

###### v13 
The nations will rush like the rushing of many waters: but he will rebuke them, and they will flee far off, and will be chased like the chaff of the mountains before the wind, and like the whirling dust before the storm. 

###### v14 
At evening, behold, terror! Before the morning, they are no more. This is the portion of those who plunder us, and the lot of those who rob us.

***
[[Isa-16|← Isaiah 16]] | [[Isaiah]] | [[Isa-18|Isaiah 18 →]]
