# Isaiah 24

[[Isa-23|← Isaiah 23]] | [[Isaiah]] | [[Isa-25|Isaiah 25 →]]
***



###### v1 
Behold, Yahweh makes the earth empty, makes it waste, turns it upside down, and scatters its inhabitants. 

###### v2 
It will be as with the people, so with the priest; as with the servant, so with his master; as with the maid, so with her mistress; as with the buyer, so with the seller; as with the creditor, so with the debtor; as with the taker of interest, so with the giver of interest. 

###### v3 
The earth will be utterly emptied and utterly laid waste; for Yahweh has spoken this word. 

###### v4 
The earth mourns and fades away. The world languishes and fades away. The lofty people of the earth languish. 

###### v5 
The earth also is polluted under its inhabitants, because they have transgressed the laws, violated the statutes, and broken the everlasting covenant. 

###### v6 
Therefore the curse has devoured the earth, and those who dwell therein are found guilty. Therefore the inhabitants of the earth are burned, and few men are left. 

###### v7 
The new wine mourns. The vine languishes. All the merry-hearted sigh. 

###### v8 
The mirth of tambourines ceases. The sound of those who rejoice ends. The joy of the harp ceases. 

###### v9 
They will not drink wine with a song. Strong drink will be bitter to those who drink it. 

###### v10 
The confused city is broken down. Every house is shut up, that no man may come in. 

###### v11 
There is a crying in the streets because of the wine. All joy is darkened. The mirth of the land is gone. 

###### v12 
The city is left in desolation, and the gate is struck with destruction. 

###### v13 
For it will be so within the earth among the peoples, as the shaking of an olive tree, as the gleanings when the vintage is done. 

###### v14 
These shall lift up their voice. They will shout for the majesty of Yahweh. They cry aloud from the sea. 

###### v15 
Therefore glorify Yahweh in the east, even the name of Yahweh, the God of Israel, in the islands of the sea! 

###### v16 
From the uttermost part of the earth have we heard songs. Glory to the righteous! But I said, "I pine away! I pine away! woe is me!" The treacherous have dealt treacherously. Yes, the treacherous have dealt very treacherously. 

###### v17 
Fear, the pit, and the snare, are on you who inhabit the earth. 

###### v18 
It will happen that he who flees from the noise of the fear will fall into the pit; and he who comes up out of the middle of the pit will be taken in the snare; for the windows on high are opened, and the foundations of the earth tremble. 

###### v19 
The earth is utterly broken. The earth is torn apart. The earth is shaken violently. 

###### v20 
The earth will stagger like a drunken man, and will sway back and forth like a hammock. Its disobedience will be heavy on it, and it will fall and not rise again. 

###### v21 
It will happen in that day that Yahweh will punish the army of the high ones on high, and the kings of the earth on the earth. 

###### v22 
They will be gathered together, as prisoners are gathered in the pit, and will be shut up in the prison; and after many days they will be visited. 

###### v23 
Then the moon will be confounded, and the sun ashamed; for Yahweh of Armies will reign on Mount Zion, and in Jerusalem; and glory will be before his elders.

***
[[Isa-23|← Isaiah 23]] | [[Isaiah]] | [[Isa-25|Isaiah 25 →]]
