# Isaiah 37

[[Isa-36|← Isaiah 36]] | [[Isaiah]] | [[Isa-38|Isaiah 38 →]]
***



###### v1 
When king Hezekiah heard it, he tore his clothes, covered himself with sackcloth, and went into Yahweh's house. 

###### v2 
He sent Eliakim, who was over the household, and Shebna the scribe, and the elders of the priests, covered with sackcloth, to Isaiah the prophet, the son of Amoz. 

###### v3 
They said to him, "Hezekiah says, 'Today is a day of trouble, and of rebuke, and of rejection; for the children have come to the birth, and there is no strength to give birth. 

###### v4 
It may be Yahweh your God will hear the words of Rabshakeh, whom the king of Assyria his master has sent to defy the living God, and will rebuke the words which Yahweh your God has heard. Therefore lift up your prayer for the remnant that is left.'" 

###### v5 
So the servants of king Hezekiah came to Isaiah. 

###### v6 
Isaiah said to them, "Tell your master, 'Yahweh says, "Don't be afraid of the words that you have heard, with which the servants of the king of Assyria have blasphemed me. 

###### v7 
Behold, I will put a spirit in him and he will hear news, and will return to his own land. I will cause him to fall by the sword in his own land."'" 

###### v8 
So Rabshakeh returned, and found the king of Assyria warring against Libnah, for he heard that he had departed from Lachish. 

###### v9 
He heard news concerning Tirhakah king of Ethiopia, "He has come out to fight against you." When he heard it, he sent messengers to Hezekiah, saying, 

###### v10 
"Thus you shall speak to Hezekiah king of Judah, saying, 'Don't let your God in whom you trust deceive you, saying, "Jerusalem won't be given into the hand of the king of Assyria." 

###### v11 
Behold, you have heard what the kings of Assyria have done to all lands, by destroying them utterly. Shall you be delivered? 

###### v12 
Have the gods of the nations delivered them, which my fathers have destroyed, Gozan, Haran, Rezeph, and the children of Eden who were in Telassar? 

###### v13 
Where is the king of Hamath, and the king of Arpad, and the king of the city of Sepharvaim, of Hena, and Ivvah?'" 

###### v14 
Hezekiah received the letter from the hand of the messengers and read it. Then Hezekiah went up to Yahweh's house, and spread it before Yahweh. 

###### v15 
Hezekiah prayed to Yahweh, saying, 

###### v16 
"Yahweh of Armies, the God of Israel, who is enthroned among the cherubim, you are the God, even you alone, of all the kingdoms of the earth. You have made heaven and earth. 

###### v17 
Turn your ear, Yahweh, and hear. Open your eyes, Yahweh, and behold. Hear all of the words of Sennacherib, who has sent to defy the living God. 

###### v18 
Truly, Yahweh, the kings of Assyria have destroyed all the countries and their land, 

###### v19 
and have cast their gods into the fire; for they were no gods, but the work of men's hands, wood and stone; therefore they have destroyed them. 

###### v20 
Now therefore, Yahweh our God, save us from his hand, that all the kingdoms of the earth may know that you are Yahweh, even you only." 

###### v21 
Then Isaiah the son of Amoz sent to Hezekiah, saying, "Yahweh, the God of Israel says, 'Because you have prayed to me against Sennacherib king of Assyria, 

###### v22 
this is the word which Yahweh has spoken concerning him. The virgin daughter of Zion has despised you and ridiculed you. The daughter of Jerusalem has shaken her head at you. 

###### v23 
Whom have you defied and blasphemed? Against whom have you exalted your voice and lifted up your eyes on high? Against the Holy One of Israel. 

###### v24 
By your servants, you have defied the Lord, and have said, "With the multitude of my chariots I have come up to the height of the mountains, to the innermost parts of Lebanon. I will cut down its tall cedars and its choice cypress trees. I will enter into its farthest height, the forest of its fruitful field. 

###### v25 
I have dug and drunk water, and with the sole of my feet I will dry up all the rivers of Egypt." 

###### v26 
"'Have you not heard how I have done it long ago, and formed it in ancient times? Now I have brought it to pass, that it should be yours to destroy fortified cities, turning them into ruinous heaps. 

###### v27 
Therefore their inhabitants had little power. They were dismayed and confounded. They were like the grass of the field, and like the green herb, like the grass on the housetops, and like a field before its crop has grown. 

###### v28 
But I know your sitting down, your going out, your coming in, and your raging against me. 

###### v29 
Because of your raging against me, and because your arrogance has come up into my ears, therefore I will put my hook in your nose and my bridle in your lips, and I will turn you back by the way by which you came. 

###### v30 
"'This shall be the sign to you. You will eat this year that which grows of itself, and in the second year that which springs from it; and in the third year sow and reap and plant vineyards, and eat their fruit. 

###### v31 
The remnant that is escaped of the house of Judah will again take root downward, and bear fruit upward. 

###### v32 
For out of Jerusalem a remnant will go out, and survivors will escape from Mount Zion. The zeal of Yahweh of Armies will perform this.' 

###### v33 
"Therefore Yahweh says concerning the king of Assyria, 'He will not come to this city, nor shoot an arrow there, neither will he come before it with shield, nor cast up a mound against it. 

###### v34 
He will return the way that he came, and he won't come to this city,' says Yahweh. 

###### v35 
'For I will defend this city to save it, for my own sake, and for my servant David's sake.'" 

###### v36 
Then Yahweh's angel went out and struck one hundred and eighty-five thousand men in the camp of the Assyrians. When men arose early in the morning, behold, these were all dead bodies. 

###### v37 
So Sennacherib king of Assyria departed, went away, returned to Nineveh, and stayed there. 

###### v38 
As he was worshiping in the house of Nisroch his god, Adrammelech and Sharezer his sons struck him with the sword; and they escaped into the land of Ararat. Esar Haddon his son reigned in his place.

***
[[Isa-36|← Isaiah 36]] | [[Isaiah]] | [[Isa-38|Isaiah 38 →]]
