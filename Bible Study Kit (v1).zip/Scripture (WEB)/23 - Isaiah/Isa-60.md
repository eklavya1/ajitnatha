# Isaiah 60

[[Isa-59|← Isaiah 59]] | [[Isaiah]] | [[Isa-61|Isaiah 61 →]]
***



###### v1 
"Arise, shine; for your light has come, and Yahweh's glory has risen on you. 

###### v2 
For, behold, darkness will cover the earth, and thick darkness the peoples; but Yahweh will arise on you, and his glory shall be seen on you. 

###### v3 
Nations will come to your light, and kings to the brightness of your rising. 

###### v4 
"Lift up your eyes all around, and see: they all gather themselves together. They come to you. Your sons will come from far away, and your daughters will be carried in arms. 

###### v5 
Then you shall see and be radiant, and your heart will thrill and be enlarged; because the abundance of the sea will be turned to you. The wealth of the nations will come to you. 

###### v6 
A multitude of camels will cover you, the dromedaries of Midian and Ephah. All from Sheba will come. They will bring gold and frankincense, and will proclaim the praises of Yahweh. 

###### v7 
All the flocks of Kedar will be gathered together to you. The rams of Nebaioth will serve you. They will be accepted as offerings on my altar; and I will beautify my glorious house. 

###### v8 
"Who are these who fly as a cloud, and as the doves to their windows? 

###### v9 
Surely the islands will wait for me, and the ships of Tarshish first, to bring your sons from far away, their silver and their gold with them, for the name of Yahweh your God, and for the Holy One of Israel, because he has glorified you. 

###### v10 
"Foreigners will build up your walls, and their kings will serve you: for in my wrath I struck you, but in my favor I have had mercy on you. 

###### v11 
Your gates also shall be open continually; they shall not be shut day nor night, that men may bring to you the wealth of the nations, and their kings led captive. 

###### v12 
For that nation and kingdom that will not serve you shall perish; yes, those nations shall be utterly wasted. 

###### v13 
"The glory of Lebanon shall come to you, the cypress tree, the pine, and the box tree together, to beautify the place of my sanctuary; and I will make the place of my feet glorious. 

###### v14 
The sons of those who afflicted you will come bowing to you; and all those who despised you will bow themselves down at the soles of your feet. They will call you Yahweh's City, the Zion of the Holy One of Israel. 

###### v15 
"Whereas you have been forsaken and hated, so that no one passed through you, I will make you an eternal excellency, a joy of many generations. 

###### v16 
You will also drink the milk of the nations, and will nurse from royal breasts. Then you will know that I, Yahweh, am your Savior, your Redeemer, the Mighty One of Jacob. 

###### v17 
For bronze I will bring gold; for iron I will bring silver; for wood, bronze, and for stones, iron. I will also make peace your governor, and righteousness your ruler. 

###### v18 
Violence shall no more be heard in your land, nor desolation or destruction within your borders; but you will call your walls Salvation, and your gates Praise. 

###### v19 
The sun will be no more your light by day; nor will the brightness of the moon give light to you, but Yahweh will be your everlasting light, and your God will be your glory. 

###### v20 
Your sun will not go down any more, nor will your moon withdraw itself; for Yahweh will be your everlasting light, and the days of your mourning will end. 

###### v21 
Then your people will all be righteous. They will inherit the land forever, the branch of my planting, the work of my hands, that I may be glorified. 

###### v22 
The little one will become a thousand, and the small one a strong nation. I, Yahweh, will do this quickly in its time."

***
[[Isa-59|← Isaiah 59]] | [[Isaiah]] | [[Isa-61|Isaiah 61 →]]
