# Isaiah 28

[[Isa-27|← Isaiah 27]] | [[Isaiah]] | [[Isa-29|Isaiah 29 →]]
***



###### v1 
Woe to the crown of pride of the drunkards of Ephraim, and to the fading flower of his glorious beauty, which is on the head of the fertile valley of those who are overcome with wine! 

###### v2 
Behold, the Lord has a mighty and strong one. Like a storm of hail, a destroying storm, and like a storm of mighty waters overflowing, he will cast them down to the earth with his hand. 

###### v3 
The crown of pride of the drunkards of Ephraim will be trodden under foot. 

###### v4 
The fading flower of his glorious beauty, which is on the head of the fertile valley, shall be like the first-ripe fig before the summer; which someone picks and eats as soon as he sees it. 

###### v5 
In that day, Yahweh of Armies will become a crown of glory and a diadem of beauty to the residue of his people, 

###### v6 
and a spirit of justice to him who sits in judgment, and strength to those who turn back the battle at the gate. 

###### v7 
They also reel with wine, and stagger with strong drink. The priest and the prophet reel with strong drink. They are swallowed up by wine. They stagger with strong drink. They err in vision. They stumble in judgment. 

###### v8 
For all tables are completely full of filthy vomit and filthiness. 

###### v9 
Whom will he teach knowledge? To whom will he explain the message? Those who are weaned from the milk, and drawn from the breasts? 

###### v10 
For it is precept on precept, precept on precept; line on line, line on line; here a little, there a little. 

###### v11 
But he will speak to this nation with stammering lips and in another language, 

###### v12 
to whom he said, "This is the resting place. Give rest to the weary," and "This is the refreshing;" yet they would not hear. 

###### v13 
Therefore Yahweh's word will be to them precept on precept, precept on precept; line on line, line on line; here a little, there a little; that they may go, fall backward, be broken, be snared, and be taken. 

###### v14 
Therefore hear Yahweh's word, you scoffers, that rule this people in Jerusalem: 

###### v15 
"Because you have said, 'We have made a covenant with death, and we are in agreement with Sheol. When the overflowing scourge passes through, it won't come to us; for we have made lies our refuge, and we have hidden ourselves under falsehood.'" 

###### v16 
Therefore the Lord Yahweh says, "Behold, I lay in Zion for a foundation a stone, a tried stone, a precious cornerstone of a sure foundation. He who believes shall not act hastily. 

###### v17 
I will make justice the measuring line, and righteousness the plumb line. The hail will sweep away the refuge of lies, and the waters will overflow the hiding place. 

###### v18 
Your covenant with death shall be annulled, and your agreement with Sheol shall not stand. When the overflowing scourge passes through, then you will be trampled down by it. 

###### v19 
As often as it passes through, it will seize you; for morning by morning it will pass through, by day and by night; and it will be nothing but terror to understand the message." 

###### v20 
For the bed is too short to stretch out on, and the blanket is too narrow to wrap oneself in. 

###### v21 
For Yahweh will rise up as on Mount Perazim. He will be angry as in the valley of Gibeon; that he may do his work, his unusual work, and bring to pass his act, his extraordinary act. 

###### v22 
Now therefore don't be scoffers, lest your bonds be made strong; for I have heard a decree of destruction from the Lord, Yahweh of Armies, on the whole earth. 

###### v23 
Give ear, and hear my voice! Listen, and hear my speech! 

###### v24 
Does he who plows to sow plow continually? Does he keep turning the soil and breaking the clods? 

###### v25 
When he has leveled its surface, doesn't he plant the dill, and scatter the cumin seed, and put in the wheat in rows, the barley in the appointed place, and the spelt in its place? 

###### v26 
For his God instructs him in right judgment and teaches him. 

###### v27 
For the dill are not threshed with a sharp instrument, neither is a cart wheel turned over the cumin; but the dill is beaten out with a stick, and the cumin with a rod. 

###### v28 
Bread flour must be ground; so he will not always be threshing it. Although he drives the wheel of his threshing cart over it, his horses don't grind it. 

###### v29 
This also comes out from Yahweh of Armies, who is wonderful in counsel, and excellent in wisdom.

***
[[Isa-27|← Isaiah 27]] | [[Isaiah]] | [[Isa-29|Isaiah 29 →]]
