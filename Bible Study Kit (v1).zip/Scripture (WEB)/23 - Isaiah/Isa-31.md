# Isaiah 31

[[Isa-30|← Isaiah 30]] | [[Isaiah]] | [[Isa-32|Isaiah 32 →]]
***



###### v1 
Woe to those who go down to Egypt for help, and rely on horses, and trust in chariots because they are many, and in horsemen because they are very strong, but they don't look to the Holy One of Israel, and they don't seek Yahweh! 

###### v2 
Yet he also is wise, and will bring disaster, and will not call back his words, but will arise against the house of the evildoers, and against the help of those who work iniquity. 

###### v3 
Now the Egyptians are men, and not God; and their horses flesh, and not spirit. When Yahweh stretches out his hand, both he who helps shall stumble, and he who is helped shall fall, and they all shall be consumed together. 

###### v4 
For Yahweh says to me, "As the lion and the young lion growling over his prey, if a multitude of shepherds is called together against him, will not be dismayed at their voice, nor abase himself for their noise, so Yahweh of Armies will come down to fight on Mount Zion and on its heights. 

###### v5 
As birds hovering, so Yahweh of Armies will protect Jerusalem. He will protect and deliver it. He will pass over and preserve it." 

###### v6 
Return to him from whom you have deeply revolted, children of Israel. <sup class="versenum mid-line">7</sup>For in that day everyone shall cast away his idols of silver and his idols of gold--sin which your own hands have made for you. 

###### v8 
"The Assyrian will fall by the sword, not of man; and the sword, not of mankind, shall devour him. He will flee from the sword, and his young men will become subject to forced labor. 

###### v9 
His rock will pass away by reason of terror, and his princes will be afraid of the banner," says Yahweh, whose fire is in Zion, and his furnace in Jerusalem.

***
[[Isa-30|← Isaiah 30]] | [[Isaiah]] | [[Isa-32|Isaiah 32 →]]
