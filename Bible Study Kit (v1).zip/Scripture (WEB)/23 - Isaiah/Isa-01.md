# Isaiah 1

[[Isaiah]] | [[Isa-02|Isaiah 02 →]]
***



###### v1 
The vision of Isaiah the son of Amoz, which he saw concerning Judah and Jerusalem, in the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah. 

###### v2 
Hear, heavens, and listen, earth; for Yahweh has spoken: "I have nourished and brought up children and they have rebelled against me. 

###### v3 
The ox knows his owner, and the donkey his master's crib; but Israel doesn't know. My people don't consider." 

###### v4 
Ah sinful nation, a people loaded with iniquity, offspring of evildoers, children who deal corruptly! They have forsaken Yahweh. They have despised the Holy One of Israel. They are estranged and backward. 

###### v5 
Why should you be beaten more, that you revolt more and more? The whole head is sick, and the whole heart faint. 

###### v6 
From the sole of the foot even to the head there is no soundness in it: wounds, welts, and open sores. They haven't been closed, bandaged, or soothed with oil. 

###### v7 
Your country is desolate. Your cities are burned with fire. Strangers devour your land in your presence and it is desolate, as overthrown by strangers. 

###### v8 
The daughter of Zion is left like a shelter in a vineyard, like a hut in a field of melons, like a besieged city. 

###### v9 
Unless Yahweh of Armies had left to us a very small remnant, we would have been as Sodom. We would have been like Gomorrah. 

###### v10 
Hear Yahweh's word, you rulers of Sodom! Listen to the law of our God, you people of Gomorrah! 

###### v11 
"What are the multitude of your sacrifices to me?", says Yahweh. "I have had enough of the burnt offerings of rams and the fat of fed animals. I don't delight in the blood of bulls, or of lambs, or of male goats. 

###### v12 
When you come to appear before me, who has required this at your hand, to trample my courts? 

###### v13 
Bring no more vain offerings. Incense is an abomination to me. New moons, Sabbaths, and convocations: I can't stand evil assemblies. 

###### v14 
My soul hates your New Moons and your appointed feasts. They are a burden to me. I am weary of bearing them. 

###### v15 
When you spread out your hands, I will hide my eyes from you. Yes, when you make many prayers, I will not hear. Your hands are full of blood. 

###### v16 
Wash yourselves. Make yourself clean. Put away the evil of your doings from before my eyes. Cease to do evil. 

###### v17 
Learn to do well. Seek justice. Relieve the oppressed. Defend the fatherless. Plead for the widow." 

###### v18 
"Come now, and let's reason together," says Yahweh: "Though your sins are as scarlet, they shall be as white as snow. Though they are red like crimson, they shall be as wool. 

###### v19 
If you are willing and obedient, you will eat the good of the land; 

###### v20 
but if you refuse and rebel, you will be devoured with the sword; for the Yahweh's mouth has spoken it." 

###### v21 
How the faithful city has become a prostitute! She was full of justice. Righteousness lodged in her, but now there are murderers. 

###### v22 
Your silver has become dross, your wine mixed with water. 

###### v23 
Your princes are rebellious and companions of thieves. Everyone loves bribes and follows after rewards. They don't defend the fatherless, neither does the cause of the widow come to them. 

###### v24 
Therefore the Lord, Yahweh of Armies, the Mighty One of Israel, says: "Ah, I will get relief from my adversaries, and avenge myself on my enemies. 

###### v25 
I will turn my hand on you, thoroughly purge away your dross, and will take away all your tin. 

###### v26 
I will restore your judges as at the first, and your counselors as at the beginning. Afterward you shall be called 'The city of righteousness, a faithful town.' 

###### v27 
Zion shall be redeemed with justice, and her converts with righteousness. 

###### v28 
But the destruction of transgressors and sinners shall be together, and those who forsake Yahweh shall be consumed. 

###### v29 
For they shall be ashamed of the oaks which you have desired, and you shall be confounded for the gardens that you have chosen. 

###### v30 
For you shall be as an oak whose leaf fades, and as a garden that has no water. 

###### v31 
The strong will be like tinder, and his work like a spark. They will both burn together, and no one will quench them."

***
[[Isaiah]] | [[Isa-02|Isaiah 02 →]]
