# Isaiah 22

[[Isa-21|← Isaiah 21]] | [[Isaiah]] | [[Isa-23|Isaiah 23 →]]
***



###### v1 
The burden of the valley of vision. What ails you now, that you have all gone up to the housetops? 

###### v2 
You that are full of shouting, a tumultuous city, a joyous town; your slain are not slain with the sword, neither are they dead in battle. 

###### v3 
All your rulers fled away together. They were bound by the archers. All who were found by you were bound together. They fled far away. 

###### v4 
Therefore I said, "Look away from me. I will weep bitterly. Don't labor to comfort me for the destruction of the daughter of my people. 

###### v5 
For it is a day of confusion, and of treading down, and of perplexity, from the Lord, Yahweh of Armies, in the valley of vision, a breaking down of the walls, and a crying to the mountains." 

###### v6 
Elam carried his quiver, with chariots of men and horsemen; and Kir uncovered the shield. 

###### v7 
Your choicest valleys were full of chariots, and the horsemen set themselves in array at the gate. 

###### v8 
He took away the covering of Judah; and you looked in that day to the armor in the house of the forest. 

###### v9 
You saw the breaches of David's city, that they were many; and you gathered together the waters of the lower pool. 

###### v10 
You counted the houses of Jerusalem, and you broke down the houses to fortify the wall. 

###### v11 
You also made a reservoir between the two walls for the water of the old pool. But you didn't look to him who had done this, neither did you have respect for him who planned it long ago. 

###### v12 
In that day, the Lord, Yahweh of Armies, called to weeping, to mourning, to baldness, and to dressing in sackcloth; 

###### v13 
and behold, joy and gladness, killing cattle and killing sheep, eating meat and drinking wine: "Let's eat and drink, for tomorrow we will die." 

###### v14 
Yahweh of Armies revealed himself in my ears, "Surely this iniquity will not be forgiven you until you die," says the Lord, Yahweh of Armies. 

###### v15 
The Lord, Yahweh of Armies says, "Go, get yourself to this treasurer, even to Shebna, who is over the house, and say, 

###### v16 
'What are you doing here? Who has you here, that you have dug out a tomb here?' Cutting himself out a tomb on high, chiseling a habitation for himself in the rock!" 

###### v17 
Behold, Yahweh will overcome you and hurl you away violently. Yes, he will grasp you firmly. 

###### v18 
He will surely wind you around and around, and throw you like a ball into a large country. There you will die, and there the chariots of your glory will be, you disgrace of your lord's house. 

###### v19 
I will thrust you from your office. You will be pulled down from your station. 

###### v20 
It will happen in that day that I will call my servant Eliakim the son of Hilkiah, 

###### v21 
and I will clothe him with your robe, and strengthen him with your belt. I will commit your government into his hand; and he will be a father to the inhabitants of Jerusalem, and to the house of Judah. 

###### v22 
I will lay the key of David's house on his shoulder. He will open, and no one will shut. He will shut, and no one will open. 

###### v23 
I will fasten him like a nail in a sure place. He will be for a throne of glory to his father's house. 

###### v24 
They will hang on him all the glory of his father's house, the offspring and the issue, every small vessel, from the cups even to all the pitchers. 

###### v25 
"In that day," says Yahweh of Armies, "the nail that was fastened in a sure place will give way. It will be cut down and fall. The burden that was on it will be cut off, for Yahweh has spoken it."

***
[[Isa-21|← Isaiah 21]] | [[Isaiah]] | [[Isa-23|Isaiah 23 →]]
