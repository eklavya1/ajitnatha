# Isaiah 26

[[Isa-25|← Isaiah 25]] | [[Isaiah]] | [[Isa-27|Isaiah 27 →]]
***



###### v1 
In that day, this song will be sung in the land of Judah: "We have a strong city. God appoints salvation for walls and bulwarks. 

###### v2 
Open the gates, that the righteous nation may enter: the one which keeps faith. 

###### v3 
You will keep whoever's mind is steadfast in perfect peace, because he trusts in you. 

###### v4 
Trust in Yahweh forever; for in Yah, Yahweh, is an everlasting Rock. 

###### v5 
For he has brought down those who dwell on high, the lofty city. He lays it low. He lays it low even to the ground. He brings it even to the dust. 

###### v6 
The foot shall tread it down, even the feet of the poor and the steps of the needy." 

###### v7 
The way of the just is uprightness. You who are upright make the path of the righteous level. 

###### v8 
Yes, in the way of your judgments, Yahweh, we have waited for you. Your name and your renown are the desire of our soul. 

###### v9 
With my soul I have desired you in the night. Yes, with my spirit within me I will seek you earnestly; for when your judgments are in the earth, the inhabitants of the world learn righteousness. 

###### v10 
Let favor be shown to the wicked, yet he will not learn righteousness. In the land of uprightness he will deal wrongfully, and will not see Yahweh's majesty. 

###### v11 
Yahweh, your hand is lifted up, yet they don't see; but they will see your zeal for the people, and be disappointed. Yes, fire will consume your adversaries. 

###### v12 
Yahweh, you will ordain peace for us, for you have also done all our work for us. 

###### v13 
Yahweh our God, other lords besides you have had dominion over us, but we will only acknowledge your name. 

###### v14 
The dead shall not live. The departed spirits shall not rise. Therefore you have visited and destroyed them, and caused all memory of them to perish. 

###### v15 
You have increased the nation, O Yahweh. You have increased the nation! You are glorified! You have enlarged all the borders of the land. 

###### v16 
Yahweh, in trouble they have visited you. They poured out a prayer when your chastening was on them. 

###### v17 
Just as a woman with child, who draws near the time of her delivery, is in pain and cries out in her pangs, so we have been before you, Yahweh. 

###### v18 
We have been with child. We have been in pain. We gave birth, it seems, only to wind. We have not worked any deliverance in the earth; neither have the inhabitants of the world fallen. 

###### v19 
Your dead shall live. My dead bodies shall arise. Awake and sing, you who dwell in the dust; for your dew is like the dew of herbs, and the earth will cast out the departed spirits. 

###### v20 
Come, my people, enter into your rooms, and shut your doors behind you. Hide yourself for a little moment, until the indignation is past. 

###### v21 
For, behold, Yahweh comes out of his place to punish the inhabitants of the earth for their iniquity. The earth also will disclose her blood, and will no longer cover her slain.

***
[[Isa-25|← Isaiah 25]] | [[Isaiah]] | [[Isa-27|Isaiah 27 →]]
