# Isaiah 52

[[Isa-51|← Isaiah 51]] | [[Isaiah]] | [[Isa-53|Isaiah 53 →]]
***



###### v1 
Awake, awake! Put on your strength, Zion. Put on your beautiful garments, Jerusalem, the holy city: for from now on the uncircumcised and the unclean will no more come into you. 

###### v2 
Shake yourself from the dust! Arise, sit up, Jerusalem! Release yourself from the bonds of your neck, captive daughter of Zion! 

###### v3 
For Yahweh says, "You were sold for nothing; and you will be redeemed without money." 

###### v4 
For the Lord Yahweh says: "My people went down at the first into Egypt to live there: and the Assyrian has oppressed them without cause. 

###### v5 
"Now therefore, what do I do here," says Yahweh, "seeing that my people are taken away for nothing? Those who rule over them mock," says Yahweh, "and my name is blasphemed continually all day long. 

###### v6 
Therefore my people shall know my name. Therefore they shall know in that day that I am he who speaks. Behold, it is I." 

###### v7 
How beautiful on the mountains are the feet of him who brings good news, who publishes peace, who brings good news, who proclaims salvation, who says to Zion, "Your God reigns!" 

###### v8 
Your watchmen lift up their voice. Together they sing; for they shall see eye to eye when Yahweh returns to Zion. 

###### v9 
Break out into joy! Sing together, you waste places of Jerusalem; for Yahweh has comforted his people. He has redeemed Jerusalem. 

###### v10 
Yahweh has made his holy arm bare in the eyes of all the nations. All the ends of the earth have seen the salvation of our God. 

###### v11 
Depart! Depart! Go out from there! Touch no unclean thing! Go out from among her! Cleanse yourselves, you who carry Yahweh's vessels. 

###### v12 
For you shall not go out in haste, neither shall you go by flight: for Yahweh will go before you; and the God of Israel will be your rear guard. 

###### v13 
Behold, my servant will deal wisely. He will be exalted and lifted up, and will be very high. 

###### v14 
Just as many were astonished at you-- his appearance was marred more than any man, and his form more than the sons of men-- 

###### v15 
so he will cleanse many nations. Kings will shut their mouths at him; for they will see that which had not been told them, and they will understand that which they had not heard.

***
[[Isa-51|← Isaiah 51]] | [[Isaiah]] | [[Isa-53|Isaiah 53 →]]
