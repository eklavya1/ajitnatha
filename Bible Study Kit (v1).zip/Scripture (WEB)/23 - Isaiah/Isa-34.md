# Isaiah 34

[[Isa-33|← Isaiah 33]] | [[Isaiah]] | [[Isa-35|Isaiah 35 →]]
***



###### v1 
Come near, you nations, to hear! Listen, you peoples. Let the earth and all it contains hear, the world, and everything that comes from it. 

###### v2 
For Yahweh is enraged against all the nations, and angry with all their armies. He has utterly destroyed them. He has given them over for slaughter. 

###### v3 
Their slain will also be cast out, and the stench of their dead bodies will come up. The mountains will melt in their blood. 

###### v4 
All of the army of the sky will be dissolved. The sky will be rolled up like a scroll, and all its armies will fade away, as a leaf fades from off a vine or a fig tree. 

###### v5 
For my sword has drunk its fill in the sky. Behold, it will come down on Edom, and on the people of my curse, for judgment. 

###### v6 
Yahweh's sword is filled with blood. It is covered with fat, with the blood of lambs and goats, with the fat of the kidneys of rams; for Yahweh has a sacrifice in Bozrah, And a great slaughter in the land of Edom. 

###### v7 
The wild oxen will come down with them, and the young bulls with the mighty bulls; and their land will be drunken with blood, and their dust made greasy with fat. 

###### v8 
For Yahweh has a day of vengeance, a year of recompense for the cause of Zion. 

###### v9 
Its streams will be turned into pitch, its dust into sulfur, And its land will become burning pitch. 

###### v10 
It won't be quenched night or day. Its smoke will go up forever. From generation to generation, it will lie waste. No one will pass through it forever and ever. 

###### v11 
But the pelican and the porcupine will possess it. The owl and the raven will dwell in it. He will stretch the line of confusion over it, and the plumb line of emptiness. 

###### v12 
They shall call its nobles to the kingdom, but none shall be there; and all its princes shall be nothing. 

###### v13 
Thorns will come up in its palaces, nettles and thistles in its fortresses; and it will be a habitation of jackals, a court for ostriches. 

###### v14 
The wild animals of the desert will meet with the wolves, and the wild goat will cry to his fellow. Yes, the night creature shall settle there, and shall find herself a place of rest. 

###### v15 
The arrow snake will make her nest there, and lay, hatch, and gather under her shade. Yes, the kites will be gathered there, every one with her mate. 

###### v16 
Search in the book of Yahweh, and read: not one of these will be missing. None will lack her mate. For my mouth has commanded, and his Spirit has gathered them. 

###### v17 
He has cast the lot for them, and his hand has divided it to them with a measuring line. They shall possess it forever. From generation to generation they will dwell in it.

***
[[Isa-33|← Isaiah 33]] | [[Isaiah]] | [[Isa-35|Isaiah 35 →]]
