# Isaiah 55

[[Isa-54|← Isaiah 54]] | [[Isaiah]] | [[Isa-56|Isaiah 56 →]]
***



###### v1 
"Hey! Come, everyone who thirsts, to the waters! Come, he who has no money, buy, and eat! Yes, come, buy wine and milk without money and without price. 

###### v2 
Why do you spend money for that which is not bread, and your labor for that which doesn't satisfy? Listen diligently to me, and eat that which is good, and let your soul delight itself in richness. 

###### v3 
Turn your ear, and come to me. Hear, and your soul will live. I will make an everlasting covenant with you, even the sure mercies of David. 

###### v4 
Behold, I have given him for a witness to the peoples, a leader and commander to the peoples. 

###### v5 
Behold, you shall call a nation that you don't know; and a nation that didn't know you shall run to you, because of Yahweh your God, and for the Holy One of Israel; for he has glorified you." 

###### v6 
Seek Yahweh while he may be found. Call on him while he is near. 

###### v7 
Let the wicked forsake his way, and the unrighteous man his thoughts. Let him return to Yahweh, and he will have mercy on him, to our God, for he will freely pardon. 

###### v8 
"For my thoughts are not your thoughts, and your ways are not my ways," says Yahweh. 

###### v9 
"For as the heavens are higher than the earth, so are my ways higher than your ways, and my thoughts than your thoughts. 

###### v10 
For as the rain comes down and the snow from the sky, and doesn't return there, but waters the earth, and makes it grow and bud, and gives seed to the sower and bread to the eater; 

###### v11 
so is my word that goes out of my mouth: it will not return to me void, but it will accomplish that which I please, and it will prosper in the thing I sent it to do. 

###### v12 
For you shall go out with joy, and be led out with peace. The mountains and the hills will break out before you into singing; and all the trees of the fields will clap their hands. 

###### v13 
Instead of the thorn the cypress tree will come up; and instead of the brier the myrtle tree will come up. It will make a name for Yahweh, for an everlasting sign that will not be cut off."

***
[[Isa-54|← Isaiah 54]] | [[Isaiah]] | [[Isa-56|Isaiah 56 →]]
