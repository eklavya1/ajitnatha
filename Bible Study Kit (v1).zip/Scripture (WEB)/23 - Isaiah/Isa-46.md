# Isaiah 46

[[Isa-45|← Isaiah 45]] | [[Isaiah]] | [[Isa-47|Isaiah 47 →]]
***



###### v1 
Bel bows down. Nebo stoops. Their idols are carried by animals, and on the livestock. The things that you carried around are heavy loads, a burden for the weary. 

###### v2 
They stoop and they bow down together. They could not deliver the burden, but they have gone into captivity. 

###### v3 
"Listen to me, house of Jacob, and all the remnant of the house of Israel, that have been carried from their birth, that have been carried from the womb. 

###### v4 
Even to old age I am he, and even to gray hairs I will carry you. I have made, and I will bear. Yes, I will carry, and will deliver. 

###### v5 
"To whom will you compare me, and consider my equal, and compare me, as if we were the same? 

###### v6 
Some pour out gold from the bag, and weigh silver in the balance. They hire a goldsmith, and he makes it a god. They fall down-- yes, they worship. 

###### v7 
They bear it on their shoulder. They carry it, and set it in its place, and it stands there. It cannot move from its place. Yes, one may cry to it, yet it can not answer. It cannot save him out of his trouble. 

###### v8 
"Remember this, and show yourselves men. Bring it to mind again, you transgressors. 

###### v9 
Remember the former things of old: for I am God, and there is no other. I am God, and there is none like me. 

###### v10 
I declare the end from the beginning, and from ancient times things that are not yet done. I say: My counsel will stand, and I will do all that I please. 

###### v11 
I call a ravenous bird from the east, the man of my counsel from a far country. Yes, I have spoken. I will also bring it to pass. I have planned. I will also do it. 

###### v12 
Listen to me, you stubborn-hearted, who are far from righteousness! 

###### v13 
I bring my righteousness near. It is not far off, and my salvation will not wait. I will grant salvation to Zion, my glory to Israel.

***
[[Isa-45|← Isaiah 45]] | [[Isaiah]] | [[Isa-47|Isaiah 47 →]]
