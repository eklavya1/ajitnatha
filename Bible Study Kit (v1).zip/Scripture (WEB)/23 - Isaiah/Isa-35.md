# Isaiah 35

[[Isa-34|← Isaiah 34]] | [[Isaiah]] | [[Isa-36|Isaiah 36 →]]
***



###### v1 
The wilderness and the dry land will be glad. The desert will rejoice and blossom like a rose. 

###### v2 
It will blossom abundantly, and rejoice even with joy and singing. Lebanon's glory will be given to it, the excellence of Carmel and Sharon. They will see Yahweh's glory, the excellence of our God. 

###### v3 
Strengthen the weak hands, and make the feeble knees firm. 

###### v4 
Tell those who have a fearful heart, "Be strong! Don't be afraid! Behold, your God will come with vengeance, God's retribution. He will come and save you. 

###### v5 
Then the eyes of the blind will be opened, and the ears of the deaf will be unstopped. 

###### v6 
Then the lame man will leap like a deer, and the tongue of the mute will sing; for waters will break out in the wilderness, and streams in the desert. 

###### v7 
The burning sand will become a pool, and the thirsty ground springs of water. Grass with reeds and rushes will be in the habitation of jackals, where they lay. 

###### v8 
A highway will be there, a road, and it will be called "The Holy Way". The unclean shall not pass over it, but it will be for those who walk in the Way. Wicked fools shall not go there. 

###### v9 
No lion will be there, nor will any ravenous animal go up on it. They will not be found there; but the redeemed will walk there. 

###### v10 
Then Yahweh's ransomed ones will return, and come with singing to Zion; and everlasting joy will be on their heads. They will obtain gladness and joy, and sorrow and sighing will flee away."

***
[[Isa-34|← Isaiah 34]] | [[Isaiah]] | [[Isa-36|Isaiah 36 →]]
