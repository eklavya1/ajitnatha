# Isaiah 38

[[Isa-37|← Isaiah 37]] | [[Isaiah]] | [[Isa-39|Isaiah 39 →]]
***



###### v1 
In those days Hezekiah was sick and near death. Isaiah the prophet, the son of Amoz, came to him, and said to him, "Yahweh says, 'Set your house in order, for you will die, and not live.'" 

###### v2 
Then Hezekiah turned his face to the wall and prayed to Yahweh, 

###### v3 
and said, "Remember now, Yahweh, I beg you, how I have walked before you in truth and with a perfect heart, and have done that which is good in your sight." Then Hezekiah wept bitterly. 

###### v4 
Then Yahweh's word came to Isaiah, saying, 

###### v5 
"Go, and tell Hezekiah, 'Yahweh, the God of David your father, says, "I have heard your prayer. I have seen your tears. Behold, I will add fifteen years to your life. 

###### v6 
I will deliver you and this city out of the hand of the king of Assyria, and I will defend this city. 

###### v7 
This shall be the sign to you from Yahweh, that Yahweh will do this thing that he has spoken. 

###### v8 
Behold, I will cause the shadow on the sundial, which has gone down on the sundial of Ahaz with the sun, to return backward ten steps."'" So the sun returned ten steps on the sundial on which it had gone down. 

###### v9 
The writing of Hezekiah king of Judah, when he had been sick, and had recovered of his sickness. 

###### v10 
I said, "In the middle of my life I go into the gates of Sheol. I am deprived of the residue of my years." 

###### v11 
I said, "I won't see Yah, Yah in the land of the living. I will see man no more with the inhabitants of the world. 

###### v12 
My dwelling is removed, and is carried away from me like a shepherd's tent. I have rolled up my life like a weaver. He will cut me off from the loom. From day even to night you will make an end of me. 

###### v13 
I waited patiently until morning. He breaks all my bones like a lion. From day even to night you will make an end of me. 

###### v14 
I chattered like a swallow or a crane. I moaned like a dove. My eyes weaken looking upward. Lord, I am oppressed. Be my security." 

###### v15 
What will I say? He has both spoken to me, and himself has done it. I will walk carefully all my years because of the anguish of my soul. 

###### v16 
Lord, men live by these things; and my spirit finds life in all of them: you restore me, and cause me to live. 

###### v17 
Behold, for peace I had great anguish, but you have in love for my soul delivered it from the pit of corruption; for you have cast all my sins behind your back. 

###### v18 
For Sheol can't praise you. Death can't celebrate you. Those who go down into the pit can't hope for your truth. 

###### v19 
The living, the living, he shall praise you, as I do today. The father shall make known your truth to the children. 

###### v20 
Yahweh will save me. Therefore we will sing my songs with stringed instruments all the days of our life in Yahweh's house. 

###### v21 
Now Isaiah had said, "Let them take a cake of figs, and lay it for a poultice on the boil, and he shall recover." 

###### v22 
Hezekiah also had said, "What is the sign that I will go up to Yahweh's house?"

***
[[Isa-37|← Isaiah 37]] | [[Isaiah]] | [[Isa-39|Isaiah 39 →]]
