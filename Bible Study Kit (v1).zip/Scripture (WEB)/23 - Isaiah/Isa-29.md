# Isaiah 29

[[Isa-28|← Isaiah 28]] | [[Isaiah]] | [[Isa-30|Isaiah 30 →]]
***



###### v1 
Woe to Ariel! Ariel, the city where David encamped! Add year to year; let the feasts come around; 

###### v2 
then I will distress Ariel, and there will be mourning and lamentation. She shall be to me as an altar hearth. 

###### v3 
I will encamp against you all around you, and will lay siege against you with posted troops. I will raise siege works against you. 

###### v4 
You will be brought down, and will speak out of the ground. Your speech will mumble out of the dust. Your voice will be as of one who has a familiar spirit, out of the ground, and your speech will whisper out of the dust. 

###### v5 
But the multitude of your foes will be like fine dust, and the multitude of the ruthless ones like chaff that blows away. Yes, it will be in an instant, suddenly. 

###### v6 
She will be visited by Yahweh of Armies with thunder, with earthquake, with great noise, with whirlwind and storm, and with the flame of a devouring fire. 

###### v7 
The multitude of all the nations that fight against Ariel, even all who fight against her and her stronghold, and who distress her, will be like a dream, a vision of the night. 

###### v8 
It will be like when a hungry man dreams, and behold, he eats; but he awakes, and his hunger isn't satisfied; or like when a thirsty man dreams, and behold, he drinks; but he awakes, and behold, he is faint, and he is still thirsty. The multitude of all the nations that fight against Mount Zion will be like that. 

###### v9 
Pause and wonder! Blind yourselves and be blind! They are drunken, but not with wine; they stagger, but not with strong drink. 

###### v10 
For Yahweh has poured out on you a spirit of deep sleep, and has closed your eyes, the prophets; and he has covered your heads, the seers. 

###### v11 
All vision has become to you like the words of a book that is sealed, which men deliver to one who is educated, saying, "Read this, please;" and he says, "I can't, for it is sealed;" 

###### v12 
and the book is delivered to one who is not educated, saying, "Read this, please;" and he says, "I can't read." 

###### v13 
The Lord said, "Because this people draws near with their mouth and honors me with their lips, but they have removed their heart far from me, and their fear of me is a commandment of men which has been taught; 

###### v14 
therefore, behold, I will proceed to do a marvelous work among this people, even a marvelous work and a wonder; and the wisdom of their wise men will perish, and the understanding of their prudent men will be hidden." 

###### v15 
Woe to those who deeply hide their counsel from Yahweh, and whose deeds are in the dark, and who say, "Who sees us?" and "Who knows us?" 

###### v16 
You turn things upside down! Should the potter be thought to be like clay; that the thing made should say about him who made it, "He didn't make me;" or the thing formed say of him who formed it, "He has no understanding?" 

###### v17 
Isn't it yet a very little while, and Lebanon will be turned into a fruitful field, and the fruitful field will be regarded as a forest? 

###### v18 
In that day, the deaf will hear the words of the book, and the eyes of the blind will see out of obscurity and out of darkness. 

###### v19 
The humble also will increase their joy in Yahweh, and the poor among men will rejoice in the Holy One of Israel. 

###### v20 
For the ruthless is brought to nothing, and the scoffer ceases, and all those who are alert to do evil are cut off-- 

###### v21 
who cause a person to be indicted by a word, and lay a snare for one who reproves in the gate, and who deprive the innocent of justice with false testimony. 

###### v22 
Therefore Yahweh, who redeemed Abraham, says concerning the house of Jacob: "Jacob shall no longer be ashamed, neither shall his face grow pale. 

###### v23 
But when he sees his children, the work of my hands, in the middle of him, they will sanctify my name. Yes, they will sanctify the Holy One of Jacob, and will stand in awe of the God of Israel. 

###### v24 
They also who err in spirit will come to understanding, and those who grumble will receive instruction."

***
[[Isa-28|← Isaiah 28]] | [[Isaiah]] | [[Isa-30|Isaiah 30 →]]
