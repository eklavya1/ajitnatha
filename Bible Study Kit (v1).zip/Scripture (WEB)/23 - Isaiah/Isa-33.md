# Isaiah 33

[[Isa-32|← Isaiah 32]] | [[Isaiah]] | [[Isa-34|Isaiah 34 →]]
***



###### v1 
Woe to you who destroy, but you weren't destroyed, and who betray, but nobody betrayed you! When you have finished destroying, you will be destroyed; and when you have finished betrayal, you will be betrayed. 

###### v2 
Yahweh, be gracious to us. We have waited for you. Be our strength every morning, our salvation also in the time of trouble. 

###### v3 
At the noise of the thunder, the peoples have fled. When you lift yourself up, the nations are scattered. 

###### v4 
Your plunder will be gathered as the caterpillar gathers. Men will leap on it as locusts leap. 

###### v5 
Yahweh is exalted, for he dwells on high. He has filled Zion with justice and righteousness. 

###### v6 
There will be stability in your times, abundance of salvation, wisdom, and knowledge. The fear of Yahweh is your treasure. 

###### v7 
Behold, their valiant ones cry outside; the ambassadors of peace weep bitterly. 

###### v8 
The highways are desolate. The traveling man ceases. The covenant is broken. He has despised the cities. He doesn't respect man. 

###### v9 
The land mourns and languishes. Lebanon is confounded and withers away. Sharon is like a desert, and Bashan and Carmel are stripped bare. 

###### v10 
"Now I will arise," says Yahweh. "Now I will lift myself up. Now I will be exalted. 

###### v11 
You will conceive chaff. You will give birth to stubble. Your breath is a fire that will devour you. 

###### v12 
The peoples will be like the burning of lime, like thorns that are cut down and burned in the fire. 

###### v13 
Hear, you who are far off, what I have done; and, you who are near, acknowledge my might." 

###### v14 
The sinners in Zion are afraid. Trembling has seized the godless ones. Who among us can live with the devouring fire? Who among us can live with everlasting burning? 

###### v15 
He who walks righteously and speaks blamelessly, he who despises the gain of oppressions, who gestures with his hands, refusing to take a bribe, who stops his ears from hearing of blood, and shuts his eyes from looking at evil-- 

###### v16 
he will dwell on high. His place of defense will be the fortress of rocks. His bread will be supplied. His waters will be sure. 

###### v17 
Your eyes will see the king in his beauty. They will see a distant land. 

###### v18 
Your heart will meditate on the terror. Where is he who counted? Where is he who weighed? Where is he who counted the towers? 

###### v19 
You will no longer see the fierce people, a people of a deep speech that you can't comprehend, with a strange language that you can't understand. 

###### v20 
Look at Zion, the city of our appointed festivals. Your eyes will see Jerusalem, a quiet habitation, a tent that won't be removed. Its stakes will never be plucked up, nor will any of its cords be broken. 

###### v21 
But there Yahweh will be with us in majesty, a place of wide rivers and streams, in which no galley with oars will go, neither will any gallant ship pass by there. 

###### v22 
For Yahweh is our judge. Yahweh is our lawgiver. Yahweh is our king. He will save us. 

###### v23 
Your rigging is untied. They couldn't strengthen the foot of their mast. They couldn't spread the sail. Then the prey of a great plunder was divided. The lame took the prey. 

###### v24 
The inhabitant won't say, "I am sick." The people who dwell therein will be forgiven their iniquity.

***
[[Isa-32|← Isaiah 32]] | [[Isaiah]] | [[Isa-34|Isaiah 34 →]]
