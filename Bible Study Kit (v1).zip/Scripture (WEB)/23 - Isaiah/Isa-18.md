# Isaiah 18

[[Isa-17|← Isaiah 17]] | [[Isaiah]] | [[Isa-19|Isaiah 19 →]]
***



###### v1 
Ah, the land of the rustling of wings, which is beyond the rivers of Ethiopia; 

###### v2 
that sends ambassadors by the sea, even in vessels of papyrus on the waters, saying, "Go, you swift messengers, to a nation tall and smooth, to a people awesome from their beginning onward, a nation that measures out and treads down, whose land the rivers divide!" 

###### v3 
All you inhabitants of the world, and you dwellers on the earth, when a banner is lifted up on the mountains, look! When the trumpet is blown, listen! 

###### v4 
For Yahweh said to me, "I will be still, and I will see in my dwelling place, like clear heat in sunshine, like a cloud of dew in the heat of harvest." 

###### v5 
For before the harvest, when the blossom is over, and the flower becomes a ripening grape, he will cut off the sprigs with pruning hooks, and he will cut down and take away the spreading branches. 

###### v6 
They will be left together for the ravenous birds of the mountains, and for the animals of the earth. The ravenous birds will eat them in the summer, and all the animals of the earth will eat them in the winter. 

###### v7 
In that time, a present will be brought to Yahweh of Armies from a people tall and smooth, even from a people awesome from their beginning onward, a nation that measures out and treads down, whose land the rivers divide, to the place of the name of Yahweh of Armies, Mount Zion.

***
[[Isa-17|← Isaiah 17]] | [[Isaiah]] | [[Isa-19|Isaiah 19 →]]
