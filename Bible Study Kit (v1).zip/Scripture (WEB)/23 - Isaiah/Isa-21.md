# Isaiah 21

[[Isa-20|← Isaiah 20]] | [[Isaiah]] | [[Isa-22|Isaiah 22 →]]
***



###### v1 
The burden of the wilderness of the sea. As whirlwinds in the South sweep through, it comes from the wilderness, from an awesome land. 

###### v2 
A grievous vision is declared to me. The treacherous man deals treacherously, and the destroyer destroys. Go up, Elam; attack! I have stopped all of Media's sighing. 

###### v3 
Therefore my thighs are filled with anguish. Pains have seized me, like the pains of a woman in labor. I am in so much pain that I can't hear. I am so dismayed that I can't see. 

###### v4 
My heart flutters. Horror has frightened me. The twilight that I desired has been turned into trembling for me. 

###### v5 
They prepare the table. They set the watch. They eat. They drink. Rise up, you princes, oil the shield! 

###### v6 
For the Lord said to me, "Go, set a watchman. Let him declare what he sees. 

###### v7 
When he sees a troop, horsemen in pairs, a troop of donkeys, a troop of camels, he shall listen diligently with great attentiveness." 

###### v8 
He cried like a lion: "Lord, I stand continually on the watchtower in the daytime, and every night I stay at my post. 

###### v9 
Behold, here comes a troop of men, horsemen in pairs." He answered, "Fallen, fallen is Babylon; and all the engraved images of her gods are broken to the ground. 

###### v10 
You are my threshing, and the grain of my floor!" That which I have heard from Yahweh of Armies, the God of Israel, I have declared to you. 

###### v11 
The burden of Dumah. One calls to me out of Seir, "Watchman, what of the night? Watchman, what of the night?" 

###### v12 
The watchman said, "The morning comes, and also the night. If you will inquire, inquire. Come back again." 

###### v13 
The burden on Arabia. In the forest in Arabia you will lodge, you caravans of Dedanites. 

###### v14 
They brought water to him who was thirsty. The inhabitants of the land of Tema met the fugitives with their bread. 

###### v15 
For they fled away from the swords, from the drawn sword, from the bent bow, and from the heat of battle. 

###### v16 
For the Lord said to me, "Within a year, as a worker bound by contract would count it, all the glory of Kedar will fail, 

###### v17 
and the residue of the number of the archers, the mighty men of the children of Kedar, will be few; for Yahweh, the God of Israel, has spoken it."

***
[[Isa-20|← Isaiah 20]] | [[Isaiah]] | [[Isa-22|Isaiah 22 →]]
