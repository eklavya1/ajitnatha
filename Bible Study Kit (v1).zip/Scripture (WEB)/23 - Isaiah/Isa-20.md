# Isaiah 20

[[Isa-19|← Isaiah 19]] | [[Isaiah]] | [[Isa-21|Isaiah 21 →]]
***



###### v1 
In the year that Tartan came to Ashdod, when Sargon the king of Assyria sent him, and he fought against Ashdod and took it; 

###### v2 
at that time Yahweh spoke by Isaiah the son of Amoz, saying, "Go, and loosen the sackcloth from off your waist, and take your sandals from off your feet." He did so, walking naked and barefoot. 

###### v3 
Yahweh said, "As my servant Isaiah has walked naked and barefoot three years for a sign and a wonder concerning Egypt and concerning Ethiopia, 

###### v4 
so the king of Assyria will lead away the captives of Egypt and the exiles of Ethiopia, young and old, naked and barefoot, and with buttocks uncovered, to the shame of Egypt. 

###### v5 
They will be dismayed and confounded, because of Ethiopia their expectation, and of Egypt their glory. 

###### v6 
The inhabitants of this coast land will say in that day, 'Behold, this is our expectation, where we fled for help to be delivered from the king of Assyria. And we, how will we escape?'"

***
[[Isa-19|← Isaiah 19]] | [[Isaiah]] | [[Isa-21|Isaiah 21 →]]
