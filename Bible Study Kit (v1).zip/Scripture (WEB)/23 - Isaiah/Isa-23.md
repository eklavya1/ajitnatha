# Isaiah 23

[[Isa-22|← Isaiah 22]] | [[Isaiah]] | [[Isa-24|Isaiah 24 →]]
***



###### v1 
The burden of Tyre. Howl, you ships of Tarshish! For it is laid waste, so that there is no house, no entering in. From the land of Kittim it is revealed to them. 

###### v2 
Be still, you inhabitants of the coast, you whom the merchants of Sidon that pass over the sea have replenished. 

###### v3 
On great waters, the seed of the Shihor, the harvest of the Nile, was her revenue. She was the market of nations. 

###### v4 
Be ashamed, Sidon; for the sea has spoken, the stronghold of the sea, saying, "I have not travailed, nor given birth, neither have I nourished young men, nor brought up virgins." 

###### v5 
When the report comes to Egypt, they will be in anguish at the report of Tyre. 

###### v6 
Pass over to Tarshish! Wail, you inhabitants of the coast! 

###### v7 
Is this your joyous city, whose antiquity is of ancient days, whose feet carried her far away to travel? 

###### v8 
Who has planned this against Tyre, the giver of crowns, whose merchants are princes, whose traders are the honorable of the earth? 

###### v9 
Yahweh of Armies has planned it, to stain the pride of all glory, to bring into contempt all the honorable of the earth. 

###### v10 
Pass through your land like the Nile, daughter of Tarshish. There is no restraint any more. 

###### v11 
He has stretched out his hand over the sea. He has shaken the kingdoms. Yahweh has ordered the destruction of Canaan's strongholds. 

###### v12 
He said, "You shall rejoice no more, you oppressed virgin daughter of Sidon. Arise, pass over to Kittim. Even there you will have no rest." 

###### v13 
Behold, the land of the Chaldeans. This people didn't exist. The Assyrians founded it for those who dwell in the wilderness. They set up their towers. They overthrew its palaces. They made it a ruin. 

###### v14 
Howl, you ships of Tarshish, for your stronghold is laid waste! 

###### v15 
It will come to pass in that day that Tyre will be forgotten seventy years, according to the days of one king. After the end of seventy years it will be to Tyre like in the song of the prostitute. 

###### v16 
Take a harp; go about the city, you prostitute that has been forgotten. Make sweet melody. Sing many songs, that you may be remembered. 

###### v17 
It will happen after the end of seventy years that Yahweh will visit Tyre. She will return to her wages, and will play the prostitute with all the kingdoms of the world on the surface of the earth. 

###### v18 
Her merchandise and her wages will be holiness to Yahweh. It will not be treasured nor laid up; for her merchandise will be for those who dwell before Yahweh, to eat sufficiently, and for durable clothing.

***
[[Isa-22|← Isaiah 22]] | [[Isaiah]] | [[Isa-24|Isaiah 24 →]]
