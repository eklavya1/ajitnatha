# Isaiah 58

[[Isa-57|← Isaiah 57]] | [[Isaiah]] | [[Isa-59|Isaiah 59 →]]
***



###### v1 
"Cry aloud! Don't spare! Lift up your voice like a trumpet! Declare to my people their disobedience, and to the house of Jacob their sins. 

###### v2 
Yet they seek me daily, and delight to know my ways. As a nation that did righteousness, and didn't forsake the ordinance of their God, they ask of me righteous judgments. They delight to draw near to God. 

###### v3 
'Why have we fasted,' they say, 'and you don't see? Why have we afflicted our soul, and you don't notice?' "Behold, in the day of your fast you find pleasure, and oppress all your laborers. 

###### v4 
Behold, you fast for strife and contention, and to strike with the fist of wickedness. You don't fast today so as to make your voice to be heard on high. 

###### v5 
Is this the fast that I have chosen? A day for a man to humble his soul? Is it to bow down his head like a reed, and to spread sackcloth and ashes under himself? Will you call this a fast, and an acceptable day to Yahweh? 

###### v6 
"Isn't this the fast that I have chosen: to release the bonds of wickedness, to undo the straps of the yoke, to let the oppressed go free, and that you break every yoke? 

###### v7 
Isn't it to distribute your bread to the hungry, and that you bring the poor who are cast out to your house? When you see the naked, that you cover him; and that you not hide yourself from your own flesh? 

###### v8 
Then your light will break out as the morning, and your healing will appear quickly; then your righteousness shall go before you, and Yahweh's glory will be your rear guard. 

###### v9 
Then you will call, and Yahweh will answer. You will cry for help, and he will say, 'Here I am.' "If you take away from among you the yoke, finger pointing, and speaking wickedly; 

###### v10 
and if you pour out your soul to the hungry, and satisfy the afflicted soul, then your light will rise in darkness, and your obscurity will be as the noonday; 

###### v11 
and Yahweh will guide you continually, satisfy your soul in dry places, and make your bones strong. You will be like a watered garden, and like a spring of water whose waters don't fail. 

###### v12 
Those who will be of you will build the old waste places. You will raise up the foundations of many generations. You will be called Repairer of the Breach, Restorer of Paths with Dwellings. 

###### v13 
"If you turn away your foot from the Sabbath, from doing your pleasure on my holy day; and call the Sabbath a delight, and the holy of Yahweh honorable; and honor it, not doing your own ways, nor finding your own pleasure, nor speaking your own words, 

###### v14 
then you will delight yourself in Yahweh, and I will make you to ride on the high places of the earth, and I will feed you with the heritage of Jacob your father;" for Yahweh's mouth has spoken it.

***
[[Isa-57|← Isaiah 57]] | [[Isaiah]] | [[Isa-59|Isaiah 59 →]]
