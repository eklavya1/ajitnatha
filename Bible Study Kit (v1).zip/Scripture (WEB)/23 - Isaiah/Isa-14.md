# Isaiah 14

[[Isa-13|← Isaiah 13]] | [[Isaiah]] | [[Isa-15|Isaiah 15 →]]
***



###### v1 
For Yahweh will have compassion on Jacob, and will yet choose Israel, and set them in their own land. The foreigner will join himself with them, and they will unite with the house of Jacob. 

###### v2 
The peoples will take them, and bring them to their place. The house of Israel will possess them in Yahweh's land for servants and for handmaids. They will take as captives those whose captives they were; and they shall rule over their oppressors. 

###### v3 
It will happen in the day that Yahweh will give you rest from your sorrow, from your trouble, and from the hard service in which you were made to serve, 

###### v4 
that you will take up this parable against the king of Babylon, and say, "How the oppressor has ceased! The golden city has ceased!" 

###### v5 
Yahweh has broken the staff of the wicked, the scepter of the rulers, 

###### v6 
who struck the peoples in wrath with a continual stroke, who ruled the nations in anger, with a persecution that no one restrained. 

###### v7 
The whole earth is at rest, and is quiet. They break out in song. 

###### v8 
Yes, the cypress trees rejoice with you, with the cedars of Lebanon, saying, "Since you are humbled, no lumberjack has come up against us." 

###### v9 
Sheol from beneath has moved for you to meet you at your coming. It stirs up the departed spirits for you, even all the rulers of the earth. It has raised up from their thrones all the kings of the nations. 

###### v10 
They all will answer and ask you, "Have you also become as weak as we are? Have you become like us?" 

###### v11 
Your pomp is brought down to Sheol, with the sound of your stringed instruments. Maggots are spread out under you, and worms cover you. 

###### v12 
How you have fallen from heaven, shining one, son of the dawn! How you are cut down to the ground, who laid the nations low! 

###### v13 
You said in your heart, "I will ascend into heaven! I will exalt my throne above the stars of God! I will sit on the mountain of assembly, in the far north! 

###### v14 
I will ascend above the heights of the clouds! I will make myself like the Most High!" 

###### v15 
Yet you shall be brought down to Sheol, to the depths of the pit. 

###### v16 
Those who see you will stare at you. They will ponder you, saying, "Is this the man who made the earth to tremble, who shook kingdoms, 

###### v17 
who made the world like a wilderness, and overthrew its cities, who didn't release his prisoners to their home?" 

###### v18 
All the kings of the nations sleep in glory, everyone in his own house. 

###### v19 
But you are cast away from your tomb like an abominable branch, clothed with the slain, who are thrust through with the sword, who go down to the stones of the pit; like a dead body trodden under foot. 

###### v20 
You will not join them in burial, because you have destroyed your land. You have killed your people. The offspring of evildoers will not be named forever. 

###### v21 
Prepare for slaughter of his children because of the iniquity of their fathers, that they not rise up and possess the earth, and fill the surface of the world with cities. 

###### v22 
"I will rise up against them," says Yahweh of Armies, "and cut off from Babylon name and remnant, and son and son's son," says Yahweh. 

###### v23 
"I will also make it a possession for the porcupine, and pools of water. I will sweep it with the broom of destruction," says Yahweh of Armies. 

###### v24 
Yahweh of Armies has sworn, saying, "Surely, as I have thought, so shall it happen; and as I have purposed, so shall it stand: 

###### v25 
that I will break the Assyrian in my land, and tread him under foot on my mountains. Then his yoke will leave them, and his burden leave their shoulders. 

###### v26 
This is the plan that is determined for the whole earth. This is the hand that is stretched out over all the nations. 

###### v27 
For Yahweh of Armies has planned, and who can stop it? His hand is stretched out, and who can turn it back?" 

###### v28 
This burden was in the year that king Ahaz died. 

###### v29 
Don't rejoice, O Philistia, all of you, because the rod that struck you is broken; for out of the serpent's root an adder will emerge, and his fruit will be a fiery flying serpent. 

###### v30 
The firstborn of the poor will eat, and the needy will lie down in safety; and I will kill your root with famine, and your remnant will be killed. 

###### v31 
Howl, gate! Cry, city! You are melted away, Philistia, all of you; for smoke comes out of the north, and there is no straggler in his ranks. 

###### v32 
What will they answer the messengers of the nation? That Yahweh has founded Zion, and in her the afflicted of his people will take refuge.

***
[[Isa-13|← Isaiah 13]] | [[Isaiah]] | [[Isa-15|Isaiah 15 →]]
