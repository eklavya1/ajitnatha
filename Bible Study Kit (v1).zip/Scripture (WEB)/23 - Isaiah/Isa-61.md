# Isaiah 61

[[Isa-60|← Isaiah 60]] | [[Isaiah]] | [[Isa-62|Isaiah 62 →]]
***



###### v1 
The Lord Yahweh's Spirit is on me, because Yahweh has anointed me to preach good news to the humble. He has sent me to bind up the broken hearted, to proclaim liberty to the captives and release to those who are bound, 

###### v2 
to proclaim the year of Yahweh's favor and the day of vengeance of our God, to comfort all who mourn, 

###### v3 
to provide for those who mourn in Zion, to give to them a garland for ashes, the oil of joy for mourning, the garment of praise for the spirit of heaviness, that they may be called trees of righteousness, the planting of Yahweh, that he may be glorified. 

###### v4 
They will rebuild the old ruins. They will raise up the former devastated places. They will repair the ruined cities that have been devastated for many generations. 

###### v5 
Strangers will stand and feed your flocks. Foreigners will work your fields and your vineyards. 

###### v6 
But you will be called Yahweh's priests. Men will call you the servants of our God. You will eat the wealth of the nations. You will boast in their glory. 

###### v7 
Instead of your shame you will have double. Instead of dishonor, they will rejoice in their portion. Therefore in their land they will possess double. Everlasting joy will be to them. 

###### v8 
"For I, Yahweh, love justice. I hate robbery and iniquity. I will give them their reward in truth and I will make an everlasting covenant with them. 

###### v9 
Their offspring will be known among the nations, and their offspring among the peoples. All who see them will acknowledge them, that they are the offspring which Yahweh has blessed." 

###### v10 
I will greatly rejoice in Yahweh! My soul will be joyful in my God, for he has clothed me with the garments of salvation. He has covered me with the robe of righteousness, as a bridegroom decks himself with a garland and as a bride adorns herself with her jewels. 

###### v11 
For as the earth produces its bud, and as the garden causes the things that are sown in it to spring up, so the Lord Yahweh will cause righteousness and praise to spring up before all the nations.

***
[[Isa-60|← Isaiah 60]] | [[Isaiah]] | [[Isa-62|Isaiah 62 →]]
