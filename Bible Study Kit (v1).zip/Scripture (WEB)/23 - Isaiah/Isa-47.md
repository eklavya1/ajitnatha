# Isaiah 47

[[Isa-46|← Isaiah 46]] | [[Isaiah]] | [[Isa-48|Isaiah 48 →]]
***



###### v1 
"Come down and sit in the dust, virgin daughter of Babylon. Sit on the ground without a throne, daughter of the Chaldeans. For you will no longer be called tender and delicate. 

###### v2 
Take the millstones and grind flour. Remove your veil, lift up your skirt, uncover your legs, and wade through the rivers. 

###### v3 
Your nakedness will be uncovered. Yes, your shame will be seen. I will take vengeance, and will spare no one." 

###### v4 
Our Redeemer, Yahweh of Armies is his name, is the Holy One of Israel. 

###### v5 
"Sit in silence, and go into darkness, daughter of the Chaldeans. For you shall no longer be called the mistress of kingdoms. 

###### v6 
I was angry with my people. I profaned my inheritance and gave them into your hand. You showed them no mercy. You laid a very heavy yoke on the aged. 

###### v7 
You said, 'I will be a princess forever,' so that you didn't lay these things to your heart, nor did you remember the results. 

###### v8 
"Now therefore hear this, you who are given to pleasures, who sit securely, who say in your heart, 'I am, and there is no one else besides me. I won't sit as a widow, neither will I know the loss of children.' 

###### v9 
But these two things will come to you in a moment in one day, the loss of children and widowhood. They will come on you in their full measure, in the multitude of your sorceries, and the great abundance of your enchantments. 

###### v10 
For you have trusted in your wickedness. You have said, 'No one sees me.' Your wisdom and your knowledge has perverted you. You have said in your heart, 'I am, and there is no one else besides me.' 

###### v11 
Therefore disaster will come on you. You won't know when it dawns. Mischief will fall on you. You won't be able to put it away. Desolation will come on you suddenly, which you don't understand. 

###### v12 
"Stand now with your enchantments and with the multitude of your sorceries, in which you have labored from your youth, as if you might profit, as if you might prevail. 

###### v13 
You are wearied in the multitude of your counsels. Now let the astrologers, the stargazers, and the monthly prognosticators stand up and save you from the things that will happen to you. 

###### v14 
Behold, they are like stubble. The fire will burn them. They won't deliver themselves from the power of the flame. It won't be a coal to warm at or a fire to sit by. 

###### v15 
The things that you labored in will be like this: those who have trafficked with you from your youth will each wander in his own way. There will be no one to save you.

***
[[Isa-46|← Isaiah 46]] | [[Isaiah]] | [[Isa-48|Isaiah 48 →]]
