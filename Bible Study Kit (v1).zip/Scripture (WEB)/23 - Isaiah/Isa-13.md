# Isaiah 13

[[Isa-12|← Isaiah 12]] | [[Isaiah]] | [[Isa-14|Isaiah 14 →]]
***



###### v1 
The burden of Babylon, which Isaiah the son of Amoz saw. 

###### v2 
Set up a banner on the bare mountain! Lift up your voice to them! Wave your hand, that they may go into the gates of the nobles. 

###### v3 
I have commanded my consecrated ones; yes, I have called my mighty men for my anger, even my proudly exulting ones. 

###### v4 
The noise of a multitude is in the mountains, as of a great people; the noise of an uproar of the kingdoms of the nations gathered together! Yahweh of Armies is mustering the army for the battle. 

###### v5 
They come from a far country, from the uttermost part of heaven, even Yahweh, and the weapons of his indignation, to destroy the whole land. 

###### v6 
Wail, for Yahweh's day is at hand! It will come as destruction from the Almighty. 

###### v7 
Therefore all hands will be feeble, and everyone's heart will melt. 

###### v8 
They will be dismayed. Pangs and sorrows will seize them. They will be in pain like a woman in labor. They will look in amazement one at another. Their faces will be faces of flame. 

###### v9 
Behold, the day of Yahweh comes, cruel, with wrath and fierce anger; to make the land a desolation, and to destroy its sinners out of it. 

###### v10 
For the stars of the sky and its constellations will not give their light. The sun will be darkened in its going out, and the moon will not cause its light to shine. 

###### v11 
I will punish the world for their evil, and the wicked for their iniquity. I will cause the arrogance of the proud to cease, and will humble the arrogance of the terrible. 

###### v12 
I will make people more rare than fine gold, even a person than the pure gold of Ophir. 

###### v13 
Therefore I will make the heavens tremble, and the earth will be shaken out of its place in Yahweh of Armies' wrath, and in the day of his fierce anger. 

###### v14 
It will happen that like a hunted gazelle, and like sheep that no one gathers, they will each turn to their own people, and will each flee to their own land. 

###### v15 
Everyone who is found will be thrust through. Everyone who is captured will fall by the sword. 

###### v16 
Their infants also will be dashed in pieces before their eyes. Their houses will be ransacked, and their wives raped. 

###### v17 
Behold, I will stir up the Medes against them, who will not value silver, and as for gold, they will not delight in it. 

###### v18 
Their bows will dash the young men in pieces; and they shall have no pity on the fruit of the womb. Their eyes will not spare children. 

###### v19 
Babylon, the glory of kingdoms, the beauty of the Chaldeans' pride, will be like when God overthrew Sodom and Gomorrah. 

###### v20 
It will never be inhabited, neither will it be lived in from generation to generation. The Arabian will not pitch a tent there, neither will shepherds make their flocks lie down there. 

###### v21 
But wild animals of the desert will lie there, and their houses will be full of jackals. Ostriches will dwell there, and wild goats will frolic there. 

###### v22 
Wolves will cry in their fortresses, and jackals in the pleasant palaces. Her time is near to come, and her days will not be prolonged.

***
[[Isa-12|← Isaiah 12]] | [[Isaiah]] | [[Isa-14|Isaiah 14 →]]
