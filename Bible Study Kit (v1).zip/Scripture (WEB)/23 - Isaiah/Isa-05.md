# Isaiah 5

[[Isa-04|← Isaiah 04]] | [[Isaiah]] | [[Isa-06|Isaiah 06 →]]
***



###### v1 
Let me sing for my well beloved a song of my beloved about his vineyard. My beloved had a vineyard on a very fruitful hill. 

###### v2 
He dug it up, gathered out its stones, planted it with the choicest vine, built a tower in the middle of it, and also cut out a wine press in it. He looked for it to yield grapes, but it yielded wild grapes. 

###### v3 
"Now, inhabitants of Jerusalem and men of Judah, please judge between me and my vineyard. 

###### v4 
What could have been done more to my vineyard, that I have not done in it? Why, when I looked for it to yield grapes, did it yield wild grapes? 

###### v5 
Now I will tell you what I will do to my vineyard. I will take away its hedge, and it will be eaten up. I will break down its wall, and it will be trampled down. 

###### v6 
I will lay it a wasteland. It won't be pruned or hoed, but it will grow briers and thorns. I will also command the clouds that they rain no rain on it." 

###### v7 
For the vineyard of Yahweh of Armies is the house of Israel, and the men of Judah his pleasant plant: and he looked for justice, but, behold, oppression; for righteousness, but, behold, a cry of distress. 

###### v8 
Woe to those who join house to house, who lay field to field, until there is no room, and you are made to dwell alone in the middle of the land! 

###### v9 
In my ears, Yahweh of Armies says: "Surely many houses will be desolate, even great and beautiful, unoccupied. 

###### v10 
For ten acres of vineyard shall yield one bath, and a homer of seed shall yield an ephah." 

###### v11 
Woe to those who rise up early in the morning, that they may follow strong drink, who stay late into the night, until wine inflames them! 

###### v12 
The harp, lyre, tambourine, and flute, with wine, are at their feasts; but they don't respect the work of Yahweh, neither have they considered the operation of his hands. 

###### v13 
Therefore my people go into captivity for lack of knowledge. Their honorable men are famished, and their multitudes are parched with thirst. 

###### v14 
Therefore Sheol has enlarged its desire, and opened its mouth without measure; and their glory, their multitude, their pomp, and he who rejoices among them, descend into it. 

###### v15 
So man is brought low, mankind is humbled, and the eyes of the arrogant ones are humbled; 

###### v16 
but Yahweh of Armies is exalted in justice, and God the Holy One is sanctified in righteousness. 

###### v17 
Then the lambs will graze as in their pasture, and strangers will eat the ruins of the rich. 

###### v18 
Woe to those who draw iniquity with cords of falsehood, and wickedness as with cart rope, 

###### v19 
who say, "Let him make haste, let him hasten his work, that we may see it; let the counsel of the Holy One of Israel draw near and come, that we may know it!" 

###### v20 
Woe to those who call evil good, and good evil; who put darkness for light, and light for darkness; who put bitter for sweet, and sweet for bitter! 

###### v21 
Woe to those who are wise in their own eyes, and prudent in their own sight! 

###### v22 
Woe to those who are mighty to drink wine, and champions at mixing strong drink; 

###### v23 
who acquit the guilty for a bribe, but deny justice for the innocent! 

###### v24 
Therefore as the tongue of fire devours the stubble, and as the dry grass sinks down in the flame, so their root shall be as rottenness, and their blossom shall go up as dust, because they have rejected the law of Yahweh of Armies, and despised the word of the Holy One of Israel. 

###### v25 
Therefore Yahweh's anger burns against his people, and he has stretched out his hand against them and has struck them. The mountains tremble, and their dead bodies are as refuse in the middle of the streets. For all this, his anger is not turned away, but his hand is still stretched out. 

###### v26 
He will lift up a banner to the nations from far away, and he will whistle for them from the end of the earth. Behold, they will come speedily and swiftly. 

###### v27 
No one shall be weary nor stumble among them; no one shall slumber nor sleep, neither shall the belt of their waist be untied, nor the strap of their sandals be broken, 

###### v28 
whose arrows are sharp, and all their bows bent. Their horses' hoofs will be like flint, and their wheels like a whirlwind. 

###### v29 
Their roaring will be like a lioness. They will roar like young lions. Yes, they shall roar, and seize their prey and carry it off, and there will be no one to deliver. 

###### v30 
They will roar against them in that day like the roaring of the sea. If one looks to the land, behold, darkness and distress. The light is darkened in its clouds.

***
[[Isa-04|← Isaiah 04]] | [[Isaiah]] | [[Isa-06|Isaiah 06 →]]
