# Isaiah 62

[[Isa-61|← Isaiah 61]] | [[Isaiah]] | [[Isa-63|Isaiah 63 →]]
***



###### v1 
For Zion's sake I will not hold my peace, and for Jerusalem's sake I will not rest, until her righteousness shines out like the dawn, and her salvation like a burning lamp. 

###### v2 
The nations will see your righteousness, and all kings your glory. You will be called by a new name, which Yahweh's mouth will name. 

###### v3 
You will also be a crown of beauty in Yahweh's hand, and a royal diadem in your God's hand. 

###### v4 
You will not be called Forsaken any more, nor will your land be called Desolate any more; but you will be called Hephzibah, and your land Beulah; for Yahweh delights in you, and your land will be married. 

###### v5 
For as a young man marries a virgin, so your sons will marry you. As a bridegroom rejoices over his bride, so your God will rejoice over you. 

###### v6 
I have set watchmen on your walls, Jerusalem. They will never be silent day nor night. You who call on Yahweh, take no rest, 

###### v7 
and give him no rest, until he establishes, and until he makes Jerusalem a praise in the earth. 

###### v8 
Yahweh has sworn by his right hand, and by the arm of his strength, "Surely I will no more give your grain to be food for your enemies, and foreigners will not drink your new wine, for which you have labored, 

###### v9 
but those who have harvested it will eat it, and praise Yahweh. Those who have gathered it will drink it in the courts of my sanctuary." 

###### v10 
Go through, go through the gates! Prepare the way of the people! Build up, build up the highway! Gather out the stones! Lift up a banner for the peoples. 

###### v11 
Behold, Yahweh has proclaimed to the end of the earth, "Say to the daughter of Zion, 'Behold, your salvation comes! Behold, his reward is with him, and his recompense before him!'" 

###### v12 
They will call them "The Holy People, Yahweh's Redeemed". You will be called "Sought Out, A City Not Forsaken".

***
[[Isa-61|← Isaiah 61]] | [[Isaiah]] | [[Isa-63|Isaiah 63 →]]
