# Isaiah 50

[[Isa-49|← Isaiah 49]] | [[Isaiah]] | [[Isa-51|Isaiah 51 →]]
***



###### v1 
Yahweh says, "Where is the bill of your mother's divorce, with which I have put her away? Or to which of my creditors have I sold you? Behold, you were sold for your iniquities, and your mother was put away for your transgressions. 

###### v2 
Why, when I came, was there no one? When I called, why was there no one to answer? Is my hand shortened at all, that it can't redeem? Or have I no power to deliver? Behold, at my rebuke I dry up the sea. I make the rivers a wilderness. Their fish stink because there is no water, and die of thirst. 

###### v3 
I clothe the heavens with blackness. I make sackcloth their covering." 

###### v4 
The Lord Yahweh has given me the tongue of those who are taught, that I may know how to sustain with words him who is weary. He awakens morning by morning, he awakens my ear to hear as those who are taught. 

###### v5 
The Lord Yahweh has opened my ear. I was not rebellious. I have not turned back. 

###### v6 
I gave my back to those who beat me, and my cheeks to those who plucked off the hair. I didn't hide my face from shame and spitting. 

###### v7 
For the Lord Yahweh will help me. Therefore I have not been confounded. Therefore I have set my face like a flint, and I know that I won't be disappointed. 

###### v8 
He who justifies me is near. Who will bring charges against me? Let us stand up together. Who is my adversary? Let him come near to me. 

###### v9 
Behold, the Lord Yahweh will help me! Who is he who will condemn me? Behold, they will all grow old like a garment. The moths will eat them up. 

###### v10 
Who among you fears Yahweh and obeys the voice of his servant? He who walks in darkness and has no light, let him trust in Yahweh's name, and rely on his God. 

###### v11 
Behold, all you who kindle a fire, who adorn yourselves with torches around yourselves, walk in the flame of your fire, and among the torches that you have kindled. You will have this from my hand: you will lie down in sorrow.

***
[[Isa-49|← Isaiah 49]] | [[Isaiah]] | [[Isa-51|Isaiah 51 →]]
