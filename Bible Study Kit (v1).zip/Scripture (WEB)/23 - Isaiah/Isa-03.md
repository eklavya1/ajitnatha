# Isaiah 3

[[Isa-02|← Isaiah 02]] | [[Isaiah]] | [[Isa-04|Isaiah 04 →]]
***



###### v1 
For, behold, the Lord, Yahweh of Armies, takes away from Jerusalem and from Judah supply and support, the whole supply of bread, and the whole supply of water; 

###### v2 
the mighty man, the man of war, the judge, the prophet, the diviner, the elder, 

###### v3 
the captain of fifty, the honorable man, the counselor, the skilled craftsman, and the clever enchanter. 

###### v4 
I will give boys to be their princes, and children shall rule over them. 

###### v5 
The people will be oppressed, everyone by another, and everyone by his neighbor. The child will behave himself proudly against the old man, and the wicked against the honorable. 

###### v6 
Indeed a man shall take hold of his brother in the house of his father, saying, "You have clothing, you be our ruler, and let this ruin be under your hand." 

###### v7 
In that day he will cry out, saying, "I will not be a healer; for in my house is neither bread nor clothing. You shall not make me ruler of the people." 

###### v8 
For Jerusalem is ruined, and Judah is fallen; because their tongue and their doings are against Yahweh, to provoke the eyes of his glory. 

###### v9 
The look of their faces testify against them. They parade their sin like Sodom. They don't hide it. Woe to their soul! For they have brought disaster upon themselves. 

###### v10 
Tell the righteous "Good!" For they shall eat the fruit of their deeds. 

###### v11 
Woe to the wicked! Disaster is upon them; for the deeds of his hands will be paid back to him. 

###### v12 
As for my people, children are their oppressors, and women rule over them. My people, those who lead you cause you to err, and destroy the way of your paths. 

###### v13 
Yahweh stands up to contend, and stands to judge the peoples. 

###### v14 
Yahweh will enter into judgment with the elders of his people and their leaders: "It is you who have eaten up the vineyard. The plunder of the poor is in your houses. 

###### v15 
What do you mean that you crush my people, and grind the face of the poor?" says the Lord, Yahweh of Armies. 

###### v16 
Moreover Yahweh said, "Because the daughters of Zion are arrogant, and walk with outstretched necks and flirting eyes, walking to trip as they go, jingling ornaments on their feet; 

###### v17 
therefore the Lord brings sores on the crown of the head of the women of Zion, and Yahweh will make their scalps bald." 

###### v18 
In that day the Lord will take away the beauty of their anklets, the headbands, the crescent necklaces, 

###### v19 
the earrings, the bracelets, the veils, 

###### v20 
the headdresses, the ankle chains, the sashes, the perfume containers, the charms, 

###### v21 
the signet rings, the nose rings, 

###### v22 
the fine robes, the capes, the cloaks, the purses, 

###### v23 
the hand mirrors, the fine linen garments, the tiaras, and the shawls. 

###### v24 
It shall happen that instead of sweet spices, there shall be rottenness; instead of a belt, a rope; instead of well set hair, baldness; instead of a robe, a wearing of sackcloth; and branding instead of beauty. 

###### v25 
Your men shall fall by the sword, and your mighty in the war. 

###### v26 
Her gates shall lament and mourn. She shall be desolate and sit on the ground.

***
[[Isa-02|← Isaiah 02]] | [[Isaiah]] | [[Isa-04|Isaiah 04 →]]
