# Isaiah 40

[[Isa-39|← Isaiah 39]] | [[Isaiah]] | [[Isa-41|Isaiah 41 →]]
***



###### v1 
"Comfort, comfort my people," says your God. 

###### v2 
"Speak comfortably to Jerusalem; and call out to her that her warfare is accomplished, that her iniquity is pardoned, that she has received of Yahweh's hand double for all her sins." 

###### v3 
The voice of one who calls out, "Prepare the way of Yahweh in the wilderness! Make a level highway in the desert for our God. 

###### v4 
Every valley shall be exalted, and every mountain and hill shall be made low. The uneven shall be made level, and the rough places a plain. 

###### v5 
Yahweh's glory shall be revealed, and all flesh shall see it together; for the mouth of Yahweh has spoken it." 

###### v6 
The voice of one saying, "Cry!" One said, "What shall I cry?" "All flesh is like grass, and all its glory is like the flower of the field. 

###### v7 
The grass withers, the flower fades, because Yahweh's breath blows on it. Surely the people are like grass. 

###### v8 
The grass withers, the flower fades; but the word of our God stands forever." 

###### v9 
You who tell good news to Zion, go up on a high mountain. You who tell good news to Jerusalem, lift up your voice with strength! Lift it up! Don't be afraid! Say to the cities of Judah, "Behold, your God!" 

###### v10 
Behold, the Lord Yahweh will come as a mighty one, and his arm will rule for him. Behold, his reward is with him, and his recompense before him. 

###### v11 
He will feed his flock like a shepherd. He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young. 

###### v12 
Who has measured the waters in the hollow of his hand, and marked off the sky with his span, and calculated the dust of the earth in a measuring basket, and weighed the mountains in scales, and the hills in a balance? 

###### v13 
Who has directed Yahweh's Spirit, or has taught him as his counselor? 

###### v14 
Who did he take counsel with, and who instructed him, and taught him in the path of justice, and taught him knowledge, and showed him the way of understanding? 

###### v15 
Behold, the nations are like a drop in a bucket, and are regarded as a speck of dust on a balance. Behold, he lifts up the islands like a very little thing. 

###### v16 
Lebanon is not sufficient to burn, nor its animals sufficient for a burnt offering. 

###### v17 
All the nations are like nothing before him. They are regarded by him as less than nothing, and vanity. 

###### v18 
To whom then will you liken God? Or what likeness will you compare to him? 

###### v19 
A workman has cast an image, and the goldsmith overlays it with gold, and casts silver chains for it. 

###### v20 
He who is too impoverished for such an offering chooses a tree that will not rot. He seeks a skillful workman to set up a carved image for him that will not be moved. 

###### v21 
Haven't you known? Haven't you heard? Haven't you been told from the beginning? Haven't you understood from the foundations of the earth? 

###### v22 
It is he who sits above the circle of the earth, and its inhabitants are like grasshoppers; who stretches out the heavens like a curtain, and spreads them out like a tent to dwell in, 

###### v23 
who brings princes to nothing, who makes the judges of the earth meaningless. 

###### v24 
They are planted scarcely. They are sown scarcely. Their stock has scarcely taken root in the ground. He merely blows on them, and they wither, and the whirlwind takes them away as stubble. 

###### v25 
"To whom then will you liken me? Who is my equal?" says the Holy One. 

###### v26 
Lift up your eyes on high, and see who has created these, who brings out their army by number. He calls them all by name. by the greatness of his might, and because he is strong in power, not one is lacking. 

###### v27 
Why do you say, Jacob, and speak, Israel, "My way is hidden from Yahweh, and the justice due me is disregarded by my God?" 

###### v28 
Haven't you known? Haven't you heard? The everlasting God, Yahweh, the Creator of the ends of the earth, doesn't faint. He isn't weary. His understanding is unsearchable. 

###### v29 
He gives power to the weak. He increases the strength of him who has no might. 

###### v30 
Even the youths faint and get weary, and the young men utterly fall; 

###### v31 
but those who wait for Yahweh will renew their strength. They will mount up with wings like eagles. They will run, and not be weary. They will walk, and not faint.

***
[[Isa-39|← Isaiah 39]] | [[Isaiah]] | [[Isa-41|Isaiah 41 →]]
