# Isaiah 9

[[Isa-08|← Isaiah 08]] | [[Isaiah]] | [[Isa-10|Isaiah 10 →]]
***



###### v1 
But there shall be no more gloom for her who was in anguish. In the former time, he brought into contempt the land of Zebulun and the land of Naphtali; but in the latter time he has made it glorious, by the way of the sea, beyond the Jordan, Galilee of the nations. 

###### v2 
The people who walked in darkness have seen a great light. The light has shined on those who lived in the land of the shadow of death. 

###### v3 
You have multiplied the nation. You have increased their joy. They rejoice before you according to the joy in harvest, as men rejoice when they divide the plunder. 

###### v4 
For the yoke of his burden, and the staff of his shoulder, the rod of his oppressor, you have broken as in the day of Midian. 

###### v5 
For all the armor of the armed man in the noisy battle, and the garments rolled in blood, will be for burning, fuel for the fire. 

###### v6 
For a child is born to us. A son is given to us; and the government will be on his shoulders. His name will be called Wonderful Counselor, Mighty God, Everlasting Father, Prince of Peace. 

###### v7 
Of the increase of his government and of peace there shall be no end, on David's throne, and on his kingdom, to establish it, and to uphold it with justice and with righteousness from that time on, even forever. The zeal of Yahweh of Armies will perform this. 

###### v8 
The Lord sent a word into Jacob, and it falls on Israel. 

###### v9 
All the people will know, including Ephraim and the inhabitants of Samaria, who say in pride and in arrogance of heart, 

###### v10 
"The bricks have fallen, but we will build with cut stone. The sycamore fig trees have been cut down, but we will put cedars in their place." 

###### v11 
Therefore Yahweh will set up on high against him the adversaries of Rezin, and will stir up his enemies, 

###### v12 
The Syrians in front, and the Philistines behind; and they will devour Israel with open mouth. For all this, his anger is not turned away, but his hand is stretched out still. 

###### v13 
Yet the people have not turned to him who struck them, neither have they sought Yahweh of Armies. 

###### v14 
Therefore Yahweh will cut off from Israel head and tail, palm branch and reed, in one day. 

###### v15 
The elder and the honorable man is the head, and the prophet who teaches lies is the tail. 

###### v16 
For those who lead this people lead them astray; and those who are led by them are destroyed. 

###### v17 
Therefore the Lord will not rejoice over their young men, neither will he have compassion on their fatherless and widows; for everyone is profane and an evildoer, and every mouth speaks folly. For all this his anger is not turned away, but his hand is stretched out still. 

###### v18 
For wickedness burns like a fire. It devours the briers and thorns; yes, it kindles in the thickets of the forest, and they roll upward in a column of smoke. 

###### v19 
Through Yahweh of Armies' wrath, the land is burned up; and the people are the fuel for the fire. No one spares his brother. 

###### v20 
One will devour on the right hand, and be hungry; and he will eat on the left hand, and they will not be satisfied. Everyone will eat the flesh of his own arm: 

###### v21 
Manasseh, Ephraim; and Ephraim, Manasseh; and they together shall be against Judah. For all this his anger is not turned away, but his hand is stretched out still.

***
[[Isa-08|← Isaiah 08]] | [[Isaiah]] | [[Isa-10|Isaiah 10 →]]
