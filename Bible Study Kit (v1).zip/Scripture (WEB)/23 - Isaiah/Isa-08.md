# Isaiah 8

[[Isa-07|← Isaiah 07]] | [[Isaiah]] | [[Isa-09|Isaiah 09 →]]
***



###### v1 
Yahweh said to me, "Take a large tablet, and write on it with a man's pen, 'For Maher Shalal Hash Baz'; 

###### v2 
and I will take for myself faithful witnesses to testify: Uriah the priest, and Zechariah the son of Jeberechiah." 

###### v3 
I went to the prophetess, and she conceived, and bore a son. Then Yahweh said to me, "Call his name 'Maher Shalal Hash Baz.' 

###### v4 
For before the child knows how to say, 'My father,' and, 'My mother,' the riches of Damascus and the plunder of Samaria will be carried away by the king of Assyria." 

###### v5 
Yahweh spoke to me yet again, saying, 

###### v6 
"Because this people has refused the waters of Shiloah that go softly, and rejoice in Rezin and Remaliah's son; 

###### v7 
now therefore, behold, the Lord brings upon them the mighty flood waters of the River: the king of Assyria and all his glory. It will come up over all its channels, and go over all its banks. 

###### v8 
It will sweep onward into Judah. It will overflow and pass through. It will reach even to the neck. The stretching out of its wings will fill the width of your land, Immanuel. 

###### v9 
Make an uproar, you peoples, and be broken in pieces! Listen, all you from far countries: dress for battle, and be shattered! Dress for battle, and be shattered! 

###### v10 
Take counsel together, and it will be brought to nothing; speak the word, and it will not stand, for God is with us." 

###### v11 
For Yahweh spoke this to me with a strong hand, and instructed me not to walk in the way of this people, saying, 

###### v12 
"Don't say, 'A conspiracy!' concerning all about which this people say, 'A conspiracy!' neither fear their threats, nor be terrorized. 

###### v13 
Yahweh of Armies is who you must respect as holy. He is the one you must fear. He is the one you must dread. 

###### v14 
He will be a sanctuary, but for both houses of Israel, he will be a stumbling stone and a rock that makes them fall. For the people of Jerusalem, he will be a trap and a snare. 

###### v15 
Many will stumble over it, fall, be broken, be snared, and be captured." 

###### v16 
Wrap up the covenant. Seal the law among my disciples. 

###### v17 
I will wait for Yahweh, who hides his face from the house of Jacob, and I will look for him. 

###### v18 
Behold, I and the children whom Yahweh has given me are for signs and for wonders in Israel from Yahweh of Armies, who dwells in Mount Zion. 

###### v19 
When they tell you, "Consult with those who have familiar spirits and with the wizards, who chirp and who mutter," shouldn't a people consult with their God? Should they consult the dead on behalf of the living? 

###### v20 
Turn to the law and to the covenant! If they don't speak according to this word, surely there is no morning for them. 

###### v21 
They will pass through it, very distressed and hungry. It will happen that when they are hungry, they will worry, and curse by their king and by their God. They will turn their faces upward, 

###### v22 
and look to the earth, and see distress, darkness, and the gloom of anguish. They will be driven into thick darkness.

***
[[Isa-07|← Isaiah 07]] | [[Isaiah]] | [[Isa-09|Isaiah 09 →]]
