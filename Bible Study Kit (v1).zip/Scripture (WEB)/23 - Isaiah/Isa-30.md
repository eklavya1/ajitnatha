# Isaiah 30

[[Isa-29|← Isaiah 29]] | [[Isaiah]] | [[Isa-31|Isaiah 31 →]]
***



###### v1 
"Woe to the rebellious children", says Yahweh, "who take counsel, but not from me; and who make an alliance, but not with my Spirit, that they may add sin to sin, 

###### v2 
who set out to go down into Egypt, and have not asked my advice, to strengthen themselves in the strength of Pharaoh, and to take refuge in the shadow of Egypt! 

###### v3 
Therefore the strength of Pharaoh will be your shame, and the refuge in the shadow of Egypt your confusion. 

###### v4 
For their princes are at Zoan, and their ambassadors have come to Hanes. 

###### v5 
They shall all be ashamed because of a people that can't profit them, that are not a help nor profit, but a shame, and also a reproach." 

###### v6 
The burden of the animals of the South. Through the land of trouble and anguish, of the lioness and the lion, the viper and fiery flying serpent, they carry their riches on the shoulders of young donkeys, and their treasures on the humps of camels, to an unprofitable people. 

###### v7 
For Egypt helps in vain, and to no purpose; therefore I have called her Rahab who sits still. 

###### v8 
Now go, write it before them on a tablet, and inscribe it in a book, that it may be for the time to come forever and ever. 

###### v9 
For it is a rebellious people, lying children, children who will not hear Yahweh's law; 

###### v10 
who tell the seers, "Don't see!" and the prophets, "Don't prophesy to us right things. Tell us pleasant things. Prophesy deceits. 

###### v11 
Get out of the way. Turn away from the path. Cause the Holy One of Israel to cease from before us." 

###### v12 
Therefore the Holy One of Israel says, "Because you despise this word, and trust in oppression and perverseness, and rely on it, 

###### v13 
therefore this iniquity shall be to you like a breach ready to fall, swelling out in a high wall, whose breaking comes suddenly in an instant. 

###### v14 
He will break it as a potter's vessel is broken, breaking it in pieces without sparing, so that there won't be found among the broken pieces a piece good enough to take fire from the hearth, or to dip up water out of the cistern." 

###### v15 
For thus said the Lord Yahweh, the Holy One of Israel, "You will be saved in returning and rest. Your strength will be in quietness and in confidence." You refused, 

###### v16 
but you said, "No, for we will flee on horses;" therefore you will flee; and, "We will ride on the swift;" therefore those who pursue you will be swift. 

###### v17 
One thousand will flee at the threat of one. At the threat of five, you will flee until you are left like a beacon on the top of a mountain, and like a banner on a hill. 

###### v18 
Therefore Yahweh will wait, that he may be gracious to you; and therefore he will be exalted, that he may have mercy on you, for Yahweh is a God of justice. Blessed are all those who wait for him. 

###### v19 
For the people will dwell in Zion at Jerusalem. You will weep no more. He will surely be gracious to you at the voice of your cry. When he hears you, he will answer you. 

###### v20 
Though the Lord may give you the bread of adversity and the water of affliction, yet your teachers won't be hidden any more, but your eyes will see your teachers; 

###### v21 
and when you turn to the right hand, and when you turn to the left, your ears will hear a voice behind you, saying, "This is the way. Walk in it." 

###### v22 
You shall defile the overlaying of your engraved images of silver, and the plating of your molten images of gold. You shall cast them away as an unclean thing. You shall tell it, "Go away!" 

###### v23 
He will give the rain for your seed, with which you will sow the ground; and bread of the increase of the ground will be rich and plentiful. In that day, your livestock will feed in large pastures. 

###### v24 
The oxen likewise and the young donkeys that till the ground will eat savory feed, which has been winnowed with the shovel and with the fork. 

###### v25 
There will be brooks and streams of water on every lofty mountain and on every high hill in the day of the great slaughter, when the towers fall. 

###### v26 
Moreover the light of the moon will be like the light of the sun, and the light of the sun will be seven times brighter, like the light of seven days, in the day that Yahweh binds up the fracture of his people, and heals the wound they were struck with. 

###### v27 
Behold, Yahweh's name comes from far away, burning with his anger, and in thick rising smoke. His lips are full of indignation. His tongue is as a devouring fire. 

###### v28 
His breath is as an overflowing stream that reaches even to the neck, to sift the nations with the sieve of destruction. A bridle that leads to ruin will be in the jaws of the peoples. 

###### v29 
You will have a song, as in the night when a holy feast is kept, and gladness of heart, as when one goes with a flute to come to Yahweh's mountain, to Israel's Rock. 

###### v30 
Yahweh will cause his glorious voice to be heard, and will show the descent of his arm, with the indignation of his anger, and the flame of a devouring fire, with a blast, storm, and hailstones. 

###### v31 
For through Yahweh's voice the Assyrian will be dismayed. He will strike him with his rod. 

###### v32 
Every stroke of the rod of punishment, which Yahweh will lay on him, will be with the sound of tambourines and harps. He will fight with them in battles, brandishing weapons. 

###### v33 
For his burning place has long been ready. Yes, it is prepared for the king. He has made its pyre deep and large with fire and much wood. Yahweh's breath, like a stream of sulfur, kindles it.

***
[[Isa-29|← Isaiah 29]] | [[Isaiah]] | [[Isa-31|Isaiah 31 →]]
