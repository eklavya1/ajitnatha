# Isaiah 19

[[Isa-18|← Isaiah 18]] | [[Isaiah]] | [[Isa-20|Isaiah 20 →]]
***



###### v1 
The burden of Egypt. "Behold, Yahweh rides on a swift cloud, and comes to Egypt. The idols of Egypt will tremble at his presence; and the heart of Egypt will melt within it. 

###### v2 
I will stir up the Egyptians against the Egyptians, and they will fight everyone against his brother, and everyone against his neighbor; city against city, and kingdom against kingdom. 

###### v3 
The spirit of the Egyptians will fail within them. I will destroy their counsel. They will seek the idols, the charmers, those who have familiar spirits, and the wizards. 

###### v4 
I will give over the Egyptians into the hand of a cruel lord. A fierce king will rule over them," says the Lord, Yahweh of Armies. 

###### v5 
The waters will fail from the sea, and the river will be wasted and become dry. 

###### v6 
The rivers will become foul. The streams of Egypt will be diminished and dried up. The reeds and flags will wither away. 

###### v7 
The meadows by the Nile, by the brink of the Nile, and all the sown fields of the Nile, will become dry, be driven away, and be no more. 

###### v8 
The fishermen will lament, and all those who fish in the Nile will mourn, and those who spread nets on the waters will languish. 

###### v9 
Moreover those who work in combed flax, and those who weave white cloth, will be confounded. 

###### v10 
The pillars will be broken in pieces. All those who work for hire will be grieved in soul. 

###### v11 
The princes of Zoan are utterly foolish. The counsel of the wisest counselors of Pharaoh has become stupid. How do you say to Pharaoh, "I am the son of the wise, the son of ancient kings?" 

###### v12 
Where then are your wise men? Let them tell you now; and let them know what Yahweh of Armies has purposed concerning Egypt. 

###### v13 
The princes of Zoan have become fools. The princes of Memphis are deceived. They have caused Egypt to go astray, who are the cornerstone of her tribes. 

###### v14 
Yahweh has mixed a spirit of perverseness in the middle of her; and they have caused Egypt to go astray in all of its works, like a drunken man staggers in his vomit. 

###### v15 
Neither shall there be any work for Egypt, which head or tail, palm branch or rush, may do. 

###### v16 
In that day the Egyptians will be like women. They will tremble and fear because of the shaking of Yahweh of Armies's hand, which he shakes over them. 

###### v17 
The land of Judah will become a terror to Egypt. Everyone to whom mention is made of it will be afraid, because of the plans of Yahweh of Armies, which he determines against it. 

###### v18 
In that day, there will be five cities in the land of Egypt that speak the language of Canaan, and swear to Yahweh of Armies. One will be called "The city of destruction." 

###### v19 
In that day, there will be an altar to Yahweh in the middle of the land of Egypt, and a pillar to Yahweh at its border. 

###### v20 
It will be for a sign and for a witness to Yahweh of Armies in the land of Egypt; for they will cry to Yahweh because of oppressors, and he will send them a savior and a defender, and he will deliver them. 

###### v21 
Yahweh will be known to Egypt, and the Egyptians will know Yahweh in that day. Yes, they will worship with sacrifice and offering, and will vow a vow to Yahweh, and will perform it. 

###### v22 
Yahweh will strike Egypt, striking and healing. They will return to Yahweh, and he will be entreated by them, and will heal them. 

###### v23 
In that day there will be a highway out of Egypt to Assyria, and the Assyrian shall come into Egypt, and the Egyptian into Assyria; and the Egyptians will worship with the Assyrians. 

###### v24 
In that day, Israel will be the third with Egypt and with Assyria, a blessing within the earth; 

###### v25 
because Yahweh of Armies has blessed them, saying, "Blessed be Egypt my people, Assyria the work of my hands, and Israel my inheritance."

***
[[Isa-18|← Isaiah 18]] | [[Isaiah]] | [[Isa-20|Isaiah 20 →]]
