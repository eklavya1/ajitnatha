# Isaiah 4

[[Isa-03|← Isaiah 03]] | [[Isaiah]] | [[Isa-05|Isaiah 05 →]]
***



###### v1 
Seven women shall take hold of one man in that day, saying, "We will eat our own bread, and wear our own clothing. Just let us be called by your name. Take away our reproach." 

###### v2 
In that day, Yahweh's branch will be beautiful and glorious, and the fruit of the land will be the beauty and glory of the survivors of Israel. 

###### v3 
It will happen that he who is left in Zion and he who remains in Jerusalem shall be called holy, even everyone who is written among the living in Jerusalem, 

###### v4 
when the Lord shall have washed away the filth of the daughters of Zion, and shall have purged the blood of Jerusalem from within it, by the spirit of justice and by the spirit of burning. 

###### v5 
Yahweh will create over the whole habitation of Mount Zion and over her assemblies, a cloud and smoke by day, and the shining of a flaming fire by night, for over all the glory will be a canopy. 

###### v6 
There will be a pavilion for a shade in the daytime from the heat, and for a refuge and for a shelter from storm and from rain.

***
[[Isa-03|← Isaiah 03]] | [[Isaiah]] | [[Isa-05|Isaiah 05 →]]
