# Isaiah 25

[[Isa-24|← Isaiah 24]] | [[Isaiah]] | [[Isa-26|Isaiah 26 →]]
***



###### v1 
Yahweh, you are my God. I will exalt you! I will praise your name, for you have done wonderful things, things planned long ago, in complete faithfulness and truth. 

###### v2 
For you have made a city into a heap, a fortified city into a ruin, a palace of strangers to be no city. It will never be built. 

###### v3 
Therefore a strong people will glorify you. A city of awesome nations will fear you. 

###### v4 
For you have been a stronghold to the poor, a stronghold to the needy in his distress, a refuge from the storm, a shade from the heat, when the blast of the dreaded ones is like a storm against the wall. 

###### v5 
As the heat in a dry place you will bring down the noise of strangers; as the heat by the shade of a cloud, the song of the dreaded ones will be brought low. 

###### v6 
In this mountain, Yahweh of Armies will make all peoples a feast of choice meat, a feast of choice wines, of choice meat full of marrow, of well refined choice wines. 

###### v7 
He will destroy in this mountain the surface of the covering that covers all peoples, and the veil that is spread over all nations. 

###### v8 
He has swallowed up death forever! The Lord Yahweh will wipe away tears from off all faces. He will take the reproach of his people away from off all the earth, for Yahweh has spoken it. 

###### v9 
It shall be said in that day, "Behold, this is our God! We have waited for him, and he will save us! This is Yahweh! We have waited for him. We will be glad and rejoice in his salvation!" 

###### v10 
For Yahweh's hand will rest in this mountain. Moab will be trodden down in his place, even like straw is trodden down in the water of the dunghill. 

###### v11 
He will spread out his hands in the middle of it, like one who swims spreads out hands to swim, but his pride will be humbled together with the craft of his hands. 

###### v12 
He has brought the high fortress of your walls down, laid low, and brought to the ground, even to the dust.

***
[[Isa-24|← Isaiah 24]] | [[Isaiah]] | [[Isa-26|Isaiah 26 →]]
