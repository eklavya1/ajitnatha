# Luke 13

[[Luke-12|← Luke 12]] | [[Luke]] | [[Luke-14|Luke 14 →]]
***



###### v1 
Now there were some present at the same time who told him about the Galileans, whose blood Pilate had mixed with their sacrifices. 

###### v2 
Jesus answered them, "Do you think that these Galileans were worse sinners than all the other Galileans, because they suffered such things? 

###### v3 
I tell you, no, but unless you repent, you will all perish in the same way. 

###### v4 
Or those eighteen, on whom the tower in Siloam fell and killed them; do you think that they were worse offenders than all the men who dwell in Jerusalem? 

###### v5 
I tell you, no, but, unless you repent, you will all perish in the same way." 

###### v6 
He spoke this parable. "A certain man had a fig tree planted in his vineyard, and he came seeking fruit on it, and found none. 

###### v7 
He said to the vine dresser, 'Behold, these three years I have come looking for fruit on this fig tree, and found none. Cut it down. Why does it waste the soil?' 

###### v8 
He answered, 'Lord, leave it alone this year also, until I dig around it and fertilize it. 

###### v9 
If it bears fruit, fine; but if not, after that, you can cut it down.'" 

###### v10 
He was teaching in one of the synagogues on the Sabbath day. 

###### v11 
Behold, there was a woman who had a spirit of infirmity eighteen years. She was bent over, and could in no way straighten herself up. 

###### v12 
When Jesus saw her, he called her, and said to her, "Woman, you are freed from your infirmity." 

###### v13 
He laid his hands on her, and immediately she stood up straight and glorified God. 

###### v14 
The ruler of the synagogue, being indignant because Jesus had healed on the Sabbath, said to the multitude, "There are six days in which men ought to work. Therefore come on those days and be healed, and not on the Sabbath day!" 

###### v15 
Therefore the Lord answered him, "You hypocrites! Doesn't each one of you free his ox or his donkey from the stall on the Sabbath, and lead him away to water? 

###### v16 
Ought not this woman, being a daughter of Abraham whom Satan had bound eighteen long years, be freed from this bondage on the Sabbath day?" 

###### v17 
As he said these things, all his adversaries were disappointed and all the multitude rejoiced for all the glorious things that were done by him. 

###### v18 
He said, "What is God's Kingdom like? To what shall I compare it? 

###### v19 
It is like a grain of mustard seed which a man took and put in his own garden. It grew and became a large tree, and the birds of the sky live in its branches." 

###### v20 
Again he said, "To what shall I compare God's Kingdom? 

###### v21 
It is like yeast, which a woman took and hid in three measures of flour, until it was all leavened." 

###### v22 
He went on his way through cities and villages, teaching, and traveling on to Jerusalem. 

###### v23 
One said to him, "Lord, are they few who are saved?" He said to them, 

###### v24 
"Strive to enter in by the narrow door, for many, I tell you, will seek to enter in and will not be able. 

###### v25 
When once the master of the house has risen up, and has shut the door, and you begin to stand outside and to knock at the door, saying, 'Lord, Lord, open to us!' then he will answer and tell you, 'I don't know you or where you come from.' 

###### v26 
Then you will begin to say, 'We ate and drank in your presence, and you taught in our streets.' 

###### v27 
He will say, 'I tell you, I don't know where you come from. Depart from me, all you workers of iniquity.' 

###### v28 
There will be weeping and gnashing of teeth when you see Abraham, Isaac, Jacob, and all the prophets in God's Kingdom, and yourselves being thrown outside. 

###### v29 
They will come from the east, west, north, and south, and will sit down in God's Kingdom. 

###### v30 
Behold, there are some who are last who will be first, and there are some who are first who will be last." 

###### v31 
On that same day, some Pharisees came, saying to him, "Get out of here, and go away, for Herod wants to kill you." 

###### v32 
He said to them, "Go and tell that fox, 'Behold, I cast out demons and perform cures today and tomorrow, and the third day I complete my mission. 

###### v33 
Nevertheless I must go on my way today and tomorrow and the next day, for it can't be that a prophet would perish outside of Jerusalem.' 

###### v34 
"Jerusalem, Jerusalem, you who kills the prophets and stones those who are sent to her! How often I wanted to gather your children together, like a hen gathers her own brood under her wings, and you refused! 

###### v35 
Behold, your house is left to you desolate. I tell you, you will not see me until you say, 'Blessed is he who comes in the name of the Lord!'" 

***
[[Luke-12|← Luke 12]] | [[Luke]] | [[Luke-14|Luke 14 →]]
