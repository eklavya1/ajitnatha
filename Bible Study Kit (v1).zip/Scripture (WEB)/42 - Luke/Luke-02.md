# Luke 2

[[Luke-01|← Luke 01]] | [[Luke]] | [[Luke-03|Luke 03 →]]
***



###### v1 
Now in those days, a decree went out from Caesar Augustus that all the world should be enrolled. 

###### v2 
This was the first enrollment made when Quirinius was governor of Syria. 

###### v3 
All went to enroll themselves, everyone to his own city. 

###### v4 
Joseph also went up from Galilee, out of the city of Nazareth, into Judea, to David's city, which is called Bethlehem, because he was of the house and family of David; 

###### v5 
to enroll himself with Mary, who was pledged to be married to him as wife, being pregnant. 

###### v6 
While they were there, the day had come for her to give birth. 

###### v7 
She gave birth to her firstborn son. She wrapped him in bands of cloth, and laid him in a feeding trough, because there was no room for them in the inn. 

###### v8 
There were shepherds in the same country staying in the field, and keeping watch by night over their flock. 

###### v9 
Behold, an angel of the Lord stood by them, and the glory of the Lord shone around them, and they were terrified. 

###### v10 
The angel said to them, "Don't be afraid, for behold, I bring you good news of great joy which will be to all the people. 

###### v11 
For there is born to you today, in David's city, a Savior, who is Christ the Lord. 

###### v12 
This is the sign to you: you will find a baby wrapped in strips of cloth, lying in a feeding trough." 

###### v13 
Suddenly, there was with the angel a multitude of the heavenly army praising God, and saying, 

###### v14 
"Glory to God in the highest, on earth peace, good will toward men." 

###### v15 
When the angels went away from them into the sky, the shepherds said to one another, "Let's go to Bethlehem, now, and see this thing that has happened, which the Lord has made known to us." 

###### v16 
They came with haste, and found both Mary and Joseph, and the baby was lying in the feeding trough. 

###### v17 
When they saw it, they publicized widely the saying which was spoken to them about this child. 

###### v18 
All who heard it wondered at the things which were spoken to them by the shepherds. 

###### v19 
But Mary kept all these sayings, pondering them in her heart. 

###### v20 
The shepherds returned, glorifying and praising God for all the things that they had heard and seen, just as it was told them. 

###### v21 
When eight days were fulfilled for the circumcision of the child, his name was called Jesus, which was given by the angel before he was conceived in the womb. 

###### v22 
When the days of their purification according to the law of Moses were fulfilled, they brought him up to Jerusalem, to present him to the Lord 

###### v23 
(as it is written in the law of the Lord, "Every male who opens the womb shall be called holy to the Lord"), 

###### v24 
and to offer a sacrifice according to that which is said in the law of the Lord, "A pair of turtledoves, or two young pigeons." 

###### v25 
Behold, there was a man in Jerusalem whose name was Simeon. This man was righteous and devout, looking for the consolation of Israel, and the Holy Spirit was on him. 

###### v26 
It had been revealed to him by the Holy Spirit that he should not see death before he had seen the Lord's Christ. 

###### v27 
He came in the Spirit into the temple. When the parents brought in the child, Jesus, that they might do concerning him according to the custom of the law, 

###### v28 
then he received him into his arms, and blessed God, and said, 

###### v29 
"Now you are releasing your servant, Master, according to your word, in peace; 

###### v30 
for my eyes have seen your salvation, 

###### v31 
which you have prepared before the face of all peoples; 

###### v32 
a light for revelation to the nations, and the glory of your people Israel." 

###### v33 
Joseph and his mother were marveling at the things which were spoken concerning him, 

###### v34 
and Simeon blessed them, and said to Mary, his mother, "Behold, this child is set for the falling and the rising of many in Israel, and for a sign which is spoken against. 

###### v35 
Yes, a sword will pierce through your own soul, that the thoughts of many hearts may be revealed." 

###### v36 
There was one Anna, a prophetess, the daughter of Phanuel, of the tribe of Asher (she was of a great age, having lived with a husband seven years from her virginity, 

###### v37 
and she had been a widow for about eighty-four years), who didn't depart from the temple, worshiping with fastings and petitions night and day. 

###### v38 
Coming up at that very hour, she gave thanks to the Lord, and spoke of him to all those who were looking for redemption in Jerusalem. 

###### v39 
When they had accomplished all things that were according to the law of the Lord, they returned into Galilee, to their own city, Nazareth. 

###### v40 
The child was growing, and was becoming strong in spirit, being filled with wisdom, and the grace of God was upon him. 

###### v41 
His parents went every year to Jerusalem at the feast of the Passover. 

###### v42 
When he was twelve years old, they went up to Jerusalem according to the custom of the feast, 

###### v43 
and when they had fulfilled the days, as they were returning, the boy Jesus stayed behind in Jerusalem. Joseph and his mother didn't know it, 

###### v44 
but supposing him to be in the company, they went a day's journey, and they looked for him among their relatives and acquaintances. 

###### v45 
When they didn't find him, they returned to Jerusalem, looking for him. 

###### v46 
After three days they found him in the temple, sitting in the middle of the teachers, both listening to them, and asking them questions. 

###### v47 
All who heard him were amazed at his understanding and his answers. 

###### v48 
When they saw him, they were astonished, and his mother said to him, "Son, why have you treated us this way? Behold, your father and I were anxiously looking for you." 

###### v49 
He said to them, "Why were you looking for me? Didn't you know that I must be in my Father's house?" 

###### v50 
They didn't understand the saying which he spoke to them. 

###### v51 
And he went down with them, and came to Nazareth. He was subject to them, and his mother kept all these sayings in her heart. 

###### v52 
And Jesus increased in wisdom and stature, and in favor with God and men.

***
[[Luke-01|← Luke 01]] | [[Luke]] | [[Luke-03|Luke 03 →]]
