# Luke 6

[[Luke-05|← Luke 05]] | [[Luke]] | [[Luke-07|Luke 07 →]]
***



###### v1 
Now on the second Sabbath after the first, he was going through the grain fields. His disciples plucked the heads of grain and ate, rubbing them in their hands. 

###### v2 
But some of the Pharisees said to them, "Why do you do that which is not lawful to do on the Sabbath day?" 

###### v3 
Jesus, answering them, said, "Haven't you read what David did when he was hungry, he, and those who were with him; 

###### v4 
how he entered into God's house, and took and ate the show bread, and gave also to those who were with him, which is not lawful to eat except for the priests alone?" 

###### v5 
He said to them, "The Son of Man is lord of the Sabbath." 

###### v6 
It also happened on another Sabbath that he entered into the synagogue and taught. There was a man there, and his right hand was withered. 

###### v7 
The scribes and the Pharisees watched him, to see whether he would heal on the Sabbath, that they might find an accusation against him. 

###### v8 
But he knew their thoughts; and he said to the man who had the withered hand, "Rise up, and stand in the middle." He arose and stood. 

###### v9 
Then Jesus said to them, "I will ask you something: Is it lawful on the Sabbath to do good, or to do harm? To save a life, or to kill?" 

###### v10 
He looked around at them all, and said to the man, "Stretch out your hand." He did, and his hand was restored as sound as the other. 

###### v11 
But they were filled with rage, and talked with one another about what they might do to Jesus. 

###### v12 
In these days, he went out to the mountain to pray, and he continued all night in prayer to God. 

###### v13 
When it was day, he called his disciples, and from them he chose twelve, whom he also named apostles: 

###### v14 
Simon, whom he also named Peter; Andrew, his brother; James; John; Philip; Bartholomew; 

###### v15 
Matthew; Thomas; James, the son of Alphaeus; Simon, who was called the Zealot; 

###### v16 
Judas the son of James; and Judas Iscariot, who also became a traitor. 

###### v17 
He came down with them, and stood on a level place, with a crowd of his disciples, and a great number of the people from all Judea and Jerusalem, and the sea coast of Tyre and Sidon, who came to hear him and to be healed of their diseases; 

###### v18 
as well as those who were troubled by unclean spirits, and they were being healed. 

###### v19 
All the multitude sought to touch him, for power came out of him and healed them all. 

###### v20 
He lifted up his eyes to his disciples, and said, "Blessed are you who are poor, God's Kingdom is yours. 

###### v21 
Blessed are you who hunger now, for you will be filled. Blessed are you who weep now, for you will laugh. 

###### v22 
Blessed are you when men hate you, and when they exclude and mock you, and throw out your name as evil, for the Son of Man's sake. 

###### v23 
Rejoice in that day, and leap for joy, for behold, your reward is great in heaven, for their fathers did the same thing to the prophets. 

###### v24 
"But woe to you who are rich! For you have received your consolation. 

###### v25 
Woe to you, you who are full now, for you will be hungry. Woe to you who laugh now, for you will mourn and weep. 

###### v26 
Woe, when men speak well of you, for their fathers did the same thing to the false prophets. 

###### v27 
"But I tell you who hear: love your enemies, do good to those who hate you, 

###### v28 
bless those who curse you, and pray for those who mistreat you. 

###### v29 
To him who strikes you on the cheek, offer also the other; and from him who takes away your cloak, don't withhold your coat also. 

###### v30 
Give to everyone who asks you, and don't ask him who takes away your goods to give them back again. 

###### v31 
"As you would like people to do to you, do exactly so to them. 

###### v32 
If you love those who love you, what credit is that to you? For even sinners love those who love them. 

###### v33 
If you do good to those who do good to you, what credit is that to you? For even sinners do the same. 

###### v34 
If you lend to those from whom you hope to receive, what credit is that to you? Even sinners lend to sinners, to receive back as much. 

###### v35 
But love your enemies, and do good, and lend, expecting nothing back; and your reward will be great, and you will be children of the Most High; for he is kind toward the unthankful and evil. 

###### v36 
"Therefore be merciful, even as your Father is also merciful. 

###### v37 
Don't judge, and you won't be judged. Don't condemn, and you won't be condemned. Set free, and you will be set free. 

###### v38 
"Give, and it will be given to you: good measure, pressed down, shaken together, and running over, will be given to you. For with the same measure you measure it will be measured back to you." 

###### v39 
He spoke a parable to them. "Can the blind guide the blind? Won't they both fall into a pit? 

###### v40 
A disciple is not above his teacher, but everyone when he is fully trained will be like his teacher. 

###### v41 
Why do you see the speck of chaff that is in your brother's eye, but don't consider the beam that is in your own eye? 

###### v42 
Or how can you tell your brother, 'Brother, let me remove the speck of chaff that is in your eye,' when you yourself don't see the beam that is in your own eye? You hypocrite! First remove the beam from your own eye, and then you can see clearly to remove the speck of chaff that is in your brother's eye. 

###### v43 
For there is no good tree that produces rotten fruit; nor again a rotten tree that produces good fruit. 

###### v44 
For each tree is known by its own fruit. For people don't gather figs from thorns, nor do they gather grapes from a bramble bush. 

###### v45 
The good man out of the good treasure of his heart brings out that which is good, and the evil man out of the evil treasure of his heart brings out that which is evil, for out of the abundance of the heart, his mouth speaks. 

###### v46 
"Why do you call me, 'Lord, Lord,' and don't do the things which I say? 

###### v47 
Everyone who comes to me, and hears my words, and does them, I will show you who he is like. 

###### v48 
He is like a man building a house, who dug and went deep, and laid a foundation on the rock. When a flood arose, the stream broke against that house, and could not shake it, because it was founded on the rock. 

###### v49 
But he who hears, and doesn't do, is like a man who built a house on the earth without a foundation, against which the stream broke, and immediately it fell, and the ruin of that house was great."

***
[[Luke-05|← Luke 05]] | [[Luke]] | [[Luke-07|Luke 07 →]]
