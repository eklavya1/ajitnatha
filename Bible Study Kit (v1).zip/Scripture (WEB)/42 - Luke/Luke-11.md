# Luke 11

[[Luke-10|← Luke 10]] | [[Luke]] | [[Luke-12|Luke 12 →]]
***



###### v1 
When he finished praying in a certain place, one of his disciples said to him, "Lord, teach us to pray, just as John also taught his disciples." 

###### v2 
He said to them, "When you pray, say, 'Our Father in heaven, may your name be kept holy. May your Kingdom come. May your will be done on earth, as it is in heaven. 

###### v3 
Give us day by day our daily bread. 

###### v4 
Forgive us our sins, for we ourselves also forgive everyone who is indebted to us. Bring us not into temptation, but deliver us from the evil one.'" 

###### v5 
He said to them, "Which of you, if you go to a friend at midnight, and tell him, 'Friend, lend me three loaves of bread, 

###### v6 
for a friend of mine has come to me from a journey, and I have nothing to set before him,' 

###### v7 
and he from within will answer and say, 'Don't bother me. The door is now shut, and my children are with me in bed. I can't get up and give it to you'? 

###### v8 
I tell you, although he will not rise and give it to him because he is his friend, yet because of his persistence, he will get up and give him as many as he needs. 

###### v9 
"I tell you, keep asking, and it will be given you. Keep seeking, and you will find. Keep knocking, and it will be opened to you. 

###### v10 
For everyone who asks receives. He who seeks finds. To him who knocks it will be opened. 

###### v11 
"Which of you fathers, if your son asks for bread, will give him a stone? Or if he asks for a fish, he won't give him a snake instead of a fish, will he? 

###### v12 
Or if he asks for an egg, he won't give him a scorpion, will he? 

###### v13 
If you then, being evil, know how to give good gifts to your children, how much more will your heavenly Father give the Holy Spirit to those who ask him?" 

###### v14 
He was casting out a demon, and it was mute. When the demon had gone out, the mute man spoke; and the multitudes marveled. 

###### v15 
But some of them said, "He casts out demons by Beelzebul, the prince of the demons." 

###### v16 
Others, testing him, sought from him a sign from heaven. 

###### v17 
But he, knowing their thoughts, said to them, "Every kingdom divided against itself is brought to desolation. A house divided against itself falls. 

###### v18 
If Satan also is divided against himself, how will his kingdom stand? For you say that I cast out demons by Beelzebul. 

###### v19 
But if I cast out demons by Beelzebul, by whom do your children cast them out? Therefore they will be your judges. 

###### v20 
But if I by God's finger cast out demons, then God's Kingdom has come to you. 

###### v21 
"When the strong man, fully armed, guards his own dwelling, his goods are safe. 

###### v22 
But when someone stronger attacks him and overcomes him, he takes from him his whole armor in which he trusted, and divides his plunder. 

###### v23 
"He that is not with me is against me. He who doesn't gather with me scatters. 

###### v24 
The unclean spirit, when he has gone out of the man, passes through dry places, seeking rest, and finding none, he says, 'I will turn back to my house from which I came out.' 

###### v25 
When he returns, he finds it swept and put in order. 

###### v26 
Then he goes, and takes seven other spirits more evil than himself, and they enter in and dwell there. The last state of that man becomes worse than the first." 

###### v27 
It came to pass, as he said these things, a certain woman out of the multitude lifted up her voice, and said to him, "Blessed is the womb that bore you, and the breasts which nursed you!" 

###### v28 
But he said, "On the contrary, blessed are those who hear the word of God, and keep it." 

###### v29 
When the multitudes were gathering together to him, he began to say, "This is an evil generation. It seeks after a sign. No sign will be given to it but the sign of Jonah, the prophet. 

###### v30 
For even as Jonah became a sign to the Ninevites, so the Son of Man will also be to this generation. 

###### v31 
The Queen of the South will rise up in the judgment with the men of this generation, and will condemn them: for she came from the ends of the earth to hear the wisdom of Solomon; and behold, one greater than Solomon is here. 

###### v32 
The men of Nineveh will stand up in the judgment with this generation, and will condemn it: for they repented at the preaching of Jonah, and behold, one greater than Jonah is here. 

###### v33 
"No one, when he has lit a lamp, puts it in a cellar or under a basket, but on a stand, that those who come in may see the light. 

###### v34 
The lamp of the body is the eye. Therefore when your eye is good, your whole body is also full of light; but when it is evil, your body also is full of darkness. 

###### v35 
Therefore see whether the light that is in you isn't darkness. 

###### v36 
If therefore your whole body is full of light, having no part dark, it will be wholly full of light, as when the lamp with its bright shining gives you light." 

###### v37 
Now as he spoke, a certain Pharisee asked him to dine with him. He went in and sat at the table. 

###### v38 
When the Pharisee saw it, he marveled that he had not first washed himself before dinner. 

###### v39 
The Lord said to him, "Now you Pharisees cleanse the outside of the cup and of the platter, but your inward part is full of extortion and wickedness. 

###### v40 
You foolish ones, didn't he who made the outside make the inside also? 

###### v41 
But give for gifts to the needy those things which are within, and behold, all things will be clean to you. 

###### v42 
But woe to you Pharisees! For you tithe mint and rue and every herb, but you bypass justice and God's love. You ought to have done these, and not to have left the other undone. 

###### v43 
Woe to you Pharisees! For you love the best seats in the synagogues, and the greetings in the marketplaces. 

###### v44 
Woe to you, scribes and Pharisees, hypocrites! For you are like hidden graves, and the men who walk over them don't know it." 

###### v45 
One of the lawyers answered him, "Teacher, in saying this you insult us also." 

###### v46 
He said, "Woe to you lawyers also! For you load men with burdens that are difficult to carry, and you yourselves won't even lift one finger to help carry those burdens. 

###### v47 
Woe to you! For you build the tombs of the prophets, and your fathers killed them. 

###### v48 
So you testify and consent to the works of your fathers. For they killed them, and you build their tombs. 

###### v49 
Therefore also the wisdom of God said, 'I will send to them prophets and apostles; and some of them they will kill and persecute, 

###### v50 
that the blood of all the prophets, which was shed from the foundation of the world, may be required of this generation; 

###### v51 
from the blood of Abel to the blood of Zachariah, who perished between the altar and the sanctuary.' Yes, I tell you, it will be required of this generation. 

###### v52 
Woe to you lawyers! For you took away the key of knowledge. You didn't enter in yourselves, and those who were entering in, you hindered." 

###### v53 
As he said these things to them, the scribes and the Pharisees began to be terribly angry, and to draw many things out of him; 

###### v54 
lying in wait for him, and seeking to catch him in something he might say, that they might accuse him.

***
[[Luke-10|← Luke 10]] | [[Luke]] | [[Luke-12|Luke 12 →]]
