# Luke 4

[[Luke-03|← Luke 03]] | [[Luke]] | [[Luke-05|Luke 05 →]]
***



###### v1 
Jesus, full of the Holy Spirit, returned from the Jordan, and was led by the Spirit into the wilderness 

###### v2 
for forty days, being tempted by the devil. He ate nothing in those days. Afterward, when they were completed, he was hungry. 

###### v3 
The devil said to him, "If you are the Son of God, command this stone to become bread." 

###### v4 
Jesus answered him, saying, "It is written, 'Man shall not live by bread alone, but by every word of God.'" 

###### v5 
The devil, leading him up on a high mountain, showed him all the kingdoms of the world in a moment of time. 

###### v6 
The devil said to him, "I will give you all this authority, and their glory, for it has been delivered to me; and I give it to whomever I want. 

###### v7 
If you therefore will worship before me, it will all be yours." 

###### v8 
Jesus answered him, "Get behind me Satan! For it is written, 'You shall worship the Lord your God, and you shall serve him only.'" 

###### v9 
He led him to Jerusalem, and set him on the pinnacle of the temple, and said to him, "If you are the Son of God, cast yourself down from here, 

###### v10 
for it is written, 'He will put his angels in charge of you, to guard you;' 

###### v11 
and, 'On their hands they will bear you up, lest perhaps you dash your foot against a stone.'" 

###### v12 
Jesus answering, said to him, "It has been said, 'You shall not tempt the Lord your God.'" 

###### v13 
When the devil had completed every temptation, he departed from him until another time. 

###### v14 
Jesus returned in the power of the Spirit into Galilee, and news about him spread through all the surrounding area. 

###### v15 
He taught in their synagogues, being glorified by all. 

###### v16 
He came to Nazareth, where he had been brought up. He entered, as was his custom, into the synagogue on the Sabbath day, and stood up to read. 

###### v17 
The book of the prophet Isaiah was handed to him. He opened the book, and found the place where it was written, 

###### v18 
"The Spirit of the Lord is on me, because he has anointed me to preach good news to the poor. He has sent me to heal the broken hearted, to proclaim release to the captives, recovering of sight to the blind, to deliver those who are crushed, 

###### v19 
and to proclaim the acceptable year of the Lord." 

###### v20 
He closed the book, gave it back to the attendant, and sat down. The eyes of all in the synagogue were fastened on him. 

###### v21 
He began to tell them, "Today, this Scripture has been fulfilled in your hearing." 

###### v22 
All testified about him, and wondered at the gracious words which proceeded out of his mouth, and they said, "Isn't this Joseph's son?" 

###### v23 
He said to them, "Doubtless you will tell me this parable, 'Physician, heal yourself! Whatever we have heard done at Capernaum, do also here in your hometown.'" 

###### v24 
He said, "Most certainly I tell you, no prophet is acceptable in his hometown. 

###### v25 
But truly I tell you, there were many widows in Israel in the days of Elijah, when the sky was shut up three years and six months, when a great famine came over all the land. 

###### v26 
Elijah was sent to none of them, except to Zarephath, in the land of Sidon, to a woman who was a widow. 

###### v27 
There were many lepers in Israel in the time of Elisha the prophet, yet not one of them was cleansed, except Naaman, the Syrian." 

###### v28 
They were all filled with wrath in the synagogue, as they heard these things. 

###### v29 
They rose up, threw him out of the city, and led him to the brow of the hill that their city was built on, that they might throw him off the cliff. 

###### v30 
But he, passing through the middle of them, went his way. 

###### v31 
He came down to Capernaum, a city of Galilee. He was teaching them on the Sabbath day, 

###### v32 
and they were astonished at his teaching, for his word was with authority. 

###### v33 
In the synagogue there was a man who had a spirit of an unclean demon, and he cried out with a loud voice, 

###### v34 
saying, "Ah! what have we to do with you, Jesus of Nazareth? Have you come to destroy us? I know who you are: the Holy One of God!" 

###### v35 
Jesus rebuked him, saying, "Be silent, and come out of him!" When the demon had thrown him down in the middle of them, he came out of him, having done him no harm. 

###### v36 
Amazement came on all, and they spoke together, one with another, saying, "What is this word? For with authority and power he commands the unclean spirits, and they come out!" 

###### v37 
News about him went out into every place of the surrounding region. 

###### v38 
He rose up from the synagogue, and entered into Simon's house. Simon's mother-in-law was afflicted with a great fever, and they begged him for her. 

###### v39 
He stood over her, and rebuked the fever; and it left her. Immediately she rose up and served them. 

###### v40 
When the sun was setting, all those who had any sick with various diseases brought them to him; and he laid his hands on every one of them, and healed them. 

###### v41 
Demons also came out of many, crying out, and saying, "You are the Christ, the Son of God!" Rebuking them, he didn't allow them to speak, because they knew that he was the Christ. 

###### v42 
When it was day, he departed and went into an uninhabited place, and the multitudes looked for him, and came to him, and held on to him, so that he wouldn't go away from them. 

###### v43 
But he said to them, "I must preach the good news of God's Kingdom to the other cities also. For this reason I have been sent." 

###### v44 
He was preaching in the synagogues of Galilee.

***
[[Luke-03|← Luke 03]] | [[Luke]] | [[Luke-05|Luke 05 →]]
