# Luke 24

[[Luke-23|← Luke 23]] | [[Luke]]
***



###### v1 
But on the first day of the week, at early dawn, they and some others came to the tomb, bringing the spices which they had prepared. 

###### v2 
They found the stone rolled away from the tomb. 

###### v3 
They entered in, and didn't find the Lord Jesus' body. 

###### v4 
While they were greatly perplexed about this, behold, two men stood by them in dazzling clothing. 

###### v5 
Becoming terrified, they bowed their faces down to the earth. They said to them, "Why do you seek the living among the dead? 

###### v6 
He isn't here, but is risen. Remember what he told you when he was still in Galilee, 

###### v7 
saying that the Son of Man must be delivered up into the hands of sinful men and be crucified, and the third day rise again?" 

###### v8 
They remembered his words, 

###### v9 
returned from the tomb, and told all these things to the eleven and to all the rest. 

###### v10 
Now they were Mary Magdalene, Joanna, and Mary the mother of James. The other women with them told these things to the apostles. 

###### v11 
These words seemed to them to be nonsense, and they didn't believe them. 

###### v12 
But Peter got up and ran to the tomb. Stooping and looking in, he saw the strips of linen lying by themselves, and he departed to his home, wondering what had happened. 

###### v13 
Behold, two of them were going that very day to a village named Emmaus, which was sixty stadia from Jerusalem. 

###### v14 
They talked with each other about all of these things which had happened. 

###### v15 
While they talked and questioned together, Jesus himself came near, and went with them. 

###### v16 
But their eyes were kept from recognizing him. 

###### v17 
He said to them, "What are you talking about as you walk, and are sad?" 

###### v18 
One of them, named Cleopas, answered him, "Are you the only stranger in Jerusalem who doesn't know the things which have happened there in these days?" 

###### v19 
He said to them, "What things?" They said to him, "The things concerning Jesus, the Nazarene, who was a prophet mighty in deed and word before God and all the people; 

###### v20 
and how the chief priests and our rulers delivered him up to be condemned to death, and crucified him. 

###### v21 
But we were hoping that it was he who would redeem Israel. Yes, and besides all this, it is now the third day since these things happened. 

###### v22 
Also, certain women of our company amazed us, having arrived early at the tomb; 

###### v23 
and when they didn't find his body, they came saying that they had also seen a vision of angels, who said that he was alive. 

###### v24 
Some of us went to the tomb, and found it just like the women had said, but they didn't see him." 

###### v25 
He said to them, "Foolish men, and slow of heart to believe in all that the prophets have spoken! 

###### v26 
Didn't the Christ have to suffer these things and to enter into his glory?" 

###### v27 
Beginning from Moses and from all the prophets, he explained to them in all the Scriptures the things concerning himself. 

###### v28 
They came near to the village where they were going, and he acted like he would go further. 

###### v29 
They urged him, saying, "Stay with us, for it is almost evening, and the day is almost over." He went in to stay with them. 

###### v30 
When he had sat down at the table with them, he took the bread and gave thanks. Breaking it, he gave it to them. 

###### v31 
Their eyes were opened and they recognized him, then he vanished out of their sight. 

###### v32 
They said to one another, "Weren't our hearts burning within us, while he spoke to us along the way, and while he opened the Scriptures to us?" 

###### v33 
They rose up that very hour, returned to Jerusalem, and found the eleven gathered together, and those who were with them, 

###### v34 
saying, "The Lord is risen indeed, and has appeared to Simon!" 

###### v35 
They related the things that happened along the way, and how he was recognized by them in the breaking of the bread. 

###### v36 
As they said these things, Jesus himself stood among them, and said to them, "Peace be to you." 

###### v37 
But they were terrified and filled with fear, and supposed that they had seen a spirit. 

###### v38 
He said to them, "Why are you troubled? Why do doubts arise in your hearts? 

###### v39 
See my hands and my feet, that it is truly me. Touch me and see, for a spirit doesn't have flesh and bones, as you see that I have." 

###### v40 
When he had said this, he showed them his hands and his feet. 

###### v41 
While they still didn't believe for joy, and wondered, he said to them, "Do you have anything here to eat?" 

###### v42 
They gave him a piece of a broiled fish and some honeycomb. 

###### v43 
He took them, and ate in front of them. 

###### v44 
He said to them, "This is what I told you, while I was still with you, that all things which are written in the law of Moses, the prophets, and the psalms, concerning me must be fulfilled." 

###### v45 
Then he opened their minds, that they might understand the Scriptures. 

###### v46 
He said to them, "Thus it is written, and thus it was necessary for the Christ to suffer and to rise from the dead the third day, 

###### v47 
and that repentance and remission of sins should be preached in his name to all the nations, beginning at Jerusalem. 

###### v48 
You are witnesses of these things. 

###### v49 
Behold, I send out the promise of my Father on you. But wait in the city of Jerusalem until you are clothed with power from on high." 

###### v50 
He led them out as far as Bethany, and he lifted up his hands, and blessed them. 

###### v51 
While he blessed them, he withdrew from them, and was carried up into heaven. 

###### v52 
They worshiped him, and returned to Jerusalem with great joy, 

###### v53 
and were continually in the temple, praising and blessing God. Amen.

***
[[Luke-23|← Luke 23]] | [[Luke]]
