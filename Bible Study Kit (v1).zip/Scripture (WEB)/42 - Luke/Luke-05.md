# Luke 5

[[Luke-04|← Luke 04]] | [[Luke]] | [[Luke-06|Luke 06 →]]
***



###### v1 
Now while the multitude pressed on him and heard the word of God, he was standing by the lake of Gennesaret. 

###### v2 
He saw two boats standing by the lake, but the fishermen had gone out of them, and were washing their nets. 

###### v3 
He entered into one of the boats, which was Simon's, and asked him to put out a little from the land. He sat down and taught the multitudes from the boat. 

###### v4 
When he had finished speaking, he said to Simon, "Put out into the deep, and let down your nets for a catch." 

###### v5 
Simon answered him, "Master, we worked all night, and took nothing; but at your word I will let down the net." 

###### v6 
When they had done this, they caught a great multitude of fish, and their net was breaking. 

###### v7 
They beckoned to their partners in the other boat, that they should come and help them. They came, and filled both boats, so that they began to sink. 

###### v8 
But Simon Peter, when he saw it, fell down at Jesus' knees, saying, "Depart from me, for I am a sinful man, Lord." 

###### v9 
For he was amazed, and all who were with him, at the catch of fish which they had caught; 

###### v10 
and so also were James and John, sons of Zebedee, who were partners with Simon. Jesus said to Simon, "Don't be afraid. From now on you will be catching people alive." 

###### v11 
When they had brought their boats to land, they left everything, and followed him. 

###### v12 
While he was in one of the cities, behold, there was a man full of leprosy. When he saw Jesus, he fell on his face, and begged him, saying, "Lord, if you want to, you can make me clean." 

###### v13 
He stretched out his hand, and touched him, saying, "I want to. Be made clean." Immediately the leprosy left him. 

###### v14 
He commanded him to tell no one, "But go your way, and show yourself to the priest, and offer for your cleansing according to what Moses commanded, for a testimony to them." 

###### v15 
But the report concerning him spread much more, and great multitudes came together to hear, and to be healed by him of their infirmities. 

###### v16 
But he withdrew himself into the desert, and prayed. 

###### v17 
On one of those days, he was teaching; and there were Pharisees and teachers of the law sitting by, who had come out of every village of Galilee, Judea, and Jerusalem. The power of the Lord was with him to heal them. 

###### v18 
Behold, men brought a paralyzed man on a cot, and they sought to bring him in to lay before Jesus. 

###### v19 
Not finding a way to bring him in because of the multitude, they went up to the housetop, and let him down through the tiles with his cot into the middle before Jesus. 

###### v20 
Seeing their faith, he said to him, "Man, your sins are forgiven you." 

###### v21 
The scribes and the Pharisees began to reason, saying, "Who is this who speaks blasphemies? Who can forgive sins, but God alone?" 

###### v22 
But Jesus, perceiving their thoughts, answered them, "Why are you reasoning so in your hearts? 

###### v23 
Which is easier to say, 'Your sins are forgiven you;' or to say, 'Arise and walk?' 

###### v24 
But that you may know that the Son of Man has authority on earth to forgive sins" (he said to the paralyzed man), "I tell you, arise, take up your cot, and go to your house." 

###### v25 
Immediately he rose up before them, and took up that which he was laying on, and departed to his house, glorifying God. 

###### v26 
Amazement took hold on all, and they glorified God. They were filled with fear, saying, "We have seen strange things today." 

###### v27 
After these things he went out, and saw a tax collector named Levi sitting at the tax office, and said to him, "Follow me!" 

###### v28 
He left everything, and rose up and followed him. 

###### v29 
Levi made a great feast for him in his house. There was a great crowd of tax collectors and others who were reclining with them. 

###### v30 
Their scribes and the Pharisees murmured against his disciples, saying, "Why do you eat and drink with the tax collectors and sinners?" 

###### v31 
Jesus answered them, "Those who are healthy have no need for a physician, but those who are sick do. 

###### v32 
I have not come to call the righteous, but sinners to repentance." 

###### v33 
They said to him, "Why do John's disciples often fast and pray, likewise also the disciples of the Pharisees, but yours eat and drink?" 

###### v34 
He said to them, "Can you make the friends of the bridegroom fast while the bridegroom is with them? 

###### v35 
But the days will come when the bridegroom will be taken away from them. Then they will fast in those days." 

###### v36 
He also told a parable to them. "No one puts a piece from a new garment on an old garment, or else he will tear the new, and also the piece from the new will not match the old. 

###### v37 
No one puts new wine into old wine skins, or else the new wine will burst the skins, and it will be spilled, and the skins will be destroyed. 

###### v38 
But new wine must be put into fresh wine skins, and both are preserved. 

###### v39 
No man having drunk old wine immediately desires new, for he says, 'The old is better.'"

***
[[Luke-04|← Luke 04]] | [[Luke]] | [[Luke-06|Luke 06 →]]
