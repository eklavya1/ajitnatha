# Luke 1

[[Luke]] | [[Luke-02|Luke 02 →]]
***



###### v1 
Since many have undertaken to set in order a narrative concerning those matters which have been fulfilled among us, 

###### v2 
even as those who from the beginning were eyewitnesses and servants of the word delivered them to us, 

###### v3 
it seemed good to me also, having traced the course of all things accurately from the first, to write to you in order, most excellent Theophilus; 

###### v4 
that you might know the certainty concerning the things in which you were instructed. 

###### v5 
There was in the days of Herod, the king of Judea, a certain priest named Zacharias, of the priestly division of Abijah. He had a wife of the daughters of Aaron, and her name was Elizabeth. 

###### v6 
They were both righteous before God, walking blamelessly in all the commandments and ordinances of the Lord. 

###### v7 
But they had no child, because Elizabeth was barren, and they both were well advanced in years. 

###### v8 
Now while he executed the priest's office before God in the order of his division 

###### v9 
according to the custom of the priest's office, his lot was to enter into the temple of the Lord and burn incense. 

###### v10 
The whole multitude of the people were praying outside at the hour of incense. 

###### v11 
An angel of the Lord appeared to him, standing on the right side of the altar of incense. 

###### v12 
Zacharias was troubled when he saw him, and fear fell upon him. 

###### v13 
But the angel said to him, "Don't be afraid, Zacharias, because your request has been heard. Your wife, Elizabeth, will bear you a son, and you shall call his name John. 

###### v14 
You will have joy and gladness, and many will rejoice at his birth. 

###### v15 
For he will be great in the sight of the Lord, and he will drink no wine nor strong drink. He will be filled with the Holy Spirit, even from his mother's womb. 

###### v16 
He will turn many of the children of Israel to the Lord their God. 

###### v17 
He will go before him in the spirit and power of Elijah, 'to turn the hearts of the fathers to the children,' and the disobedient to the wisdom of the just; to prepare a people prepared for the Lord." 

###### v18 
Zacharias said to the angel, "How can I be sure of this? For I am an old man, and my wife is well advanced in years." 

###### v19 
The angel answered him, "I am Gabriel, who stands in the presence of God. I was sent to speak to you and to bring you this good news. 

###### v20 
Behold, you will be silent and not able to speak until the day that these things will happen, because you didn't believe my words, which will be fulfilled in their proper time." 

###### v21 
The people were waiting for Zacharias, and they marveled that he delayed in the temple. 

###### v22 
When he came out, he could not speak to them. They perceived that he had seen a vision in the temple. He continued making signs to them, and remained mute. 

###### v23 
When the days of his service were fulfilled, he departed to his house. 

###### v24 
After these days Elizabeth his wife conceived, and she hid herself five months, saying, 

###### v25 
"Thus has the Lord done to me in the days in which he looked at me, to take away my reproach among men." 

###### v26 
Now in the sixth month, the angel Gabriel was sent from God to a city of Galilee named Nazareth, 

###### v27 
to a virgin pledged to be married to a man whose name was Joseph, of David's house. The virgin's name was Mary. 

###### v28 
Having come in, the angel said to her, "Rejoice, you highly favored one! The Lord is with you. Blessed are you among women!" 

###### v29 
But when she saw him, she was greatly troubled at the saying, and considered what kind of salutation this might be. 

###### v30 
The angel said to her, "Don't be afraid, Mary, for you have found favor with God. 

###### v31 
Behold, you will conceive in your womb and give birth to a son, and shall name him 'Jesus.' 

###### v32 
He will be great and will be called the Son of the Most High. The Lord God will give him the throne of his father David, 

###### v33 
and he will reign over the house of Jacob forever. There will be no end to his Kingdom." 

###### v34 
Mary said to the angel, "How can this be, seeing I am a virgin?" 

###### v35 
The angel answered her, "The Holy Spirit will come on you, and the power of the Most High will overshadow you. Therefore also the holy one who is born from you will be called the Son of God. 

###### v36 
Behold, Elizabeth your relative also has conceived a son in her old age; and this is the sixth month with her who was called barren. 

###### v37 
For nothing spoken by God is impossible." 

###### v38 
Mary said, "Behold, the servant of the Lord; let it be done to me according to your word." Then the angel departed from her. 

###### v39 
Mary arose in those days and went into the hill country with haste, into a city of Judah, 

###### v40 
and entered into the house of Zacharias and greeted Elizabeth. 

###### v41 
When Elizabeth heard Mary's greeting, the baby leaped in her womb; and Elizabeth was filled with the Holy Spirit. 

###### v42 
She called out with a loud voice and said, "Blessed are you among women, and blessed is the fruit of your womb! 

###### v43 
Why am I so favored, that the mother of my Lord should come to me? 

###### v44 
For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy! 

###### v45 
Blessed is she who believed, for there will be a fulfillment of the things which have been spoken to her from the Lord!" 

###### v46 
Mary said, "My soul magnifies the Lord. 

###### v47 
My spirit has rejoiced in God my Savior, 

###### v48 
for he has looked at the humble state of his servant. For behold, from now on, all generations will call me blessed. 

###### v49 
For he who is mighty has done great things for me. Holy is his name. 

###### v50 
His mercy is for generations and generations on those who fear him. 

###### v51 
He has shown strength with his arm. He has scattered the proud in the imagination of their hearts. 

###### v52 
He has put down princes from their thrones, and has exalted the lowly. 

###### v53 
He has filled the hungry with good things. He has sent the rich away empty. 

###### v54 
He has given help to Israel, his servant, that he might remember mercy, 

###### v55 
as he spoke to our fathers, to Abraham and his offspring forever." 

###### v56 
Mary stayed with her about three months, and then returned to her house. 

###### v57 
Now the time that Elizabeth should give birth was fulfilled, and she gave birth to a son. 

###### v58 
Her neighbors and her relatives heard that the Lord had magnified his mercy toward her, and they rejoiced with her. 

###### v59 
On the eighth day, they came to circumcise the child; and they would have called him Zacharias, after the name of his father. 

###### v60 
His mother answered, "Not so; but he will be called John." 

###### v61 
They said to her, "There is no one among your relatives who is called by this name." 

###### v62 
They made signs to his father, what he would have him called. 

###### v63 
He asked for a writing tablet, and wrote, "His name is John." They all marveled. 

###### v64 
His mouth was opened immediately and his tongue freed, and he spoke, blessing God. 

###### v65 
Fear came on all who lived around them, and all these sayings were talked about throughout all the hill country of Judea. 

###### v66 
All who heard them laid them up in their heart, saying, "What then will this child be?" The hand of the Lord was with him. 

###### v67 
His father Zacharias was filled with the Holy Spirit, and prophesied, saying, 

###### v68 
"Blessed be the Lord, the God of Israel, for he has visited and redeemed his people; 

###### v69 
and has raised up a horn of salvation for us in the house of his servant David 

###### v70 
(as he spoke by the mouth of his holy prophets who have been from of old), 

###### v71 
salvation from our enemies and from the hand of all who hate us; 

###### v72 
to show mercy toward our fathers, to remember his holy covenant, 

###### v73 
the oath which he swore to Abraham our father, 

###### v74 
to grant to us that we, being delivered out of the hand of our enemies, should serve him without fear, 

###### v75 
in holiness and righteousness before him all the days of our life. 

###### v76 
And you, child, will be called a prophet of the Most High; for you will go before the face of the Lord to prepare his ways, 

###### v77 
to give knowledge of salvation to his people by the remission of their sins, 

###### v78 
because of the tender mercy of our God, by which the dawn from on high will visit us, 

###### v79 
to shine on those who sit in darkness and the shadow of death; to guide our feet into the way of peace." 

###### v80 
The child was growing and becoming strong in spirit, and was in the desert until the day of his public appearance to Israel.

***
[[Luke]] | [[Luke-02|Luke 02 →]]
