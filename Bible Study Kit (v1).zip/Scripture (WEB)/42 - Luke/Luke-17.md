# Luke 17

[[Luke-16|← Luke 16]] | [[Luke]] | [[Luke-18|Luke 18 →]]
***



###### v1 
He said to the disciples, "It is impossible that no occasions of stumbling should come, but woe to him through whom they come! 

###### v2 
It would be better for him if a millstone were hung around his neck, and he were thrown into the sea, rather than that he should cause one of these little ones to stumble. 

###### v3 
Be careful. If your brother sins against you, rebuke him. If he repents, forgive him. 

###### v4 
If he sins against you seven times in the day, and seven times returns, saying, 'I repent,' you shall forgive him." 

###### v5 
The apostles said to the Lord, "Increase our faith." 

###### v6 
The Lord said, "If you had faith like a grain of mustard seed, you would tell this sycamore tree, 'Be uprooted, and be planted in the sea,' and it would obey you. 

###### v7 
But who is there among you, having a servant plowing or keeping sheep, that will say when he comes in from the field, 'Come immediately and sit down at the table,' 

###### v8 
and will not rather tell him, 'Prepare my supper, clothe yourself properly, and serve me, while I eat and drink. Afterward you shall eat and drink'? 

###### v9 
Does he thank that servant because he did the things that were commanded? I think not. 

###### v10 
Even so you also, when you have done all the things that are commanded you, say, 'We are unworthy servants. We have done our duty.'" 

###### v11 
As he was on his way to Jerusalem, he was passing along the borders of Samaria and Galilee. 

###### v12 
As he entered into a certain village, ten men who were lepers met him, who stood at a distance. 

###### v13 
They lifted up their voices, saying, "Jesus, Master, have mercy on us!" 

###### v14 
When he saw them, he said to them, "Go and show yourselves to the priests." As they went, they were cleansed. 

###### v15 
One of them, when he saw that he was healed, turned back, glorifying God with a loud voice. 

###### v16 
He fell on his face at Jesus' feet, giving him thanks; and he was a Samaritan. 

###### v17 
Jesus answered, "Weren't the ten cleansed? But where are the nine? 

###### v18 
Were there none found who returned to give glory to God, except this foreigner?" 

###### v19 
Then he said to him, "Get up, and go your way. Your faith has healed you." 

###### v20 
Being asked by the Pharisees when God's Kingdom would come, he answered them, "God's Kingdom doesn't come with observation; 

###### v21 
neither will they say, 'Look, here!' or, 'Look, there!' for behold, God's Kingdom is within you." 

###### v22 
He said to the disciples, "The days will come when you will desire to see one of the days of the Son of Man, and you will not see it. 

###### v23 
They will tell you, 'Look, here!' or 'Look, there!' Don't go away or follow after them, 

###### v24 
for as the lightning, when it flashes out of one part under the sky, shines to another part under the sky; so will the Son of Man be in his day. 

###### v25 
But first, he must suffer many things and be rejected by this generation. 

###### v26 
As it was in the days of Noah, even so it will also be in the days of the Son of Man. 

###### v27 
They ate, they drank, they married, and they were given in marriage until the day that Noah entered into the ship, and the flood came and destroyed them all. 

###### v28 
Likewise, even as it was in the days of Lot: they ate, they drank, they bought, they sold, they planted, they built; 

###### v29 
but in the day that Lot went out from Sodom, it rained fire and sulfur from the sky and destroyed them all. 

###### v30 
It will be the same way in the day that the Son of Man is revealed. 

###### v31 
In that day, he who will be on the housetop and his goods in the house, let him not go down to take them away. Let him who is in the field likewise not turn back. 

###### v32 
Remember Lot's wife! 

###### v33 
Whoever seeks to save his life loses it, but whoever loses his life preserves it. 

###### v34 
I tell you, in that night there will be two people in one bed. One will be taken and the other will be left. 

###### v35 
There will be two grinding grain together. One will be taken and the other will be left." 

###### v36 


###### v37 
They, answering, asked him, "Where, Lord?" He said to them, "Where the body is, there the vultures will also be gathered together."

***
[[Luke-16|← Luke 16]] | [[Luke]] | [[Luke-18|Luke 18 →]]
