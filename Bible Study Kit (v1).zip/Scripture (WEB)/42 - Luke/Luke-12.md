# Luke 12

[[Luke-11|← Luke 11]] | [[Luke]] | [[Luke-13|Luke 13 →]]
***



###### v1 
Meanwhile, when a multitude of many thousands had gathered together, so much so that they trampled on each other, he began to tell his disciples first of all, "Beware of the yeast of the Pharisees, which is hypocrisy. 

###### v2 
But there is nothing covered up that will not be revealed, nor hidden that will not be known. 

###### v3 
Therefore whatever you have said in the darkness will be heard in the light. What you have spoken in the ear in the inner rooms will be proclaimed on the housetops. 

###### v4 
"I tell you, my friends, don't be afraid of those who kill the body, and after that have no more that they can do. 

###### v5 
But I will warn you whom you should fear. Fear him who after he has killed, has power to cast into Gehenna. Yes, I tell you, fear him. 

###### v6 
"Aren't five sparrows sold for two assaria coins ? Not one of them is forgotten by God. 

###### v7 
But the very hairs of your head are all counted. Therefore don't be afraid. You are of more value than many sparrows. 

###### v8 
"I tell you, everyone who confesses me before men, the Son of Man will also confess before the angels of God; 

###### v9 
but he who denies me in the presence of men will be denied in the presence of God's angels. 

###### v10 
Everyone who speaks a word against the Son of Man will be forgiven, but those who blaspheme against the Holy Spirit will not be forgiven. 

###### v11 
When they bring you before the synagogues, the rulers, and the authorities, don't be anxious how or what you will answer, or what you will say; 

###### v12 
for the Holy Spirit will teach you in that same hour what you must say." 

###### v13 
One of the multitude said to him, "Teacher, tell my brother to divide the inheritance with me." 

###### v14 
But he said to him, "Man, who made me a judge or an arbitrator over you?" 

###### v15 
He said to them, "Beware! Keep yourselves from covetousness, for a man's life doesn't consist of the abundance of the things which he possesses." 

###### v16 
He spoke a parable to them, saying, "The ground of a certain rich man produced abundantly. 

###### v17 
He reasoned within himself, saying, 'What will I do, because I don't have room to store my crops?' 

###### v18 
He said, 'This is what I will do. I will pull down my barns, build bigger ones, and there I will store all my grain and my goods. 

###### v19 
I will tell my soul, "Soul, you have many goods laid up for many years. Take your ease, eat, drink, and be merry."' 

###### v20 
"But God said to him, 'You foolish one, tonight your soul is required of you. The things which you have prepared--whose will they be?' 

###### v21 
So is he who lays up treasure for himself, and is not rich toward God." 

###### v22 
He said to his disciples, "Therefore I tell you, don't be anxious for your life, what you will eat, nor yet for your body, what you will wear. 

###### v23 
Life is more than food, and the body is more than clothing. 

###### v24 
Consider the ravens: they don't sow, they don't reap, they have no warehouse or barn, and God feeds them. How much more valuable are you than birds! 

###### v25 
Which of you by being anxious can add a cubit to his height? 

###### v26 
If then you aren't able to do even the least things, why are you anxious about the rest? 

###### v27 
Consider the lilies, how they grow. They don't toil, neither do they spin; yet I tell you, even Solomon in all his glory was not arrayed like one of these. 

###### v28 
But if this is how God clothes the grass in the field, which today exists, and tomorrow is cast into the oven, how much more will he clothe you, O you of little faith? 

###### v29 
Don't seek what you will eat or what you will drink; neither be anxious. 

###### v30 
For the nations of the world seek after all of these things, but your Father knows that you need these things. 

###### v31 
But seek God's Kingdom, and all these things will be added to you. 

###### v32 
Don't be afraid, little flock, for it is your Father's good pleasure to give you the Kingdom. 

###### v33 
Sell that which you have, and give gifts to the needy. Make for yourselves purses which don't grow old, a treasure in the heavens that doesn't fail, where no thief approaches, neither moth destroys. 

###### v34 
For where your treasure is, there will your heart be also. 

###### v35 
"Let your waist be dressed and your lamps burning. 

###### v36 
Be like men watching for their lord, when he returns from the wedding feast; that when he comes and knocks, they may immediately open to him. 

###### v37 
Blessed are those servants whom the lord will find watching when he comes. Most certainly I tell you that he will dress himself, make them recline, and will come and serve them. 

###### v38 
They will be blessed if he comes in the second or third watch, and finds them so. 

###### v39 
But know this, that if the master of the house had known in what hour the thief was coming, he would have watched, and not allowed his house to be broken into. 

###### v40 
Therefore be ready also, for the Son of Man is coming in an hour that you don't expect him." 

###### v41 
Peter said to him, "Lord, are you telling this parable to us, or to everybody?" 

###### v42 
The Lord said, "Who then is the faithful and wise steward, whom his lord will set over his household, to give them their portion of food at the right times? 

###### v43 
Blessed is that servant whom his lord will find doing so when he comes. 

###### v44 
Truly I tell you, that he will set him over all that he has. 

###### v45 
But if that servant says in his heart, 'My lord delays his coming,' and begins to beat the menservants and the maidservants, and to eat and drink, and to be drunken, 

###### v46 
then the lord of that servant will come in a day when he isn't expecting him, and in an hour that he doesn't know, and will cut him in two, and place his portion with the unfaithful. 

###### v47 
That servant, who knew his lord's will, and didn't prepare, nor do what he wanted, will be beaten with many stripes, 

###### v48 
but he who didn't know, and did things worthy of stripes, will be beaten with few stripes. To whomever much is given, of him will much be required; and to whom much was entrusted, of him more will be asked. 

###### v49 
"I came to throw fire on the earth. I wish it were already kindled. 

###### v50 
But I have a baptism to be baptized with, and how distressed I am until it is accomplished! 

###### v51 
Do you think that I have come to give peace in the earth? I tell you, no, but rather division. 

###### v52 
For from now on, there will be five in one house divided, three against two, and two against three. 

###### v53 
They will be divided, father against son, and son against father; mother against daughter, and daughter against her mother; mother-in-law against her daughter-in-law, and daughter-in-law against her mother-in-law."  

###### v54 
He said to the multitudes also, "When you see a cloud rising from the west, immediately you say, 'A shower is coming,' and so it happens. 

###### v55 
When a south wind blows, you say, 'There will be a scorching heat,' and it happens. 

###### v56 
You hypocrites! You know how to interpret the appearance of the earth and the sky, but how is it that you don't interpret this time? 

###### v57 
Why don't you judge for yourselves what is right? 

###### v58 
For when you are going with your adversary before the magistrate, try diligently on the way to be released from him, lest perhaps he drag you to the judge, and the judge deliver you to the officer, and the officer throw you into prison. 

###### v59 
I tell you, you will by no means get out of there, until you have paid the very last penny."

***
[[Luke-11|← Luke 11]] | [[Luke]] | [[Luke-13|Luke 13 →]]
