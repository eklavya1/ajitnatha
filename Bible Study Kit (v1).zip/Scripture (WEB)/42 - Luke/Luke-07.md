# Luke 7

[[Luke-06|← Luke 06]] | [[Luke]] | [[Luke-08|Luke 08 →]]
***



###### v1 
After he had finished speaking in the hearing of the people, he entered into Capernaum. 

###### v2 
A certain centurion's servant, who was dear to him, was sick and at the point of death. 

###### v3 
When he heard about Jesus, he sent to him elders of the Jews, asking him to come and save his servant. 

###### v4 
When they came to Jesus, they begged him earnestly, saying, "He is worthy for you to do this for him, 

###### v5 
for he loves our nation, and he built our synagogue for us." 

###### v6 
Jesus went with them. When he was now not far from the house, the centurion sent friends to him, saying to him, "Lord, don't trouble yourself, for I am not worthy for you to come under my roof. 

###### v7 
Therefore I didn't even think myself worthy to come to you; but say the word, and my servant will be healed. 

###### v8 
For I also am a man placed under authority, having under myself soldiers. I tell this one, 'Go!' and he goes; and to another, 'Come!' and he comes; and to my servant, 'Do this,' and he does it." 

###### v9 
When Jesus heard these things, he marveled at him, and turned and said to the multitude who followed him, "I tell you, I have not found such great faith, no, not in Israel." 

###### v10 
Those who were sent, returning to the house, found that the servant who had been sick was well. 

###### v11 
Soon afterwards, he went to a city called Nain. Many of his disciples, along with a great multitude, went with him. 

###### v12 
Now when he came near to the gate of the city, behold, one who was dead was carried out, the only son of his mother, and she was a widow. Many people of the city were with her. 

###### v13 
When the Lord saw her, he had compassion on her, and said to her, "Don't cry." 

###### v14 
He came near and touched the coffin, and the bearers stood still. He said, "Young man, I tell you, arise!" 

###### v15 
He who was dead sat up, and began to speak. And he gave him to his mother. 

###### v16 
Fear took hold of all, and they glorified God, saying, "A great prophet has arisen among us!" and, "God has visited his people!" 

###### v17 
This report went out concerning him in the whole of Judea, and in all the surrounding region. 

###### v18 
The disciples of John told him about all these things. 

###### v19 
John, calling to himself two of his disciples, sent them to Jesus, saying, "Are you the one who is coming, or should we look for another?" 

###### v20 
When the men had come to him, they said, "John the Baptizer has sent us to you, saying, 'Are you he who comes, or should we look for another?'" 

###### v21 
In that hour he cured many of diseases and plagues and evil spirits; and to many who were blind he gave sight. 

###### v22 
Jesus answered them, "Go and tell John the things which you have seen and heard: that the blind receive their sight, the lame walk, the lepers are cleansed, the deaf hear, the dead are raised up, and the poor have good news preached to them. 

###### v23 
Blessed is he who finds no occasion for stumbling in me." 

###### v24 
When John's messengers had departed, he began to tell the multitudes about John, "What did you go out into the wilderness to see? A reed shaken by the wind? 

###### v25 
But what did you go out to see? A man clothed in soft clothing? Behold, those who are gorgeously dressed, and live delicately, are in kings' courts. 

###### v26 
But what did you go out to see? A prophet? Yes, I tell you, and much more than a prophet. 

###### v27 
This is he of whom it is written, 'Behold, I send my messenger before your face, who will prepare your way before you.' 

###### v28 
"For I tell you, among those who are born of women there is not a greater prophet than John the Baptizer, yet he who is least in God's Kingdom is greater than he." 

###### v29 
When all the people and the tax collectors heard this, they declared God to be just, having been baptized with John's baptism. 

###### v30 
But the Pharisees and the lawyers rejected the counsel of God, not being baptized by him themselves. 

###### v31 
"To what then should I compare the people of this generation? What are they like? 

###### v32 
They are like children who sit in the marketplace, and call to one another, saying, 'We piped to you, and you didn't dance. We mourned, and you didn't weep.' 

###### v33 
For John the Baptizer came neither eating bread nor drinking wine, and you say, 'He has a demon.' 

###### v34 
The Son of Man has come eating and drinking, and you say, 'Behold, a gluttonous man, and a drunkard; a friend of tax collectors and sinners!' 

###### v35 
Wisdom is justified by all her children." 

###### v36 
One of the Pharisees invited him to eat with him. He entered into the Pharisee's house, and sat at the table. 

###### v37 
Behold, a woman in the city who was a sinner, when she knew that he was reclining in the Pharisee's house, brought an alabaster jar of ointment. 

###### v38 
Standing behind at his feet weeping, she began to wet his feet with her tears, and she wiped them with the hair of her head, kissed his feet, and anointed them with the ointment. 

###### v39 
Now when the Pharisee who had invited him saw it, he said to himself, "This man, if he were a prophet, would have perceived who and what kind of woman this is who touches him, that she is a sinner." 

###### v40 
Jesus answered him, "Simon, I have something to tell you." He said, "Teacher, say on." 

###### v41 
"A certain lender had two debtors. The one owed five hundred denarii, and the other fifty. 

###### v42 
When they couldn't pay, he forgave them both. Which of them therefore will love him most?" 

###### v43 
Simon answered, "He, I suppose, to whom he forgave the most." He said to him, "You have judged correctly." 

###### v44 
Turning to the woman, he said to Simon, "Do you see this woman? I entered into your house, and you gave me no water for my feet, but she has wet my feet with her tears, and wiped them with the hair of her head. 

###### v45 
You gave me no kiss, but she, since the time I came in, has not ceased to kiss my feet. 

###### v46 
You didn't anoint my head with oil, but she has anointed my feet with ointment. 

###### v47 
Therefore I tell you, her sins, which are many, are forgiven, for she loved much. But one to whom little is forgiven, loves little." 

###### v48 
He said to her, "Your sins are forgiven." 

###### v49 
Those who sat at the table with him began to say to themselves, "Who is this who even forgives sins?" 

###### v50 
He said to the woman, "Your faith has saved you. Go in peace."

***
[[Luke-06|← Luke 06]] | [[Luke]] | [[Luke-08|Luke 08 →]]
