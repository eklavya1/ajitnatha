# Luke 3

[[Luke-02|← Luke 02]] | [[Luke]] | [[Luke-04|Luke 04 →]]
***



###### v1 
Now in the fifteenth year of the reign of Tiberius Caesar, Pontius Pilate being governor of Judea, and Herod being tetrarch of Galilee, and his brother Philip tetrarch of the region of Ituraea and Trachonitis, and Lysanias tetrarch of Abilene, 

###### v2 
in the high priesthood of Annas and Caiaphas, the word of God came to John, the son of Zacharias, in the wilderness. 

###### v3 
He came into all the region around the Jordan, preaching the baptism of repentance for remission of sins. 

###### v4 
As it is written in the book of the words of Isaiah the prophet, "The voice of one crying in the wilderness, 'Make ready the way of the Lord. Make his paths straight. 

###### v5 
Every valley will be filled. Every mountain and hill will be brought low. The crooked will become straight, and the rough ways smooth. 

###### v6 
All flesh will see God's salvation.'" 

###### v7 
He said therefore to the multitudes who went out to be baptized by him, "You offspring of vipers, who warned you to flee from the wrath to come? 

###### v8 
Therefore produce fruits worthy of repentance, and don't begin to say among yourselves, 'We have Abraham for our father;' for I tell you that God is able to raise up children to Abraham from these stones! 

###### v9 
Even now the ax also lies at the root of the trees. Every tree therefore that doesn't produce good fruit is cut down, and thrown into the fire." 

###### v10 
The multitudes asked him, "What then must we do?" 

###### v11 
He answered them, "He who has two coats, let him give to him who has none. He who has food, let him do likewise." 

###### v12 
Tax collectors also came to be baptized, and they said to him, "Teacher, what must we do?" 

###### v13 
He said to them, "Collect no more than that which is appointed to you." 

###### v14 
Soldiers also asked him, saying, "What about us? What must we do?" He said to them, "Extort from no one by violence, neither accuse anyone wrongfully. Be content with your wages." 

###### v15 
As the people were in expectation, and all men reasoned in their hearts concerning John, whether perhaps he was the Christ, 

###### v16 
John answered them all, "I indeed baptize you with water, but he comes who is mightier than I, the strap of whose sandals I am not worthy to loosen. He will baptize you in the Holy Spirit and fire, 

###### v17 
whose fan is in his hand, and he will thoroughly cleanse his threshing floor, and will gather the wheat into his barn; but he will burn up the chaff with unquenchable fire." 

###### v18 
Then with many other exhortations he preached good news to the people, 

###### v19 
but Herod the tetrarch, being reproved by him for Herodias, his brother's wife, and for all the evil things which Herod had done, 

###### v20 
added this also to them all, that he shut up John in prison. 

###### v21 
Now when all the people were baptized, Jesus also had been baptized, and was praying. The sky was opened, 

###### v22 
and the Holy Spirit descended in a bodily form like a dove on him; and a voice came out of the sky, saying "You are my beloved Son. In you I am well pleased." 

###### v23 
Jesus himself, when he began to teach, was about thirty years old, being the son (as was supposed) of Joseph, the son of Heli, 

###### v24 
the son of Matthat, the son of Levi, the son of Melchi, the son of Jannai, the son of Joseph, 

###### v25 
the son of Mattathias, the son of Amos, the son of Nahum, the son of Esli, the son of Naggai, 

###### v26 
the son of Maath, the son of Mattathias, the son of Semein, the son of Joseph, the son of Judah, 

###### v27 
the son of Joanan, the son of Rhesa, the son of Zerubbabel, the son of Shealtiel, the son of Neri, 

###### v28 
the son of Melchi, the son of Addi, the son of Cosam, the son of Elmodam, the son of Er, 

###### v29 
the son of Jose, the son of Eliezer, the son of Jorim, the son of Matthat, the son of Levi, 

###### v30 
the son of Simeon, the son of Judah, the son of Joseph, the son of Jonan, the son of Eliakim, 

###### v31 
the son of Melea, the son of Menan, the son of Mattatha, the son of Nathan, the son of David, 

###### v32 
the son of Jesse, the son of Obed, the son of Boaz, the son of Salmon, the son of Nahshon, 

###### v33 
the son of Amminadab, the son of Aram, the son of Hezron, the son of Perez, the son of Judah, 

###### v34 
the son of Jacob, the son of Isaac, the son of Abraham, the son of Terah, the son of Nahor, 

###### v35 
the son of Serug, the son of Reu, the son of Peleg, the son of Eber, the son of Shelah, 

###### v36 
the son of Cainan, the son of Arphaxad, the son of Shem, the son of Noah, the son of Lamech, 

###### v37 
the son of Methuselah, the son of Enoch, the son of Jared, the son of Mahalaleel, the son of Cainan, 

###### v38 
the son of Enos, the son of Seth, the son of Adam, the son of God.

***
[[Luke-02|← Luke 02]] | [[Luke]] | [[Luke-04|Luke 04 →]]
