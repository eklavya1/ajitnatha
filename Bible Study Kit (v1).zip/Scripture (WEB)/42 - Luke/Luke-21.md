# Luke 21

[[Luke-20|← Luke 20]] | [[Luke]] | [[Luke-22|Luke 22 →]]
***



###### v1 
He looked up and saw the rich people who were putting their gifts into the treasury. 

###### v2 
He saw a certain poor widow casting in two small brass coins. 

###### v3 
He said, "Truly I tell you, this poor widow put in more than all of them, 

###### v4 
for all these put in gifts for God from their abundance, but she, out of her poverty, put in all that she had to live on." 

###### v5 
As some were talking about the temple and how it was decorated with beautiful stones and gifts, he said, 

###### v6 
"As for these things which you see, the days will come, in which there will not be left here one stone on another that will not be thrown down." 

###### v7 
They asked him, "Teacher, so when will these things be? What is the sign that these things are about to happen?" 

###### v8 
He said, "Watch out that you don't get led astray, for many will come in my name, saying, 'I am he,' and, 'The time is at hand.' Therefore don't follow them. 

###### v9 
When you hear of wars and disturbances, don't be terrified, for these things must happen first, but the end won't come immediately." 

###### v10 
Then he said to them, "Nation will rise against nation, and kingdom against kingdom. 

###### v11 
There will be great earthquakes, famines, and plagues in various places. There will be terrors and great signs from heaven. 

###### v12 
But before all these things, they will lay their hands on you and will persecute you, delivering you up to synagogues and prisons, bringing you before kings and governors for my name's sake. 

###### v13 
It will turn out as a testimony for you. 

###### v14 
Settle it therefore in your hearts not to meditate beforehand how to answer, 

###### v15 
for I will give you a mouth and wisdom which all your adversaries will not be able to withstand or to contradict. 

###### v16 
You will be handed over even by parents, brothers, relatives, and friends. They will cause some of you to be put to death. 

###### v17 
You will be hated by all men for my name's sake. 

###### v18 
And not a hair of your head will perish. 

###### v19 
"By your endurance you will win your lives. 

###### v20 
"But when you see Jerusalem surrounded by armies, then know that its desolation is at hand. 

###### v21 
Then let those who are in Judea flee to the mountains. Let those who are in the middle of her depart. Let those who are in the country not enter therein. 

###### v22 
For these are days of vengeance, that all things which are written may be fulfilled. 

###### v23 
Woe to those who are pregnant and to those who nurse infants in those days! For there will be great distress in the land, and wrath to this people. 

###### v24 
They will fall by the edge of the sword, and will be led captive into all the nations. Jerusalem will be trampled down by the Gentiles, until the times of the Gentiles are fulfilled. 

###### v25 
There will be signs in the sun, moon, and stars; and on the earth anxiety of nations, in perplexity for the roaring of the sea and the waves; 

###### v26 
men fainting for fear, and for expectation of the things which are coming on the world: for the powers of the heavens will be shaken. 

###### v27 
Then they will see the Son of Man coming in a cloud with power and great glory. 

###### v28 
But when these things begin to happen, look up and lift up your heads, because your redemption is near." 

###### v29 
He told them a parable. "See the fig tree and all the trees. 

###### v30 
When they are already budding, you see it and know by your own selves that the summer is already near. 

###### v31 
Even so you also, when you see these things happening, know that God's Kingdom is near. 

###### v32 
Most certainly I tell you, this generation will not pass away until all things are accomplished. 

###### v33 
Heaven and earth will pass away, but my words will by no means pass away. 

###### v34 
"So be careful, or your hearts will be loaded down with carousing, drunkenness, and cares of this life, and that day will come on you suddenly. 

###### v35 
For it will come like a snare on all those who dwell on the surface of all the earth. 

###### v36 
Therefore be watchful all the time, praying that you may be counted worthy to escape all these things that will happen, and to stand before the Son of Man." 

###### v37 
Every day Jesus was teaching in the temple, and every night he would go out and spend the night on the mountain that is called Olivet. 

###### v38 
All the people came early in the morning to him in the temple to hear him.

***
[[Luke-20|← Luke 20]] | [[Luke]] | [[Luke-22|Luke 22 →]]
