# Luke 9

[[Luke-08|← Luke 08]] | [[Luke]] | [[Luke-10|Luke 10 →]]
***



###### v1 
He called the twelve together, and gave them power and authority over all demons, and to cure diseases. 

###### v2 
He sent them out to preach God's Kingdom and to heal the sick. 

###### v3 
He said to them, "Take nothing for your journey--no staffs, nor wallet, nor bread, nor money. Don't have two coats each. 

###### v4 
Into whatever house you enter, stay there, and depart from there. 

###### v5 
As many as don't receive you, when you depart from that city, shake off even the dust from your feet for a testimony against them." 

###### v6 
They departed and went throughout the villages, preaching the Good News and healing everywhere. 

###### v7 
Now Herod the tetrarch heard of all that was done by him; and he was very perplexed, because it was said by some that John had risen from the dead, 

###### v8 
and by some that Elijah had appeared, and by others that one of the old prophets had risen again. 

###### v9 
Herod said, "I beheaded John, but who is this about whom I hear such things?" He sought to see him. 

###### v10 
The apostles, when they had returned, told him what things they had done. He took them and withdrew apart to a desert region of a city called Bethsaida. 

###### v11 
But the multitudes, perceiving it, followed him. He welcomed them, spoke to them of God's Kingdom, and he cured those who needed healing. 

###### v12 
The day began to wear away; and the twelve came and said to him, "Send the multitude away, that they may go into the surrounding villages and farms, and lodge, and get food, for we are here in a deserted place." 

###### v13 
But he said to them, "You give them something to eat." They said, "We have no more than five loaves and two fish, unless we should go and buy food for all these people." 

###### v14 
For they were about five thousand men. He said to his disciples, "Make them sit down in groups of about fifty each." 

###### v15 
They did so, and made them all sit down. 

###### v16 
He took the five loaves and the two fish, and looking up to the sky, he blessed them, broke them, and gave them to the disciples to set before the multitude. 

###### v17 
They ate and were all filled. They gathered up twelve baskets of broken pieces that were left over. 

###### v18 
As he was praying alone, the disciples were with him, and he asked them, "Who do the multitudes say that I am?" 

###### v19 
They answered, "'John the Baptizer,' but others say, 'Elijah,' and others, that one of the old prophets has risen again." 

###### v20 
He said to them, "But who do you say that I am?" Peter answered, "The Christ of God." 

###### v21 
But he warned them, and commanded them to tell this to no one, 

###### v22 
saying, "The Son of Man must suffer many things, and be rejected by the elders, chief priests, and scribes, and be killed, and the third day be raised up." 

###### v23 
He said to all, "If anyone desires to come after me, let him deny himself, take up his cross, and follow me. 

###### v24 
For whoever desires to save his life will lose it, but whoever will lose his life for my sake, will save it. 

###### v25 
For what does it profit a man if he gains the whole world, and loses or forfeits his own self? 

###### v26 
For whoever will be ashamed of me and of my words, of him will the Son of Man be ashamed, when he comes in his glory, and the glory of the Father, and of the holy angels. 

###### v27 
But I tell you the truth: There are some of those who stand here who will in no way taste of death until they see God's Kingdom." 

###### v28 
About eight days after these sayings, he took with him Peter, John, and James, and went up onto the mountain to pray. 

###### v29 
As he was praying, the appearance of his face was altered, and his clothing became white and dazzling. 

###### v30 
Behold, two men were talking with him, who were Moses and Elijah, 

###### v31 
who appeared in glory, and spoke of his departure, which he was about to accomplish at Jerusalem. 

###### v32 
Now Peter and those who were with him were heavy with sleep, but when they were fully awake, they saw his glory, and the two men who stood with him. 

###### v33 
As they were parting from him, Peter said to Jesus, "Master, it is good for us to be here. Let's make three tents: one for you, one for Moses, and one for Elijah," not knowing what he said. 

###### v34 
While he said these things, a cloud came and overshadowed them, and they were afraid as they entered into the cloud. 

###### v35 
A voice came out of the cloud, saying, "This is my beloved Son. Listen to him!" 

###### v36 
When the voice came, Jesus was found alone. They were silent, and told no one in those days any of the things which they had seen. 

###### v37 
On the next day, when they had come down from the mountain, a great multitude met him. 

###### v38 
Behold, a man from the crowd called out, saying, "Teacher, I beg you to look at my son, for he is my only child. 

###### v39 
Behold, a spirit takes him, he suddenly cries out, and it convulses him so that he foams, and it hardly departs from him, bruising him severely. 

###### v40 
I begged your disciples to cast it out, and they couldn't." 

###### v41 
Jesus answered, "Faithless and perverse generation, how long shall I be with you and bear with you? Bring your son here." 

###### v42 
While he was still coming, the demon threw him down and convulsed him violently. But Jesus rebuked the unclean spirit, healed the boy, and gave him back to his father. 

###### v43 
They were all astonished at the majesty of God. But while all were marveling at all the things which Jesus did, he said to his disciples, 

###### v44 
"Let these words sink into your ears, for the Son of Man will be delivered up into the hands of men." 

###### v45 
But they didn't understand this saying. It was concealed from them, that they should not perceive it, and they were afraid to ask him about this saying. 

###### v46 
An argument arose among them about which of them was the greatest. 

###### v47 
Jesus, perceiving the reasoning of their hearts, took a little child, and set him by his side, 

###### v48 
and said to them, "Whoever receives this little child in my name receives me. Whoever receives me receives him who sent me. For whoever is least among you all, this one will be great." 

###### v49 
John answered, "Master, we saw someone casting out demons in your name, and we forbade him, because he doesn't follow with us." 

###### v50 
Jesus said to him, "Don't forbid him, for he who is not against us is for us." 

###### v51 
It came to pass, when the days were near that he should be taken up, he intently set his face to go to Jerusalem 

###### v52 
and sent messengers before his face. They went and entered into a village of the Samaritans, so as to prepare for him. 

###### v53 
They didn't receive him, because he was traveling with his face set toward Jerusalem. 

###### v54 
When his disciples, James and John, saw this, they said, "Lord, do you want us to command fire to come down from the sky and destroy them, just as Elijah did?" 

###### v55 
But he turned and rebuked them, "You don't know of what kind of spirit you are. 

###### v56 
For the Son of Man didn't come to destroy men's lives, but to save them." They went to another village. 

###### v57 
As they went on the way, a certain man said to him, "I want to follow you wherever you go, Lord." 

###### v58 
Jesus said to him, "The foxes have holes, and the birds of the sky have nests, but the Son of Man has no place to lay his head." 

###### v59 
He said to another, "Follow me!" But he said, "Lord, allow me first to go and bury my father." 

###### v60 
But Jesus said to him, "Leave the dead to bury their own dead, but you go and announce God's Kingdom." 

###### v61 
Another also said, "I want to follow you, Lord, but first allow me to say good-bye to those who are at my house." 

###### v62 
But Jesus said to him, "No one, having put his hand to the plow and looking back, is fit for God's Kingdom."

***
[[Luke-08|← Luke 08]] | [[Luke]] | [[Luke-10|Luke 10 →]]
