# Luke 19

[[Luke-18|← Luke 18]] | [[Luke]] | [[Luke-20|Luke 20 →]]
***



###### v1 
He entered and was passing through Jericho. 

###### v2 
There was a man named Zacchaeus. He was a chief tax collector, and he was rich. 

###### v3 
He was trying to see who Jesus was, and couldn't because of the crowd, because he was short. 

###### v4 
He ran on ahead, and climbed up into a sycamore tree to see him, for he was going to pass that way. 

###### v5 
When Jesus came to the place, he looked up and saw him, and said to him, "Zacchaeus, hurry and come down, for today I must stay at your house." 

###### v6 
He hurried, came down, and received him joyfully. 

###### v7 
When they saw it, they all murmured, saying, "He has gone in to lodge with a man who is a sinner." 

###### v8 
Zacchaeus stood and said to the Lord, "Behold, Lord, half of my goods I give to the poor. If I have wrongfully exacted anything of anyone, I restore four times as much." 

###### v9 
Jesus said to him, "Today, salvation has come to this house, because he also is a son of Abraham. 

###### v10 
For the Son of Man came to seek and to save that which was lost." 

###### v11 
As they heard these things, he went on and told a parable, because he was near Jerusalem, and they supposed that God's Kingdom would be revealed immediately. 

###### v12 
He said therefore, "A certain nobleman went into a far country to receive for himself a kingdom and to return. 

###### v13 
He called ten servants of his and gave them ten mina coins, and told them, 'Conduct business until I come.' 

###### v14 
But his citizens hated him, and sent an envoy after him, saying, 'We don't want this man to reign over us.' 

###### v15 
"When he had come back again, having received the kingdom, he commanded these servants, to whom he had given the money, to be called to him, that he might know what they had gained by conducting business. 

###### v16 
The first came before him, saying, 'Lord, your mina has made ten more minas.' 

###### v17 
"He said to him, 'Well done, you good servant! Because you were found faithful with very little, you shall have authority over ten cities.' 

###### v18 
"The second came, saying, 'Your mina, Lord, has made five minas.' 

###### v19 
"So he said to him, 'And you are to be over five cities.' 

###### v20 
Another came, saying, 'Lord, behold, your mina, which I kept laid away in a handkerchief, 

###### v21 
for I feared you, because you are an exacting man. You take up that which you didn't lay down, and reap that which you didn't sow.' 

###### v22 
"He said to him, 'Out of your own mouth I will judge you, you wicked servant! You knew that I am an exacting man, taking up that which I didn't lay down, and reaping that which I didn't sow. 

###### v23 
Then why didn't you deposit my money in the bank, and at my coming, I might have earned interest on it?' 

###### v24 
He said to those who stood by, 'Take the mina away from him and give it to him who has the ten minas.' 

###### v25 
"They said to him, 'Lord, he has ten minas!' 

###### v26 
'For I tell you that to everyone who has, will more be given; but from him who doesn't have, even that which he has will be taken away from him. 

###### v27 
But bring those enemies of mine who didn't want me to reign over them here, and kill them before me.'" 

###### v28 
Having said these things, he went on ahead, going up to Jerusalem. 

###### v29 
When he came near to Bethsphage and Bethany, at the mountain that is called Olivet, he sent two of his disciples, 

###### v30 
saying, "Go your way into the village on the other side, in which, as you enter, you will find a colt tied, which no man had ever sat upon. Untie it and bring it. 

###### v31 
If anyone asks you, 'Why are you untying it?' say to him: 'The Lord needs it.'" 

###### v32 
Those who were sent went away, and found things just as he had told them. 

###### v33 
As they were untying the colt, its owners said to them, "Why are you untying the colt?" 

###### v34 
They said, "The Lord needs it." 

###### v35 
Then they brought it to Jesus. They threw their cloaks on the colt, and sat Jesus on them. 

###### v36 
As he went, they spread their cloaks on the road. 

###### v37 
As he was now getting near, at the descent of the Mount of Olives, the whole multitude of the disciples began to rejoice and praise God with a loud voice for all the mighty works which they had seen, 

###### v38 
saying, "Blessed is the King who comes in the name of the Lord!  Peace in heaven, and glory in the highest!" 

###### v39 
Some of the Pharisees from the multitude said to him, "Teacher, rebuke your disciples!" 

###### v40 
He answered them, "I tell you that if these were silent, the stones would cry out." 

###### v41 
When he came near, he saw the city and wept over it, 

###### v42 
saying, "If you, even you, had known today the things which belong to your peace! But now, they are hidden from your eyes. 

###### v43 
For the days will come on you, when your enemies will throw up a barricade against you, surround you, hem you in on every side, 

###### v44 
and will dash you and your children within you to the ground. They will not leave in you one stone on another, because you didn't know the time of your visitation." 

###### v45 
He entered into the temple, and began to drive out those who bought and sold in it, 

###### v46 
saying to them, "It is written, 'My house is a house of prayer,'  

###### v47 
He was teaching daily in the temple, but the chief priests, the scribes, and the leading men among the people sought to destroy him. 

###### v48 
They couldn't find what they might do, for all the people hung on to every word that he said.

***
[[Luke-18|← Luke 18]] | [[Luke]] | [[Luke-20|Luke 20 →]]
