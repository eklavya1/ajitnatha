# Luke 14

[[Luke-13|← Luke 13]] | [[Luke]] | [[Luke-15|Luke 15 →]]
***



###### v1 
When he went into the house of one of the rulers of the Pharisees on a Sabbath to eat bread, they were watching him. 

###### v2 
Behold, a certain man who had dropsy was in front of him. 

###### v3 
Jesus, answering, spoke to the lawyers and Pharisees, saying, "Is it lawful to heal on the Sabbath?" 

###### v4 
But they were silent. He took him, and healed him, and let him go. 

###### v5 
He answered them, "Which of you, if your son or an ox fell into a well, wouldn't immediately pull him out on a Sabbath day?" 

###### v6 
They couldn't answer him regarding these things. 

###### v7 
He spoke a parable to those who were invited, when he noticed how they chose the best seats, and said to them, 

###### v8 
"When you are invited by anyone to a wedding feast, don't sit in the best seat, since perhaps someone more honorable than you might be invited by him, 

###### v9 
and he who invited both of you would come and tell you, 'Make room for this person.' Then you would begin, with shame, to take the lowest place. 

###### v10 
But when you are invited, go and sit in the lowest place, so that when he who invited you comes, he may tell you, 'Friend, move up higher.' Then you will be honored in the presence of all who sit at the table with you. 

###### v11 
For everyone who exalts himself will be humbled, and whoever humbles himself will be exalted." 

###### v12 
He also said to the one who had invited him, "When you make a dinner or a supper, don't call your friends, nor your brothers, nor your kinsmen, nor rich neighbors, or perhaps they might also return the favor, and pay you back. 

###### v13 
But when you make a feast, ask the poor, the maimed, the lame, or the blind; 

###### v14 
and you will be blessed, because they don't have the resources to repay you. For you will be repaid in the resurrection of the righteous." 

###### v15 
When one of those who sat at the table with him heard these things, he said to him, "Blessed is he who will feast in God's Kingdom!" 

###### v16 
But he said to him, "A certain man made a great supper, and he invited many people. 

###### v17 
He sent out his servant at supper time to tell those who were invited, 'Come, for everything is ready now.' 

###### v18 
They all as one began to make excuses. "The first said to him, 'I have bought a field, and I must go and see it. Please have me excused.' 

###### v19 
"Another said, 'I have bought five yoke of oxen, and I must go try them out. Please have me excused.' 

###### v20 
"Another said, 'I have married a wife, and therefore I can't come.' 

###### v21 
"That servant came, and told his lord these things. Then the master of the house, being angry, said to his servant, 'Go out quickly into the streets and lanes of the city, and bring in the poor, maimed, blind, and lame.' 

###### v22 
"The servant said, 'Lord, it is done as you commanded, and there is still room.' 

###### v23 
"The lord said to the servant, 'Go out into the highways and hedges, and compel them to come in, that my house may be filled. 

###### v24 
For I tell you that none of those men who were invited will taste of my supper.'" 

###### v25 
Now great multitudes were going with him. He turned and said to them, 

###### v26 
"If anyone comes to me, and doesn't disregard his own father, mother, wife, children, brothers, and sisters, yes, and his own life also, he can't be my disciple. 

###### v27 
Whoever doesn't bear his own cross, and come after me, can't be my disciple. 

###### v28 
For which of you, desiring to build a tower, doesn't first sit down and count the cost, to see if he has enough to complete it? 

###### v29 
Or perhaps, when he has laid a foundation, and is not able to finish, everyone who sees begins to mock him, 

###### v30 
saying, 'This man began to build, and wasn't able to finish.' 

###### v31 
Or what king, as he goes to encounter another king in war, will not sit down first and consider whether he is able with ten thousand to meet him who comes against him with twenty thousand? 

###### v32 
Or else, while the other is yet a great way off, he sends an envoy, and asks for conditions of peace. 

###### v33 
So therefore whoever of you who doesn't renounce all that he has, he can't be my disciple. 

###### v34 
Salt is good, but if the salt becomes flat and tasteless, with what do you season it? 

###### v35 
It is fit neither for the soil nor for the manure pile. It is thrown out. He who has ears to hear, let him hear."

***
[[Luke-13|← Luke 13]] | [[Luke]] | [[Luke-15|Luke 15 →]]
