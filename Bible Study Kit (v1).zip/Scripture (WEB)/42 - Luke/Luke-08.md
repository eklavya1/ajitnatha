# Luke 8

[[Luke-07|← Luke 07]] | [[Luke]] | [[Luke-09|Luke 09 →]]
***



###### v1 
Soon afterwards, he went about through cities and villages, preaching and bringing the good news of God's Kingdom. With him were the twelve, 

###### v2 
and certain women who had been healed of evil spirits and infirmities: Mary who was called Magdalene, from whom seven demons had gone out; 

###### v3 
and Joanna, the wife of Chuzas, Herod's steward; Susanna; and many others; who served them from their possessions. 

###### v4 
When a great multitude came together, and people from every city were coming to him, he spoke by a parable. 

###### v5 
"The farmer went out to sow his seed. As he sowed, some fell along the road, and it was trampled under foot, and the birds of the sky devoured it. 

###### v6 
Other seed fell on the rock, and as soon as it grew, it withered away, because it had no moisture. 

###### v7 
Other fell amid the thorns, and the thorns grew with it, and choked it. 

###### v8 
Other fell into the good ground, and grew, and produced one hundred times as much fruit." As he said these things, he called out, "He who has ears to hear, let him hear!" 

###### v9 
Then his disciples asked him, "What does this parable mean?" 

###### v10 
He said, "To you it is given to know the mysteries of God's Kingdom, but to the rest in parables; that 'seeing they may not see, and hearing they may not understand.' 

###### v11 
Now the parable is this: The seed is the word of God. 

###### v12 
Those along the road are those who hear, then the devil comes, and takes away the word from their heart, that they may not believe and be saved. 

###### v13 
Those on the rock are they who, when they hear, receive the word with joy; but these have no root, who believe for a while, then fall away in time of temptation. 

###### v14 
That which fell among the thorns, these are those who have heard, and as they go on their way they are choked with cares, riches, and pleasures of life, and bring no fruit to maturity. 

###### v15 
Those in the good ground, these are those who with an honest and good heart, having heard the word, hold it tightly, and produce fruit with perseverance. 

###### v16 
"No one, when he has lit a lamp, covers it with a container, or puts it under a bed; but puts it on a stand, that those who enter in may see the light. 

###### v17 
For nothing is hidden that will not be revealed; nor anything secret that will not be known and come to light. 

###### v18 
Be careful therefore how you hear. For whoever has, to him will be given; and whoever doesn't have, from him will be taken away even that which he thinks he has." 

###### v19 
His mother and brothers came to him, and they could not come near him for the crowd. 

###### v20 
Some people told him, "Your mother and your brothers stand outside, desiring to see you." 

###### v21 
But he answered them, "My mother and my brothers are these who hear the word of God, and do it." 

###### v22 
Now on one of those days, he entered into a boat, himself and his disciples, and he said to them, "Let's go over to the other side of the lake." So they launched out. 

###### v23 
But as they sailed, he fell asleep. A wind storm came down on the lake, and they were taking on dangerous amounts of water. 

###### v24 
They came to him, and awoke him, saying, "Master, master, we are dying!" He awoke, and rebuked the wind and the raging of the water, and they ceased, and it was calm. 

###### v25 
He said to them, "Where is your faith?" Being afraid they marveled, saying to one another, "Who is this then, that he commands even the winds and the water, and they obey him?" 

###### v26 
Then they arrived at the country of the Gadarenes, which is opposite Galilee. 

###### v27 
When Jesus stepped ashore, a certain man out of the city who had demons for a long time met him. He wore no clothes, and didn't live in a house, but in the tombs. 

###### v28 
When he saw Jesus, he cried out, and fell down before him, and with a loud voice said, "What do I have to do with you, Jesus, you Son of the Most High God? I beg you, don't torment me!" 

###### v29 
For Jesus was commanding the unclean spirit to come out of the man. For the unclean spirit had often seized the man. He was kept under guard, and bound with chains and fetters. Breaking the bonds apart, he was driven by the demon into the desert. 

###### v30 
Jesus asked him, "What is your name?" He said, "Legion," for many demons had entered into him. 

###### v31 
They begged him that he would not command them to go into the abyss. 

###### v32 
Now there was there a herd of many pigs feeding on the mountain, and they begged him that he would allow them to enter into those. Then he allowed them. 

###### v33 
The demons came out of the man, and entered into the pigs, and the herd rushed down the steep bank into the lake, and were drowned. 

###### v34 
When those who fed them saw what had happened, they fled and told it in the city and in the country. 

###### v35 
People went out to see what had happened. They came to Jesus and found the man from whom the demons had gone out, sitting at Jesus' feet, clothed and in his right mind; and they were afraid. 

###### v36 
Those who saw it told them how he who had been possessed by demons was healed. 

###### v37 
All the people of the surrounding country of the Gadarenes asked him to depart from them, for they were very much afraid. Then he entered into the boat and returned. 

###### v38 
But the man from whom the demons had gone out begged him that he might go with him, but Jesus sent him away, saying, 

###### v39 
"Return to your house, and declare what great things God has done for you." He went his way, proclaiming throughout the whole city what great things Jesus had done for him. 

###### v40 
When Jesus returned, the multitude welcomed him, for they were all waiting for him. 

###### v41 
Behold, a man named Jairus came. He was a ruler of the synagogue. He fell down at Jesus' feet, and begged him to come into his house, 

###### v42 
for he had an only daughter, about twelve years of age, and she was dying. But as he went, the multitudes pressed against him. 

###### v43 
A woman who had a flow of blood for twelve years, who had spent all her living on physicians and could not be healed by any 

###### v44 
came behind him, and touched the fringe of his cloak. Immediately the flow of her blood stopped. 

###### v45 
Jesus said, "Who touched me?" When all denied it, Peter and those with him said, "Master, the multitudes press and jostle you, and you say, 'Who touched me?'" 

###### v46 
But Jesus said, "Someone did touch me, for I perceived that power has gone out of me." 

###### v47 
When the woman saw that she was not hidden, she came trembling, and falling down before him declared to him in the presence of all the people the reason why she had touched him, and how she was healed immediately. 

###### v48 
He said to her, "Daughter, cheer up. Your faith has made you well. Go in peace." 

###### v49 
While he still spoke, one from the ruler of the synagogue's house came, saying to him, "Your daughter is dead. Don't trouble the Teacher." 

###### v50 
But Jesus hearing it, answered him, "Don't be afraid. Only believe, and she will be healed." 

###### v51 
When he came to the house, he didn't allow anyone to enter in, except Peter, John, James, the father of the child, and her mother. 

###### v52 
All were weeping and mourning her, but he said, "Don't weep. She isn't dead, but sleeping." 

###### v53 
They were ridiculing him, knowing that she was dead. 

###### v54 
But he put them all outside, and taking her by the hand, he called, saying, "Child, arise!" 

###### v55 
Her spirit returned, and she rose up immediately. He commanded that something be given to her to eat. 

###### v56 
Her parents were amazed, but he commanded them to tell no one what had been done.

***
[[Luke-07|← Luke 07]] | [[Luke]] | [[Luke-09|Luke 09 →]]
