# Luke 16

[[Luke-15|← Luke 15]] | [[Luke]] | [[Luke-17|Luke 17 →]]
***



###### v1 
He also said to his disciples, "There was a certain rich man who had a manager. An accusation was made to him that this man was wasting his possessions. 

###### v2 
He called him, and said to him, 'What is this that I hear about you? Give an accounting of your management, for you can no longer be manager.' 

###### v3 
"The manager said within himself, 'What will I do, seeing that my lord is taking away the management position from me? I don't have strength to dig. I am ashamed to beg. 

###### v4 
I know what I will do, so that when I am removed from management, they may receive me into their houses.' 

###### v5 
Calling each one of his lord's debtors to him, he said to the first, 'How much do you owe to my lord?' 

###### v6 
He said, 'A hundred batos of oil.' He said to him, 'Take your bill, and sit down quickly and write fifty.' 

###### v7 
Then he said to another, 'How much do you owe?' He said, 'A hundred cors of wheat.' He said to him, 'Take your bill, and write eighty.' 

###### v8 
"His lord commended the dishonest manager because he had done wisely, for the children of this world are, in their own generation, wiser than the children of the light. 

###### v9 
I tell you, make for yourselves friends by means of unrighteous mammon, so that when you fail, they may receive you into the eternal tents. 

###### v10 
He who is faithful in a very little is faithful also in much. He who is dishonest in a very little is also dishonest in much. 

###### v11 
If therefore you have not been faithful in the unrighteous mammon, who will commit to your trust the true riches? 

###### v12 
If you have not been faithful in that which is another's, who will give you that which is your own? 

###### v13 
No servant can serve two masters, for either he will hate the one, and love the other; or else he will hold to one, and despise the other. You aren't able to serve God and Mammon." 

###### v14 
The Pharisees, who were lovers of money, also heard all these things, and they scoffed at him. 

###### v15 
He said to them, "You are those who justify yourselves in the sight of men, but God knows your hearts. For that which is exalted among men is an abomination in the sight of God. 

###### v16 
The law and the prophets were until John. From that time the Good News of God's Kingdom is preached, and everyone is forcing his way into it. 

###### v17 
But it is easier for heaven and earth to pass away than for one tiny stroke of a pen in the law to fall. 

###### v18 
Everyone who divorces his wife and marries another commits adultery. He who marries one who is divorced from a husband commits adultery. 

###### v19 
"Now there was a certain rich man, and he was clothed in purple and fine linen, living in luxury every day. 

###### v20 
A certain beggar, named Lazarus, was taken to his gate, full of sores, 

###### v21 
and desiring to be fed with the crumbs that fell from the rich man's table. Yes, even the dogs came and licked his sores. 

###### v22 
The beggar died, and he was carried away by the angels to Abraham's bosom. The rich man also died, and was buried. 

###### v23 
In Hades, he lifted up his eyes, being in torment, and saw Abraham far off, and Lazarus at his bosom. 

###### v24 
He cried and said, 'Father Abraham, have mercy on me, and send Lazarus, that he may dip the tip of his finger in water, and cool my tongue! For I am in anguish in this flame.' 

###### v25 
"But Abraham said, 'Son, remember that you, in your lifetime, received your good things, and Lazarus, in the same way, bad things. But here he is now comforted, and you are in anguish. 

###### v26 
Besides all this, between us and you there is a great gulf fixed, that those who want to pass from here to you are not able, and that no one may cross over from there to us.' 

###### v27 
"He said, 'I ask you therefore, father, that you would send him to my father's house; 

###### v28 
for I have five brothers, that he may testify to them, so they won't also come into this place of torment.' 

###### v29 
"But Abraham said to him, 'They have Moses and the prophets. Let them listen to them.' 

###### v30 
"He said, 'No, father Abraham, but if one goes to them from the dead, they will repent.' 

###### v31 
"He said to him, 'If they don't listen to Moses and the prophets, neither will they be persuaded if one rises from the dead.'"

***
[[Luke-15|← Luke 15]] | [[Luke]] | [[Luke-17|Luke 17 →]]
