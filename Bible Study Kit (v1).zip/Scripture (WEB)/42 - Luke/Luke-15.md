# Luke 15

[[Luke-14|← Luke 14]] | [[Luke]] | [[Luke-16|Luke 16 →]]
***



###### v1 
Now all the tax collectors and sinners were coming close to him to hear him. 

###### v2 
The Pharisees and the scribes murmured, saying, "This man welcomes sinners, and eats with them." 

###### v3 
He told them this parable. 

###### v4 
"Which of you men, if you had one hundred sheep, and lost one of them, wouldn't leave the ninety-nine in the wilderness, and go after the one that was lost, until he found it? 

###### v5 
When he has found it, he carries it on his shoulders, rejoicing. 

###### v6 
When he comes home, he calls together his friends and his neighbors, saying to them, 'Rejoice with me, for I have found my sheep which was lost!' 

###### v7 
I tell you that even so there will be more joy in heaven over one sinner who repents, than over ninety-nine righteous people who need no repentance. 

###### v8 
Or what woman, if she had ten drachma coins, if she lost one drachma coin, wouldn't light a lamp, sweep the house, and seek diligently until she found it? 

###### v9 
When she has found it, she calls together her friends and neighbors, saying, 'Rejoice with me, for I have found the drachma which I had lost.' 

###### v10 
Even so, I tell you, there is joy in the presence of the angels of God over one sinner repenting." 

###### v11 
He said, "A certain man had two sons. 

###### v12 
The younger of them said to his father, 'Father, give me my share of your property.' So he divided his livelihood between them. 

###### v13 
Not many days after, the younger son gathered all of this together and traveled into a far country. There he wasted his property with riotous living. 

###### v14 
When he had spent all of it, there arose a severe famine in that country, and he began to be in need. 

###### v15 
He went and joined himself to one of the citizens of that country, and he sent him into his fields to feed pigs. 

###### v16 
He wanted to fill his belly with the husks that the pigs ate, but no one gave him any. 

###### v17 
But when he came to himself he said, 'How many hired servants of my father's have bread enough to spare, and I'm dying with hunger! 

###### v18 
I will get up and go to my father, and will tell him, "Father, I have sinned against heaven, and in your sight. 

###### v19 
I am no more worthy to be called your son. Make me as one of your hired servants."' 

###### v20 
"He arose, and came to his father. But while he was still far off, his father saw him, and was moved with compassion, and ran, and fell on his neck, and kissed him. 

###### v21 
The son said to him, 'Father, I have sinned against heaven and in your sight. I am no longer worthy to be called your son.' 

###### v22 
"But the father said to his servants, 'Bring out the best robe, and put it on him. Put a ring on his hand, and sandals on his feet. 

###### v23 
Bring the fattened calf, kill it, and let's eat, and celebrate; 

###### v24 
for this, my son, was dead, and is alive again. He was lost, and is found.' Then they began to celebrate. 

###### v25 
"Now his elder son was in the field. As he came near to the house, he heard music and dancing. 

###### v26 
He called one of the servants to him, and asked what was going on. 

###### v27 
He said to him, 'Your brother has come, and your father has killed the fattened calf, because he has received him back safe and healthy.' 

###### v28 
But he was angry, and would not go in. Therefore his father came out, and begged him. 

###### v29 
But he answered his father, 'Behold, these many years I have served you, and I never disobeyed a commandment of yours, but you never gave me a goat, that I might celebrate with my friends. 

###### v30 
But when this your son came, who has devoured your living with prostitutes, you killed the fattened calf for him.' 

###### v31 
"He said to him, 'Son, you are always with me, and all that is mine is yours. 

###### v32 
But it was appropriate to celebrate and be glad, for this, your brother, was dead, and is alive again. He was lost, and is found.'"

***
[[Luke-14|← Luke 14]] | [[Luke]] | [[Luke-16|Luke 16 →]]
