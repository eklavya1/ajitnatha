# Luke 22

[[Luke-21|← Luke 21]] | [[Luke]] | [[Luke-23|Luke 23 →]]
***



###### v1 
Now the feast of unleavened bread, which is called the Passover, was approaching. 

###### v2 
The chief priests and the scribes sought how they might put him to death, for they feared the people. 

###### v3 
Satan entered into Judas, who was also called Iscariot, who was counted with the twelve. 

###### v4 
He went away, and talked with the chief priests and captains about how he might deliver him to them. 

###### v5 
They were glad, and agreed to give him money. 

###### v6 
He consented, and sought an opportunity to deliver him to them in the absence of the multitude. 

###### v7 
The day of unleavened bread came, on which the Passover must be sacrificed. 

###### v8 
Jesus sent Peter and John, saying, "Go and prepare the Passover for us, that we may eat." 

###### v9 
They said to him, "Where do you want us to prepare?" 

###### v10 
He said to them, "Behold, when you have entered into the city, a man carrying a pitcher of water will meet you. Follow him into the house which he enters. 

###### v11 
Tell the master of the house, 'The Teacher says to you, "Where is the guest room, where I may eat the Passover with my disciples?"' 

###### v12 
He will show you a large, furnished upper room. Make preparations there." 

###### v13 
They went, found things as Jesus had told them, and they prepared the Passover. 

###### v14 
When the hour had come, he sat down with the twelve apostles. 

###### v15 
He said to them, "I have earnestly desired to eat this Passover with you before I suffer, 

###### v16 
for I tell you, I will no longer by any means eat of it until it is fulfilled in God's Kingdom." 

###### v17 
He received a cup, and when he had given thanks, he said, "Take this, and share it among yourselves, 

###### v18 
for I tell you, I will not drink at all again from the fruit of the vine, until God's Kingdom comes." 

###### v19 
He took bread, and when he had given thanks, he broke, and gave it to them, saying, "This is my body which is given for you. Do this in memory of me." 

###### v20 
Likewise, he took the cup after supper, saying, "This cup is the new covenant in my blood, which is poured out for you. 

###### v21 
But behold, the hand of him who betrays me is with me on the table. 

###### v22 
The Son of Man indeed goes, as it has been determined, but woe to that man through whom he is betrayed!" 

###### v23 
They began to question among themselves, which of them it was who would do this thing. 

###### v24 
A dispute also arose among them, which of them was considered to be greatest. 

###### v25 
He said to them, "The kings of the nations lord it over them, and those who have authority over them are called 'benefactors.' 

###### v26 
But not so with you. But one who is the greater among you, let him become as the younger, and one who is governing, as one who serves. 

###### v27 
For who is greater, one who sits at the table, or one who serves? Isn't it he who sits at the table? But I am among you as one who serves. 

###### v28 
But you are those who have continued with me in my trials. 

###### v29 
I confer on you a kingdom, even as my Father conferred on me, 

###### v30 
that you may eat and drink at my table in my Kingdom. You will sit on thrones, judging the twelve tribes of Israel." 

###### v31 
The Lord said, "Simon, Simon, behold, Satan asked to have all of you, that he might sift you as wheat, 

###### v32 
but I prayed for you, that your faith wouldn't fail. You, when once you have turned again, establish your brothers." 

###### v33 
He said to him, "Lord, I am ready to go with you both to prison and to death!" 

###### v34 
He said, "I tell you, Peter, the rooster will by no means crow today until you deny that you know me three times." 

###### v35 
He said to them, "When I sent you out without purse, wallet, and sandals, did you lack anything?" They said, "Nothing." 

###### v36 
Then he said to them, "But now, whoever has a purse, let him take it, and likewise a wallet. Whoever has none, let him sell his cloak, and buy a sword. 

###### v37 
For I tell you that this which is written must still be fulfilled in me: 'He was counted with transgressors.' For that which concerns me has an end." 

###### v38 
They said, "Lord, behold, here are two swords." He said to them, "That is enough." 

###### v39 
He came out and went, as his custom was, to the Mount of Olives. His disciples also followed him. 

###### v40 
When he was at the place, he said to them, "Pray that you don't enter into temptation." 

###### v41 
He was withdrawn from them about a stone's throw, and he knelt down and prayed, 

###### v42 
saying, "Father, if you are willing, remove this cup from me. Nevertheless, not my will, but yours, be done." 

###### v43 
An angel from heaven appeared to him, strengthening him. 

###### v44 
Being in agony he prayed more earnestly. His sweat became like great drops of blood falling down on the ground. 

###### v45 
When he rose up from his prayer, he came to the disciples, and found them sleeping because of grief, 

###### v46 
and said to them, "Why do you sleep? Rise and pray that you may not enter into temptation." 

###### v47 
While he was still speaking, a crowd appeared. He who was called Judas, one of the twelve, was leading them. He came near to Jesus to kiss him. 

###### v48 
But Jesus said to him, "Judas, do you betray the Son of Man with a kiss?" 

###### v49 
When those who were around him saw what was about to happen, they said to him, "Lord, shall we strike with the sword?" 

###### v50 
A certain one of them struck the servant of the high priest, and cut off his right ear. 

###### v51 
But Jesus answered, "Let me at least do this"--and he touched his ear, and healed him. 

###### v52 
Jesus said to the chief priests, captains of the temple, and elders, who had come against him, "Have you come out as against a robber, with swords and clubs? 

###### v53 
When I was with you in the temple daily, you didn't stretch out your hands against me. But this is your hour, and the power of darkness." 

###### v54 
They seized him, and led him away, and brought him into the high priest's house. But Peter followed from a distance. 

###### v55 
When they had kindled a fire in the middle of the courtyard, and had sat down together, Peter sat among them. 

###### v56 
A certain servant girl saw him as he sat in the light, and looking intently at him, said, "This man also was with him." 

###### v57 
He denied Jesus, saying, "Woman, I don't know him." 

###### v58 
After a little while someone else saw him, and said, "You also are one of them!" But Peter answered, "Man, I am not!" 

###### v59 
After about one hour passed, another confidently affirmed, saying, "Truly this man also was with him, for he is a Galilean!" 

###### v60 
But Peter said, "Man, I don't know what you are talking about!" Immediately, while he was still speaking, a rooster crowed. 

###### v61 
The Lord turned and looked at Peter. Then Peter remembered the Lord's word, how he said to him, "Before the rooster crows you will deny me three times." 

###### v62 
He went out, and wept bitterly. 

###### v63 
The men who held Jesus mocked him and beat him. 

###### v64 
Having blindfolded him, they struck him on the face and asked him, "Prophesy! Who is the one who struck you?" 

###### v65 
They spoke many other things against him, insulting him. 

###### v66 
As soon as it was day, the assembly of the elders of the people were gathered together, both chief priests and scribes, and they led him away into their council, saying, 

###### v67 
"If you are the Christ, tell us." But he said to them, "If I tell you, you won't believe, 

###### v68 
and if I ask, you will in no way answer me or let me go. 

###### v69 
From now on, the Son of Man will be seated at the right hand of the power of God." 

###### v70 
They all said, "Are you then the Son of God?" He said to them, "You say it, because I am." 

###### v71 
They said, "Why do we need any more witness? For we ourselves have heard from his own mouth!"

***
[[Luke-21|← Luke 21]] | [[Luke]] | [[Luke-23|Luke 23 →]]
