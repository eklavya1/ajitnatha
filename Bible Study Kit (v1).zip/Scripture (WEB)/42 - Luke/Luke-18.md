# Luke 18

[[Luke-17|← Luke 17]] | [[Luke]] | [[Luke-19|Luke 19 →]]
***



###### v1 
He also spoke a parable to them that they must always pray, and not give up, 

###### v2 
saying, "There was a judge in a certain city who didn't fear God, and didn't respect man. 

###### v3 
A widow was in that city, and she often came to him, saying, 'Defend me from my adversary!' 

###### v4 
He wouldn't for a while, but afterward he said to himself, 'Though I neither fear God, nor respect man, 

###### v5 
yet because this widow bothers me, I will defend her, or else she will wear me out by her continual coming.'" 

###### v6 
The Lord said, "Listen to what the unrighteous judge says. 

###### v7 
Won't God avenge his chosen ones who are crying out to him day and night, and yet he exercises patience with them? 

###### v8 
I tell you that he will avenge them quickly. Nevertheless, when the Son of Man comes, will he find faith on the earth?" 

###### v9 
He also spoke this parable to certain people who were convinced of their own righteousness, and who despised all others. 

###### v10 
"Two men went up into the temple to pray; one was a Pharisee, and the other was a tax collector. 

###### v11 
The Pharisee stood and prayed to himself like this: 'God, I thank you that I am not like the rest of men, extortionists, unrighteous, adulterers, or even like this tax collector. 

###### v12 
I fast twice a week. I give tithes of all that I get.' 

###### v13 
But the tax collector, standing far away, wouldn't even lift up his eyes to heaven, but beat his breast, saying, 'God, be merciful to me, a sinner!' 

###### v14 
I tell you, this man went down to his house justified rather than the other; for everyone who exalts himself will be humbled, but he who humbles himself will be exalted." 

###### v15 
They were also bringing their babies to him, that he might touch them. But when the disciples saw it, they rebuked them. 

###### v16 
Jesus summoned them, saying, "Allow the little children to come to me, and don't hinder them, for God's Kingdom belongs to such as these. 

###### v17 
Most certainly, I tell you, whoever doesn't receive God's Kingdom like a little child, he will in no way enter into it." 

###### v18 
A certain ruler asked him, saying, "Good Teacher, what shall I do to inherit eternal life?" 

###### v19 
Jesus asked him, "Why do you call me good? No one is good, except one: God. 

###### v20 
You know the commandments: 'Don't commit adultery,' 'Don't murder,' 'Don't steal,' 'Don't give false testimony,' 'Honor your father and your mother.'" 

###### v21 
He said, "I have observed all these things from my youth up." 

###### v22 
When Jesus heard these things, he said to him, "You still lack one thing. Sell all that you have, and distribute it to the poor. Then you will have treasure in heaven; then come, follow me." 

###### v23 
But when he heard these things, he became very sad, for he was very rich. 

###### v24 
Jesus, seeing that he became very sad, said, "How hard it is for those who have riches to enter into God's Kingdom! 

###### v25 
For it is easier for a camel to enter in through a needle's eye than for a rich man to enter into God's Kingdom." 

###### v26 
Those who heard it said, "Then who can be saved?" 

###### v27 
But he said, "The things which are impossible with men are possible with God." 

###### v28 
Peter said, "Look, we have left everything and followed you." 

###### v29 
He said to them, "Most certainly I tell you, there is no one who has left house, or wife, or brothers, or parents, or children, for God's Kingdom's sake, 

###### v30 
who will not receive many times more in this time, and in the world to come, eternal life." 

###### v31 
He took the twelve aside, and said to them, "Behold, we are going up to Jerusalem, and all the things that are written through the prophets concerning the Son of Man will be completed. 

###### v32 
For he will be delivered up to the Gentiles, will be mocked, treated shamefully, and spit on. 

###### v33 
They will scourge and kill him. On the third day, he will rise again." 

###### v34 
They understood none of these things. This saying was hidden from them, and they didn't understand the things that were said. 

###### v35 
As he came near Jericho, a certain blind man sat by the road, begging. 

###### v36 
Hearing a multitude going by, he asked what this meant. 

###### v37 
They told him that Jesus of Nazareth was passing by. 

###### v38 
He cried out, "Jesus, you son of David, have mercy on me!" 

###### v39 
Those who led the way rebuked him, that he should be quiet; but he cried out all the more, "You son of David, have mercy on me!" 

###### v40 
Standing still, Jesus commanded him to be brought to him. When he had come near, he asked him, 

###### v41 
"What do you want me to do?" He said, "Lord, that I may see again." 

###### v42 
Jesus said to him, "Receive your sight. Your faith has healed you." 

###### v43 
Immediately he received his sight and followed him, glorifying God. All the people, when they saw it, praised God.

***
[[Luke-17|← Luke 17]] | [[Luke]] | [[Luke-19|Luke 19 →]]
