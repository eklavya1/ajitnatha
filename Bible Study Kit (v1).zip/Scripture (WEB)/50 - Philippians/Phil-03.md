# Philippians 3

[[Phil-02|← Philippians 02]] | [[Philippians]] | [[Phil-04|Philippians 04 →]]
***



###### v1 
Finally, my brothers, rejoice in the Lord! To write the same things to you, to me indeed is not tiresome, but for you it is safe. 

###### v2 
Beware of the dogs; beware of the evil workers; beware of the false circumcision. 

###### v3 
For we are the circumcision, who worship God in the Spirit, and rejoice in Christ Jesus, and have no confidence in the flesh; 

###### v4 
though I myself might have confidence even in the flesh. If any other man thinks that he has confidence in the flesh, I yet more: 

###### v5 
circumcised the eighth day, of the stock of Israel, of the tribe of Benjamin, a Hebrew of Hebrews; concerning the law, a Pharisee; 

###### v6 
concerning zeal, persecuting the assembly; concerning the righteousness which is in the law, found blameless. 

###### v7 
However, I consider those things that were gain to me as a loss for Christ. 

###### v8 
Yes most certainly, and I count all things to be a loss for the excellency of the knowledge of Christ Jesus, my Lord, for whom I suffered the loss of all things, and count them nothing but refuse, that I may gain Christ 

###### v9 
and be found in him, not having a righteousness of my own, that which is of the law, but that which is through faith in Christ, the righteousness which is from God by faith, 

###### v10 
that I may know him, and the power of his resurrection, and the fellowship of his sufferings, becoming conformed to his death, 

###### v11 
if by any means I may attain to the resurrection from the dead. 

###### v12 
Not that I have already obtained, or am already made perfect; but I press on, that I may take hold of that for which also I was taken hold of by Christ Jesus. 

###### v13 
Brothers, I don't regard myself as yet having taken hold, but one thing I do: forgetting the things which are behind, and stretching forward to the things which are before, 

###### v14 
I press on toward the goal for the prize of the high calling of God in Christ Jesus. 

###### v15 
Let us therefore, as many as are perfect, think this way. If in anything you think otherwise, God will also reveal that to you. 

###### v16 
Nevertheless, to the extent that we have already attained, let's walk by the same rule. Let's be of the same mind. 

###### v17 
Brothers, be imitators together of me, and note those who walk this way, even as you have us for an example. 

###### v18 
For many walk, of whom I told you often, and now tell you even weeping, as the enemies of the cross of Christ, 

###### v19 
whose end is destruction, whose god is the belly, and whose glory is in their shame, who think about earthly things. 

###### v20 
For our citizenship is in heaven, from where we also wait for a Savior, the Lord Jesus Christ, 

###### v21 
who will change the body of our humiliation to be conformed to the body of his glory, according to the working by which he is able even to subject all things to himself.

***
[[Phil-02|← Philippians 02]] | [[Philippians]] | [[Phil-04|Philippians 04 →]]
