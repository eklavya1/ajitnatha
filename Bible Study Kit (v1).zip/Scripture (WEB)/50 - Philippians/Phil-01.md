# Philippians 1

[[Philippians]] | [[Phil-02|Philippians 02 →]]
***



###### v1 
Paul and Timothy, servants of Jesus Christ; To all the saints in Christ Jesus who are at Philippi, with the overseers and servants: 

###### v2 
Grace to you, and peace from God our Father and the Lord Jesus Christ. 

###### v3 
I thank my God whenever I remember you, 

###### v4 
always in every request of mine on behalf of you all, making my requests with joy, 

###### v5 
for your partnership in furtherance of the Good News from the first day until now; 

###### v6 
being confident of this very thing, that he who began a good work in you will complete it until the day of Jesus Christ. 

###### v7 
It is even right for me to think this way on behalf of all of you, because I have you in my heart, because both in my bonds and in the defense and confirmation of the Good News, you all are partakers with me of grace. 

###### v8 
For God is my witness, how I long after all of you in the tender mercies of Christ Jesus. 

###### v9 
This I pray, that your love may abound yet more and more in knowledge and all discernment, 

###### v10 
so that you may approve the things that are excellent, that you may be sincere and without offense to the day of Christ, 

###### v11 
being filled with the fruits of righteousness, which are through Jesus Christ, to the glory and praise of God. 

###### v12 
Now I desire to have you know, brothers, that the things which happened to me have turned out rather to the progress of the Good News, 

###### v13 
so that it became evident to the whole palace guard, and to all the rest, that my bonds are in Christ, 

###### v14 
and that most of the brothers in the Lord, being confident through my bonds, are more abundantly bold to speak the word of God without fear. 

###### v15 
Some indeed preach Christ even out of envy and strife, and some also out of good will. 

###### v16 
The former insincerely preach Christ from selfish ambition, thinking that they add affliction to my chains; 

###### v17 
but the latter out of love, knowing that I am appointed for the defense of the Good News. 

###### v18 
What does it matter? Only that in every way, whether in pretense or in truth, Christ is proclaimed. I rejoice in this, yes, and will rejoice. 

###### v19 
For I know that this will turn out to my salvation, through your prayers and the supply of the Spirit of Jesus Christ, 

###### v20 
according to my earnest expectation and hope, that I will in no way be disappointed, but with all boldness, as always, now also Christ will be magnified in my body, whether by life or by death. 

###### v21 
For to me to live is Christ, and to die is gain. 

###### v22 
But if I live on in the flesh, this will bring fruit from my work; yet I don't know what I will choose. 

###### v23 
But I am hard pressed between the two, having the desire to depart and be with Christ, which is far better. 

###### v24 
Yet to remain in the flesh is more needful for your sake. 

###### v25 
Having this confidence, I know that I will remain, yes, and remain with you all for your progress and joy in the faith, 

###### v26 
that your rejoicing may abound in Christ Jesus in me through my presence with you again. 

###### v27 
Only let your way of life be worthy of the Good News of Christ, that whether I come and see you or am absent, I may hear of your state, that you stand firm in one spirit, with one soul striving for the faith of the Good News; 

###### v28 
and in nothing frightened by the adversaries, which is for them a proof of destruction, but to you of salvation, and that from God. 

###### v29 
Because it has been granted to you on behalf of Christ, not only to believe in him, but also to suffer on his behalf, 

###### v30 
having the same conflict which you saw in me and now hear is in me.

***
[[Philippians]] | [[Phil-02|Philippians 02 →]]
