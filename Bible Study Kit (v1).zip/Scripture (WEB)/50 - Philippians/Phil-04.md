# Philippians 4

[[Phil-03|← Philippians 03]] | [[Philippians]]
***



###### v1 
Therefore, my brothers, beloved and longed for, my joy and crown, stand firm in the Lord in this way, my beloved. 

###### v2 
I exhort Euodia, and I exhort Syntyche, to think the same way in the Lord. 

###### v3 
Yes, I beg you also, true partner, help these women, for they labored with me in the Good News with Clement also, and the rest of my fellow workers, whose names are in the book of life. 

###### v4 
Rejoice in the Lord always! Again I will say, "Rejoice!" 

###### v5 
Let your gentleness be known to all men. The Lord is at hand. 

###### v6 
In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. 

###### v7 
And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus. 

###### v8 
Finally, brothers, whatever things are true, whatever things are honorable, whatever things are just, whatever things are pure, whatever things are lovely, whatever things are of good report: if there is any virtue and if there is any praise, think about these things. 

###### v9 
The things which you learned, received, heard, and saw in me: do these things, and the God of peace will be with you. 

###### v10 
But I rejoice in the Lord greatly, that now at length you have revived your thought for me; in which you did indeed take thought, but you lacked opportunity. 

###### v11 
Not that I speak because of lack, for I have learned in whatever state I am, to be content in it. 

###### v12 
I know how to be humbled, and I also know how to abound. In everything and in all things I have learned the secret both to be filled and to be hungry, both to abound and to be in need. 

###### v13 
I can do all things through Christ, who strengthens me. 

###### v14 
However you did well that you shared in my affliction. 

###### v15 
You yourselves also know, you Philippians, that in the beginning of the Good News, when I departed from Macedonia, no assembly shared with me in the matter of giving and receiving but you only. 

###### v16 
For even in Thessalonica you sent once and again to my need. 

###### v17 
Not that I seek for the gift, but I seek for the fruit that increases to your account. 

###### v18 
But I have all things and abound. I am filled, having received from Epaphroditus the things that came from you, a sweet-smelling fragrance, an acceptable and well-pleasing sacrifice to God. 

###### v19 
My God will supply every need of yours according to his riches in glory in Christ Jesus. 

###### v20 
Now to our God and Father be the glory forever and ever! Amen. 

###### v21 
Greet every saint in Christ Jesus. The brothers who are with me greet you. 

###### v22 
All the saints greet you, especially those who are of Caesar's household. 

###### v23 
The grace of the Lord Jesus Christ be with you all. Amen.

***
[[Phil-03|← Philippians 03]] | [[Philippians]]
