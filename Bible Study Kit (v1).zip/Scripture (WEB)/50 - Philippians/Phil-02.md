# Philippians 2

[[Phil-01|← Philippians 01]] | [[Philippians]] | [[Phil-03|Philippians 03 →]]
***



###### v1 
If therefore there is any exhortation in Christ, if any consolation of love, if any fellowship of the Spirit, if any tender mercies and compassion, 

###### v2 
make my joy full by being like-minded, having the same love, being of one accord, of one mind; 

###### v3 
doing nothing through rivalry or through conceit, but in humility, each counting others better than himself; 

###### v4 
each of you not just looking to his own things, but each of you also to the things of others. 

###### v5 
Have this in your mind, which was also in Christ Jesus, 

###### v6 
who, existing in the form of God, didn't consider equality with God a thing to be grasped, 

###### v7 
but emptied himself, taking the form of a servant, being made in the likeness of men. 

###### v8 
And being found in human form, he humbled himself, becoming obedient to the point of death, yes, the death of the cross. 

###### v9 
Therefore God also highly exalted him, and gave to him the name which is above every name, 

###### v10 
that at the name of Jesus every knee should bow, of those in heaven, those on earth, and those under the earth, 

###### v11 
and that every tongue should confess that Jesus Christ is Lord, to the glory of God the Father. 

###### v12 
So then, my beloved, even as you have always obeyed, not only in my presence, but now much more in my absence, work out your own salvation with fear and trembling. 

###### v13 
For it is God who works in you both to will and to work, for his good pleasure. 

###### v14 
Do all things without complaining and arguing, 

###### v15 
that you may become blameless and harmless, children of God without defect in the middle of a crooked and perverse generation, among whom you are seen as lights in the world, 

###### v16 
holding up the word of life, that I may have something to boast in the day of Christ, that I didn't run in vain nor labor in vain. 

###### v17 
Yes, and if I am poured out on the sacrifice and service of your faith, I rejoice, and rejoice with you all. 

###### v18 
In the same way, you also rejoice, and rejoice with me. 

###### v19 
But I hope in the Lord Jesus to send Timothy to you soon, that I also may be cheered up when I know how you are doing. 

###### v20 
For I have no one else like-minded, who will truly care about you. 

###### v21 
For they all seek their own, not the things of Jesus Christ. 

###### v22 
But you know the proof of him, that as a child serves a father, so he served with me in furtherance of the Good News. 

###### v23 
Therefore I hope to send him at once, as soon as I see how it will go with me. 

###### v24 
But I trust in the Lord that I myself also will come shortly. 

###### v25 
But I counted it necessary to send to you Epaphroditus, my brother, fellow worker, fellow soldier, and your apostle and servant of my need, 

###### v26 
since he longed for you all, and was very troubled because you had heard that he was sick. 

###### v27 
For indeed he was sick, nearly to death, but God had mercy on him, and not on him only, but on me also, that I might not have sorrow on sorrow. 

###### v28 
I have sent him therefore the more diligently, that when you see him again, you may rejoice, and that I may be the less sorrowful. 

###### v29 
Receive him therefore in the Lord with all joy, and hold such people in honor, 

###### v30 
because for the work of Christ he came near to death, risking his life to supply that which was lacking in your service toward me.

***
[[Phil-01|← Philippians 01]] | [[Philippians]] | [[Phil-03|Philippians 03 →]]
