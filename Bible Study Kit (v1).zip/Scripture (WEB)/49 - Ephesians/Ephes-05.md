# Ephesians 5

[[Ephes-04|← Ephesians 04]] | [[Ephesians]] | [[Ephes-06|Ephesians 06 →]]
***



###### v1 
Be therefore imitators of God, as beloved children. 

###### v2 
Walk in love, even as Christ also loved us and gave himself up for us, an offering and a sacrifice to God for a sweet-smelling fragrance. 

###### v3 
But sexual immorality, and all uncleanness or covetousness, let it not even be mentioned among you, as becomes saints; 

###### v4 
nor filthiness, nor foolish talking, nor jesting, which are not appropriate, but rather giving of thanks. 

###### v5 
Know this for sure, that no sexually immoral person, nor unclean person, nor covetous man, who is an idolater, has any inheritance in the Kingdom of Christ and God. 

###### v6 
Let no one deceive you with empty words. For because of these things, the wrath of God comes on the children of disobedience. 

###### v7 
Therefore don't be partakers with them. 

###### v8 
For you were once darkness, but are now light in the Lord. Walk as children of light, 

###### v9 
for the fruit of the Spirit is in all goodness and righteousness and truth, 

###### v10 
proving what is well pleasing to the Lord. 

###### v11 
Have no fellowship with the unfruitful deeds of darkness, but rather even reprove them. 

###### v12 
For it is a shame even to speak of the things which are done by them in secret. 

###### v13 
But all things, when they are reproved, are revealed by the light, for everything that reveals is light. 

###### v14 
Therefore he says, "Awake, you who sleep, and arise from the dead, and Christ will shine on you." 

###### v15 
Therefore watch carefully how you walk, not as unwise, but as wise, 

###### v16 
redeeming the time, because the days are evil. 

###### v17 
Therefore don't be foolish, but understand what the will of the Lord is. 

###### v18 
Don't be drunken with wine, in which is dissipation, but be filled with the Spirit, 

###### v19 
speaking to one another in psalms, hymns, and spiritual songs; singing and making melody in your heart to the Lord; 

###### v20 
giving thanks always concerning all things in the name of our Lord Jesus Christ, to God, even the Father; 

###### v21 
subjecting yourselves to one another in the fear of Christ. 

###### v22 
Wives, be subject to your own husbands, as to the Lord. 

###### v23 
For the husband is the head of the wife, as Christ also is the head of the assembly, being himself the savior of the body. 

###### v24 
But as the assembly is subject to Christ, so let the wives also be to their own husbands in everything. 

###### v25 
Husbands, love your wives, even as Christ also loved the assembly, and gave himself up for it; 

###### v26 
that he might sanctify it, having cleansed it by the washing of water with the word, 

###### v27 
that he might present the assembly to himself gloriously, not having spot or wrinkle or any such thing; but that it should be holy and without defect. 

###### v28 
Even so husbands also ought to love their own wives as their own bodies. He who loves his own wife loves himself. 

###### v29 
For no man ever hated his own flesh; but nourishes and cherishes it, even as the Lord also does the assembly; 

###### v30 
because we are members of his body, of his flesh and bones. 

###### v31 
"For this cause a man will leave his father and mother, and will be joined to his wife. Then the two will become one flesh." 

###### v32 
This mystery is great, but I speak concerning Christ and of the assembly. 

###### v33 
Nevertheless each of you must also love his own wife even as himself; and let the wife see that she respects her husband.

***
[[Ephes-04|← Ephesians 04]] | [[Ephesians]] | [[Ephes-06|Ephesians 06 →]]
