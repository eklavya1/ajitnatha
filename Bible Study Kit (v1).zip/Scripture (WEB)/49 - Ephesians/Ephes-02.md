# Ephesians 2

[[Ephes-01|← Ephesians 01]] | [[Ephesians]] | [[Ephes-03|Ephesians 03 →]]
***



###### v1 
You were made alive when you were dead in transgressions and sins, 

###### v2 
in which you once walked according to the course of this world, according to the prince of the power of the air, the spirit who now works in the children of disobedience. 

###### v3 
We also all once lived among them in the lusts of our flesh, doing the desires of the flesh and of the mind, and were by nature children of wrath, even as the rest. 

###### v4 
But God, being rich in mercy, for his great love with which he loved us, 

###### v5 
even when we were dead through our trespasses, made us alive together with Christ--by grace you have been saved-- 

###### v6 
and raised us up with him, and made us to sit with him in the heavenly places in Christ Jesus, 

###### v7 
that in the ages to come he might show the exceeding riches of his grace in kindness toward us in Christ Jesus; 

###### v8 
for by grace you have been saved through faith, and that not of yourselves; it is the gift of God, 

###### v9 
not of works, that no one would boast. 

###### v10 
For we are his workmanship, created in Christ Jesus for good works, which God prepared before that we would walk in them. 

###### v11 
Therefore remember that once you, the Gentiles in the flesh, who are called "uncircumcision" by that which is called "circumcision" (in the flesh, made by hands), 

###### v12 
that you were at that time separate from Christ, alienated from the commonwealth of Israel, and strangers from the covenants of the promise, having no hope and without God in the world. 

###### v13 
But now in Christ Jesus you who once were far off are made near in the blood of Christ. 

###### v14 
For he is our peace, who made both one, and broke down the middle wall of separation, 

###### v15 
having abolished in his flesh the hostility, the law of commandments contained in ordinances, that he might create in himself one new man of the two, making peace, 

###### v16 
and might reconcile them both in one body to God through the cross, having killed the hostility through it. 

###### v17 
He came and preached peace to you who were far off and to those who were near. 

###### v18 
For through him we both have our access in one Spirit to the Father. 

###### v19 
So then you are no longer strangers and foreigners, but you are fellow citizens with the saints and of the household of God, 

###### v20 
being built on the foundation of the apostles and prophets, Christ Jesus himself being the chief cornerstone; 

###### v21 
in whom the whole building, fitted together, grows into a holy temple in the Lord; 

###### v22 
in whom you also are built together for a habitation of God in the Spirit.

***
[[Ephes-01|← Ephesians 01]] | [[Ephesians]] | [[Ephes-03|Ephesians 03 →]]
