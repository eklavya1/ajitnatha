# Ephesians 6

[[Ephes-05|← Ephesians 05]] | [[Ephesians]]
***



###### v1 
Children, obey your parents in the Lord, for this is right. 

###### v2 
"Honor your father and mother," which is the first commandment with a promise: 

###### v3 
"that it may be well with you, and you may live long on the earth."  

###### v4 
You fathers, don't provoke your children to wrath, but nurture them in the discipline and instruction of the Lord. 

###### v5 
Servants, be obedient to those who according to the flesh are your masters, with fear and trembling, in singleness of your heart, as to Christ, 

###### v6 
not in the way of service only when eyes are on you, as men pleasers, but as servants of Christ, doing the will of God from the heart, 

###### v7 
with good will doing service as to the Lord, and not to men, 

###### v8 
knowing that whatever good thing each one does, he will receive the same good again from the Lord, whether he is bound or free. 

###### v9 
You masters, do the same things to them, and give up threatening, knowing that he who is both their Master and yours is in heaven, and there is no partiality with him. 

###### v10 
Finally, be strong in the Lord, and in the strength of his might. 

###### v11 
Put on the whole armor of God, that you may be able to stand against the wiles of the devil. 

###### v12 
For our wrestling is not against flesh and blood, but against the principalities, against the powers, against the world's rulers of the darkness of this age, and against the spiritual forces of wickedness in the heavenly places. 

###### v13 
Therefore put on the whole armor of God, that you may be able to withstand in the evil day, and having done all, to stand. 

###### v14 
Stand therefore, having the utility belt of truth buckled around your waist, and having put on the breastplate of righteousness, 

###### v15 
and having fitted your feet with the preparation of the Good News of peace, 

###### v16 
above all, taking up the shield of faith, with which you will be able to quench all the fiery darts of the evil one. 

###### v17 
And take the helmet of salvation, and the sword of the Spirit, which is the word of God; 

###### v18 
with all prayer and requests, praying at all times in the Spirit, and being watchful to this end in all perseverance and requests for all the saints: 

###### v19 
on my behalf, that utterance may be given to me in opening my mouth, to make known with boldness the mystery of the Good News, 

###### v20 
for which I am an ambassador in chains; that in it I may speak boldly, as I ought to speak. 

###### v21 
But that you also may know my affairs, how I am doing, Tychicus, the beloved brother and faithful servant in the Lord, will make known to you all things. 

###### v22 
I have sent him to you for this very purpose, that you may know our state and that he may comfort your hearts. 

###### v23 
Peace be to the brothers, and love with faith, from God the Father and the Lord Jesus Christ. 

###### v24 
Grace be with all those who love our Lord Jesus Christ with incorruptible love. Amen.

***
[[Ephes-05|← Ephesians 05]] | [[Ephesians]]
