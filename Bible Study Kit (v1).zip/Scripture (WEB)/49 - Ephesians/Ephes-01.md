# Ephesians 1

[[Ephesians]] | [[Ephes-02|Ephesians 02 →]]
***



###### v1 
Paul, an apostle of Christ Jesus through the will of God, to the saints who are at Ephesus, and the faithful in Christ Jesus: 

###### v2 
Grace to you and peace from God our Father and the Lord Jesus Christ. 

###### v3 
Blessed be the God and Father of our Lord Jesus Christ, who has blessed us with every spiritual blessing in the heavenly places in Christ, 

###### v4 
even as he chose us in him before the foundation of the world, that we would be holy and without defect before him in love, 

###### v5 
having predestined us for adoption as children through Jesus Christ to himself, according to the good pleasure of his desire, 

###### v6 
to the praise of the glory of his grace, by which he freely gave us favor in the Beloved, 

###### v7 
in whom we have our redemption through his blood, the forgiveness of our trespasses, according to the riches of his grace, 

###### v8 
which he made to abound toward us in all wisdom and prudence, 

###### v9 
making known to us the mystery of his will, according to his good pleasure which he purposed in him 

###### v10 
to an administration of the fullness of the times, to sum up all things in Christ, the things in the heavens and the things on the earth, in him. 

###### v11 
We were also assigned an inheritance in him, having been foreordained according to the purpose of him who does all things after the counsel of his will, 

###### v12 
to the end that we should be to the praise of his glory, we who had before hoped in Christ. 

###### v13 
In him you also, having heard the word of the truth, the Good News of your salvation--in whom, having also believed, you were sealed with the promised Holy Spirit, 

###### v14 
who is a pledge of our inheritance, to the redemption of God's own possession, to the praise of his glory. 

###### v15 
For this cause I also, having heard of the faith in the Lord Jesus which is among you, and the love which you have toward all the saints, 

###### v16 
don't cease to give thanks for you, making mention of you in my prayers, 

###### v17 
that the God of our Lord Jesus Christ, the Father of glory, may give to you a spirit of wisdom and revelation in the knowledge of him, 

###### v18 
having the eyes of your hearts enlightened, that you may know what is the hope of his calling, and what are the riches of the glory of his inheritance in the saints, 

###### v19 
and what is the exceeding greatness of his power toward us who believe, according to that working of the strength of his might 

###### v20 
which he worked in Christ, when he raised him from the dead and made him to sit at his right hand in the heavenly places, 

###### v21 
far above all rule, authority, power, dominion, and every name that is named, not only in this age, but also in that which is to come. 

###### v22 
He put all things in subjection under his feet, and gave him to be head over all things for the assembly, 

###### v23 
which is his body, the fullness of him who fills all in all.

***
[[Ephesians]] | [[Ephes-02|Ephesians 02 →]]
