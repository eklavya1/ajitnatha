# Ephesians 4

[[Ephes-03|← Ephesians 03]] | [[Ephesians]] | [[Ephes-05|Ephesians 05 →]]
***



###### v1 
I therefore, the prisoner in the Lord, beg you to walk worthily of the calling with which you were called, 

###### v2 
with all lowliness and humility, with patience, bearing with one another in love, 

###### v3 
being eager to keep the unity of the Spirit in the bond of peace. 

###### v4 
There is one body and one Spirit, even as you also were called in one hope of your calling, 

###### v5 
one Lord, one faith, one baptism, 

###### v6 
one God and Father of all, who is over all and through all, and in us all. 

###### v7 
But to each one of us, the grace was given according to the measure of the gift of Christ. 

###### v8 
Therefore he says, "When he ascended on high, he led captivity captive, and gave gifts to people." 

###### v9 
Now this, "He ascended", what is it but that he also first descended into the lower parts of the earth? 

###### v10 
He who descended is the one who also ascended far above all the heavens, that he might fill all things. 

###### v11 
He gave some to be apostles; and some, prophets; and some, evangelists; and some, shepherds and teachers; 

###### v12 
for the perfecting of the saints, to the work of serving, to the building up of the body of Christ, 

###### v13 
until we all attain to the unity of the faith and of the knowledge of the Son of God, to a full grown man, to the measure of the stature of the fullness of Christ, 

###### v14 
that we may no longer be children, tossed back and forth and carried about with every wind of doctrine, by the trickery of men, in craftiness, after the wiles of error; 

###### v15 
but speaking truth in love, we may grow up in all things into him who is the head, Christ, 

###### v16 
from whom all the body, being fitted and knit together through that which every joint supplies, according to the working in measure of each individual part, makes the body increase to the building up of itself in love. 

###### v17 
This I say therefore, and testify in the Lord, that you no longer walk as the rest of the Gentiles also walk, in the futility of their mind, 

###### v18 
being darkened in their understanding, alienated from the life of God because of the ignorance that is in them, because of the hardening of their hearts. 

###### v19 
They, having become callous, gave themselves up to lust, to work all uncleanness with greediness. 

###### v20 
But you didn't learn Christ that way, 

###### v21 
if indeed you heard him, and were taught in him, even as truth is in Jesus: 

###### v22 
that you put away, as concerning your former way of life, the old man that grows corrupt after the lusts of deceit, 

###### v23 
and that you be renewed in the spirit of your mind, 

###### v24 
and put on the new man, who in the likeness of God has been created in righteousness and holiness of truth. 

###### v25 
Therefore putting away falsehood, speak truth each one with his neighbor. For we are members of one another. 

###### v26 
"Be angry, and don't sin." Don't let the sun go down on your wrath, 

###### v27 
and don't give place to the devil. 

###### v28 
Let him who stole steal no more; but rather let him labor, producing with his hands something that is good, that he may have something to give to him who has need. 

###### v29 
Let no corrupt speech proceed out of your mouth, but only what is good for building others up as the need may be, that it may give grace to those who hear. 

###### v30 
Don't grieve the Holy Spirit of God, in whom you were sealed for the day of redemption. 

###### v31 
Let all bitterness, wrath, anger, outcry, and slander be put away from you, with all malice. 

###### v32 
And be kind to one another, tender hearted, forgiving each other, just as God also in Christ forgave you.

***
[[Ephes-03|← Ephesians 03]] | [[Ephesians]] | [[Ephes-05|Ephesians 05 →]]
