# Ephesians 3

[[Ephes-02|← Ephesians 02]] | [[Ephesians]] | [[Ephes-04|Ephesians 04 →]]
***



###### v1 
For this cause I, Paul, am the prisoner of Christ Jesus on behalf of you Gentiles, 

###### v2 
if it is so that you have heard of the administration of that grace of God which was given me toward you, 

###### v3 
how that by revelation the mystery was made known to me, as I wrote before in few words, 

###### v4 
by which, when you read, you can perceive my understanding in the mystery of Christ, 

###### v5 
which in other generations was not made known to the children of men, as it has now been revealed to his holy apostles and prophets in the Spirit, 

###### v6 
that the Gentiles are fellow heirs and fellow members of the body, and fellow partakers of his promise in Christ Jesus through the Good News, 

###### v7 
of which I was made a servant according to the gift of that grace of God which was given me according to the working of his power. 

###### v8 
To me, the very least of all saints, was this grace given, to preach to the Gentiles the unsearchable riches of Christ, 

###### v9 
and to make all men see what is the administration of the mystery which for ages has been hidden in God, who created all things through Jesus Christ, 

###### v10 
to the intent that now through the assembly the manifold wisdom of God might be made known to the principalities and the powers in the heavenly places, 

###### v11 
according to the eternal purpose which he accomplished in Christ Jesus our Lord. 

###### v12 
In him we have boldness and access in confidence through our faith in him. 

###### v13 
Therefore I ask that you may not lose heart at my troubles for you, which are your glory. 

###### v14 
For this cause, I bow my knees to the Father of our Lord Jesus Christ, 

###### v15 
from whom every family in heaven and on earth is named, 

###### v16 
that he would grant you, according to the riches of his glory, that you may be strengthened with power through his Spirit in the inner person, 

###### v17 
that Christ may dwell in your hearts through faith, to the end that you, being rooted and grounded in love, 

###### v18 
may be strengthened to comprehend with all the saints what is the width and length and height and depth, 

###### v19 
and to know Christ's love which surpasses knowledge, that you may be filled with all the fullness of God. 

###### v20 
Now to him who is able to do exceedingly abundantly above all that we ask or think, according to the power that works in us, 

###### v21 
to him be the glory in the assembly and in Christ Jesus to all generations forever and ever. Amen.

***
[[Ephes-02|← Ephesians 02]] | [[Ephesians]] | [[Ephes-04|Ephesians 04 →]]
