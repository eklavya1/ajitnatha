# Genesis 40

[[Gen-39|← Genesis 39]] | [[Genesis]] | [[Gen-41|Genesis 41 →]]
***



###### v1 
After these things, the butler of the king of Egypt and his baker offended their lord, the king of Egypt. 

###### v2 
Pharaoh was angry with his two officers, the chief cup bearer and the chief baker. 

###### v3 
He put them in custody in the house of the captain of the guard, into the prison, the place where Joseph was bound. 

###### v4 
The captain of the guard assigned them to Joseph, and he took care of them. They stayed in prison many days. 

###### v5 
They both dreamed a dream, each man his dream, in one night, each man according to the interpretation of his dream, the cup bearer and the baker of the king of Egypt, who were bound in the prison. 

###### v6 
Joseph came in to them in the morning, and saw them, and saw that they were sad. 

###### v7 
He asked Pharaoh's officers who were with him in custody in his master's house, saying, "Why do you look so sad today?" 

###### v8 
They said to him, "We have dreamed a dream, and there is no one who can interpret it." Joseph said to them, "Don't interpretations belong to God? Please tell it to me." 

###### v9 
The chief cup bearer told his dream to Joseph, and said to him, "In my dream, behold, a vine was in front of me, 

###### v10 
and in the vine were three branches. It was as though it budded, it blossomed, and its clusters produced ripe grapes. 

###### v11 
Pharaoh's cup was in my hand; and I took the grapes, and pressed them into Pharaoh's cup, and I gave the cup into Pharaoh's hand." 

###### v12 
Joseph said to him, "This is its interpretation: the three branches are three days. 

###### v13 
Within three more days, Pharaoh will lift up your head, and restore you to your office. You will give Pharaoh's cup into his hand, the way you did when you were his cup bearer. 

###### v14 
But remember me when it is well with you. Please show kindness to me, and make mention of me to Pharaoh, and bring me out of this house. 

###### v15 
For indeed, I was stolen away out of the land of the Hebrews, and here also I have done nothing that they should put me into the dungeon." 

###### v16 
When the chief baker saw that the interpretation was good, he said to Joseph, "I also was in my dream, and behold, three baskets of white bread were on my head. 

###### v17 
In the uppermost basket there were all kinds of baked food for Pharaoh, and the birds ate them out of the basket on my head." 

###### v18 
Joseph answered, "This is its interpretation. The three baskets are three days. 

###### v19 
Within three more days, Pharaoh will lift up your head from off you, and will hang you on a tree; and the birds will eat your flesh from off you." 

###### v20 
On the third day, which was Pharaoh's birthday, he made a feast for all his servants, and he lifted up the head of the chief cup bearer and the head of the chief baker among his servants. 

###### v21 
He restored the chief cup bearer to his position again, and he gave the cup into Pharaoh's hand; 

###### v22 
but he hanged the chief baker, as Joseph had interpreted to them. 

###### v23 
Yet the chief cup bearer didn't remember Joseph, but forgot him.

***
[[Gen-39|← Genesis 39]] | [[Genesis]] | [[Gen-41|Genesis 41 →]]
