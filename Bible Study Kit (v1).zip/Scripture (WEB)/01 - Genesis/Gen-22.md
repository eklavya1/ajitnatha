# Genesis 22

[[Gen-21|← Genesis 21]] | [[Genesis]] | [[Gen-23|Genesis 23 →]]
***



###### v1 
After these things, God tested Abraham, and said to him, "Abraham!" He said, "Here I am." 

###### v2 
He said, "Now take your son, your only son, Isaac, whom you love, and go into the land of Moriah. Offer him there as a burnt offering on one of the mountains which I will tell you of." 

###### v3 
Abraham rose early in the morning, and saddled his donkey; and took two of his young men with him, and Isaac his son. He split the wood for the burnt offering, and rose up, and went to the place of which God had told him. 

###### v4 
On the third day Abraham lifted up his eyes, and saw the place far off. 

###### v5 
Abraham said to his young men, "Stay here with the donkey. The boy and I will go over there. We will worship, and come back to you." 

###### v6 
Abraham took the wood of the burnt offering and laid it on Isaac his son. He took in his hand the fire and the knife. They both went together. 

###### v7 
Isaac spoke to Abraham his father, and said, "My father?" He said, "Here I am, my son." He said, "Here is the fire and the wood, but where is the lamb for a burnt offering?" 

###### v8 
Abraham said, "God will provide himself the lamb for a burnt offering, my son." So they both went together. 

###### v9 
They came to the place which God had told him of. Abraham built the altar there, and laid the wood in order, bound Isaac his son, and laid him on the altar, on the wood. 

###### v10 
Abraham stretched out his hand, and took the knife to kill his son. 

###### v11 
Yahweh's angel called to him out of the sky, and said, "Abraham, Abraham!" He said, "Here I am." 

###### v12 
He said, "Don't lay your hand on the boy or do anything to him. For now I know that you fear God, since you have not withheld your son, your only son, from me." 

###### v13 
Abraham lifted up his eyes, and looked, and saw that behind him was a ram caught in the thicket by his horns. Abraham went and took the ram, and offered him up for a burnt offering instead of his son. 

###### v14 
Abraham called the name of that place "Yahweh Will Provide". As it is said to this day, "On Yahweh's mountain, it will be provided." 

###### v15 
Yahweh's angel called to Abraham a second time out of the sky, 

###### v16 
and said, "'I have sworn by myself,' says Yahweh, 'because you have done this thing, and have not withheld your son, your only son, 

###### v17 
that I will bless you greatly, and I will multiply your offspring greatly like the stars of the heavens, and like the sand which is on the seashore. Your offspring will possess the gate of his enemies. 

###### v18 
All the nations of the earth will be blessed by your offspring, because you have obeyed my voice.'" 

###### v19 
So Abraham returned to his young men, and they rose up and went together to Beersheba. Abraham lived at Beersheba. 

###### v20 
After these things, Abraham was told, "Behold, Milcah, she also has borne children to your brother Nahor: 

###### v21 
Uz his firstborn, Buz his brother, Kemuel the father of Aram, 

###### v22 
Chesed, Hazo, Pildash, Jidlaph, and Bethuel." 

###### v23 
Bethuel became the father of Rebekah. These eight Milcah bore to Nahor, Abraham's brother. 

###### v24 
His concubine, whose name was Reumah, also bore Tebah, Gaham, Tahash, and Maacah.

***
[[Gen-21|← Genesis 21]] | [[Genesis]] | [[Gen-23|Genesis 23 →]]
