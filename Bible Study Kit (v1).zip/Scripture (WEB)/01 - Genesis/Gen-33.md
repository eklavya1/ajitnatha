# Genesis 33

[[Gen-32|← Genesis 32]] | [[Genesis]] | [[Gen-34|Genesis 34 →]]
***



###### v1 
Jacob lifted up his eyes, and looked, and, behold, Esau was coming, and with him four hundred men. He divided the children between Leah, Rachel, and the two servants. 

###### v2 
He put the servants and their children in front, Leah and her children after, and Rachel and Joseph at the rear. 

###### v3 
He himself passed over in front of them, and bowed himself to the ground seven times, until he came near to his brother. 

###### v4 
Esau ran to meet him, embraced him, fell on his neck, kissed him, and they wept. 

###### v5 
He lifted up his eyes, and saw the women and the children; and said, "Who are these with you?" He said, "The children whom God has graciously given your servant." 

###### v6 
Then the servants came near with their children, and they bowed themselves. 

###### v7 
Leah also and her children came near, and bowed themselves. After them, Joseph came near with Rachel, and they bowed themselves. 

###### v8 
Esau said, "What do you mean by all this company which I met?" Jacob said, "To find favor in the sight of my lord." 

###### v9 
Esau said, "I have enough, my brother; let that which you have be yours." 

###### v10 
Jacob said, "Please, no, if I have now found favor in your sight, then receive my present at my hand, because I have seen your face, as one sees the face of God, and you were pleased with me. 

###### v11 
Please take the gift that I brought to you, because God has dealt graciously with me, and because I have enough." He urged him, and he took it. 

###### v12 
Esau said, "Let's take our journey, and let's go, and I will go before you." 

###### v13 
Jacob said to him, "My lord knows that the children are tender, and that the flocks and herds with me have their young, and if they overdrive them one day, all the flocks will die. 

###### v14 
Please let my lord pass over before his servant, and I will lead on gently, according to the pace of the livestock that are before me and according to the pace of the children, until I come to my lord to Seir." 

###### v15 
Esau said, "Let me now leave with you some of the people who are with me." He said, "Why? Let me find favor in the sight of my lord." 

###### v16 
So Esau returned that day on his way to Seir. 

###### v17 
Jacob traveled to Succoth, built himself a house, and made shelters for his livestock. Therefore the name of the place is called Succoth. 

###### v18 
Jacob came in peace to the city of Shechem, which is in the land of Canaan, when he came from Paddan Aram; and encamped before the city. 

###### v19 
He bought the parcel of ground where he had spread his tent, at the hand of the children of Hamor, Shechem's father, for one hundred pieces of money. 

###### v20 
He erected an altar there, and called it El Elohe Israel.

***
[[Gen-32|← Genesis 32]] | [[Genesis]] | [[Gen-34|Genesis 34 →]]
