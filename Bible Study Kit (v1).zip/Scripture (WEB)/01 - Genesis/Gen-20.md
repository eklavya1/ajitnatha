# Genesis 20

[[Gen-19|← Genesis 19]] | [[Genesis]] | [[Gen-21|Genesis 21 →]]
***



###### v1 
Abraham traveled from there toward the land of the South, and lived between Kadesh and Shur. He lived as a foreigner in Gerar. 

###### v2 
Abraham said about Sarah his wife, "She is my sister." Abimelech king of Gerar sent, and took Sarah. 

###### v3 
But God came to Abimelech in a dream of the night, and said to him, "Behold, you are a dead man, because of the woman whom you have taken; for she is a man's wife." 

###### v4 
Now Abimelech had not come near her. He said, "Lord, will you kill even a righteous nation? 

###### v5 
Didn't he tell me, 'She is my sister'? She, even she herself, said, 'He is my brother.' I have done this in the integrity of my heart and the innocence of my hands." 

###### v6 
God said to him in the dream, "Yes, I know that in the integrity of your heart you have done this, and I also withheld you from sinning against me. Therefore I didn't allow you to touch her. 

###### v7 
Now therefore, restore the man's wife. For he is a prophet, and he will pray for you, and you will live. If you don't restore her, know for sure that you will die, you, and all who are yours." 

###### v8 
Abimelech rose early in the morning, and called all his servants, and told all these things in their ear. The men were very scared. 

###### v9 
Then Abimelech called Abraham, and said to him, "What have you done to us? How have I sinned against you, that you have brought on me and on my kingdom a great sin? You have done deeds to me that ought not to be done!" 

###### v10 
Abimelech said to Abraham, "What did you see, that you have done this thing?" 

###### v11 
Abraham said, "Because I thought, 'Surely the fear of God is not in this place. They will kill me for my wife's sake.' 

###### v12 
Besides, she is indeed my sister, the daughter of my father, but not the daughter of my mother; and she became my wife. 

###### v13 
When God caused me to wander from my father's house, I said to her, 'This is your kindness which you shall show to me. Everywhere that we go, say of me, "He is my brother."'" 

###### v14 
Abimelech took sheep and cattle, male servants and female servants, and gave them to Abraham, and restored Sarah, his wife, to him. 

###### v15 
Abimelech said, "Behold, my land is before you. Dwell where it pleases you." 

###### v16 
To Sarah he said, "Behold, I have given your brother a thousand pieces of silver. Behold, it is for you a covering of the eyes to all that are with you. In front of all you are vindicated." 

###### v17 
Abraham prayed to God. So God healed Abimelech, his wife, and his female servants, and they bore children. 

###### v18 
For Yahweh had closed up tight all the wombs of the house of Abimelech, because of Sarah, Abraham's wife.

***
[[Gen-19|← Genesis 19]] | [[Genesis]] | [[Gen-21|Genesis 21 →]]
