# Genesis 27

[[Gen-26|← Genesis 26]] | [[Genesis]] | [[Gen-28|Genesis 28 →]]
***



###### v1 
When Isaac was old, and his eyes were dim, so that he could not see, he called Esau his elder son, and said to him, "My son?" He said to him, "Here I am." 

###### v2 
He said, "See now, I am old. I don't know the day of my death. 

###### v3 
Now therefore, please take your weapons, your quiver and your bow, and go out to the field, and get me venison. 

###### v4 
Make me savory food, such as I love, and bring it to me, that I may eat, and that my soul may bless you before I die." 

###### v5 
Rebekah heard when Isaac spoke to Esau his son. Esau went to the field to hunt for venison, and to bring it. 

###### v6 
Rebekah spoke to Jacob her son, saying, "Behold, I heard your father speak to Esau your brother, saying, 

###### v7 
'Bring me venison, and make me savory food, that I may eat, and bless you before Yahweh before my death.' 

###### v8 
Now therefore, my son, obey my voice according to that which I command you. 

###### v9 
Go now to the flock and get me two good young goats from there. I will make them savory food for your father, such as he loves. 

###### v10 
You shall bring it to your father, that he may eat, so that he may bless you before his death." 

###### v11 
Jacob said to Rebekah his mother, "Behold, Esau my brother is a hairy man, and I am a smooth man. 

###### v12 
What if my father touches me? I will seem to him as a deceiver, and I would bring a curse on myself, and not a blessing." 

###### v13 
His mother said to him, "Let your curse be on me, my son. Only obey my voice, and go get them for me." 

###### v14 
He went, and got them, and brought them to his mother. His mother made savory food, such as his father loved. 

###### v15 
Rebekah took the good clothes of Esau, her elder son, which were with her in the house, and put them on Jacob, her younger son. 

###### v16 
She put the skins of the young goats on his hands, and on the smooth of his neck. 

###### v17 
She gave the savory food and the bread, which she had prepared, into the hand of her son Jacob. 

###### v18 
He came to his father, and said, "My father?" He said, "Here I am. Who are you, my son?" 

###### v19 
Jacob said to his father, "I am Esau your firstborn. I have done what you asked me to do. Please arise, sit and eat of my venison, that your soul may bless me." 

###### v20 
Isaac said to his son, "How is it that you have found it so quickly, my son?" He said, "Because Yahweh your God gave me success." 

###### v21 
Isaac said to Jacob, "Please come near, that I may feel you, my son, whether you are really my son Esau or not." 

###### v22 
Jacob went near to Isaac his father. He felt him, and said, "The voice is Jacob's voice, but the hands are the hands of Esau." 

###### v23 
He didn't recognize him, because his hands were hairy, like his brother Esau's hands. So he blessed him. 

###### v24 
He said, "Are you really my son Esau?" He said, "I am." 

###### v25 
He said, "Bring it near to me, and I will eat of my son's venison, that my soul may bless you." He brought it near to him, and he ate. He brought him wine, and he drank. 

###### v26 
His father Isaac said to him, "Come near now, and kiss me, my son." 

###### v27 
He came near, and kissed him. He smelled the smell of his clothing, and blessed him, and said, "Behold, the smell of my son is as the smell of a field which Yahweh has blessed. 

###### v28 
God give you of the dew of the sky, of the fatness of the earth, and plenty of grain and new wine. 

###### v29 
Let peoples serve you, and nations bow down to you. Be lord over your brothers. Let your mother's sons bow down to you. Cursed be everyone who curses you. Blessed be everyone who blesses you." 

###### v30 
As soon as Isaac had finished blessing Jacob, and Jacob had just gone out from the presence of Isaac his father, Esau his brother came in from his hunting. 

###### v31 
He also made savory food, and brought it to his father. He said to his father, "Let my father arise, and eat of his son's venison, that your soul may bless me." 

###### v32 
Isaac his father said to him, "Who are you?" He said, "I am your son, your firstborn, Esau." 

###### v33 
Isaac trembled violently, and said, "Who, then, is he who has taken venison, and brought it to me, and I have eaten of all before you came, and have blessed him? Yes, he will be blessed." 

###### v34 
When Esau heard the words of his father, he cried with an exceedingly great and bitter cry, and said to his father, "Bless me, even me also, my father." 

###### v35 
He said, "Your brother came with deceit, and has taken away your blessing." 

###### v36 
He said, "Isn't he rightly named Jacob? For he has supplanted me these two times. He took away my birthright. See, now he has taken away my blessing." He said, "Haven't you reserved a blessing for me?" 

###### v37 
Isaac answered Esau, "Behold, I have made him your lord, and all his brothers I have given to him for servants. I have sustained him with grain and new wine. What then will I do for you, my son?" 

###### v38 
Esau said to his father, "Do you have just one blessing, my father? Bless me, even me also, my father." Esau lifted up his voice, and wept. 

###### v39 
Isaac his father answered him, "Behold, your dwelling will be of the fatness of the earth, and of the dew of the sky from above. 

###### v40 
You will live by your sword, and you will serve your brother. It will happen, when you will break loose, that you will shake his yoke from off your neck." 

###### v41 
Esau hated Jacob because of the blessing with which his father blessed him. Esau said in his heart, "The days of mourning for my father are at hand. Then I will kill my brother Jacob." 

###### v42 
The words of Esau, her elder son, were told to Rebekah. She sent and called Jacob, her younger son, and said to him, "Behold, your brother Esau comforts himself about you by planning to kill you. 

###### v43 
Now therefore, my son, obey my voice. Arise, flee to Laban, my brother, in Haran. 

###### v44 
Stay with him a few days, until your brother's fury turns away-- 

###### v45 
until your brother's anger turns away from you, and he forgets what you have done to him. Then I will send, and get you from there. Why should I be bereaved of you both in one day?" 

###### v46 
Rebekah said to Isaac, "I am weary of my life because of the daughters of Heth. If Jacob takes a wife of the daughters of Heth, such as these, of the daughters of the land, what good will my life do me?"

***
[[Gen-26|← Genesis 26]] | [[Genesis]] | [[Gen-28|Genesis 28 →]]
