# Genesis 35

[[Gen-34|← Genesis 34]] | [[Genesis]] | [[Gen-36|Genesis 36 →]]
***



###### v1 
God said to Jacob, "Arise, go up to Bethel, and live there. Make there an altar to God, who appeared to you when you fled from the face of Esau your brother." 

###### v2 
Then Jacob said to his household, and to all who were with him, "Put away the foreign gods that are among you, purify yourselves, change your garments. 

###### v3 
Let's arise, and go up to Bethel. I will make there an altar to God, who answered me in the day of my distress, and was with me on the way which I went." 

###### v4 
They gave to Jacob all the foreign gods which were in their hands, and the rings which were in their ears; and Jacob hid them under the oak which was by Shechem. 

###### v5 
They traveled, and a terror of God was on the cities that were around them, and they didn't pursue the sons of Jacob. 

###### v6 
So Jacob came to Luz (that is, Bethel), which is in the land of Canaan, he and all the people who were with him. 

###### v7 
He built an altar there, and called the place El Beth El; because there God was revealed to him, when he fled from the face of his brother. 

###### v8 
Deborah, Rebekah's nurse, died, and she was buried below Bethel under the oak; and its name was called Allon Bacuth. 

###### v9 
God appeared to Jacob again, when he came from Paddan Aram, and blessed him. 

###### v10 
God said to him, "Your name is Jacob. Your name shall not be Jacob any more, but your name will be Israel." He named him Israel. 

###### v11 
God said to him, "I am God Almighty. Be fruitful and multiply. A nation and a company of nations will be from you, and kings will come out of your body. 

###### v12 
The land which I gave to Abraham and Isaac, I will give it to you, and to your offspring after you I will give the land." 

###### v13 
God went up from him in the place where he spoke with him. 

###### v14 
Jacob set up a pillar in the place where he spoke with him, a pillar of stone. He poured out a drink offering on it, and poured oil on it. 

###### v15 
Jacob called the name of the place where God spoke with him "Bethel". 

###### v16 
They traveled from Bethel. There was still some distance to come to Ephrath, and Rachel travailed. She had hard labor. 

###### v17 
When she was in hard labor, the midwife said to her, "Don't be afraid, for now you will have another son." 

###### v18 
As her soul was departing (for she died), she named him Benoni, but his father named him Benjamin. 

###### v19 
Rachel died, and was buried on the way to Ephrath (also called Bethlehem). 

###### v20 
Jacob set up a pillar on her grave. The same is the Pillar of Rachel's grave to this day. 

###### v21 
Israel traveled, and spread his tent beyond the tower of Eder. 

###### v22 
While Israel lived in that land, Reuben went and lay with Bilhah, his father's concubine, and Israel heard of it. Now the sons of Jacob were twelve. 

###### v23 
The sons of Leah: Reuben (Jacob's firstborn), Simeon, Levi, Judah, Issachar, and Zebulun. 

###### v24 
The sons of Rachel: Joseph and Benjamin. 

###### v25 
The sons of Bilhah (Rachel's servant): Dan and Naphtali. 

###### v26 
The sons of Zilpah (Leah's servant): Gad and Asher. These are the sons of Jacob, who were born to him in Paddan Aram. 

###### v27 
Jacob came to Isaac his father, to Mamre, to Kiriath Arba (which is Hebron), where Abraham and Isaac lived as foreigners. 

###### v28 
The days of Isaac were one hundred eighty years. 

###### v29 
Isaac gave up the spirit and died, and was gathered to his people, old and full of days. Esau and Jacob, his sons, buried him.

***
[[Gen-34|← Genesis 34]] | [[Genesis]] | [[Gen-36|Genesis 36 →]]
