# Genesis 43

[[Gen-42|← Genesis 42]] | [[Genesis]] | [[Gen-44|Genesis 44 →]]
***



###### v1 
The famine was severe in the land. 

###### v2 
When they had eaten up the grain which they had brought out of Egypt, their father said to them, "Go again, buy us a little more food." 

###### v3 
Judah spoke to him, saying, "The man solemnly warned us, saying, 'You shall not see my face, unless your brother is with you.' 

###### v4 
If you'll send our brother with us, we'll go down and buy you food; 

###### v5 
but if you don't send him, we won't go down, for the man said to us, 'You shall not see my face, unless your brother is with you.'" 

###### v6 
Israel said, "Why did you treat me so badly, telling the man that you had another brother?" 

###### v7 
They said, "The man asked directly concerning ourselves, and concerning our relatives, saying, 'Is your father still alive? Have you another brother?' We just answered his questions. Is there any way we could know that he would say, 'Bring your brother down?'" 

###### v8 
Judah said to Israel, his father, "Send the boy with me, and we'll get up and go, so that we may live, and not die, both we, and you, and also our little ones. 

###### v9 
I'll be collateral for him. From my hand will you require him. If I don't bring him to you, and set him before you, then let me bear the blame forever; 

###### v10 
for if we hadn't delayed, surely we would have returned a second time by now." 

###### v11 
Their father, Israel, said to them, "If it must be so, then do this: Take from the choice fruits of the land in your bags, and carry down a present for the man, a little balm, a little honey, spices and myrrh, nuts, and almonds; 

###### v12 
and take double money in your hand, and take back the money that was returned in the mouth of your sacks. Perhaps it was an oversight. 

###### v13 
Take your brother also, get up, and return to the man. 

###### v14 
May God Almighty give you mercy before the man, that he may release to you your other brother and Benjamin. If I am bereaved of my children, I am bereaved." 

###### v15 
The men took that present, and they took double money in their hand, and Benjamin; and got up, went down to Egypt, and stood before Joseph. 

###### v16 
When Joseph saw Benjamin with them, he said to the steward of his house, "Bring the men into the house, and butcher an animal, and prepare; for the men will dine with me at noon." 

###### v17 
The man did as Joseph commanded, and the man brought the men to Joseph's house. 

###### v18 
The men were afraid, because they were brought to Joseph's house; and they said, "Because of the money that was returned in our sacks the first time, we're brought in; that he may seek occasion against us, attack us, and seize us as slaves, along with our donkeys." 

###### v19 
They came near to the steward of Joseph's house, and they spoke to him at the door of the house, 

###### v20 
and said, "Oh, my lord, we indeed came down the first time to buy food. 

###### v21 
When we came to the lodging place, we opened our sacks, and behold, each man's money was in the mouth of his sack, our money in full weight. We have brought it back in our hand. 

###### v22 
We have brought down other money in our hand to buy food. We don't know who put our money in our sacks." 

###### v23 
He said, "Peace be to you. Don't be afraid. Your God, and the God of your father, has given you treasure in your sacks. I received your money." He brought Simeon out to them. 

###### v24 
The man brought the men into Joseph's house, and gave them water, and they washed their feet. He gave their donkeys fodder. 

###### v25 
They prepared the present for Joseph's coming at noon, for they heard that they should eat bread there. 

###### v26 
When Joseph came home, they brought him the present which was in their hand into the house, and bowed themselves down to the earth before him. 

###### v27 
He asked them of their welfare, and said, "Is your father well, the old man of whom you spoke? Is he yet alive?" 

###### v28 
They said, "Your servant, our father, is well. He is still alive." They bowed down humbly. 

###### v29 
He lifted up his eyes, and saw Benjamin, his brother, his mother's son, and said, "Is this your youngest brother, of whom you spoke to me?" He said, "God be gracious to you, my son." 

###### v30 
Joseph hurried, for his heart yearned over his brother; and he sought a place to weep. He entered into his room, and wept there. 

###### v31 
He washed his face, and came out. He controlled himself, and said, "Serve the meal." 

###### v32 
They served him by himself, and them by themselves, and the Egyptians who ate with him by themselves, because the Egyptians don't eat with the Hebrews, for that is an abomination to the Egyptians. 

###### v33 
They sat before him, the firstborn according to his birthright, and the youngest according to his youth, and the men marveled with one another. 

###### v34 
He sent portions to them from before him, but Benjamin's portion was five times as much as any of theirs. They drank, and were merry with him.

***
[[Gen-42|← Genesis 42]] | [[Genesis]] | [[Gen-44|Genesis 44 →]]
