# Genesis 25

[[Gen-24|← Genesis 24]] | [[Genesis]] | [[Gen-26|Genesis 26 →]]
***



###### v1 
Abraham took another wife, and her name was Keturah. 

###### v2 
She bore him Zimran, Jokshan, Medan, Midian, Ishbak, and Shuah. 

###### v3 
Jokshan became the father of Sheba, and Dedan. The sons of Dedan were Asshurim, Letushim, and Leummim. 

###### v4 
The sons of Midian were Ephah, Epher, Hanoch, Abida, and Eldaah. All these were the children of Keturah. 

###### v5 
Abraham gave all that he had to Isaac, 

###### v6 
but Abraham gave gifts to the sons of Abraham's concubines. While he still lived, he sent them away from Isaac his son, eastward, to the east country. 

###### v7 
These are the days of the years of Abraham's life which he lived: one hundred seventy-five years. 

###### v8 
Abraham gave up his spirit, and died at a good old age, an old man, and full of years, and was gathered to his people. 

###### v9 
Isaac and Ishmael, his sons, buried him in the cave of Machpelah, in the field of Ephron, the son of Zohar the Hittite, which is near Mamre, 

###### v10 
the field which Abraham purchased from the children of Heth. Abraham was buried there with Sarah, his wife. 

###### v11 
After the death of Abraham, God blessed Isaac, his son. Isaac lived by Beer Lahai Roi. 

###### v12 
Now this is the history of the generations of Ishmael, Abraham's son, whom Hagar the Egyptian, Sarah's servant, bore to Abraham. 

###### v13 
These are the names of the sons of Ishmael, by their names, according to the order of their birth: the firstborn of Ishmael, Nebaioth, then Kedar, Adbeel, Mibsam, 

###### v14 
Mishma, Dumah, Massa, 

###### v15 
Hadad, Tema, Jetur, Naphish, and Kedemah. 

###### v16 
These are the sons of Ishmael, and these are their names, by their villages, and by their encampments: twelve princes, according to their nations. 

###### v17 
These are the years of the life of Ishmael: one hundred thirty-seven years. He gave up his spirit and died, and was gathered to his people. 

###### v18 
They lived from Havilah to Shur that is before Egypt, as you go toward Assyria. He lived opposite all his relatives. 

###### v19 
This is the history of the generations of Isaac, Abraham's son. Abraham became the father of Isaac. 

###### v20 
Isaac was forty years old when he took Rebekah, the daughter of Bethuel the Syrian of Paddan Aram, the sister of Laban the Syrian, to be his wife. 

###### v21 
Isaac entreated Yahweh for his wife, because she was barren. Yahweh was entreated by him, and Rebekah his wife conceived. 

###### v22 
The children struggled together within her. She said, "If it is like this, why do I live?" She went to inquire of Yahweh. 

###### v23 
Yahweh said to her, "Two nations are in your womb. Two peoples will be separated from your body. The one people will be stronger than the other people. The elder will serve the younger." 

###### v24 
When her days to be delivered were fulfilled, behold, there were twins in her womb. 

###### v25 
The first came out red all over, like a hairy garment. They named him Esau. 

###### v26 
After that, his brother came out, and his hand had hold on Esau's heel. He was named Jacob. Isaac was sixty years old when she bore them. 

###### v27 
The boys grew. Esau was a skillful hunter, a man of the field. Jacob was a quiet man, living in tents. 

###### v28 
Now Isaac loved Esau, because he ate his venison. Rebekah loved Jacob. 

###### v29 
Jacob boiled stew. Esau came in from the field, and he was famished. 

###### v30 
Esau said to Jacob, "Please feed me with some of that red stew, for I am famished." Therefore his name was called Edom. 

###### v31 
Jacob said, "First, sell me your birthright." 

###### v32 
Esau said, "Behold, I am about to die. What good is the birthright to me?" 

###### v33 
Jacob said, "Swear to me first." He swore to him. He sold his birthright to Jacob. 

###### v34 
Jacob gave Esau bread and lentil stew. He ate and drank, rose up, and went his way. So Esau despised his birthright.

***
[[Gen-24|← Genesis 24]] | [[Genesis]] | [[Gen-26|Genesis 26 →]]
