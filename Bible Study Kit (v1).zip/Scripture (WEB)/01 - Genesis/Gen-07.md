# Genesis 7

[[Gen-06|← Genesis 06]] | [[Genesis]] | [[Gen-08|Genesis 08 →]]
***



###### v1 
Yahweh said to Noah, "Come with all of your household into the ship, for I have seen your righteousness before me in this generation. 

###### v2 
You shall take seven pairs of every clean animal with you, the male and his female. Of the animals that are not clean, take two, the male and his female. 

###### v3 
Also of the birds of the sky, seven and seven, male and female, to keep seed alive on the surface of all the earth. 

###### v4 
In seven days, I will cause it to rain on the earth for forty days and forty nights. I will destroy every living thing that I have made from the surface of the ground." 

###### v5 
Noah did everything that Yahweh commanded him. 

###### v6 
Noah was six hundred years old when the flood of waters came on the earth. 

###### v7 
Noah went into the ship with his sons, his wife, and his sons' wives, because of the floodwaters. 

###### v8 
Clean animals, unclean animals, birds, and everything that creeps on the ground 

###### v9 
went by pairs to Noah into the ship, male and female, as God commanded Noah. 

###### v10 
After the seven days, the floodwaters came on the earth. 

###### v11 
In the six hundredth year of Noah's life, in the second month, on the seventeenth day of the month, on that day all the fountains of the great deep burst open, and the sky's windows opened. 

###### v12 
It rained on the earth forty days and forty nights. 

###### v13 
In the same day Noah, and Shem, Ham, and Japheth--the sons of Noah--and Noah's wife and the three wives of his sons with them, entered into the ship-- 

###### v14 
they, and every animal after its kind, all the livestock after their kind, every creeping thing that creeps on the earth after its kind, and every bird after its kind, every bird of every sort. 

###### v15 
Pairs from all flesh with the breath of life in them went into the ship to Noah. 

###### v16 
Those who went in, went in male and female of all flesh, as God commanded him; then Yahweh shut him in. 

###### v17 
The flood was forty days on the earth. The waters increased, and lifted up the ship, and it was lifted up above the earth. 

###### v18 
The waters rose, and increased greatly on the earth; and the ship floated on the surface of the waters. 

###### v19 
The waters rose very high on the earth. All the high mountains that were under the whole sky were covered. 

###### v20 
The waters rose fifteen cubits higher, and the mountains were covered. 

###### v21 
All flesh died that moved on the earth, including birds, livestock, animals, every creeping thing that creeps on the earth, and every man. 

###### v22 
All on the dry land, in whose nostrils was the breath of the spirit of life, died. 

###### v23 
Every living thing was destroyed that was on the surface of the ground, including man, livestock, creeping things, and birds of the sky. They were destroyed from the earth. Only Noah was left, and those who were with him in the ship. 

###### v24 
The waters flooded the earth one hundred fifty days.

***
[[Gen-06|← Genesis 06]] | [[Genesis]] | [[Gen-08|Genesis 08 →]]
