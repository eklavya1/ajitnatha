# Genesis 38

[[Gen-37|← Genesis 37]] | [[Genesis]] | [[Gen-39|Genesis 39 →]]
***



###### v1 
At that time, Judah went down from his brothers, and visited a certain Adullamite, whose name was Hirah. 

###### v2 
There, Judah saw the daughter of a certain Canaanite man named Shua. He took her, and went in to her. 

###### v3 
She conceived, and bore a son; and he named him Er. 

###### v4 
She conceived again, and bore a son; and she named him Onan. 

###### v5 
She yet again bore a son, and named him Shelah. He was at Chezib when she bore him. 

###### v6 
Judah took a wife for Er, his firstborn, and her name was Tamar. 

###### v7 
Er, Judah's firstborn, was wicked in Yahweh's sight. So Yahweh killed him. 

###### v8 
Judah said to Onan, "Go in to your brother's wife, and perform the duty of a husband's brother to her, and raise up offspring for your brother." 

###### v9 
Onan knew that the offspring wouldn't be his; and when he went in to his brother's wife, he spilled his semen on the ground, lest he should give offspring to his brother. 

###### v10 
The thing which he did was evil in Yahweh's sight, and he killed him also. 

###### v11 
Then Judah said to Tamar, his daughter-in-law, "Remain a widow in your father's house, until Shelah, my son, is grown up;" for he said, "Lest he also die, like his brothers." Tamar went and lived in her father's house. 

###### v12 
After many days, Shua's daughter, the wife of Judah, died. Judah was comforted, and went up to his sheep shearers to Timnah, he and his friend Hirah, the Adullamite. 

###### v13 
Tamar was told, "Behold, your father-in-law is going up to Timnah to shear his sheep." 

###### v14 
She took off the garments of her widowhood, and covered herself with her veil, and wrapped herself, and sat in the gate of Enaim, which is on the way to Timnah; for she saw that Shelah was grown up, and she wasn't given to him as a wife. 

###### v15 
When Judah saw her, he thought that she was a prostitute, for she had covered her face. 

###### v16 
He turned to her by the way, and said, "Please come, let me come in to you," for he didn't know that she was his daughter-in-law. She said, "What will you give me, that you may come in to me?" 

###### v17 
He said, "I will send you a young goat from the flock." She said, "Will you give me a pledge, until you send it?" 

###### v18 
He said, "What pledge will I give you?" She said, "Your signet and your cord, and your staff that is in your hand." He gave them to her, and came in to her, and she conceived by him. 

###### v19 
She arose, and went away, and put off her veil from her, and put on the garments of her widowhood. 

###### v20 
Judah sent the young goat by the hand of his friend, the Adullamite, to receive the pledge from the woman's hand, but he didn't find her. 

###### v21 
Then he asked the men of her place, saying, "Where is the prostitute, that was at Enaim by the road?" They said, "There has been no prostitute here." 

###### v22 
He returned to Judah, and said, "I haven't found her; and also the men of the place said, 'There has been no prostitute here.'" 

###### v23 
Judah said, "Let her keep it, lest we be shamed. Behold, I sent this young goat, and you haven't found her." 

###### v24 
About three months later, Judah was told, "Tamar, your daughter-in-law, has played the prostitute. Moreover, behold, she is with child by prostitution." Judah said, "Bring her out, and let her be burned." 

###### v25 
When she was brought out, she sent to her father-in-law, saying, "I am with child by the man who owns these." She also said, "Please discern whose these are--the signet, and the cords, and the staff." 

###### v26 
Judah acknowledged them, and said, "She is more righteous than I, because I didn't give her to Shelah, my son." He knew her again no more. 

###### v27 
In the time of her travail, behold, twins were in her womb. 

###### v28 
When she travailed, one put out a hand, and the midwife took and tied a scarlet thread on his hand, saying, "This came out first." 

###### v29 
As he drew back his hand, behold, his brother came out, and she said, "Why have you made a breach for yourself?" Therefore his name was called Perez. 

###### v30 
Afterward his brother came out, who had the scarlet thread on his hand, and his name was called Zerah.

***
[[Gen-37|← Genesis 37]] | [[Genesis]] | [[Gen-39|Genesis 39 →]]
