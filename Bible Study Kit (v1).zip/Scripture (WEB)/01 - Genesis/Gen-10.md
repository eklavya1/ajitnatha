# Genesis 10

[[Gen-09|← Genesis 09]] | [[Genesis]] | [[Gen-11|Genesis 11 →]]
***



###### v1 
Now this is the history of the generations of the sons of Noah and of Shem, Ham, and Japheth. Sons were born to them after the flood. 

###### v2 
The sons of Japheth were: Gomer, Magog, Madai, Javan, Tubal, Meshech, and Tiras. 

###### v3 
The sons of Gomer were: Ashkenaz, Riphath, and Togarmah. 

###### v4 
The sons of Javan were: Elishah, Tarshish, Kittim, and Dodanim. 

###### v5 
Of these were the islands of the nations divided in their lands, everyone after his language, after their families, in their nations. 

###### v6 
The sons of Ham were: Cush, Mizraim, Put, and Canaan. 

###### v7 
The sons of Cush were: Seba, Havilah, Sabtah, Raamah, and Sabteca. The sons of Raamah were: Sheba and Dedan. 

###### v8 
Cush became the father of Nimrod. He began to be a mighty one in the earth. 

###### v9 
He was a mighty hunter before Yahweh. Therefore it is said, "like Nimrod, a mighty hunter before Yahweh". 

###### v10 
The beginning of his kingdom was Babel, Erech, Accad, and Calneh, in the land of Shinar. 

###### v11 
Out of that land he went into Assyria, and built Nineveh, Rehoboth Ir, Calah, 

###### v12 
and Resen between Nineveh and the great city Calah. 

###### v13 
Mizraim became the father of Ludim, Anamim, Lehabim, Naphtuhim, 

###### v14 
Pathrusim, Casluhim (which the Philistines descended from), and Caphtorim. 

###### v15 
Canaan became the father of Sidon (his firstborn), Heth, 

###### v16 
the Jebusites, the Amorites, the Girgashites, 

###### v17 
the Hivites, the Arkites, the Sinites, 

###### v18 
the Arvadites, the Zemarites, and the Hamathites. Afterward the families of the Canaanites were spread abroad. 

###### v19 
The border of the Canaanites was from Sidon--as you go toward Gerar--to Gaza--as you go toward Sodom, Gomorrah, Admah, and Zeboiim--to Lasha. 

###### v20 
These are the sons of Ham, after their families, according to their languages, in their lands and their nations. 

###### v21 
Children were also born to Shem (the elder brother of Japheth), the father of all the children of Eber. 

###### v22 
The sons of Shem were: Elam, Asshur, Arpachshad, Lud, and Aram. 

###### v23 
The sons of Aram were: Uz, Hul, Gether, and Mash. 

###### v24 
Arpachshad became the father of Shelah. Shelah became the father of Eber. 

###### v25 
To Eber were born two sons. The name of the one was Peleg, for in his days the earth was divided. His brother's name was Joktan. 

###### v26 
Joktan became the father of Almodad, Sheleph, Hazarmaveth, Jerah, 

###### v27 
Hadoram, Uzal, Diklah, 

###### v28 
Obal, Abimael, Sheba, 

###### v29 
Ophir, Havilah, and Jobab. All these were the sons of Joktan. 

###### v30 
Their dwelling extended from Mesha, as you go toward Sephar, the mountain of the east. 

###### v31 
These are the sons of Shem, by their families, according to their languages, lands, and nations. 

###### v32 
These are the families of the sons of Noah, by their generations, according to their nations. The nations divided from these in the earth after the flood.

***
[[Gen-09|← Genesis 09]] | [[Genesis]] | [[Gen-11|Genesis 11 →]]
