# Genesis 21

[[Gen-20|← Genesis 20]] | [[Genesis]] | [[Gen-22|Genesis 22 →]]
***



###### v1 
Yahweh visited Sarah as he had said, and Yahweh did to Sarah as he had spoken. 

###### v2 
Sarah conceived, and bore Abraham a son in his old age, at the set time of which God had spoken to him. 

###### v3 
Abraham called his son who was born to him, whom Sarah bore to him, Isaac. 

###### v4 
Abraham circumcised his son, Isaac, when he was eight days old, as God had commanded him. 

###### v5 
Abraham was one hundred years old when his son, Isaac, was born to him. 

###### v6 
Sarah said, "God has made me laugh. Everyone who hears will laugh with me." 

###### v7 
She said, "Who would have said to Abraham that Sarah would nurse children? For I have borne him a son in his old age." 

###### v8 
The child grew and was weaned. Abraham made a great feast on the day that Isaac was weaned. 

###### v9 
Sarah saw the son of Hagar the Egyptian, whom she had borne to Abraham, mocking. 

###### v10 
Therefore she said to Abraham, "Cast out this servant and her son! For the son of this servant will not be heir with my son, Isaac." 

###### v11 
The thing was very grievous in Abraham's sight on account of his son. 

###### v12 
God said to Abraham, "Don't let it be grievous in your sight because of the boy, and because of your servant. In all that Sarah says to you, listen to her voice. For your offspring will be named through Isaac. 

###### v13 
I will also make a nation of the son of the servant, because he is your child." 

###### v14 
Abraham rose up early in the morning, and took bread and a container of water, and gave it to Hagar, putting it on her shoulder; and gave her the child, and sent her away. She departed, and wandered in the wilderness of Beersheba. 

###### v15 
The water in the container was spent, and she put the child under one of the shrubs. 

###### v16 
She went and sat down opposite him, a good way off, about a bow shot away. For she said, "Don't let me see the death of the child." She sat opposite him, and lifted up her voice, and wept. 

###### v17 
God heard the voice of the boy. The angel of God called to Hagar out of the sky, and said to her, "What troubles you, Hagar? Don't be afraid. For God has heard the voice of the boy where he is. 

###### v18 
Get up, lift up the boy, and hold him with your hand. For I will make him a great nation." 

###### v19 
God opened her eyes, and she saw a well of water. She went, filled the container with water, and gave the boy a drink. 

###### v20 
God was with the boy, and he grew. He lived in the wilderness, and as he grew up, he became an archer. 

###### v21 
He lived in the wilderness of Paran. His mother got a wife for him out of the land of Egypt. 

###### v22 
At that time, Abimelech and Phicol the captain of his army spoke to Abraham, saying, "God is with you in all that you do. 

###### v23 
Now, therefore, swear to me here by God that you will not deal falsely with me, nor with my son, nor with my son's son. But according to the kindness that I have done to you, you shall do to me, and to the land in which you have lived as a foreigner." 

###### v24 
Abraham said, "I will swear." 

###### v25 
Abraham complained to Abimelech because of a water well, which Abimelech's servants had violently taken away. 

###### v26 
Abimelech said, "I don't know who has done this thing. You didn't tell me, and I didn't hear of it until today." 

###### v27 
Abraham took sheep and cattle, and gave them to Abimelech. Those two made a covenant. 

###### v28 
Abraham set seven ewe lambs of the flock by themselves. 

###### v29 
Abimelech said to Abraham, "What do these seven ewe lambs, which you have set by themselves, mean?" 

###### v30 
He said, "You shall take these seven ewe lambs from my hand, that it may be a witness to me, that I have dug this well." 

###### v31 
Therefore he called that place Beersheba, because they both swore an oath there. 

###### v32 
So they made a covenant at Beersheba. Abimelech rose up with Phicol, the captain of his army, and they returned into the land of the Philistines. 

###### v33 
Abraham planted a tamarisk tree in Beersheba, and there he called on the name of Yahweh, the Everlasting God. 

###### v34 
Abraham lived as a foreigner in the land of the Philistines many days.

***
[[Gen-20|← Genesis 20]] | [[Genesis]] | [[Gen-22|Genesis 22 →]]
