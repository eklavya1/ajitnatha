# Genesis 34

[[Gen-33|← Genesis 33]] | [[Genesis]] | [[Gen-35|Genesis 35 →]]
***



###### v1 
Dinah, the daughter of Leah, whom she bore to Jacob, went out to see the daughters of the land. 

###### v2 
Shechem the son of Hamor the Hivite, the prince of the land, saw her. He took her, lay with her, and humbled her. 

###### v3 
His soul joined to Dinah, the daughter of Jacob, and he loved the young lady, and spoke kindly to the young lady. 

###### v4 
Shechem spoke to his father, Hamor, saying, "Get me this young lady as a wife." 

###### v5 
Now Jacob heard that he had defiled Dinah, his daughter; and his sons were with his livestock in the field. Jacob held his peace until they came. 

###### v6 
Hamor the father of Shechem went out to Jacob to talk with him. 

###### v7 
The sons of Jacob came in from the field when they heard it. The men were grieved, and they were very angry, because he had done folly in Israel in lying with Jacob's daughter, a thing that ought not to be done. 

###### v8 
Hamor talked with them, saying, "The soul of my son, Shechem, longs for your daughter. Please give her to him as a wife. 

###### v9 
Make marriages with us. Give your daughters to us, and take our daughters for yourselves. 

###### v10 
You shall dwell with us, and the land will be before you. Live and trade in it, and get possessions in it." 

###### v11 
Shechem said to her father and to her brothers, "Let me find favor in your eyes, and whatever you will tell me I will give. 

###### v12 
Ask me a great amount for a dowry, and I will give whatever you ask of me, but give me the young lady as a wife." 

###### v13 
The sons of Jacob answered Shechem and Hamor his father with deceit when they spoke, because he had defiled Dinah their sister, 

###### v14 
and said to them, "We can't do this thing, to give our sister to one who is uncircumcised; for that is a reproach to us. 

###### v15 
Only on this condition will we consent to you. If you will be as we are, that every male of you be circumcised, 

###### v16 
then will we give our daughters to you; and we will take your daughters to us, and we will dwell with you, and we will become one people. 

###### v17 
But if you will not listen to us and be circumcised, then we will take our sister, and we will be gone." 

###### v18 
Their words pleased Hamor and Shechem, Hamor's son. 

###### v19 
The young man didn't wait to do this thing, because he had delight in Jacob's daughter, and he was honored above all the house of his father. 

###### v20 
Hamor and Shechem, his son, came to the gate of their city, and talked with the men of their city, saying, 

###### v21 
"These men are peaceful with us. Therefore let them live in the land and trade in it. For behold, the land is large enough for them. Let's take their daughters to us for wives, and let's give them our daughters. 

###### v22 
Only on this condition will the men consent to us to live with us, to become one people, if every male among us is circumcised, as they are circumcised. 

###### v23 
Won't their livestock and their possessions and all their animals be ours? Only let's give our consent to them, and they will dwell with us." 

###### v24 
All who went out of the gate of his city listened to Hamor, and to Shechem his son; and every male was circumcised, all who went out of the gate of his city. 

###### v25 
On the third day, when they were sore, two of Jacob's sons, Simeon and Levi, Dinah's brothers, each took his sword, came upon the unsuspecting city, and killed all the males. 

###### v26 
They killed Hamor and Shechem, his son, with the edge of the sword, and took Dinah out of Shechem's house, and went away. 

###### v27 
Jacob's sons came on the dead, and plundered the city, because they had defiled their sister. 

###### v28 
They took their flocks, their herds, their donkeys, that which was in the city, that which was in the field, 

###### v29 
and all their wealth. They took captive all their little ones and their wives, and took as plunder everything that was in the house. 

###### v30 
Jacob said to Simeon and Levi, "You have troubled me, to make me odious to the inhabitants of the land, among the Canaanites and the Perizzites. I am few in number. They will gather themselves together against me and strike me, and I will be destroyed, I and my house." 

###### v31 
They said, "Should he deal with our sister as with a prostitute?"

***
[[Gen-33|← Genesis 33]] | [[Genesis]] | [[Gen-35|Genesis 35 →]]
