# Genesis 18

[[Gen-17|← Genesis 17]] | [[Genesis]] | [[Gen-19|Genesis 19 →]]
***



###### v1 
Yahweh appeared to him by the oaks of Mamre, as he sat in the tent door in the heat of the day. 

###### v2 
He lifted up his eyes and looked, and saw that three men stood near him. When he saw them, he ran to meet them from the tent door, and bowed himself to the earth, 

###### v3 
and said, "My lord, if now I have found favor in your sight, please don't go away from your servant. 

###### v4 
Now let a little water be fetched, wash your feet, and rest yourselves under the tree. 

###### v5 
I will get a piece of bread so you can refresh your heart. After that you may go your way, now that you have come to your servant." They said, "Very well, do as you have said." 

###### v6 
Abraham hurried into the tent to Sarah, and said, "Quickly prepare three seahs of fine meal, knead it, and make cakes." 

###### v7 
Abraham ran to the herd, and fetched a tender and good calf, and gave it to the servant. He hurried to dress it. 

###### v8 
He took butter, milk, and the calf which he had dressed, and set it before them. He stood by them under the tree, and they ate. 

###### v9 
They asked him, "Where is Sarah, your wife?" He said, "There, in the tent." 

###### v10 
He said, "I will certainly return to you at about this time next year; and behold, Sarah your wife will have a son." Sarah heard in the tent door, which was behind him. 

###### v11 
Now Abraham and Sarah were old, well advanced in age. Sarah had passed the age of childbearing. 

###### v12 
Sarah laughed within herself, saying, "After I have grown old will I have pleasure, my lord being old also?" 

###### v13 
Yahweh said to Abraham, "Why did Sarah laugh, saying, 'Will I really bear a child when I am old?' 

###### v14 
Is anything too hard for Yahweh? At the set time I will return to you, when the season comes around, and Sarah will have a son." 

###### v15 
Then Sarah denied it, saying, "I didn't laugh," for she was afraid. He said, "No, but you did laugh." 

###### v16 
The men rose up from there, and looked toward Sodom. Abraham went with them to see them on their way. 

###### v17 
Yahweh said, "Will I hide from Abraham what I do, 

###### v18 
since Abraham will surely become a great and mighty nation, and all the nations of the earth will be blessed in him? 

###### v19 
For I have known him, to the end that he may command his children and his household after him, that they may keep the way of Yahweh, to do righteousness and justice; to the end that Yahweh may bring on Abraham that which he has spoken of him." 

###### v20 
Yahweh said, "Because the cry of Sodom and Gomorrah is great, and because their sin is very grievous, 

###### v21 
I will go down now, and see whether their deeds are as bad as the reports which have come to me. If not, I will know." 

###### v22 
The men turned from there, and went toward Sodom, but Abraham stood yet before Yahweh. 

###### v23 
Abraham came near, and said, "Will you consume the righteous with the wicked? 

###### v24 
What if there are fifty righteous within the city? Will you consume and not spare the place for the fifty righteous who are in it? 

###### v25 
May it be far from you to do things like that, to kill the righteous with the wicked, so that the righteous should be like the wicked. May that be far from you. Shouldn't the Judge of all the earth do right?" 

###### v26 
Yahweh said, "If I find in Sodom fifty righteous within the city, then I will spare the whole place for their sake." 

###### v27 
Abraham answered, "See now, I have taken it on myself to speak to the Lord, although I am dust and ashes. 

###### v28 
What if there will lack five of the fifty righteous? Will you destroy all the city for lack of five?" He said, "I will not destroy it if I find forty-five there." 

###### v29 
He spoke to him yet again, and said, "What if there are forty found there?" He said, "I will not do it for the forty's sake." 

###### v30 
He said, "Oh don't let the Lord be angry, and I will speak. What if there are thirty found there?" He said, "I will not do it if I find thirty there." 

###### v31 
He said, "See now, I have taken it on myself to speak to the Lord. What if there are twenty found there?" He said, "I will not destroy it for the twenty's sake." 

###### v32 
He said, "Oh don't let the Lord be angry, and I will speak just once more. What if ten are found there?" He said, "I will not destroy it for the ten's sake." 

###### v33 
Yahweh went his way as soon as he had finished communing with Abraham, and Abraham returned to his place.

***
[[Gen-17|← Genesis 17]] | [[Genesis]] | [[Gen-19|Genesis 19 →]]
