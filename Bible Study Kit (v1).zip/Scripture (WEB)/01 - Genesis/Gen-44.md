# Genesis 44

[[Gen-43|← Genesis 43]] | [[Genesis]] | [[Gen-45|Genesis 45 →]]
***



###### v1 
He commanded the steward of his house, saying, "Fill the men's sacks with food, as much as they can carry, and put each man's money in his sack's mouth. 

###### v2 
Put my cup, the silver cup, in the sack's mouth of the youngest, with his grain money." He did according to the word that Joseph had spoken. 

###### v3 
As soon as the morning was light, the men were sent away, they and their donkeys. 

###### v4 
When they had gone out of the city, and were not yet far off, Joseph said to his steward, "Up, follow after the men. When you overtake them, ask them, 'Why have you rewarded evil for good? 

###### v5 
Isn't this that from which my lord drinks, and by which he indeed divines? You have done evil in so doing.'" 

###### v6 
He overtook them, and he spoke these words to them. 

###### v7 
They said to him, "Why does my lord speak such words as these? Far be it from your servants that they should do such a thing! 

###### v8 
Behold, the money, which we found in our sacks' mouths, we brought again to you out of the land of Canaan. How then should we steal silver or gold out of your lord's house? 

###### v9 
With whomever of your servants it is found, let him die, and we also will be my lord's slaves." 

###### v10 
He said, "Now also let it be according to your words. He with whom it is found will be my slave; and you will be blameless." 

###### v11 
Then they hurried, and each man took his sack down to the ground, and each man opened his sack. 

###### v12 
He searched, beginning with the oldest, and ending at the youngest. The cup was found in Benjamin's sack. 

###### v13 
Then they tore their clothes, and each man loaded his donkey, and returned to the city. 

###### v14 
Judah and his brothers came to Joseph's house, and he was still there. They fell on the ground before him. 

###### v15 
Joseph said to them, "What deed is this that you have done? Don't you know that such a man as I can indeed do divination?" 

###### v16 
Judah said, "What will we tell my lord? What will we speak? How will we clear ourselves? God has found out the iniquity of your servants. Behold, we are my lord's slaves, both we and he also in whose hand the cup is found." 

###### v17 
He said, "Far be it from me that I should do so. The man in whose hand the cup is found, he will be my slave; but as for you, go up in peace to your father." 

###### v18 
Then Judah came near to him, and said, "Oh, my lord, please let your servant speak a word in my lord's ears, and don't let your anger burn against your servant; for you are even as Pharaoh. 

###### v19 
My lord asked his servants, saying, 'Have you a father, or a brother?' 

###### v20 
We said to my lord, 'We have a father, an old man, and a child of his old age, a little one; and his brother is dead, and he alone is left of his mother; and his father loves him.' 

###### v21 
You said to your servants, 'Bring him down to me, that I may set my eyes on him.' 

###### v22 
We said to my lord, 'The boy can't leave his father, for if he should leave his father, his father would die.' 

###### v23 
You said to your servants, 'Unless your youngest brother comes down with you, you will see my face no more.' 

###### v24 
When we came up to your servant my father, we told him the words of my lord. 

###### v25 
Our father said, 'Go again and buy us a little food.' 

###### v26 
We said, 'We can't go down. If our youngest brother is with us, then we will go down: for we may not see the man's face, unless our youngest brother is with us.' 

###### v27 
Your servant, my father, said to us, 'You know that my wife bore me two sons. 

###### v28 
One went out from me, and I said, "Surely he is torn in pieces;" and I haven't seen him since. 

###### v29 
If you take this one also from me, and harm happens to him, you will bring down my gray hairs with sorrow to Sheol.' 

###### v30 
Now therefore when I come to your servant my father, and the boy is not with us; since his life is bound up in the boy's life; 

###### v31 
it will happen, when he sees that the boy is no more, that he will die. Your servants will bring down the gray hairs of your servant, our father, with sorrow to Sheol. 

###### v32 
For your servant became collateral for the boy to my father, saying, 'If I don't bring him to you, then I will bear the blame to my father forever.' 

###### v33 
Now therefore, please let your servant stay instead of the boy, my lord's slave; and let the boy go up with his brothers. 

###### v34 
For how will I go up to my father, if the boy isn't with me?--lest I see the evil that will come on my father."

***
[[Gen-43|← Genesis 43]] | [[Genesis]] | [[Gen-45|Genesis 45 →]]
