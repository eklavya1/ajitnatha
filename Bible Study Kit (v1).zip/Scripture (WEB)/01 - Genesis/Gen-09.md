# Genesis 9

[[Gen-08|← Genesis 08]] | [[Genesis]] | [[Gen-10|Genesis 10 →]]
***



###### v1 
God blessed Noah and his sons, and said to them, "Be fruitful, multiply, and replenish the earth. 

###### v2 
The fear of you and the dread of you will be on every animal of the earth, and on every bird of the sky. Everything that moves along the ground, and all the fish of the sea, are delivered into your hand. 

###### v3 
Every moving thing that lives will be food for you. As I gave you the green herb, I have given everything to you. 

###### v4 
But flesh with its life, that is, its blood, you shall not eat. 

###### v5 
I will surely require accounting for your life's blood. At the hand of every animal I will require it. At the hand of man, even at the hand of every man's brother, I will require the life of man. 

###### v6 
Whoever sheds man's blood, his blood will be shed by man, for God made man in his own image. 

###### v7 
Be fruitful and multiply. Increase abundantly in the earth, and multiply in it." 

###### v8 
God spoke to Noah and to his sons with him, saying, 

###### v9 
"As for me, behold, I establish my covenant with you, and with your offspring after you, 

###### v10 
and with every living creature that is with you: the birds, the livestock, and every animal of the earth with you, of all that go out of the ship, even every animal of the earth. 

###### v11 
I will establish my covenant with you: All flesh will not be cut off any more by the waters of the flood. There will never again be a flood to destroy the earth." 

###### v12 
God said, "This is the token of the covenant which I make between me and you and every living creature that is with you, for perpetual generations: 

###### v13 
I set my rainbow in the cloud, and it will be a sign of a covenant between me and the earth. 

###### v14 
When I bring a cloud over the earth, that the rainbow will be seen in the cloud, 

###### v15 
I will remember my covenant, which is between me and you and every living creature of all flesh, and the waters will no more become a flood to destroy all flesh. 

###### v16 
The rainbow will be in the cloud. I will look at it, that I may remember the everlasting covenant between God and every living creature of all flesh that is on the earth." 

###### v17 
God said to Noah, "This is the token of the covenant which I have established between me and all flesh that is on the earth." 

###### v18 
The sons of Noah who went out from the ship were Shem, Ham, and Japheth. Ham is the father of Canaan. 

###### v19 
These three were the sons of Noah, and from these the whole earth was populated. 

###### v20 
Noah began to be a farmer, and planted a vineyard. 

###### v21 
He drank of the wine and got drunk. He was uncovered within his tent. 

###### v22 
Ham, the father of Canaan, saw the nakedness of his father, and told his two brothers outside. 

###### v23 
Shem and Japheth took a garment, and laid it on both their shoulders, went in backwards, and covered the nakedness of their father. Their faces were backwards, and they didn't see their father's nakedness. 

###### v24 
Noah awoke from his wine, and knew what his youngest son had done to him. 

###### v25 
He said, "Canaan is cursed. He will be a servant of servants to his brothers." 

###### v26 
He said, "Blessed be Yahweh, the God of Shem. Let Canaan be his servant. 

###### v27 
May God enlarge Japheth. Let him dwell in the tents of Shem. Let Canaan be his servant." 

###### v28 
Noah lived three hundred fifty years after the flood. 

###### v29 
All the days of Noah were nine hundred fifty years, and then he died.

***
[[Gen-08|← Genesis 08]] | [[Genesis]] | [[Gen-10|Genesis 10 →]]
