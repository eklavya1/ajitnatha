# Genesis 14

[[Gen-13|← Genesis 13]] | [[Genesis]] | [[Gen-15|Genesis 15 →]]
***



###### v1 
In the days of Amraphel, king of Shinar; Arioch, king of Ellasar; Chedorlaomer, king of Elam; and Tidal, king of Goiim, 

###### v2 
they made war with Bera, king of Sodom; Birsha, king of Gomorrah; Shinab, king of Admah; Shemeber, king of Zeboiim; and the king of Bela (also called Zoar). 

###### v3 
All these joined together in the valley of Siddim (also called the Salt Sea). 

###### v4 
They served Chedorlaomer for twelve years, and in the thirteenth year they rebelled. 

###### v5 
In the fourteenth year Chedorlaomer and the kings who were with him came and struck the Rephaim in Ashteroth Karnaim, the Zuzim in Ham, the Emim in Shaveh Kiriathaim, 

###### v6 
and the Horites in their Mount Seir, to El Paran, which is by the wilderness. 

###### v7 
They returned, and came to En Mishpat (also called Kadesh), and struck all the country of the Amalekites, and also the Amorites, that lived in Hazazon Tamar. 

###### v8 
The king of Sodom, and the king of Gomorrah, the king of Admah, the king of Zeboiim, and the king of Bela (also called Zoar) went out; and they set the battle in array against them in the valley of Siddim 

###### v9 
against Chedorlaomer king of Elam, Tidal king of Goiim, Amraphel king of Shinar, and Arioch king of Ellasar; four kings against the five. 

###### v10 
Now the valley of Siddim was full of tar pits; and the kings of Sodom and Gomorrah fled, and some fell there. Those who remained fled to the hills. 

###### v11 
They took all the goods of Sodom and Gomorrah, and all their food, and went their way. 

###### v12 
They took Lot, Abram's brother's son, who lived in Sodom, and his goods, and departed. 

###### v13 
One who had escaped came and told Abram, the Hebrew. At that time, he lived by the oaks of Mamre, the Amorite, brother of Eshcol and brother of Aner. They were allies of Abram. 

###### v14 
When Abram heard that his relative was taken captive, he led out his three hundred eighteen trained men, born in his house, and pursued as far as Dan. 

###### v15 
He divided himself against them by night, he and his servants, and struck them, and pursued them to Hobah, which is on the left hand of Damascus. 

###### v16 
He brought back all the goods, and also brought back his relative Lot and his goods, and the women also, and the other people. 

###### v17 
The king of Sodom went out to meet him after his return from the slaughter of Chedorlaomer and the kings who were with him, at the valley of Shaveh (that is, the King's Valley). 

###### v18 
Melchizedek king of Salem brought out bread and wine. He was priest of God Most High. 

###### v19 
He blessed him, and said, "Blessed be Abram of God Most High, possessor of heaven and earth. 

###### v20 
Blessed be God Most High, who has delivered your enemies into your hand." Abram gave him a tenth of all. 

###### v21 
The king of Sodom said to Abram, "Give me the people, and take the goods for yourself." 

###### v22 
Abram said to the king of Sodom, "I have lifted up my hand to Yahweh, God Most High, possessor of heaven and earth, 

###### v23 
that I will not take a thread nor a sandal strap nor anything that is yours, lest you should say, 'I have made Abram rich.' 

###### v24 
I will accept nothing from you except that which the young men have eaten, and the portion of the men who went with me: Aner, Eshcol, and Mamre. Let them take their portion."

***
[[Gen-13|← Genesis 13]] | [[Genesis]] | [[Gen-15|Genesis 15 →]]
