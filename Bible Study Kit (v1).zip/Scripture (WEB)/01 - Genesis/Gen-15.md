# Genesis 15

[[Gen-14|← Genesis 14]] | [[Genesis]] | [[Gen-16|Genesis 16 →]]
***



###### v1 
After these things Yahweh's word came to Abram in a vision, saying, "Don't be afraid, Abram. I am your shield, your exceedingly great reward." 

###### v2 
Abram said, "Lord Yahweh, what will you give me, since I go childless, and he who will inherit my estate is Eliezer of Damascus?" 

###### v3 
Abram said, "Behold, you have given no children to me: and, behold, one born in my house is my heir." 

###### v4 
Behold, Yahweh's word came to him, saying, "This man will not be your heir, but he who will come out of your own body will be your heir." 

###### v5 
Yahweh brought him outside, and said, "Look now toward the sky, and count the stars, if you are able to count them." He said to Abram, "So your offspring will be." 

###### v6 
He believed in Yahweh, who credited it to him for righteousness. 

###### v7 
He said to Abram, "I am Yahweh who brought you out of Ur of the Chaldees, to give you this land to inherit it." 

###### v8 
He said, "Lord Yahweh, how will I know that I will inherit it?" 

###### v9 
He said to him, "Bring me a heifer three years old, a female goat three years old, a ram three years old, a turtledove, and a young pigeon." 

###### v10 
He brought him all these, and divided them in the middle, and laid each half opposite the other; but he didn't divide the birds. 

###### v11 
The birds of prey came down on the carcasses, and Abram drove them away. 

###### v12 
When the sun was going down, a deep sleep fell on Abram. Now terror and great darkness fell on him. 

###### v13 
He said to Abram, "Know for sure that your offspring will live as foreigners in a land that is not theirs, and will serve them. They will afflict them four hundred years. 

###### v14 
I will also judge that nation, whom they will serve. Afterward they will come out with great wealth; 

###### v15 
but you will go to your fathers in peace. You will be buried at a good old age. 

###### v16 
In the fourth generation they will come here again, for the iniquity of the Amorite is not yet full." 

###### v17 
It came to pass that, when the sun went down, and it was dark, behold, a smoking furnace and a flaming torch passed between these pieces. 

###### v18 
In that day Yahweh made a covenant with Abram, saying, "I have given this land to your offspring, from the river of Egypt to the great river, the river Euphrates: 

###### v19 
the land of the Kenites, the Kenizzites, the Kadmonites, 

###### v20 
the Hittites, the Perizzites, the Rephaim, 

###### v21 
the Amorites, the Canaanites, the Girgashites, and the Jebusites."

***
[[Gen-14|← Genesis 14]] | [[Genesis]] | [[Gen-16|Genesis 16 →]]
