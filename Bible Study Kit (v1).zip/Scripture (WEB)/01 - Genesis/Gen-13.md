# Genesis 13

[[Gen-12|← Genesis 12]] | [[Genesis]] | [[Gen-14|Genesis 14 →]]
***



###### v1 
Abram went up out of Egypt--he, his wife, all that he had, and Lot with him--into the South. 

###### v2 
Abram was very rich in livestock, in silver, and in gold. 

###### v3 
He went on his journeys from the South as far as Bethel, to the place where his tent had been at the beginning, between Bethel and Ai, 

###### v4 
to the place of the altar, which he had made there at the first. There Abram called on Yahweh's name. 

###### v5 
Lot also, who went with Abram, had flocks, herds, and tents. 

###### v6 
The land was not able to bear them, that they might live together; for their possessions were so great that they couldn't live together. 

###### v7 
There was strife between the herdsmen of Abram's livestock and the herdsmen of Lot's livestock. The Canaanites and the Perizzites lived in the land at that time. 

###### v8 
Abram said to Lot, "Please, let there be no strife between you and me, and between your herdsmen and my herdsmen; for we are relatives. 

###### v9 
Isn't the whole land before you? Please separate yourself from me. If you go to the left hand, then I will go to the right. Or if you go to the right hand, then I will go to the left." 

###### v10 
Lot lifted up his eyes, and saw all the plain of the Jordan, that it was well-watered everywhere, before Yahweh destroyed Sodom and Gomorrah, like the garden of Yahweh, like the land of Egypt, as you go to Zoar. 

###### v11 
So Lot chose the Plain of the Jordan for himself. Lot traveled east, and they separated themselves from one other. 

###### v12 
Abram lived in the land of Canaan, and Lot lived in the cities of the plain, and moved his tent as far as Sodom. 

###### v13 
Now the men of Sodom were exceedingly wicked and sinners against Yahweh. 

###### v14 
Yahweh said to Abram, after Lot was separated from him, "Now, lift up your eyes, and look from the place where you are, northward and southward and eastward and westward, 

###### v15 
for I will give all the land which you see to you and to your offspring forever. 

###### v16 
I will make your offspring as the dust of the earth, so that if a man can count the dust of the earth, then your offspring may also be counted. 

###### v17 
Arise, walk through the land in its length and in its width; for I will give it to you." 

###### v18 
Abram moved his tent, and came and lived by the oaks of Mamre, which are in Hebron, and built an altar there to Yahweh.

***
[[Gen-12|← Genesis 12]] | [[Genesis]] | [[Gen-14|Genesis 14 →]]
