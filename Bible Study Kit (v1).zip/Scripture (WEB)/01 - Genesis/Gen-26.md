# Genesis 26

[[Gen-25|← Genesis 25]] | [[Genesis]] | [[Gen-27|Genesis 27 →]]
***



###### v1 
There was a famine in the land, in addition to the first famine that was in the days of Abraham. Isaac went to Abimelech king of the Philistines, to Gerar. 

###### v2 
Yahweh appeared to him, and said, "Don't go down into Egypt. Live in the land I will tell you about. 

###### v3 
Live in this land, and I will be with you, and will bless you. For I will give to you, and to your offspring, all these lands, and I will establish the oath which I swore to Abraham your father. 

###### v4 
I will multiply your offspring as the stars of the sky, and will give all these lands to your offspring. In your offspring all the nations of the earth will be blessed, 

###### v5 
because Abraham obeyed my voice, and kept my requirements, my commandments, my statutes, and my laws." 

###### v6 
Isaac lived in Gerar. 

###### v7 
The men of the place asked him about his wife. He said, "She is my sister," for he was afraid to say, "My wife", lest, he thought, "the men of the place might kill me for Rebekah, because she is beautiful to look at." 

###### v8 
When he had been there a long time, Abimelech king of the Philistines looked out at a window, and saw, and, behold, Isaac was caressing Rebekah, his wife. 

###### v9 
Abimelech called Isaac, and said, "Behold, surely she is your wife. Why did you say, 'She is my sister?'" Isaac said to him, "Because I said, 'Lest I die because of her.'" 

###### v10 
Abimelech said, "What is this you have done to us? One of the people might easily have lain with your wife, and you would have brought guilt on us!" 

###### v11 
Abimelech commanded all the people, saying, "He who touches this man or his wife will surely be put to death." 

###### v12 
Isaac sowed in that land, and reaped in the same year one hundred times what he planted. Yahweh blessed him. 

###### v13 
The man grew great, and grew more and more until he became very great. 

###### v14 
He had possessions of flocks, possessions of herds, and a great household. The Philistines envied him. 

###### v15 
Now all the wells which his father's servants had dug in the days of Abraham his father, the Philistines had stopped, and filled with earth. 

###### v16 
Abimelech said to Isaac, "Go away from us, for you are much mightier than we." 

###### v17 
Isaac departed from there, encamped in the valley of Gerar, and lived there. 

###### v18 
Isaac dug again the wells of water, which they had dug in the days of Abraham his father, for the Philistines had stopped them after the death of Abraham. He called their names after the names by which his father had called them. 

###### v19 
Isaac's servants dug in the valley, and found there a well of flowing water. 

###### v20 
The herdsmen of Gerar argued with Isaac's herdsmen, saying, "The water is ours." So he called the name of the well Esek, because they contended with him. 

###### v21 
They dug another well, and they argued over that, also. So he called its name Sitnah. 

###### v22 
He left that place, and dug another well. They didn't argue over that one. So he called it Rehoboth. He said, "For now Yahweh has made room for us, and we will be fruitful in the land." 

###### v23 
He went up from there to Beersheba. 

###### v24 
Yahweh appeared to him the same night, and said, "I am the God of Abraham your father. Don't be afraid, for I am with you, and will bless you, and multiply your offspring for my servant Abraham's sake." 

###### v25 
He built an altar there, and called on Yahweh's name, and pitched his tent there. There Isaac's servants dug a well. 

###### v26 
Then Abimelech went to him from Gerar with Ahuzzath his friend, and Phicol the captain of his army. 

###### v27 
Isaac said to them, "Why have you come to me, since you hate me, and have sent me away from you?" 

###### v28 
They said, "We saw plainly that Yahweh was with you. We said, 'Let there now be an oath between us, even between us and you, and let's make a covenant with you, 

###### v29 
that you will do us no harm, as we have not touched you, and as we have done to you nothing but good, and have sent you away in peace.' You are now the blessed of Yahweh." 

###### v30 
He made them a feast, and they ate and drank. 

###### v31 
They rose up some time in the morning, and swore an oath to one another. Isaac sent them away, and they departed from him in peace. 

###### v32 
The same day, Isaac's servants came, and told him concerning the well which they had dug, and said to him, "We have found water." 

###### v33 
He called it "Shibah". Therefore the name of the city is "Beersheba" to this day. 

###### v34 
When Esau was forty years old, he took as wife Judith, the daughter of Beeri the Hittite, and Basemath, the daughter of Elon the Hittite. 

###### v35 
They grieved Isaac's and Rebekah's spirits.

***
[[Gen-25|← Genesis 25]] | [[Genesis]] | [[Gen-27|Genesis 27 →]]
