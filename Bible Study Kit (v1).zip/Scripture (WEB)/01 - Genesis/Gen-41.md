# Genesis 41

[[Gen-40|← Genesis 40]] | [[Genesis]] | [[Gen-42|Genesis 42 →]]
***



###### v1 
At the end of two full years, Pharaoh dreamed, and behold, he stood by the river. 

###### v2 
Behold, seven cattle came up out of the river. They were sleek and fat, and they fed in the marsh grass. 

###### v3 
Behold, seven other cattle came up after them out of the river, ugly and thin, and stood by the other cattle on the brink of the river. 

###### v4 
The ugly and thin cattle ate up the seven sleek and fat cattle. So Pharaoh awoke. 

###### v5 
He slept and dreamed a second time; and behold, seven heads of grain came up on one stalk, healthy and good. 

###### v6 
Behold, seven heads of grain, thin and blasted with the east wind, sprung up after them. 

###### v7 
The thin heads of grain swallowed up the seven healthy and full ears. Pharaoh awoke, and behold, it was a dream. 

###### v8 
In the morning, his spirit was troubled, and he sent and called for all of Egypt's magicians and wise men. Pharaoh told them his dreams, but there was no one who could interpret them to Pharaoh. 

###### v9 
Then the chief cup bearer spoke to Pharaoh, saying, "I remember my faults today. 

###### v10 
Pharaoh was angry with his servants, and put me in custody in the house of the captain of the guard, with the chief baker. 

###### v11 
We dreamed a dream in one night, he and I. Each man dreamed according to the interpretation of his dream. 

###### v12 
There was with us there a young man, a Hebrew, servant to the captain of the guard, and we told him, and he interpreted to us our dreams. He interpreted to each man according to his dream. 

###### v13 
As he interpreted to us, so it was. He restored me to my office, and he hanged him." 

###### v14 
Then Pharaoh sent and called Joseph, and they brought him hastily out of the dungeon. He shaved himself, changed his clothing, and came in to Pharaoh. 

###### v15 
Pharaoh said to Joseph, "I have dreamed a dream, and there is no one who can interpret it. I have heard it said of you, that when you hear a dream you can interpret it." 

###### v16 
Joseph answered Pharaoh, saying, "It isn't in me. God will give Pharaoh an answer of peace." 

###### v17 
Pharaoh spoke to Joseph, "In my dream, behold, I stood on the brink of the river; 

###### v18 
and behold, seven fat and sleek cattle came up out of the river. They fed in the marsh grass; 

###### v19 
and behold, seven other cattle came up after them, poor and very ugly and thin, such as I never saw in all the land of Egypt for ugliness. 

###### v20 
The thin and ugly cattle ate up the first seven fat cattle; 

###### v21 
and when they had eaten them up, it couldn't be known that they had eaten them, but they were still ugly, as at the beginning. So I awoke. 

###### v22 
I saw in my dream, and behold, seven heads of grain came up on one stalk, full and good; 

###### v23 
and behold, seven heads of grain, withered, thin, and blasted with the east wind, sprung up after them. 

###### v24 
The thin heads of grain swallowed up the seven good heads of grain. I told it to the magicians, but there was no one who could explain it to me." 

###### v25 
Joseph said to Pharaoh, "The dream of Pharaoh is one. What God is about to do he has declared to Pharaoh. 

###### v26 
The seven good cattle are seven years; and the seven good heads of grain are seven years. The dream is one. 

###### v27 
The seven thin and ugly cattle that came up after them are seven years, and also the seven empty heads of grain blasted with the east wind; they will be seven years of famine. 

###### v28 
That is the thing which I have spoken to Pharaoh. God has shown Pharaoh what he is about to do. 

###### v29 
Behold, seven years of great plenty throughout all the land of Egypt are coming. 

###### v30 
Seven years of famine will arise after them, and all the plenty will be forgotten in the land of Egypt. The famine will consume the land, 

###### v31 
and the plenty will not be known in the land by reason of that famine which follows; for it will be very grievous. 

###### v32 
The dream was doubled to Pharaoh, because the thing is established by God, and God will shortly bring it to pass. 

###### v33 
"Now therefore let Pharaoh look for a discreet and wise man, and set him over the land of Egypt. 

###### v34 
Let Pharaoh do this, and let him appoint overseers over the land, and take up the fifth part of the land of Egypt's produce in the seven plenteous years. 

###### v35 
Let them gather all the food of these good years that come, and store grain under the hand of Pharaoh for food in the cities, and let them keep it. 

###### v36 
The food will be to supply the land against the seven years of famine, which will be in the land of Egypt; so that the land will not perish through the famine." 

###### v37 
The thing was good in the eyes of Pharaoh, and in the eyes of all his servants. 

###### v38 
Pharaoh said to his servants, "Can we find such a one as this, a man in whom is the Spirit of God?" 

###### v39 
Pharaoh said to Joseph, "Because God has shown you all of this, there is no one so discreet and wise as you. 

###### v40 
You shall be over my house. All my people will be ruled according to your word. Only in the throne I will be greater than you." 

###### v41 
Pharaoh said to Joseph, "Behold, I have set you over all the land of Egypt." 

###### v42 
Pharaoh took off his signet ring from his hand, and put it on Joseph's hand, and arrayed him in robes of fine linen, and put a gold chain about his neck. 

###### v43 
He made him ride in the second chariot which he had. They cried before him, "Bow the knee!" He set him over all the land of Egypt. 

###### v44 
Pharaoh said to Joseph, "I am Pharaoh. Without you, no man shall lift up his hand or his foot in all the land of Egypt." 

###### v45 
Pharaoh called Joseph's name Zaphenath-Paneah. He gave him Asenath, the daughter of Potiphera priest of On as a wife. Joseph went out over the land of Egypt. 

###### v46 
Joseph was thirty years old when he stood before Pharaoh king of Egypt. Joseph went out from the presence of Pharaoh, and went throughout all the land of Egypt. 

###### v47 
In the seven plenteous years the earth produced abundantly. 

###### v48 
He gathered up all the food of the seven years which were in the land of Egypt, and laid up the food in the cities. He stored food in each city from the fields around that city. 

###### v49 
Joseph laid up grain as the sand of the sea, very much, until he stopped counting, for it was without number. 

###### v50 
To Joseph were born two sons before the year of famine came, whom Asenath, the daughter of Potiphera priest of On, bore to him. 

###### v51 
Joseph called the name of the firstborn Manasseh, "For", he said, "God has made me forget all my toil, and all my father's house." 

###### v52 
The name of the second, he called Ephraim: "For God has made me fruitful in the land of my affliction." 

###### v53 
The seven years of plenty, that were in the land of Egypt, came to an end. 

###### v54 
The seven years of famine began to come, just as Joseph had said. There was famine in all lands, but in all the land of Egypt there was bread. 

###### v55 
When all the land of Egypt was famished, the people cried to Pharaoh for bread, and Pharaoh said to all the Egyptians, "Go to Joseph. What he says to you, do." 

###### v56 
The famine was over all the surface of the earth. Joseph opened all the store houses, and sold to the Egyptians. The famine was severe in the land of Egypt. 

###### v57 
All countries came into Egypt, to Joseph, to buy grain, because the famine was severe in all the earth.

***
[[Gen-40|← Genesis 40]] | [[Genesis]] | [[Gen-42|Genesis 42 →]]
