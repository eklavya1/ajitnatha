# Genesis 28

[[Gen-27|← Genesis 27]] | [[Genesis]] | [[Gen-29|Genesis 29 →]]
***



###### v1 
Isaac called Jacob, blessed him, and commanded him, "You shall not take a wife of the daughters of Canaan. 

###### v2 
Arise, go to Paddan Aram, to the house of Bethuel your mother's father. Take a wife from there from the daughters of Laban, your mother's brother. 

###### v3 
May God Almighty bless you, and make you fruitful, and multiply you, that you may be a company of peoples, 

###### v4 
and give you the blessing of Abraham, to you and to your offspring with you, that you may inherit the land where you travel, which God gave to Abraham." 

###### v5 
Isaac sent Jacob away. He went to Paddan Aram to Laban, son of Bethuel the Syrian, the brother of Rebekah, Jacob's and Esau's mother. 

###### v6 
Now Esau saw that Isaac had blessed Jacob and sent him away to Paddan Aram, to take him a wife from there, and that as he blessed him he gave him a command, saying, "You shall not take a wife of the daughters of Canaan;" 

###### v7 
and that Jacob obeyed his father and his mother, and was gone to Paddan Aram. 

###### v8 
Esau saw that the daughters of Canaan didn't please Isaac, his father. 

###### v9 
So Esau went to Ishmael, and took, in addition to the wives that he had, Mahalath the daughter of Ishmael, Abraham's son, the sister of Nebaioth, to be his wife. 

###### v10 
Jacob went out from Beersheba, and went toward Haran. 

###### v11 
He came to a certain place, and stayed there all night, because the sun had set. He took one of the stones of the place, and put it under his head, and lay down in that place to sleep. 

###### v12 
He dreamed and saw a stairway set upon the earth, and its top reached to heaven. Behold, the angels of God were ascending and descending on it. 

###### v13 
Behold, Yahweh stood above it, and said, "I am Yahweh, the God of Abraham your father, and the God of Isaac. I will give the land you lie on to you and to your offspring. 

###### v14 
Your offspring will be as the dust of the earth, and you will spread abroad to the west, and to the east, and to the north, and to the south. In you and in your offspring, all the families of the earth will be blessed. 

###### v15 
Behold, I am with you, and will keep you, wherever you go, and will bring you again into this land. For I will not leave you until I have done that which I have spoken of to you." 

###### v16 
Jacob awakened out of his sleep, and he said, "Surely Yahweh is in this place, and I didn't know it." 

###### v17 
He was afraid, and said, "How awesome this place is! This is none other than God's house, and this is the gate of heaven." 

###### v18 
Jacob rose up early in the morning, and took the stone that he had put under his head, and set it up for a pillar, and poured oil on its top. 

###### v19 
He called the name of that place Bethel, but the name of the city was Luz at the first. 

###### v20 
Jacob vowed a vow, saying, "If God will be with me, and will keep me in this way that I go, and will give me bread to eat, and clothing to put on, 

###### v21 
so that I come again to my father's house in peace, and Yahweh will be my God, 

###### v22 
then this stone, which I have set up for a pillar, will be God's house. Of all that you will give me I will surely give a tenth to you."

***
[[Gen-27|← Genesis 27]] | [[Genesis]] | [[Gen-29|Genesis 29 →]]
