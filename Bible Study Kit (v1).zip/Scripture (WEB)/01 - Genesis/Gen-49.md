# Genesis 49

[[Gen-48|← Genesis 48]] | [[Genesis]] | [[Gen-50|Genesis 50 →]]
***



###### v1 
Jacob called to his sons, and said: "Gather yourselves together, that I may tell you that which will happen to you in the days to come. 

###### v2 
Assemble yourselves, and hear, you sons of Jacob. Listen to Israel, your father. 

###### v3 
"Reuben, you are my firstborn, my might, and the beginning of my strength, excelling in dignity, and excelling in power. 

###### v4 
Boiling over like water, you shall not excel, because you went up to your father's bed, then defiled it. He went up to my couch. 

###### v5 
"Simeon and Levi are brothers. Their swords are weapons of violence. 

###### v6 
My soul, don't come into their council. My glory, don't be united to their assembly; for in their anger they killed men. In their self-will they hamstrung cattle. 

###### v7 
Cursed be their anger, for it was fierce; and their wrath, for it was cruel. I will divide them in Jacob, and scatter them in Israel. 

###### v8 
"Judah, your brothers will praise you. Your hand will be on the neck of your enemies. Your father's sons will bow down before you. 

###### v9 
Judah is a lion's cub. From the prey, my son, you have gone up. He stooped down, he crouched as a lion, as a lioness. Who will rouse him up? 

###### v10 
The scepter will not depart from Judah, nor the ruler's staff from between his feet, until he comes to whom it belongs. The obedience of the peoples will be to him. 

###### v11 
Binding his foal to the vine, his donkey's colt to the choice vine, he has washed his garments in wine, his robes in the blood of grapes. 

###### v12 
His eyes will be red with wine, his teeth white with milk. 

###### v13 
"Zebulun will dwell at the haven of the sea. He will be for a haven of ships. His border will be on Sidon. 

###### v14 
"Issachar is a strong donkey, lying down between the saddlebags. 

###### v15 
He saw a resting place, that it was good, the land, that it was pleasant. He bows his shoulder to the burden, and becomes a servant doing forced labor. 

###### v16 
"Dan will judge his people, as one of the tribes of Israel. 

###### v17 
Dan will be a serpent on the trail, an adder in the path, that bites the horse's heels, so that his rider falls backward. 

###### v18 
I have waited for your salvation, Yahweh. 

###### v19 
"A troop will press on Gad, but he will press on their heel. 

###### v20 
"Asher's food will be rich. He will produce royal dainties. 

###### v21 
"Naphtali is a doe set free, who bears beautiful fawns. 

###### v22 
"Joseph is a fruitful vine, a fruitful vine by a spring. His branches run over the wall. 

###### v23 
The archers have severely grieved him, shot at him, and persecuted him: 

###### v24 
But his bow remained strong. The arms of his hands were made strong, by the hands of the Mighty One of Jacob, (from there is the shepherd, the stone of Israel), 

###### v25 
even by the God of your father, who will help you, by the Almighty, who will bless you, with blessings of heaven above, blessings of the deep that lies below, blessings of the breasts, and of the womb. 

###### v26 
The blessings of your father have prevailed above the blessings of your ancestors, above the boundaries of the ancient hills. They will be on the head of Joseph, on the crown of the head of him who is separated from his brothers. 

###### v27 
"Benjamin is a ravenous wolf. In the morning he will devour the prey. At evening he will divide the plunder." 

###### v28 
All these are the twelve tribes of Israel, and this is what their father spoke to them, and blessed them. He blessed everyone according to his own blessing. 

###### v29 
He instructed them, and said to them, "I am to be gathered to my people. Bury me with my fathers in the cave that is in the field of Ephron the Hittite, 

###### v30 
in the cave that is in the field of Machpelah, which is before Mamre, in the land of Canaan, which Abraham bought with the field from Ephron the Hittite as a burial place. 

###### v31 
There they buried Abraham and Sarah, his wife. There they buried Isaac and Rebekah, his wife, and there I buried Leah: 

###### v32 
the field and the cave that is therein, which was purchased from the children of Heth." 

###### v33 
When Jacob finished charging his sons, he gathered up his feet into the bed, breathed his last breath, and was gathered to his people.

***
[[Gen-48|← Genesis 48]] | [[Genesis]] | [[Gen-50|Genesis 50 →]]
