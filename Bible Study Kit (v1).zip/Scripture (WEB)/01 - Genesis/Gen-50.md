# Genesis 50

[[Gen-49|← Genesis 49]] | [[Genesis]]
***

###### v1
Joseph fell on his father’s face, wept on him, and kissed him.

###### v2
Joseph commanded his servants, the physicians, to embalm his father; and the physicians embalmed Israel. 

###### v3
Forty days were used for him, for that is how many the days it takes to embalm. The Egyptians wept for Israel for seventy days.

###### v4
When the days of weeping for him were past, Joseph spoke to Pharaoh's staff, saying, "If now I have found favor in your eyes, please speak in the ears of Pharaoh, saying,

###### v5
'My father made me swear, saying, "Behold, I am dying. Bury me in my grave which I have dug for myself in the land of Canaan." Now therefore, please let me go up and bury my father, and I will come again.'"

###### v6
Pharaoh said, "Go up, and bury your father, just like he made you swear."

###### v7
Joseph went up to bury his father; and with him went up all the servants of Pharaoh, the elders of his house, all the elders of the land of Egypt,

###### v8
all the house of Joseph, his brothers, and his father's house. Only their little ones, their flocks, and their herds, they left in the land of Goshen.

###### v9
Both chariots and horsemen went up with him. It was a very great company.

###### v10
They came to the threshing floor of Atad, which is beyond the Jordan, and there they lamented with a very great and severe lamentation. He mourned for his father seven days.

###### v11
When the inhabitants of the land, the Canaanites, saw the mourning in the floor of Atad, they said, "This is a grievous mourning by the Egyptians." Therefore its name was called Abel Mizraim, which is beyond the Jordan.

###### v12
His sons did to him just as he commanded them,

###### v13
for his sons carried him into the land of Canaan, and buried him in the cave of the field of Machpelah, which Abraham bought with the field, as a possession for a burial site, from Ephron the Hittite, near Mamre.

###### v14
Joseph returned into Egypt--he, and his brothers, and all that went up with him to bury his father, after he had buried his father.

###### v15
When Joseph's brothers saw that their father was dead, they said, "It may be that Joseph will hate us, and will fully pay us back for all the evil which we did to him."

###### v16
They sent a message to Joseph, saying, "Your father commanded before he died, saying,

###### v17
'You shall tell Joseph, "Now please forgive the disobedience of your brothers, and their sin, because they did evil to you."' Now, please forgive the disobedience of the servants of the God of your father." Joseph wept when they spoke to him.

###### v18
His brothers also went and fell down before his face; and they said, "Behold, we are your servants."

###### v19
Joseph said to them, "Don't be afraid, for am I in the place of God?

###### v20
As for you, you meant evil against me, but God meant it for good, to save many people alive, as is happening today.

###### v21
Now therefore don't be afraid. I will provide for you and your little ones." He comforted them, and spoke kindly to them.

###### v22
Joseph lived in Egypt, he, and his father's house. Joseph lived one hundred ten years.

###### v23
Joseph saw Ephraim's children to the third generation. The children also of Machir, the son of Manasseh, were born on Joseph's knees.

###### v24
Joseph said to his brothers, "I am dying, but God will surely visit you, and bring you up out of this land to the land which he swore to Abraham, to Isaac, and to Jacob."

###### v25
Joseph took an oath from the children of Israel, saying, "God will surely visit you, and you shall carry up my bones from here."

###### v26
So Joseph died, being one hundred ten years old, and they embalmed him, and he was put in a coffin in Egypt.

***
[[Gen-49|← Genesis 49]] | [[Genesis]]
