# Genesis 2

[[Gen-01|← Genesis 01]] | [[Genesis]] | [[Gen-03|Genesis 03 →]]
***

###### v1
The heavens, the earth, and all their vast array were finished.

###### v2
On the seventh day God finished his work which he had done; and he rested on the seventh day from all his work which he had done.

###### v3
God blessed the seventh day, and made it holy, because he rested in it from all his work of creation which he had done.

###### v4
This is the history of the generations of the heavens and of the earth when they were created, in the day that Yahweh God made the earth and the heavens.

###### v5
No plant of the field was yet in the earth, and no herb of the field had yet sprung up; for Yahweh God had not caused it to rain on the earth. There was not a man to till the ground,

###### v6
but a mist went up from the earth, and watered the whole surface of the ground.

###### v7
Yahweh God formed man from the dust of the ground, and breathed into his nostrils the breath of life; and man became a living soul.

###### v8
Yahweh God planted a garden eastward, in Eden, and there he put the man whom he had formed.

###### v9
Out of the ground Yahweh God made every tree to grow that is pleasant to the sight, and good for food, including the tree of life in the middle of the garden and the tree of the knowledge of good and evil.

###### v10
A river went out of Eden to water the garden; and from there it was parted, and became the source of four rivers.

###### v11
The name of the first is Pishon: it flows through the whole land of Havilah, where there is gold;

###### v12
and the gold of that land is good. Bdellium and onyx stone are also there.

###### v13
The name of the second river is Gihon. It is the same river that flows through the whole land of Cush.

###### v14
The name of the third river is Hiddekel. This is the one which flows in front of Assyria. The fourth river is the Euphrates.

###### v15
Yahweh God took the man, and put him into the garden of Eden to cultivate and keep it.

###### v16
Yahweh God commanded the man, saying, "You may freely eat of every tree of the garden;

###### v17
but you shall not eat of the tree of the knowledge of good and evil; for in the day that you eat of it, you will surely die."

###### v18
Yahweh God said, "It is not good for the man to be alone. I will make him a helper comparable to him."

###### v19
Out of the ground Yahweh God formed every animal of the field, and every bird of the sky, and brought them to the man to see what he would call them. Whatever the man called every living creature became its name.

###### v20
The man gave names to all livestock, and to the birds of the sky, and to every animal of the field; but for man there was not found a helper comparable to him.

###### v21
Yahweh God caused the man to fall into a deep sleep. As the man slept, he took one of his ribs, and closed up the flesh in its place.

###### v22
Yahweh God made a woman from the rib which he had taken from the man, and brought her to the man.

###### v23
The man said, "This is now bone of my bones, and flesh of my flesh. She will be called 'woman,' because she was taken out of Man."

###### v24
Therefore a man will leave his father and his mother, and will join with his wife, and they will be one flesh.

###### v25
The man and his wife were both naked, and they were not ashamed.

***
[[Gen-01|← Genesis 01]] | [[Genesis]] | [[Gen-03|Genesis 03 →]]
