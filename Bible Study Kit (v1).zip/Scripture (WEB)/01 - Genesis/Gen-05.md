# Genesis 5

[[Gen-04|← Genesis 04]] | [[Genesis]] | [[Gen-06|Genesis 06 →]]
***



###### v1 
This is the book of the generations of Adam. In the day that God created man, he made him in God's likeness. 

###### v2 
He created them male and female, and blessed them. On the day they were created, he named them Adam. 

###### v3 
Adam lived one hundred thirty years, and became the father of a son in his own likeness, after his image, and named him Seth. 

###### v4 
The days of Adam after he became the father of Seth were eight hundred years, and he became the father of other sons and daughters. 

###### v5 
All the days that Adam lived were nine hundred thirty years, then he died. 

###### v6 
Seth lived one hundred five years, then became the father of Enosh. 

###### v7 
Seth lived after he became the father of Enosh eight hundred seven years, and became the father of other sons and daughters. 

###### v8 
All of the days of Seth were nine hundred twelve years, then he died. 

###### v9 
Enosh lived ninety years, and became the father of Kenan. 

###### v10 
Enosh lived after he became the father of Kenan eight hundred fifteen years, and became the father of other sons and daughters. 

###### v11 
All of the days of Enosh were nine hundred five years, then he died. 

###### v12 
Kenan lived seventy years, then became the father of Mahalalel. 

###### v13 
Kenan lived after he became the father of Mahalalel eight hundred forty years, and became the father of other sons and daughters 

###### v14 
and all of the days of Kenan were nine hundred ten years, then he died. 

###### v15 
Mahalalel lived sixty-five years, then became the father of Jared. 

###### v16 
Mahalalel lived after he became the father of Jared eight hundred thirty years, and became the father of other sons and daughters. 

###### v17 
All of the days of Mahalalel were eight hundred ninety-five years, then he died. 

###### v18 
Jared lived one hundred sixty-two years, then became the father of Enoch. 

###### v19 
Jared lived after he became the father of Enoch eight hundred years, and became the father of other sons and daughters. 

###### v20 
All of the days of Jared were nine hundred sixty-two years, then he died. 

###### v21 
Enoch lived sixty-five years, then became the father of Methuselah. 

###### v22 
After Methuselah's birth, Enoch walked with God for three hundred years, and became the father of more sons and daughters. 

###### v23 
All the days of Enoch were three hundred sixty-five years. 

###### v24 
Enoch walked with God, and he was not found, for God took him. 

###### v25 
Methuselah lived one hundred eighty-seven years, then became the father of Lamech. 

###### v26 
Methuselah lived after he became the father of Lamech seven hundred eighty-two years, and became the father of other sons and daughters. 

###### v27 
All the days of Methuselah were nine hundred sixty-nine years, then he died. 

###### v28 
Lamech lived one hundred eighty-two years, then became the father of a son. 

###### v29 
He named him Noah, saying, "This one will comfort us in our work and in the toil of our hands, caused by the ground which Yahweh has cursed." 

###### v30 
Lamech lived after he became the father of Noah five hundred ninety-five years, and became the father of other sons and daughters. 

###### v31 
All the days of Lamech were seven hundred seventy-seven years, then he died. 

###### v32 
Noah was five hundred years old, then Noah became the father of Shem, Ham, and Japheth.

***
[[Gen-04|← Genesis 04]] | [[Genesis]] | [[Gen-06|Genesis 06 →]]
