# Genesis 45

[[Gen-44|← Genesis 44]] | [[Genesis]] | [[Gen-46|Genesis 46 →]]
***



###### v1 
Then Joseph couldn't control himself before all those who stood before him, and he called out, "Cause everyone to go out from me!" No one else stood with him, while Joseph made himself known to his brothers. 

###### v2 
He wept aloud. The Egyptians heard, and the house of Pharaoh heard. 

###### v3 
Joseph said to his brothers, "I am Joseph! Does my father still live?" His brothers couldn't answer him; for they were terrified at his presence. 

###### v4 
Joseph said to his brothers, "Come near to me, please." They came near. He said, "I am Joseph, your brother, whom you sold into Egypt. 

###### v5 
Now don't be grieved, nor angry with yourselves, that you sold me here, for God sent me before you to preserve life. 

###### v6 
For these two years the famine has been in the land, and there are yet five years, in which there will be no plowing and no harvest. 

###### v7 
God sent me before you to preserve for you a remnant in the earth, and to save you alive by a great deliverance. 

###### v8 
So now it wasn't you who sent me here, but God, and he has made me a father to Pharaoh, lord of all his house, and ruler over all the land of Egypt. 

###### v9 
Hurry, and go up to my father, and tell him, 'This is what your son Joseph says, "God has made me lord of all Egypt. Come down to me. Don't wait. 

###### v10 
You shall dwell in the land of Goshen, and you will be near to me, you, your children, your children's children, your flocks, your herds, and all that you have. 

###### v11 
There I will provide for you; for there are yet five years of famine; lest you come to poverty, you, and your household, and all that you have."' 

###### v12 
Behold, your eyes see, and the eyes of my brother Benjamin, that it is my mouth that speaks to you. 

###### v13 
You shall tell my father of all my glory in Egypt, and of all that you have seen. You shall hurry and bring my father down here." 

###### v14 
He fell on his brother Benjamin's neck and wept, and Benjamin wept on his neck. 

###### v15 
He kissed all his brothers, and wept on them. After that his brothers talked with him. 

###### v16 
The report of it was heard in Pharaoh's house, saying, "Joseph's brothers have come." It pleased Pharaoh well, and his servants. 

###### v17 
Pharaoh said to Joseph, "Tell your brothers, 'Do this: Load your animals, and go, travel to the land of Canaan. 

###### v18 
Take your father and your households, and come to me, and I will give you the good of the land of Egypt, and you will eat the fat of the land.' 

###### v19 
Now you are commanded to do this: Take wagons out of the land of Egypt for your little ones, and for your wives, and bring your father, and come. 

###### v20 
Also, don't concern yourselves about your belongings, for the good of all the land of Egypt is yours." 

###### v21 
The sons of Israel did so. Joseph gave them wagons, according to the commandment of Pharaoh, and gave them provision for the way. 

###### v22 
He gave each one of them changes of clothing, but to Benjamin he gave three hundred pieces of silver and five changes of clothing. 

###### v23 
He sent the following to his father: ten donkeys loaded with the good things of Egypt, and ten female donkeys loaded with grain and bread and provision for his father by the way. 

###### v24 
So he sent his brothers away, and they departed. He said to them, "See that you don't quarrel on the way." 

###### v25 
They went up out of Egypt, and came into the land of Canaan, to Jacob their father. 

###### v26 
They told him, saying, "Joseph is still alive, and he is ruler over all the land of Egypt." His heart fainted, for he didn't believe them. 

###### v27 
They told him all the words of Joseph, which he had said to them. When he saw the wagons which Joseph had sent to carry him, the spirit of Jacob, their father, revived. 

###### v28 
Israel said, "It is enough. Joseph my son is still alive. I will go and see him before I die."

***
[[Gen-44|← Genesis 44]] | [[Genesis]] | [[Gen-46|Genesis 46 →]]
