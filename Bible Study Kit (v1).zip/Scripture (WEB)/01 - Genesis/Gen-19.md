# Genesis 19

[[Gen-18|← Genesis 18]] | [[Genesis]] | [[Gen-20|Genesis 20 →]]
***



###### v1 
The two angels came to Sodom at evening. Lot sat in the gate of Sodom. Lot saw them, and rose up to meet them. He bowed himself with his face to the earth, 

###### v2 
and he said, "See now, my lords, please come into your servant's house, stay all night, wash your feet, and you can rise up early, and go on your way." They said, "No, but we will stay in the street all night." 

###### v3 
He urged them greatly, and they came in with him, and entered into his house. He made them a feast, and baked unleavened bread, and they ate. 

###### v4 
But before they lay down, the men of the city, the men of Sodom, surrounded the house, both young and old, all the people from every quarter. 

###### v5 
They called to Lot, and said to him, "Where are the men who came in to you this night? Bring them out to us, that we may have sex with them." 

###### v6 
Lot went out to them through the door, and shut the door after himself. 

###### v7 
He said, "Please, my brothers, don't act so wickedly. 

###### v8 
See now, I have two virgin daughters. Please let me bring them out to you, and you may do to them what seems good to you. Only don't do anything to these men, because they have come under the shadow of my roof." 

###### v9 
They said, "Stand back!" Then they said, "This one fellow came in to live as a foreigner, and he appoints himself a judge. Now we will deal worse with you than with them!" They pressed hard on the man Lot, and came near to break the door. 

###### v10 
But the men reached out their hand, and brought Lot into the house to them, and shut the door. 

###### v11 
They struck the men who were at the door of the house with blindness, both small and great, so that they wearied themselves to find the door. 

###### v12 
The men said to Lot, "Do you have anybody else here? Sons-in-law, your sons, your daughters, and whomever you have in the city, bring them out of the place: 

###### v13 
for we will destroy this place, because the outcry against them has grown so great before Yahweh that Yahweh has sent us to destroy it." 

###### v14 
Lot went out, and spoke to his sons-in-law, who were pledged to marry his daughters, and said, "Get up! Get out of this place, for Yahweh will destroy the city!" But he seemed to his sons-in-law to be joking. 

###### v15 
When the morning came, then the angels hurried Lot, saying, "Get up! Take your wife and your two daughters who are here, lest you be consumed in the iniquity of the city." 

###### v16 
But he lingered; and the men grabbed his hand, his wife's hand, and his two daughters' hands, Yahweh being merciful to him; and they took him out, and set him outside of the city. 

###### v17 
It came to pass, when they had taken them out, that he said, "Escape for your life! Don't look behind you, and don't stay anywhere in the plain. Escape to the mountains, lest you be consumed!" 

###### v18 
Lot said to them, "Oh, not so, my lord. 

###### v19 
See now, your servant has found favor in your sight, and you have magnified your loving kindness, which you have shown to me in saving my life. I can't escape to the mountain, lest evil overtake me, and I die. 

###### v20 
See now, this city is near to flee to, and it is a little one. Oh let me escape there (isn't it a little one?), and my soul will live." 

###### v21 
He said to him, "Behold, I have granted your request concerning this thing also, that I will not overthrow the city of which you have spoken. 

###### v22 
Hurry, escape there, for I can't do anything until you get there." Therefore the name of the city was called Zoar. 

###### v23 
The sun had risen on the earth when Lot came to Zoar. 

###### v24 
Then Yahweh rained on Sodom and on Gomorrah sulfur and fire from Yahweh out of the sky. 

###### v25 
He overthrew those cities, all the plain, all the inhabitants of the cities, and that which grew on the ground. 

###### v26 
But Lot's wife looked back from behind him, and she became a pillar of salt. 

###### v27 
Abraham went up early in the morning to the place where he had stood before Yahweh. 

###### v28 
He looked toward Sodom and Gomorrah, and toward all the land of the plain, and saw that the smoke of the land went up as the smoke of a furnace. 

###### v29 
When God destroyed the cities of the plain, God remembered Abraham, and sent Lot out of the middle of the overthrow, when he overthrew the cities in which Lot lived. 

###### v30 
Lot went up out of Zoar, and lived in the mountain, and his two daughters with him; for he was afraid to live in Zoar. He lived in a cave with his two daughters. 

###### v31 
The firstborn said to the younger, "Our father is old, and there is not a man in the earth to come in to us in the way of all the earth. 

###### v32 
Come, let's make our father drink wine, and we will lie with him, that we may preserve our father's family line." 

###### v33 
They made their father drink wine that night: and the firstborn went in, and lay with her father. He didn't know when she lay down, nor when she arose. 

###### v34 
It came to pass on the next day, that the firstborn said to the younger, "Behold, I lay last night with my father. Let's make him drink wine again tonight. You go in, and lie with him, that we may preserve our father's family line." 

###### v35 
They made their father drink wine that night also. The younger went and lay with him. He didn't know when she lay down, nor when she got up. 

###### v36 
Thus both of Lot's daughters were with child by their father. 

###### v37 
The firstborn bore a son, and named him Moab. He is the father of the Moabites to this day. 

###### v38 
The younger also bore a son, and called his name Ben Ammi. He is the father of the children of Ammon to this day.

***
[[Gen-18|← Genesis 18]] | [[Genesis]] | [[Gen-20|Genesis 20 →]]
