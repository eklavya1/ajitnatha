# Genesis 8

[[Gen-07|← Genesis 07]] | [[Genesis]] | [[Gen-09|Genesis 09 →]]
***

###### v1
God remembered Noah, all the animals, and all the livestock that were with him in the ship; and God made a wind to pass over the earth. The waters subsided.

###### v2
The deep's fountains and the sky's windows were also stopped, and the rain from the sky was restrained.

###### v3
The waters continually receded from the earth. After the end of one hundred fifty days the waters receded.

###### v4
The ship rested in the seventh month, on the seventeenth day of the month, on Ararat's mountains.

###### v5
The waters receded continually until the tenth month. In the tenth month, on the first day of the month, the tops of the mountains were visible.

###### v6
At the end of forty days, Noah opened the window of the ship which he had made,

###### v7
and he sent out a raven. It went back and forth, until the waters were dried up from the earth.

###### v8
He himself sent out a dove to see if the waters were abated from the surface of the ground,

###### v9
but the dove found no place to rest her foot, and she returned into the ship to him, for the waters were on the surface of the whole earth. He put out his hand, and took her, and brought her to him into the ship.

###### v10
He waited yet another seven days; and again he sent the dove out of the ship.

###### v11
The dove came back to him at evening and, behold, in her mouth was a freshly plucked olive leaf. So Noah knew that the waters were abated from the earth.

###### v12
He waited yet another seven days, and sent out the dove; and she didn't return to him any more.

###### v13
In the six hundred first year, in the first month, the first day of the month, the waters were dried up from the earth. Noah removed the covering of the ship, and looked. He saw that the surface of the ground was dry.

###### v14
In the second month, on the twenty-seventh day of the month, the earth was dry.

###### v15
God spoke to Noah, saying,

###### v16
"Go out of the ship, you, your wife, your sons, and your sons' wives with you.

###### v17
Bring out with you every living thing that is with you of all flesh, including birds, livestock, and every creeping thing that creeps on the earth, that they may breed abundantly in the earth, and be fruitful, and multiply on the earth."

###### v18
Noah went out, with his sons, his wife, and his sons' wives with him.

###### v19
Every animal, every creeping thing, and every bird, whatever moves on the earth, after their families, went out of the ship.

###### v20
Noah built an altar to Yahweh, and took of every clean animal, and of every clean bird, and offered burnt offerings on the altar.

###### v21
Yahweh smelled the pleasant aroma. Yahweh said in his heart, "I will not again curse the ground any more for man's sake because the imagination of man's heart is evil from his youth. I will never again strike every living thing, as I have done.

###### v22
While the earth remains, seed time and harvest, and cold and heat, and summer and winter, and day and night will not cease."

***
[[Gen-07|← Genesis 07]] | [[Genesis]] | [[Gen-09|Genesis 09 →]]
