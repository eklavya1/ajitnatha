# Genesis 3

[[Gen-02|← Genesis 02]] | [[Genesis]] | [[Gen-04|Genesis 04 →]]
***



###### v1
Now the serpent was more subtle than any animal of the field which Yahweh God had made. He said to the woman, "Has God really said, 'You shall not eat of any tree of the garden'?"

###### v2
The woman said to the serpent, "We may eat fruit from the trees of the garden,

###### v3
but not the fruit of the tree which is in the middle of the garden. God has said, 'You shall not eat of it. You shall not touch it, lest you die.'"

###### v4
The serpent said to the woman, "You won't really die,

###### v5
for God knows that in the day you eat it, your eyes will be opened, and you will be like God, knowing good and evil."

###### v6
When the woman saw that the tree was good for food, and that it was a delight to the eyes, and that the tree was to be desired to make one wise, she took some of its fruit, and ate. Then she gave some to her husband with her, and he ate it, too.

###### v7
Their eyes were opened, and they both knew that they were naked. They sewed fig leaves together, and made coverings for themselves.

###### v8
They heard Yahweh God's voice walking in the garden in the cool of the day, and the man and his wife hid themselves from the presence of Yahweh God among the trees of the garden.

###### v9
Yahweh God called to the man, and said to him, "Where are you?"

###### v10
The man said, "I heard your voice in the garden, and I was afraid, because I was naked; so I hid myself."

###### v11
God said, "Who told you that you were naked? Have you eaten from the tree that I commanded you not to eat from?"

###### v12
The man said, "The woman whom you gave to be with me, she gave me fruit from the tree, and I ate it."

###### v13
Yahweh God said to the woman, "What have you done?" The woman said, "The serpent deceived me, and I ate."

###### v14
Yahweh God said to the serpent, "Because you have done this, you are cursed above all livestock, and above every animal of the field. You shall go on your belly and you shall eat dust all the days of your life.

###### v15
I will put hostility between you and the woman, and between your offspring and her offspring. He will bruise your head, and you will bruise his heel."

###### v16
To the woman he said, "I will greatly multiply your pain in childbirth. You will bear children in pain. Your desire will be for your husband, and he will rule over you."

###### v17
To Adam he said, "Because you have listened to your wife's voice, and have eaten from the tree, about which I commanded you, saying, 'You shall not eat of it,' the ground is cursed for your sake. You will eat from it with much labor all the days of your life.

###### v18
It will yield thorns and thistles to you; and you will eat the herb of the field.

###### v19
You will eat bread by the sweat of your face until you return to the ground, for you were taken out of it. For you are dust, and you shall return to dust."

###### v20
The man called his wife Eve because she would be the mother of all the living.

###### v21
Yahweh God made garments of animal skins for Adam and for his wife, and clothed them.

###### v22
Yahweh God said, "Behold, the man has become like one of us, knowing good and evil. Now, lest he reach out his hand, and also take of the tree of life, and eat, and live forever--"

###### v23
Therefore Yahweh God sent him out from the garden of Eden, to till the ground from which he was taken.

###### v24
So he drove out the man; and he placed cherubim at the east of the garden of Eden, and a flaming sword which turned every way, to guard the way to the tree of life.

***
[[Gen-02|← Genesis 02]] | [[Genesis]] | [[Gen-04|Genesis 04 →]]
