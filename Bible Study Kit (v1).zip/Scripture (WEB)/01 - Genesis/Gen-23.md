# Genesis 23

[[Gen-22|← Genesis 22]] | [[Genesis]] | [[Gen-24|Genesis 24 →]]
***



###### v1 
Sarah lived one hundred twenty-seven years. This was the length of Sarah's life. 

###### v2 
Sarah died in Kiriath Arba (also called Hebron), in the land of Canaan. Abraham came to mourn for Sarah, and to weep for her. 

###### v3 
Abraham rose up from before his dead and spoke to the children of Heth, saying, 

###### v4 
"I am a stranger and a foreigner living with you. Give me a possession of a burying-place with you, that I may bury my dead out of my sight." 

###### v5 
The children of Heth answered Abraham, saying to him, 

###### v6 
"Hear us, my lord. You are a prince of God among us. Bury your dead in the best of our tombs. None of us will withhold from you his tomb. Bury your dead." 

###### v7 
Abraham rose up, and bowed himself to the people of the land, to the children of Heth. 

###### v8 
He talked with them, saying, "If you agree that I should bury my dead out of my sight, hear me, and entreat for me to Ephron the son of Zohar, 

###### v9 
that he may sell me the cave of Machpelah, which he has, which is in the end of his field. For the full price let him sell it to me among you as a possession for a burial place." 

###### v10 
Now Ephron was sitting in the middle of the children of Heth. Ephron the Hittite answered Abraham in the hearing of the children of Heth, even of all who went in at the gate of his city, saying, 

###### v11 
"No, my lord, hear me. I give you the field, and I give you the cave that is in it. In the presence of the children of my people I give it to you. Bury your dead." 

###### v12 
Abraham bowed himself down before the people of the land. 

###### v13 
He spoke to Ephron in the audience of the people of the land, saying, "But if you will, please hear me. I will give the price of the field. Take it from me, and I will bury my dead there." 

###### v14 
Ephron answered Abraham, saying to him, 

###### v15 
"My lord, listen to me. What is a piece of land worth four hundred shekels of silver between me and you? Therefore bury your dead." 

###### v16 
Abraham listened to Ephron. Abraham weighed to Ephron the silver which he had named in the hearing of the children of Heth, four hundred shekels of silver, according to the current merchants' standard. 

###### v17 
So the field of Ephron, which was in Machpelah, which was before Mamre, the field, the cave which was in it, and all the trees that were in the field, that were in all of its borders, were deeded 

###### v18 
to Abraham for a possession in the presence of the children of Heth, before all who went in at the gate of his city. 

###### v19 
After this, Abraham buried Sarah his wife in the cave of the field of Machpelah before Mamre (that is, Hebron), in the land of Canaan. 

###### v20 
The field, and the cave that is in it, were deeded to Abraham by the children of Heth as a possession for a burial place.

***
[[Gen-22|← Genesis 22]] | [[Genesis]] | [[Gen-24|Genesis 24 →]]
