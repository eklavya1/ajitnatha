# Genesis 46

[[Gen-45|← Genesis 45]] | [[Genesis]] | [[Gen-47|Genesis 47 →]]
***



###### v1 
Israel traveled with all that he had, and came to Beersheba, and offered sacrifices to the God of his father, Isaac. 

###### v2 
God spoke to Israel in the visions of the night, and said, "Jacob, Jacob!" He said, "Here I am." 

###### v3 
He said, "I am God, the God of your father. Don't be afraid to go down into Egypt, for there I will make of you a great nation. 

###### v4 
I will go down with you into Egypt. I will also surely bring you up again. Joseph's hand will close your eyes." 

###### v5 
Jacob rose up from Beersheba, and the sons of Israel carried Jacob, their father, their little ones, and their wives, in the wagons which Pharaoh had sent to carry him. 

###### v6 
They took their livestock, and their goods, which they had gotten in the land of Canaan, and came into Egypt--Jacob, and all his offspring with him, 

###### v7 
his sons, and his sons' sons with him, his daughters, and his sons' daughters, and he brought all his offspring with him into Egypt. 

###### v8 
These are the names of the children of Israel, who came into Egypt, Jacob and his sons: Reuben, Jacob's firstborn. 

###### v9 
The sons of Reuben: Hanoch, Pallu, Hezron, and Carmi. 

###### v10 
The sons of Simeon: Jemuel, Jamin, Ohad, Jachin, Zohar, and Shaul the son of a Canaanite woman. 

###### v11 
The sons of Levi: Gershon, Kohath, and Merari. 

###### v12 
The sons of Judah: Er, Onan, Shelah, Perez, and Zerah; but Er and Onan died in the land of Canaan. The sons of Perez were Hezron and Hamul. 

###### v13 
The sons of Issachar: Tola, Puvah, Iob, and Shimron. 

###### v14 
The sons of Zebulun: Sered, Elon, and Jahleel. 

###### v15 
These are the sons of Leah, whom she bore to Jacob in Paddan Aram, with his daughter Dinah. All the souls of his sons and his daughters were thirty-three. 

###### v16 
The sons of Gad: Ziphion, Haggi, Shuni, Ezbon, Eri, Arodi, and Areli. 

###### v17 
The sons of Asher: Imnah, Ishvah, Ishvi, Beriah, and Serah their sister. The sons of Beriah: Heber and Malchiel. 

###### v18 
These are the sons of Zilpah, whom Laban gave to Leah, his daughter, and these she bore to Jacob, even sixteen souls. 

###### v19 
The sons of Rachel, Jacob's wife: Joseph and Benjamin. 

###### v20 
To Joseph in the land of Egypt were born Manasseh and Ephraim, whom Asenath, the daughter of Potiphera, priest of On, bore to him. 

###### v21 
The sons of Benjamin: Bela, Becher, Ashbel, Gera, Naaman, Ehi, Rosh, Muppim, Huppim, and Ard. 

###### v22 
These are the sons of Rachel, who were born to Jacob: all the souls were fourteen. 

###### v23 
The son of Dan: Hushim. 

###### v24 
The sons of Naphtali: Jahzeel, Guni, Jezer, and Shillem. 

###### v25 
These are the sons of Bilhah, whom Laban gave to Rachel, his daughter, and these she bore to Jacob: all the souls were seven. 

###### v26 
All the souls who came with Jacob into Egypt, who were his direct offspring, in addition to Jacob's sons' wives, all the souls were sixty-six. 

###### v27 
The sons of Joseph, who were born to him in Egypt, were two souls. All the souls of the house of Jacob, who came into Egypt, were seventy. 

###### v28 
Jacob sent Judah before him to Joseph, to show the way before him to Goshen, and they came into the land of Goshen. 

###### v29 
Joseph prepared his chariot, and went up to meet Israel, his father, in Goshen. He presented himself to him, and fell on his neck, and wept on his neck a good while. 

###### v30 
Israel said to Joseph, "Now let me die, since I have seen your face, that you are still alive." 

###### v31 
Joseph said to his brothers, and to his father's house, "I will go up, and speak with Pharaoh, and will tell him, 'My brothers, and my father's house, who were in the land of Canaan, have come to me. 

###### v32 
These men are shepherds, for they have been keepers of livestock, and they have brought their flocks, and their herds, and all that they have.' 

###### v33 
It will happen, when Pharaoh summons you, and will say, 'What is your occupation?' 

###### v34 
that you shall say, 'Your servants have been keepers of livestock from our youth even until now, both we, and our fathers:' that you may dwell in the land of Goshen; for every shepherd is an abomination to the Egyptians."

***
[[Gen-45|← Genesis 45]] | [[Genesis]] | [[Gen-47|Genesis 47 →]]
