# Genesis 30

[[Gen-29|← Genesis 29]] | [[Genesis]] | [[Gen-31|Genesis 31 →]]
***



###### v1 
When Rachel saw that she bore Jacob no children, Rachel envied her sister. She said to Jacob, "Give me children, or else I will die." 

###### v2 
Jacob's anger burned against Rachel, and he said, "Am I in God's place, who has withheld from you the fruit of the womb?" 

###### v3 
She said, "Behold, my maid Bilhah. Go in to her, that she may bear on my knees, and I also may obtain children by her." 

###### v4 
She gave him Bilhah her servant as wife, and Jacob went in to her. 

###### v5 
Bilhah conceived, and bore Jacob a son. 

###### v6 
Rachel said, "God has judged me, and has also heard my voice, and has given me a son." Therefore she called his name Dan. 

###### v7 
Bilhah, Rachel's servant, conceived again, and bore Jacob a second son. 

###### v8 
Rachel said, "I have wrestled with my sister with mighty wrestlings, and have prevailed." She named him Naphtali. 

###### v9 
When Leah saw that she had finished bearing, she took Zilpah, her servant, and gave her to Jacob as a wife. 

###### v10 
Zilpah, Leah's servant, bore Jacob a son. 

###### v11 
Leah said, "How fortunate!" She named him Gad. 

###### v12 
Zilpah, Leah's servant, bore Jacob a second son. 

###### v13 
Leah said, "Happy am I, for the daughters will call me happy." She named him Asher. 

###### v14 
Reuben went in the days of wheat harvest, and found mandrakes in the field, and brought them to his mother, Leah. Then Rachel said to Leah, "Please give me some of your son's mandrakes." 

###### v15 
Leah said to her, "Is it a small matter that you have taken away my husband? Would you take away my son's mandrakes, also?" Rachel said, "Therefore he will lie with you tonight for your son's mandrakes." 

###### v16 
Jacob came from the field in the evening, and Leah went out to meet him, and said, "You must come in to me; for I have surely hired you with my son's mandrakes." He lay with her that night. 

###### v17 
God listened to Leah, and she conceived, and bore Jacob a fifth son. 

###### v18 
Leah said, "God has given me my hire, because I gave my servant to my husband." She named him Issachar. 

###### v19 
Leah conceived again, and bore a sixth son to Jacob. 

###### v20 
Leah said, "God has endowed me with a good dowry. Now my husband will live with me, because I have borne him six sons." She named him Zebulun. 

###### v21 
Afterwards, she bore a daughter, and named her Dinah. 

###### v22 
God remembered Rachel, and God listened to her, and opened her womb. 

###### v23 
She conceived, bore a son, and said, "God has taken away my reproach." 

###### v24 
She named him Joseph, saying, "May Yahweh add another son to me." 

###### v25 
When Rachel had borne Joseph, Jacob said to Laban, "Send me away, that I may go to my own place, and to my country. 

###### v26 
Give me my wives and my children for whom I have served you, and let me go; for you know my service with which I have served you." 

###### v27 
Laban said to him, "If now I have found favor in your eyes, stay here, for I have divined that Yahweh has blessed me for your sake." 

###### v28 
He said, "Appoint me your wages, and I will give it." 

###### v29 
Jacob said to him, "You know how I have served you, and how your livestock have fared with me. 

###### v30 
For it was little which you had before I came, and it has increased to a multitude. Yahweh has blessed you wherever I turned. Now when will I provide for my own house also?" 

###### v31 
Laban said, "What shall I give you?" Jacob said, "You shall not give me anything. If you will do this thing for me, I will again feed your flock and keep it. 

###### v32 
I will pass through all your flock today, removing from there every speckled and spotted one, and every black one among the sheep, and the spotted and speckled among the goats. This will be my hire. 

###### v33 
So my righteousness will answer for me hereafter, when you come concerning my hire that is before you. Every one that is not speckled and spotted among the goats, and black among the sheep, that might be with me, will be considered stolen." 

###### v34 
Laban said, "Behold, let it be according to your word." 

###### v35 
That day, he removed the male goats that were streaked and spotted, and all the female goats that were speckled and spotted, every one that had white in it, and all the black ones among the sheep, and gave them into the hand of his sons. 

###### v36 
He set three days' journey between himself and Jacob, and Jacob fed the rest of Laban's flocks. 

###### v37 
Jacob took to himself rods of fresh poplar, almond, and plane tree, peeled white streaks in them, and made the white appear which was in the rods. 

###### v38 
He set the rods which he had peeled opposite the flocks in the watering troughs where the flocks came to drink. They conceived when they came to drink. 

###### v39 
The flocks conceived before the rods, and the flocks produced streaked, speckled, and spotted. 

###### v40 
Jacob separated the lambs, and set the faces of the flocks toward the streaked and all the black in Laban's flock. He put his own droves apart, and didn't put them into Laban's flock. 

###### v41 
Whenever the stronger of the flock conceived, Jacob laid the rods in front of the eyes of the flock in the watering troughs, that they might conceive among the rods; 

###### v42 
but when the flock were feeble, he didn't put them in. So the feebler were Laban's, and the stronger Jacob's. 

###### v43 
The man increased exceedingly, and had large flocks, female servants and male servants, and camels and donkeys.

***
[[Gen-29|← Genesis 29]] | [[Genesis]] | [[Gen-31|Genesis 31 →]]
