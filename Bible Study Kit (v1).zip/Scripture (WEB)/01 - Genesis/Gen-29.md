# Genesis 29

[[Gen-28|← Genesis 28]] | [[Genesis]] | [[Gen-30|Genesis 30 →]]
***



###### v1 
Then Jacob went on his journey, and came to the land of the children of the east. 

###### v2 
He looked, and saw a well in the field, and saw three flocks of sheep lying there by it. For out of that well they watered the flocks. The stone on the well's mouth was large. 

###### v3 
There all the flocks were gathered. They rolled the stone from the well's mouth, and watered the sheep, and put the stone back on the well's mouth in its place. 

###### v4 
Jacob said to them, "My relatives, where are you from?" They said, "We are from Haran." 

###### v5 
He said to them, "Do you know Laban, the son of Nahor?" They said, "We know him." 

###### v6 
He said to them, "Is it well with him?" They said, "It is well. See, Rachel, his daughter, is coming with the sheep." 

###### v7 
He said, "Behold, it is still the middle of the day, not time to gather the livestock together. Water the sheep, and go and feed them." 

###### v8 
They said, "We can't, until all the flocks are gathered together, and they roll the stone from the well's mouth. Then we will water the sheep." 

###### v9 
While he was yet speaking with them, Rachel came with her father's sheep, for she kept them. 

###### v10 
When Jacob saw Rachel the daughter of Laban, his mother's brother, and the sheep of Laban, his mother's brother, Jacob went near, and rolled the stone from the well's mouth, and watered the flock of Laban his mother's brother. 

###### v11 
Jacob kissed Rachel, and lifted up his voice, and wept. 

###### v12 
Jacob told Rachel that he was her father's relative, and that he was Rebekah's son. She ran and told her father. 

###### v13 
When Laban heard the news of Jacob, his sister's son, he ran to meet Jacob, and embraced him, and kissed him, and brought him to his house. Jacob told Laban all these things. 

###### v14 
Laban said to him, "Surely you are my bone and my flesh." Jacob stayed with him for a month. 

###### v15 
Laban said to Jacob, "Because you are my relative, should you therefore serve me for nothing? Tell me, what will your wages be?" 

###### v16 
Laban had two daughters. The name of the elder was Leah, and the name of the younger was Rachel. 

###### v17 
Leah's eyes were weak, but Rachel was beautiful in form and attractive. 

###### v18 
Jacob loved Rachel. He said, "I will serve you seven years for Rachel, your younger daughter." 

###### v19 
Laban said, "It is better that I give her to you, than that I should give her to another man. Stay with me." 

###### v20 
Jacob served seven years for Rachel. They seemed to him but a few days, for the love he had for her. 

###### v21 
Jacob said to Laban, "Give me my wife, for my days are fulfilled, that I may go in to her." 

###### v22 
Laban gathered together all the men of the place, and made a feast. 

###### v23 
In the evening, he took Leah his daughter, and brought her to Jacob. He went in to her. 

###### v24 
Laban gave Zilpah his servant to his daughter Leah for a servant. 

###### v25 
In the morning, behold, it was Leah! He said to Laban, "What is this you have done to me? Didn't I serve with you for Rachel? Why then have you deceived me?" 

###### v26 
Laban said, "It is not done so in our place, to give the younger before the firstborn. 

###### v27 
Fulfill the week of this one, and we will give you the other also for the service which you will serve with me for seven more years." 

###### v28 
Jacob did so, and fulfilled her week. He gave him Rachel his daughter as wife. 

###### v29 
Laban gave Bilhah, his servant, to his daughter Rachel to be her servant. 

###### v30 
He went in also to Rachel, and he loved also Rachel more than Leah, and served with him seven more years. 

###### v31 
Yahweh saw that Leah was hated, and he opened her womb, but Rachel was barren. 

###### v32 
Leah conceived, and bore a son, and she named him Reuben. For she said, "Because Yahweh has looked at my affliction; for now my husband will love me." 

###### v33 
She conceived again, and bore a son, and said, "Because Yahweh has heard that I am hated, he has therefore given me this son also." She named him Simeon. 

###### v34 
She conceived again, and bore a son. She said, "Now this time my husband will be joined to me, because I have borne him three sons." Therefore his name was called Levi. 

###### v35 
She conceived again, and bore a son. She said, "This time I will praise Yahweh." Therefore she named him Judah. Then she stopped bearing.

***
[[Gen-28|← Genesis 28]] | [[Genesis]] | [[Gen-30|Genesis 30 →]]
