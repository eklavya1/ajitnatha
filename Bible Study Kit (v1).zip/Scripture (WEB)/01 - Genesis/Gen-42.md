# Genesis 42

[[Gen-41|← Genesis 41]] | [[Genesis]] | [[Gen-43|Genesis 43 →]]
***



###### v1 
Now Jacob saw that there was grain in Egypt, and Jacob said to his sons, "Why do you look at one another?" 

###### v2 
He said, "Behold, I have heard that there is grain in Egypt. Go down there, and buy for us from there, so that we may live, and not die." 

###### v3 
Joseph's ten brothers went down to buy grain from Egypt. 

###### v4 
But Jacob didn't send Benjamin, Joseph's brother, with his brothers; for he said, "Lest perhaps harm happen to him." 

###### v5 
The sons of Israel came to buy among those who came, for the famine was in the land of Canaan. 

###### v6 
Joseph was the governor over the land. It was he who sold to all the people of the land. Joseph's brothers came, and bowed themselves down to him with their faces to the earth. 

###### v7 
Joseph saw his brothers, and he recognized them, but acted like a stranger to them, and spoke roughly with them. He said to them, "Where did you come from?" They said, "From the land of Canaan, to buy food." 

###### v8 
Joseph recognized his brothers, but they didn't recognize him. 

###### v9 
Joseph remembered the dreams which he dreamed about them, and said to them, "You are spies! You have come to see the nakedness of the land." 

###### v10 
They said to him, "No, my lord, but your servants have come to buy food. 

###### v11 
We are all one man's sons; we are honest men. Your servants are not spies." 

###### v12 
He said to them, "No, but you have come to see the nakedness of the land!" 

###### v13 
They said, "We, your servants, are twelve brothers, the sons of one man in the land of Canaan; and behold, the youngest is today with our father, and one is no more." 

###### v14 
Joseph said to them, "It is like I told you, saying, 'You are spies!' 

###### v15 
By this you shall be tested. By the life of Pharaoh, you shall not go out from here, unless your youngest brother comes here. 

###### v16 
Send one of you, and let him get your brother, and you shall be bound, that your words may be tested, whether there is truth in you, or else by the life of Pharaoh surely you are spies." 

###### v17 
He put them all together into custody for three days. 

###### v18 
Joseph said to them the third day, "Do this, and live, for I fear God. 

###### v19 
If you are honest men, then let one of your brothers be bound in your prison; but you go, carry grain for the famine of your houses. 

###### v20 
Bring your youngest brother to me; so will your words be verified, and you won't die." They did so. 

###### v21 
They said to one another, "We are certainly guilty concerning our brother, in that we saw the distress of his soul, when he begged us, and we wouldn't listen. Therefore this distress has come upon us." 

###### v22 
Reuben answered them, saying, "Didn't I tell you, saying, 'Don't sin against the child,' and you wouldn't listen? Therefore also, behold, his blood is required." 

###### v23 
They didn't know that Joseph understood them; for there was an interpreter between them. 

###### v24 
He turned himself away from them, and wept. Then he returned to them, and spoke to them, and took Simeon from among them, and bound him before their eyes. 

###### v25 
Then Joseph gave a command to fill their bags with grain, and to restore each man's money into his sack, and to give them food for the way. So it was done to them. 

###### v26 
They loaded their donkeys with their grain, and departed from there. 

###### v27 
As one of them opened his sack to give his donkey food in the lodging place, he saw his money. Behold, it was in the mouth of his sack. 

###### v28 
He said to his brothers, "My money is restored! Behold, it is in my sack!" Their hearts failed them, and they turned trembling to one another, saying, "What is this that God has done to us?" 

###### v29 
They came to Jacob their father, to the land of Canaan, and told him all that had happened to them, saying, 

###### v30 
"The man, the lord of the land, spoke roughly with us, and took us for spies of the country. 

###### v31 
We said to him, 'We are honest men. We are no spies. 

###### v32 
We are twelve brothers, sons of our father; one is no more, and the youngest is today with our father in the land of Canaan.' 

###### v33 
The man, the lord of the land, said to us, 'By this I will know that you are honest men: leave one of your brothers with me, and take grain for the famine of your houses, and go your way. 

###### v34 
Bring your youngest brother to me. Then I will know that you are not spies, but that you are honest men. So I will deliver your brother to you, and you shall trade in the land.'" 

###### v35 
As they emptied their sacks, behold, each man's bundle of money was in his sack. When they and their father saw their bundles of money, they were afraid. 

###### v36 
Jacob, their father, said to them, "You have bereaved me of my children! Joseph is no more, Simeon is no more, and you want to take Benjamin away. All these things are against me." 

###### v37 
Reuben spoke to his father, saying, "Kill my two sons, if I don't bring him to you. Entrust him to my care, and I will bring him to you again." 

###### v38 
He said, "My son shall not go down with you; for his brother is dead, and he only is left. If harm happens to him along the way in which you go, then you will bring down my gray hairs with sorrow to Sheol."

***
[[Gen-41|← Genesis 41]] | [[Genesis]] | [[Gen-43|Genesis 43 →]]
