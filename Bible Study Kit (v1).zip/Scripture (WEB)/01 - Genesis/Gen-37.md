# Genesis 37

[[Gen-36|← Genesis 36]] | [[Genesis]] | [[Gen-38|Genesis 38 →]]
***



###### v1 
Jacob lived in the land of his father's travels, in the land of Canaan. 

###### v2 
This is the history of the generations of Jacob. Joseph, being seventeen years old, was feeding the flock with his brothers. He was a boy with the sons of Bilhah and Zilpah, his father's wives. Joseph brought an evil report of them to their father. 

###### v3 
Now Israel loved Joseph more than all his children, because he was the son of his old age, and he made him a tunic of many colors. 

###### v4 
His brothers saw that their father loved him more than all his brothers, and they hated him, and couldn't speak peaceably to him. 

###### v5 
Joseph dreamed a dream, and he told it to his brothers, and they hated him all the more. 

###### v6 
He said to them, "Please hear this dream which I have dreamed: 

###### v7 
for behold, we were binding sheaves in the field, and behold, my sheaf arose and also stood upright; and behold, your sheaves came around, and bowed down to my sheaf." 

###### v8 
His brothers asked him, "Will you indeed reign over us? Will you indeed have dominion over us?" They hated him all the more for his dreams and for his words. 

###### v9 
He dreamed yet another dream, and told it to his brothers, and said, "Behold, I have dreamed yet another dream: and behold, the sun and the moon and eleven stars bowed down to me." 

###### v10 
He told it to his father and to his brothers. His father rebuked him, and said to him, "What is this dream that you have dreamed? Will I and your mother and your brothers indeed come to bow ourselves down to the earth before you?" 

###### v11 
His brothers envied him, but his father kept this saying in mind. 

###### v12 
His brothers went to feed their father's flock in Shechem. 

###### v13 
Israel said to Joseph, "Aren't your brothers feeding the flock in Shechem? Come, and I will send you to them." He said to him, "Here I am." 

###### v14 
He said to him, "Go now, see whether it is well with your brothers, and well with the flock; and bring me word again." So he sent him out of the valley of Hebron, and he came to Shechem. 

###### v15 
A certain man found him, and behold, he was wandering in the field. The man asked him, "What are you looking for?" 

###### v16 
He said, "I am looking for my brothers. Tell me, please, where they are feeding the flock." 

###### v17 
The man said, "They have left here, for I heard them say, 'Let's go to Dothan.'" Joseph went after his brothers, and found them in Dothan. 

###### v18 
They saw him afar off, and before he came near to them, they conspired against him to kill him. 

###### v19 
They said to one another, "Behold, this dreamer comes. 

###### v20 
Come now therefore, and let's kill him, and cast him into one of the pits, and we will say, 'An evil animal has devoured him.' We will see what will become of his dreams." 

###### v21 
Reuben heard it, and delivered him out of their hand, and said, "Let's not take his life." 

###### v22 
Reuben said to them, "Shed no blood. Throw him into this pit that is in the wilderness, but lay no hand on him"--that he might deliver him out of their hand, to restore him to his father. 

###### v23 
When Joseph came to his brothers, they stripped Joseph of his tunic, the tunic of many colors that was on him; 

###### v24 
and they took him, and threw him into the pit. The pit was empty. There was no water in it. 

###### v25 
They sat down to eat bread, and they lifted up their eyes and looked, and saw a caravan of Ishmaelites was coming from Gilead, with their camels bearing spices and balm and myrrh, going to carry it down to Egypt. 

###### v26 
Judah said to his brothers, "What profit is it if we kill our brother and conceal his blood? 

###### v27 
Come, and let's sell him to the Ishmaelites, and not let our hand be on him; for he is our brother, our flesh." His brothers listened to him. 

###### v28 
Midianites who were merchants passed by, and they drew and lifted up Joseph out of the pit, and sold Joseph to the Ishmaelites for twenty pieces of silver. The merchants brought Joseph into Egypt. 

###### v29 
Reuben returned to the pit, and saw that Joseph wasn't in the pit; and he tore his clothes. 

###### v30 
He returned to his brothers, and said, "The child is no more; and I, where will I go?" 

###### v31 
They took Joseph's tunic, and killed a male goat, and dipped the tunic in the blood. 

###### v32 
They took the tunic of many colors, and they brought it to their father, and said, "We have found this. Examine it, now, and see if it is your son's tunic or not." 

###### v33 
He recognized it, and said, "It is my son's tunic. An evil animal has devoured him. Joseph is without doubt torn in pieces." 

###### v34 
Jacob tore his clothes, and put sackcloth on his waist, and mourned for his son many days. 

###### v35 
All his sons and all his daughters rose up to comfort him, but he refused to be comforted. He said, "For I will go down to Sheol to my son, mourning." His father wept for him. 

###### v36 
The Midianites sold him into Egypt to Potiphar, an officer of Pharaoh's, the captain of the guard.

***
[[Gen-36|← Genesis 36]] | [[Genesis]] | [[Gen-38|Genesis 38 →]]
