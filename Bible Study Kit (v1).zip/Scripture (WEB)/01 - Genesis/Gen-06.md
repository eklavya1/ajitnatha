# Genesis 6

[[Gen-05|← Genesis 05]] | [[Genesis]] | [[Gen-07|Genesis 07 →]]
***



###### v1 
When men began to multiply on the surface of the ground, and daughters were born to them, 

###### v2 
God's sons saw that men's daughters were beautiful, and they took any that they wanted for themselves as wives. 

###### v3 
Yahweh said, "My Spirit will not strive with man forever, because he also is flesh; so his days will be one hundred twenty years." 

###### v4 
The Nephilim were in the earth in those days, and also after that, when God's sons came in to men's daughters and had children with them. Those were the mighty men who were of old, men of renown. 

###### v5 
Yahweh saw that the wickedness of man was great in the earth, and that every imagination of the thoughts of man's heart was continually only evil. 

###### v6 
Yahweh was sorry that he had made man on the earth, and it grieved him in his heart. 

###### v7 
Yahweh said, "I will destroy man whom I have created from the surface of the ground--man, along with animals, creeping things, and birds of the sky--for I am sorry that I have made them." 

###### v8 
But Noah found favor in Yahweh's eyes. 

###### v9 
This is the history of the generations of Noah: Noah was a righteous man, blameless among the people of his time. Noah walked with God. 

###### v10 
Noah became the father of three sons: Shem, Ham, and Japheth. 

###### v11 
The earth was corrupt before God, and the earth was filled with violence. 

###### v12 
God saw the earth, and saw that it was corrupt, for all flesh had corrupted their way on the earth. 

###### v13 
God said to Noah, "I will bring an end to all flesh, for the earth is filled with violence through them. Behold, I will destroy them and the earth. 

###### v14 
Make a ship of gopher wood. You shall make rooms in the ship, and shall seal it inside and outside with pitch. 

###### v15 
This is how you shall make it. The length of the ship shall be three hundred cubits, its width fifty cubits, and its height thirty cubits. 

###### v16 
You shall make a roof in the ship, and you shall finish it to a cubit upward. You shall set the door of the ship in its side. You shall make it with lower, second, and third levels. 

###### v17 
I, even I, will bring the flood of waters on this earth, to destroy all flesh having the breath of life from under the sky. Everything that is in the earth will die. 

###### v18 
But I will establish my covenant with you. You shall come into the ship, you, your sons, your wife, and your sons' wives with you. 

###### v19 
Of every living thing of all flesh, you shall bring two of every sort into the ship, to keep them alive with you. They shall be male and female. 

###### v20 
Of the birds after their kind, of the livestock after their kind, of every creeping thing of the ground after its kind, two of every sort will come to you, to keep them alive. 

###### v21 
Take with you some of all food that is eaten, and gather it to yourself; and it will be for food for you, and for them." 

###### v22 
Thus Noah did. He did all that God commanded him.

***
[[Gen-05|← Genesis 05]] | [[Genesis]] | [[Gen-07|Genesis 07 →]]
