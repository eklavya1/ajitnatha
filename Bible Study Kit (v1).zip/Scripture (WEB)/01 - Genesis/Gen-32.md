# Genesis 32

[[Gen-31|← Genesis 31]] | [[Genesis]] | [[Gen-33|Genesis 33 →]]
***



###### v1 
Jacob went on his way, and the angels of God met him. 

###### v2 
When he saw them, Jacob said, "This is God's army." He called the name of that place Mahanaim. 

###### v3 
Jacob sent messengers in front of him to Esau, his brother, to the land of Seir, the field of Edom. 

###### v4 
He commanded them, saying, "This is what you shall tell my lord, Esau: 'This is what your servant, Jacob, says. I have lived as a foreigner with Laban, and stayed until now. 

###### v5 
I have cattle, donkeys, flocks, male servants, and female servants. I have sent to tell my lord, that I may find favor in your sight.'" 

###### v6 
The messengers returned to Jacob, saying, "We came to your brother Esau. He is coming to meet you, and four hundred men are with him." 

###### v7 
Then Jacob was greatly afraid and was distressed. He divided the people who were with him, along with the flocks, the herds, and the camels, into two companies. 

###### v8 
He said, "If Esau comes to the one company, and strikes it, then the company which is left will escape." 

###### v9 
Jacob said, "God of my father Abraham, and God of my father Isaac, Yahweh, who said to me, 'Return to your country, and to your relatives, and I will do you good,' 

###### v10 
I am not worthy of the least of all the loving kindnesses, and of all the truth, which you have shown to your servant; for with just my staff I crossed over this Jordan; and now I have become two companies. 

###### v11 
Please deliver me from the hand of my brother, from the hand of Esau; for I fear him, lest he come and strike me and the mothers with the children. 

###### v12 
You said, 'I will surely do you good, and make your offspring as the sand of the sea, which can't be counted because there are so many.'" 

###### v13 
He stayed there that night, and took from that which he had with him a present for Esau, his brother: 

###### v14 
two hundred female goats and twenty male goats, two hundred ewes and twenty rams, 

###### v15 
thirty milk camels and their colts, forty cows, ten bulls, twenty female donkeys and ten foals. 

###### v16 
He delivered them into the hands of his servants, every herd by itself, and said to his servants, "Pass over before me, and put a space between herd and herd." 

###### v17 
He commanded the foremost, saying, "When Esau, my brother, meets you, and asks you, saying, 'Whose are you? Where are you going? Whose are these before you?' 

###### v18 
Then you shall say, 'They are your servant, Jacob's. It is a present sent to my lord, Esau. Behold, he also is behind us.'" 

###### v19 
He commanded also the second, and the third, and all that followed the herds, saying, "This is how you shall speak to Esau, when you find him. 

###### v20 
You shall say, 'Not only that, but behold, your servant, Jacob, is behind us.'" For, he said, "I will appease him with the present that goes before me, and afterward I will see his face. Perhaps he will accept me." 

###### v21 
So the present passed over before him, and he himself stayed that night in the camp. 

###### v22 
He rose up that night, and took his two wives, and his two servants, and his eleven sons, and crossed over the ford of the Jabbok. 

###### v23 
He took them, and sent them over the stream, and sent over that which he had. 

###### v24 
Jacob was left alone, and wrestled with a man there until the breaking of the day. 

###### v25 
When he saw that he didn't prevail against him, the man touched the hollow of his thigh, and the hollow of Jacob's thigh was strained as he wrestled. 

###### v26 
The man said, "Let me go, for the day breaks." Jacob said, "I won't let you go unless you bless me." 

###### v27 
He said to him, "What is your name?" He said, "Jacob". 

###### v28 
He said, "Your name will no longer be called Jacob, but Israel; for you have fought with God and with men, and have prevailed." 

###### v29 
Jacob asked him, "Please tell me your name." He said, "Why is it that you ask what my name is?" So he blessed him there. 

###### v30 
Jacob called the name of the place Peniel; for he said, "I have seen God face to face, and my life is preserved." 

###### v31 
The sun rose on him as he passed over Peniel, and he limped because of his thigh. 

###### v32 
Therefore the children of Israel don't eat the sinew of the hip, which is on the hollow of the thigh, to this day, because he touched the hollow of Jacob's thigh in the sinew of the hip.

***
[[Gen-31|← Genesis 31]] | [[Genesis]] | [[Gen-33|Genesis 33 →]]
