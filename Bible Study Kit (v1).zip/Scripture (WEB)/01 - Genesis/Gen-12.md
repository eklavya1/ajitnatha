# Genesis 12

[[Gen-11|← Genesis 11]] | [[Genesis]] | [[Gen-13|Genesis 13 →]]
***



###### v1 
Now Yahweh said to Abram, "Leave your country, and your relatives, and your father's house, and go to the land that I will show you. 

###### v2 
I will make of you a great nation. I will bless you and make your name great. You will be a blessing. 

###### v3 
I will bless those who bless you, and I will curse him who treats you with contempt. All the families of the earth will be blessed through you." 

###### v4 
So Abram went, as Yahweh had told him. Lot went with him. Abram was seventy-five years old when he departed from Haran. 

###### v5 
Abram took Sarai his wife, Lot his brother's son, all their possessions that they had gathered, and the people whom they had acquired in Haran, and they went to go into the land of Canaan. They entered into the land of Canaan. 

###### v6 
Abram passed through the land to the place of Shechem, to the oak of Moreh. At that time, Canaanites were in the land. 

###### v7 
Yahweh appeared to Abram and said, "I will give this land to your offspring." He built an altar there to Yahweh, who had appeared to him. 

###### v8 
He left from there to go to the mountain on the east of Bethel and pitched his tent, having Bethel on the west, and Ai on the east. There he built an altar to Yahweh and called on Yahweh's name. 

###### v9 
Abram traveled, still going on toward the South. 

###### v10 
There was a famine in the land. Abram went down into Egypt to live as a foreigner there, for the famine was severe in the land. 

###### v11 
When he had come near to enter Egypt, he said to Sarai his wife, "See now, I know that you are a beautiful woman to look at. 

###### v12 
It will happen that when the Egyptians see you, they will say, 'This is his wife.' They will kill me, but they will save you alive. 

###### v13 
Please say that you are my sister, that it may be well with me for your sake, and that my soul may live because of you." 

###### v14 
When Abram had come into Egypt, Egyptians saw that the woman was very beautiful. 

###### v15 
The princes of Pharaoh saw her, and praised her to Pharaoh; and the woman was taken into Pharaoh's house. 

###### v16 
He dealt well with Abram for her sake. He had sheep, cattle, male donkeys, male servants, female servants, female donkeys, and camels. 

###### v17 
Yahweh afflicted Pharaoh and his house with great plagues because of Sarai, Abram's wife. 

###### v18 
Pharaoh called Abram and said, "What is this that you have done to me? Why didn't you tell me that she was your wife? 

###### v19 
Why did you say, 'She is my sister,' so that I took her to be my wife? Now therefore, see your wife, take her, and go your way." 

###### v20 
Pharaoh commanded men concerning him, and they escorted him away with his wife and all that he had.

***
[[Gen-11|← Genesis 11]] | [[Genesis]] | [[Gen-13|Genesis 13 →]]
