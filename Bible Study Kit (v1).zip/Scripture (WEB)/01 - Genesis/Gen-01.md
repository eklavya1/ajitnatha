# Genesis 1

[[Genesis]] | [[Gen-02|Genesis 02 →]]
***

###### v1
In the beginning, God created the heavens and the earth.

###### v2
The earth was formless and empty. Darkness was on the surface of the deep and God's Spirit was hovering over the surface of the waters.

###### v3
God said, "Let there be light," and there was light.

###### v4
God saw the light, and saw that it was good. God divided the light from the darkness.

###### v5
God called the light "day", and the darkness he called "night". There was evening and there was morning, the first day.

###### v6
God said, "Let there be an expanse in the middle of the waters, and let it divide the waters from the waters."

###### v7
God made the expanse, and divided the waters which were under the expanse from the waters which were above the expanse; and it was so.

###### v8
God called the expanse "sky". There was evening and there was morning, a second day.

###### v9
God said, "Let the waters under the sky be gathered together to one place, and let the dry land appear;" and it was so.

###### v10
God called the dry land "earth", and the gathering together of the waters he called "seas". God saw that it was good.

###### v11
God said, "Let the earth yield grass, herbs yielding seeds, and fruit trees bearing fruit after their kind, with their seeds in it, on the earth;" and it was so.

###### v12
The earth yielded grass, herbs yielding seed after their kind, and trees bearing fruit, with their seeds in it, after their kind; and God saw that it was good.

###### v13
There was evening and there was morning, a third day.

###### v14
God said, "Let there be lights in the expanse of the sky to divide the day from the night; and let them be for signs to mark seasons, days, and years;

###### v15
and let them be for lights in the expanse of the sky to give light on the earth;" and it was so.

###### v16
God made the two great lights: the greater light to rule the day, and the lesser light to rule the night. He also made the stars.

###### v17
God set them in the expanse of the sky to give light to the earth,

###### v18
and to rule over the day and over the night, and to divide the light from the darkness. God saw that it was good.

###### v19
There was evening and there was morning, a fourth day.

###### v20
God said, "Let the waters abound with living creatures, and let birds fly above the earth in the open expanse of the sky."

###### v21
God created the large sea creatures and every living creature that moves, with which the waters swarmed, after their kind, and every winged bird after its kind. God saw that it was good.

###### v22
God blessed them, saying, "Be fruitful, and multiply, and fill the waters in the seas, and let birds multiply on the earth."

###### v23
There was evening and there was morning, a fifth day.

###### v24
God said, "Let the earth produce living creatures after their kind, livestock, creeping things, and animals of the earth after their kind;" and it was so.

###### v25
God made the animals of the earth after their kind, and the livestock after their kind, and everything that creeps on the ground after its kind. God saw that it was good.

###### v26
God said, "Let's make man in our image, after our likeness. Let them have dominion over the fish of the sea, and over the birds of the sky, and over the livestock, and over all the earth, and over every creeping thing that creeps on the earth."

###### v27
God created man in his own image. In God's image he created him; male and female he created them.

###### v28
God blessed them. God said to them, "Be fruitful, multiply, fill the earth, and subdue it. Have dominion over the fish of the sea, over the birds of the sky, and over every living thing that moves on the earth."

###### v29
God said, "Behold, I have given you every herb yielding seed, which is on the surface of all the earth, and every tree, which bears fruit yielding seed. It will be your food.

###### v30
To every animal of the earth, and to every bird of the sky, and to everything that creeps on the earth, in which there is life, I have given every green herb for food;" and it was so.

###### v31
God saw everything that he had made, and, behold, it was very good. There was evening and there was morning, a sixth day.

***
[[Genesis]] | [[Gen-02|Genesis 02 →]]
