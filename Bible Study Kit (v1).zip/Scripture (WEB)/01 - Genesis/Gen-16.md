# Genesis 16

[[Gen-15|← Genesis 15]] | [[Genesis]] | [[Gen-17|Genesis 17 →]]
***



###### v1 
Now Sarai, Abram's wife, bore him no children. She had a servant, an Egyptian, whose name was Hagar. 

###### v2 
Sarai said to Abram, "See now, Yahweh has restrained me from bearing. Please go in to my servant. It may be that I will obtain children by her." Abram listened to the voice of Sarai. 

###### v3 
Sarai, Abram's wife, took Hagar the Egyptian, her servant, after Abram had lived ten years in the land of Canaan, and gave her to Abram her husband to be his wife. 

###### v4 
He went in to Hagar, and she conceived. When she saw that she had conceived, her mistress was despised in her eyes. 

###### v5 
Sarai said to Abram, "This wrong is your fault. I gave my servant into your bosom, and when she saw that she had conceived, she despised me. May Yahweh judge between me and you." 

###### v6 
But Abram said to Sarai, "Behold, your maid is in your hand. Do to her whatever is good in your eyes." Sarai dealt harshly with her, and she fled from her face. 

###### v7 
Yahweh's angel found her by a fountain of water in the wilderness, by the fountain on the way to Shur. 

###### v8 
He said, "Hagar, Sarai's servant, where did you come from? Where are you going?" She said, "I am fleeing from the face of my mistress Sarai." 

###### v9 
Yahweh's angel said to her, "Return to your mistress, and submit yourself under her hands." 

###### v10 
Yahweh's angel said to her, "I will greatly multiply your offspring, that they will not be counted for multitude." 

###### v11 
Yahweh's angel said to her, "Behold, you are with child, and will bear a son. You shall call his name Ishmael, because Yahweh has heard your affliction. 

###### v12 
He will be like a wild donkey among men. His hand will be against every man, and every man's hand against him. He will live opposed to all of his brothers." 

###### v13 
She called the name of Yahweh who spoke to her, "You are a God who sees," for she said, "Have I even stayed alive after seeing him?" 

###### v14 
Therefore the well was called Beer Lahai Roi. Behold, it is between Kadesh and Bered. 

###### v15 
Hagar bore a son for Abram. Abram called the name of his son, whom Hagar bore, Ishmael. 

###### v16 
Abram was eighty-six years old when Hagar bore Ishmael to Abram.

***
[[Gen-15|← Genesis 15]] | [[Genesis]] | [[Gen-17|Genesis 17 →]]
