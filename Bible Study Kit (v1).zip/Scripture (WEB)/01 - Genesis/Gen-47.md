# Genesis 47

[[Gen-46|← Genesis 46]] | [[Genesis]] | [[Gen-48|Genesis 48 →]]
***



###### v1 
Then Joseph went in and told Pharaoh, and said, "My father and my brothers, with their flocks, their herds, and all that they own, have come out of the land of Canaan; and behold, they are in the land of Goshen." 

###### v2 
From among his brothers he took five men, and presented them to Pharaoh. 

###### v3 
Pharaoh said to his brothers, "What is your occupation?" They said to Pharaoh, "Your servants are shepherds, both we, and our fathers." 

###### v4 
They also said to Pharaoh, "We have come to live as foreigners in the land, for there is no pasture for your servants' flocks. For the famine is severe in the land of Canaan. Now therefore, please let your servants dwell in the land of Goshen." 

###### v5 
Pharaoh spoke to Joseph, saying, "Your father and your brothers have come to you. 

###### v6 
The land of Egypt is before you. Make your father and your brothers dwell in the best of the land. Let them dwell in the land of Goshen. If you know any able men among them, then put them in charge of my livestock." 

###### v7 
Joseph brought in Jacob, his father, and set him before Pharaoh; and Jacob blessed Pharaoh. 

###### v8 
Pharaoh said to Jacob, "How old are you?" 

###### v9 
Jacob said to Pharaoh, "The years of my pilgrimage are one hundred thirty years. The days of the years of my life have been few and evil. They have not attained to the days of the years of the life of my fathers in the days of their pilgrimage." 

###### v10 
Jacob blessed Pharaoh, and went out from the presence of Pharaoh. 

###### v11 
Joseph placed his father and his brothers, and gave them a possession in the land of Egypt, in the best of the land, in the land of Rameses, as Pharaoh had commanded. 

###### v12 
Joseph provided his father, his brothers, and all of his father's household with bread, according to the sizes of their families. 

###### v13 
There was no bread in all the land; for the famine was very severe, so that the land of Egypt and the land of Canaan fainted by reason of the famine. 

###### v14 
Joseph gathered up all the money that was found in the land of Egypt, and in the land of Canaan, for the grain which they bought: and Joseph brought the money into Pharaoh's house. 

###### v15 
When the money was all spent in the land of Egypt, and in the land of Canaan, all the Egyptians came to Joseph, and said, "Give us bread, for why should we die in your presence? For our money fails." 

###### v16 
Joseph said, "Give me your livestock; and I will give you food for your livestock, if your money is gone." 

###### v17 
They brought their livestock to Joseph, and Joseph gave them bread in exchange for the horses, and for the flocks, and for the herds, and for the donkeys: and he fed them with bread in exchange for all their livestock for that year. 

###### v18 
When that year was ended, they came to him the second year, and said to him, "We will not hide from my lord how our money is all spent, and the herds of livestock are my lord's. There is nothing left in the sight of my lord, but our bodies, and our lands. 

###### v19 
Why should we die before your eyes, both we and our land? Buy us and our land for bread, and we and our land will be servants to Pharaoh. Give us seed, that we may live, and not die, and that the land won't be desolate." 

###### v20 
So Joseph bought all the land of Egypt for Pharaoh, for every man of the Egyptians sold his field, because the famine was severe on them, and the land became Pharaoh's. 

###### v21 
As for the people, he moved them to the cities from one end of the border of Egypt even to the other end of it. 

###### v22 
Only he didn't buy the land of the priests, for the priests had a portion from Pharaoh, and ate their portion which Pharaoh gave them. That is why they didn't sell their land. 

###### v23 
Then Joseph said to the people, "Behold, I have bought you and your land today for Pharaoh. Behold, here is seed for you, and you shall sow the land. 

###### v24 
It will happen at the harvests, that you shall give a fifth to Pharaoh, and four parts will be your own, for seed of the field, for your food, for them of your households, and for food for your little ones." 

###### v25 
They said, "You have saved our lives! Let us find favor in the sight of my lord, and we will be Pharaoh's servants." 

###### v26 
Joseph made it a statute concerning the land of Egypt to this day, that Pharaoh should have the fifth. Only the land of the priests alone didn't become Pharaoh's. 

###### v27 
Israel lived in the land of Egypt, in the land of Goshen; and they got themselves possessions therein, and were fruitful, and multiplied exceedingly. 

###### v28 
Jacob lived in the land of Egypt seventeen years. So the days of Jacob, the years of his life, were one hundred forty-seven years. 

###### v29 
The time came near that Israel must die, and he called his son Joseph, and said to him, "If now I have found favor in your sight, please put your hand under my thigh, and deal kindly and truly with me. Please don't bury me in Egypt, 

###### v30 
but when I sleep with my fathers, you shall carry me out of Egypt, and bury me in their burying place." Joseph said, "I will do as you have said." 

###### v31 
Israel said, "Swear to me," and he swore to him. Then Israel bowed himself on the bed's head.

***
[[Gen-46|← Genesis 46]] | [[Genesis]] | [[Gen-48|Genesis 48 →]]
