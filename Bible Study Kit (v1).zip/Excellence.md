# Excellence
We are called to do our work with an authentic love for excellence. Jesus' work was superlative. Wherever he went, he amazed people. So is God's Creation. It's not junky or patched together. It is excellent, flowing out of abundant loving generosity.

> The church's approach to an intelligent carpenter is usually confined to exhorting him to not be drunk and disorderly in his leisure hours and to come to church on Sunday. What the church should be telling him is this: that the very first demand that his religion makes upon him is that he should make good tables.
> – *Dorothy Sayers*

In this, the good thing is he only calls us to be excellent as ourselves.
![[Rom-12#v6]]