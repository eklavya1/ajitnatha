---
aliases: [Index, Home]
---
# Home 🌱
The bird's eye view of and launchpad into everything this vault contains.

## Growing ideas
* 010 - [[010 Faith MOC|Faith]]
* 020 - [[020 Interests MOC|Interests]]

## Tending the Garden
* 030 - [[030 PKM MOC|Knowledge Management]]
* 040 -  [[040 Productivity MOC|Productivity]]