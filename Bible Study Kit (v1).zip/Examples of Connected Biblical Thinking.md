# Examples of Connected Biblical Thinking

Explore the two different ways of practicing Connected Biblical Thinking at [[Start connecting Scripture]].

* [[Examples of inductive note-taking]]
	*  [[Split Thinking#All things are under Jesus' authority]]
	*  [[Creation account]]
	*  [[John]]
	*  [[God's unified story]]
	*  [[Biblical Themes and Images MOC]]

*   [[Examples of deductive note-taking]]
	*   [[Journal Note]]
	*   [[Book Note]]
	*   [[Note Example - Design]]
	*   [[Sleep]]
	*   [[000 Home|Home]]: [[010 Faith MOC|Faith MOC]], [[020 Interests MOC|Interests MOC]], [[030 PKM MOC|PKM MOC]], [[040 Productivity MOC|Productivity MOC]]