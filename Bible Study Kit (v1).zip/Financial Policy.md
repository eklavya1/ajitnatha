links: [[About me]]
# Financial Policy
> [[Ephes-02#v8]] For by **grace** you have been saved through faith; and that not of yourselves, it is the **gift of God**; 

> [[Ephes-02#v9]] **not as a result of works**, that no one should boast.

There is no charge for any of my resources. Teaching and dissemination of the Bible should be free. Anyone who wants The Bible Study Kit and my teachings should receive them free without obligation.

When gratitude for God's Word motivates a believer to give, they have the privilege of contributing to the dissemination of God's word and its teachings. They can do so [on Patreon](https://www.patreon.com/joschua).

I wish to reflect God's Grace. 