links: [[The Bible (WEB)]]
# God's unified story
An example for an overview note for the whole Bible. This would link to a lot of different Biblical events and concepts. It is way of keeping the meta-narrative in mind.

## The Story
← *from Eternity* | Trinitarian God 🔼| Creation ❇️ | The Fall 🆘 | Children of Abraham 🕎 | Jesus Christ ✝️ | Spirit & Church 🛐 | Jesus Returns ✳️ | *to Eternity* →

### Trinitarian God 🔼
→ From Eternity to Eternity, God in Trinity in his character eternal

### Creation ❇️
→ [[Creation account]]
→ Humans are called to advance the Creation project: As Image bearers spreading beauty, abundance and order all over God's Creation

### The Fall 🆘
→ The Fall: Rebelling against being Image bearers for our King and crowning ourselves as kings instead

### Children of Abraham 🕎
→ Covenant relationship: God's loving pursuit in the mess we're in

### Jesus Christ ✝️
→ Jesus, the new Adam showing us how to fulfill advancing the Creation project.

### Spirit & Church 🛐
→ Fulfilling Humans are called to advance the Creation project in partnership with the Holy Spirit

### Jesus Returns ✳️
→ New Creation
