links: [[030 PKM MOC|PKM MOC]]

# Settings, queries and plugins

## Settings
* `Appearance` > `CSS snippets`: Toggle **on** to enable [[CSS tweaks]].

## Plugins
### Core Plugins
* Enable **page preview** to hover over a link to a passage and quickly display it.

## Queries
* `path:-"Scripture"` - This will *not* include the Bible in your search. Handy if you don't your graph view to be blown up.