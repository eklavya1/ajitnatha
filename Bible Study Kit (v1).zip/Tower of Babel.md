# Tower of Babel
➡️[[Gen-11|Start reading]]
***
## Work as an idol
![[Gen-11#v2]]
This is good. Humans are starting to spread out over the earth as they were called to.

![[Gen-11#v3]]
Humans come up with a new technology.

![[Gen-11#v4]]
Hold on. Being "dispersed" is exactly what you're called to do. It is a good thing. In rebellion, they say, no, we are staying here and we are building a city.

And they are building to the *heavens* which is were God is. They are looking to this building project for a sense of meaning and purpose that only God himself can give.

And this to *make a name for ourselves*. They're looking for identity and status.