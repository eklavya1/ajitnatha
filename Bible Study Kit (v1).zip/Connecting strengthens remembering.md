links: [[Benefits of Connected Biblical Thinking]]
# Connecting strengthens remembering
Engaging with insights in a connected way, makes us more likely to remember them. Our brains think in connections. We are forced to expend the extra effort to see how this fits into everything I know.

Secondly, **this is how Scripture works**. The Biblical authors, Jesus himself, quotes, references, re-purposes other passages in Scripture. The Bible is massively interconnected and so should our engagement with it be.
***
## Next benefit
👉 [[Connecting makes you engage Scripture]]