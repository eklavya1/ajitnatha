---
aliases: [Interests MOC]
---
links: [[000 Home|Home]]
# Interests MOC
![[1 Chron-12#v32]]

* **000s - General Reference (Encyclopedias, Journalism, Articles, News)**
	* [[030 PKM MOC|PKM MOC]]- managing my personal knowledge
	* [[Glossary]]
* **100s - Philosophy & Psychology & Logic**
	* [[Sleep]]
* **200s - Spirituality & Religion**
	* [[010 Faith MOC|Faith MOC]]
* **300s - Social Sciences (People living/working in Society, Law, Gov, Corps, Groups)**
* **400s - Language**
* **500s - Natural Sciences (math, astronomy, chemistry, geology, plants, animals)**
* **600s - Tech & Applied Sciences (technology, engineering, medicine, agriculture)**
	* [[Sleep]]
* **700s - Fine Arts & Recreation (Architecture, Painting, Photos, Music, Sports, Film & TV, songs, leisure)**
* **800s - Literature (literature, classics, books)**
* **900s - History & Biography & Geography**