links: [[God's unified story#The Fall 🆘]]
# Work is broken
Whenever we uncouple our Work from God, it becomes a god. It is what we look forward to for identity and significance.

Since it is cursed and broken, work will always be a mixed bag. It will be good and satisfying but it will also be hard and rough. That is a good thing. In it's roughness it drives us to God.

The [[Tower of Babel]] narrative shows the downfalls of pursuing work without God.