# Tooltip
```css
/* Tooltips - from Obuntu theme */
.tooltip {
  background-color: var(--base2); /* PB changed from var(--text-accent) to (123, 108, 214) to blue */ 
  color: whitesmoke; /* was 46, 41, 56 */
  font-weight: normal;
  font-size: 12px;
}
.tooltip .tooltip-arrow {
  border-bottom: 5px solid var(--tooltip-bg);
}
```
