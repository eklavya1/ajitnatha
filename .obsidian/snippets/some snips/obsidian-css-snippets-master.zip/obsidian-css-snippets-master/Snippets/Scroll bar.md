# Scroll bar
```css
/* Scrollbar */
/* change width */
::-webkit-scrollbar {
  width:15px;
}

/* no rounded corners - Obsdn-dark-RMX */
::-webkit-scrollbar-thumb {
  -webkit-border-radius: 0px;
}

::-webkit-scrollbar-thumb:active {
  -webkit-border-radius: 0px;
}
```
