# Command palette
```css
/* Command palette: change font color of hotkeys */
.suggestion-item.is-selected .suggestion-hotkey{
  color: var(--base3)
}
```
